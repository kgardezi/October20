const {test}=require('node:test');const assert=require('node:assert/strict');const I=require('../js/importer-engine.js');
const names={tl:['EDEM001TL0101','EDEM001TL0102'],cl:['EDEM001CL0101','EDEM001CL0102'],as:Array.from({length:6},(_,i)=>'EDEM001AS01'+String(i+1).padStart(2,'0'))};
function network(){
 const parsed=[...names.tl,...names.cl,...names.as].map(host=>I.parseDevice(host,`${host}#show running-config\nhostname ${host}\ninterface Gi1/0/1\n description PW:\n!`));
 const R=I.analyze(parsed);R.phys=[];
 const add=(a,b,pa,pb)=>R.phys.push({a:{dev:a,if:pa},b:{dev:b,if:pb},srcs:new Set(['cdp']),extras:[],state:'up'});
 for(let i=0;i<2;i++){add(names.tl[i],names.cl[i],'Gi0/0/1','Gi1/0/1');for(let k=0;k<6;k++)add(names.cl[i],names.as[k],'Gi1/0/'+(k+2),'Gi1/0/'+(i+1));}
 add(names.tl[0],names.tl[1],'Gi0/0/10','Gi0/0/10');add(names.cl[0],names.cl[1],'Gi1/0/48','Gi1/0/48');return R;
}
test('site pairs align above a centered access stack, with unique anchors and side lanes',()=>{
 const board=I.buildBoard(network()),p=board.pages.find(p=>p.name==='L1/L2'),devs=p.shapes.filter(s=>s.type==='device'),get=n=>devs.find(s=>s.text===n);
 assert.equal(get(names.tl[0]).y,get(names.tl[1]).y);assert.equal(get(names.cl[0]).y,get(names.cl[1]).y);
 const access=names.as.map(get),cx=(get(names.cl[0]).x+get(names.cl[1]).x+290)/2;
 for(const d of access){assert.equal(d.x+d.w/2,cx);assert.ok(d.y>get(names.cl[0]).y);}
 assert.equal(new Set(access.map(s=>s.y)).size,6);
 const used=new Set();for(const c of p.shapes.filter(s=>s.type==='connector'))for(const e of [c.start,c.end]){
  assert.ok(e.anchor);const k=e.id+JSON.stringify(e.anchor);assert.ok(!used.has(k),'Each cable uses a separate anchor');used.add(k);
 }
 assert.ok(p.shapes.filter(s=>s.routing?.kind==='access').length===12);
});
test('same-site access routes and anchors persist through saved board data',()=>{
 const p=I.buildBoard(network()).pages.find(p=>p.name==='Physical link speeds');
 const round=JSON.parse(JSON.stringify(p));assert.ok(round.shapes.some(s=>s.routing?.kind==='access'));assert.ok(round.shapes.filter(s=>s.type==='connector').every(s=>s.start.anchor&&s.end.anchor));
});
test('unknown operating rates create actionable collection notes before generation',()=>{
 const A=names.tl[0],B=names.tl[1];const R=I.analyze([A,B].map((h,i)=>I.parseDevice(h,`${h}#show interfaces description\nInterface Status Protocol Description\nGi0/0/1 up up UPLINK: ${i?A:B} Gi0/0/1\n`)));
 assert.ok(R.problems.some(p=>p.speedCollection&&p.msg.includes('show interfaces')));
});
test('Nexus 9K status and detailed observations agree on Ethernet breakout ports',()=>{
 const h='EDEM001DL0101';const p=I.parseDevice(h,`${h}#show running-config\ninterface Ethernet1/49/1\n description UPLINK: ${names.cl[0]} Twe1/0/1\n!\n${h}#show interface status\nPort Name Status Vlan Duplex Speed Type\nEth1/49/1 To Campus connected routed full a-25G SFP-H25GB-SR\n${h}#show interface Ethernet1/49/1\nEthernet1/49/1 is up\nadmin state is up, Dedicated Interface\n  full-duplex, 25 Gb/s, media type is 25G\n`);const R=I.analyze([p]);const rate=I.portOperatingSpeed(R,{dev:h,if:'Eth1/49/1'});assert.equal(rate.mbps,25000);assert.equal(rate.observations.length,2);
});
test('ASR 920 Full Duplex 1000Mbps speed is read from detail, never BW alone',()=>{
 const h=names.tl[0],text=`${h}#show interfaces\nGigabitEthernet0/0/8 is up, line protocol is up\n  MTU 1500 bytes, BW 1000000 Kbit/sec\n  Full Duplex, 1000Mbps, link type is auto, media type is SX\n`;
 const R=I.analyze([I.parseDevice(h,text)]);assert.equal(I.portOperatingSpeed(R,{dev:h,if:'Gi0/0/8'}).mbps,1000);
 const no=I.analyze([I.parseDevice(h,text.replace('  Full Duplex, 1000Mbps, link type is auto, media type is SX',''))]);assert.equal(I.portOperatingSpeed(no,{dev:h,if:'Gi0/0/8'}).mbps,null);
});
