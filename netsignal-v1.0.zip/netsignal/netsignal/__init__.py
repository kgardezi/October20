"""NetSignal - Network Syslog Intelligence for Cisco (IOS / IOS-XE / NX-OS)."""
__version__ = "1.0.0"
