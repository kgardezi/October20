# NetSignal: Cisco Syslog Intelligence Dashboard

NetSignal turns the raw Cisco syslog stream from your central syslog server into answers to three questions:
**what happened, which devices are affected, and what to investigate next.**

It reads the existing `CISCO` directory (`log` plus the daily `logYYYYMMDD.gz` files) over **read-only SFTP**. Nothing is installed or changed on the syslog server.

> **Demo mode uses SIMULATED data.** On first run NetSignal generates realistic Cisco syslog modelled on
> your server's real format (hostnames, IOS-XE and NX-OS timestamp styles, observed mnemonics). The UI shows a
> **SIMULATED DATA** badge until you point it at the real server.

---

## Quick start (about 2 minutes)

```bash
# Python 3.10+ (Windows VDI or Linux)
pip install -r requirements.txt
python -m netsignal            # opens http://127.0.0.1:8088 with simulated data
```

Windows: double-click `run.bat`. Linux: `./run.sh`.

### Connect to the real syslog server

1. Copy `config.example.yaml` to `config.yaml`.
2. Set `source.mode: ssh` and fill in `source.ssh` (host, username, key or password environment variable, `directory: /log/CISCO`).
3. Make sure the server's host key is in your `known_hosts`. Connect once with `ssh user@server` or run `ssh-keyscan`. Unknown host keys are **rejected**.
4. Test it: `python -m netsignal test-connection`
5. Run it: `python -m netsignal`

Before connecting live you can also check parser coverage offline on a copied log file:

```bash
python -m netsignal analyze /path/to/log20261018.gz   # lists any message codes that need new rules
```

---

## What's on screen

| View | Purpose |
|---|---|
| **Command Center** | Situation brief in plain English, KPI tiles (noise filtered, findings, devices affected), **10 troubleshooting panels**, *Needs attention*, *What changed*, device health, activity timeline (drag to zoom), device hotspot heatmap |
| **Panel → Category view** | Findings for the category, troubleshooting playbook, category-specific intelligence (BGP/OSPF adjacency table, 802.1X→MAB outcome analysis, PoE budget), event codes, busiest interfaces, full evidence explorer |
| **Findings** | Evidence-backed conclusions. Each one says *why it was raised*, links to the original lines, shows correlations, "what changed" and recurrence, and lists next-step CLI commands |
| **Investigate** | Faceted search over every message: histogram with drag-to-zoom, filter chips, hide-routine toggle, follow-live, CSV export |
| **Event drawer** (click any row) | Plain-English explanation, verbatim evidence, parsed fields, copyable commands, same-device ±2 min, interface history, MAC history, other devices at the site |
| **Device view** | Health score, findings, interface table with last logged state, routing neighbours, codes, site peers, timeline |
| **Interface view** | Up/down state bar over time, outage totals, every message for the port |
| **Live tail** | `tail -f log`, but parsed, colour-rated, filterable and clickable, with routine lines hidden |
| **Sources & archives** | Ingestion health (lag, rate, rotations, reconnects, duplicates ignored), import any daily `.gz`, **deep search** older archives without importing them |
| **Rules & parser lab** | Every rule with hit counts, unclassified codes to write rules for, and a paste-a-line tester |

### Global search (press `/`)

The search box takes plain entities or simple questions:

| Typed | Result |
|---|---|
| `unyc787as0705` | Device view |
| `unyc787as0705 Te1/1/1` | Interface history |
| `845c.315d.dfcf`, `845C-315D-DFCF`, `10.255.1.2`, `%LINK-3-UPDOWN`, `bsao190` | Investigation filtered by MAC / IP / code / site |
| `interfaces that flapped 3 times today` | Flap findings, threshold 3, today |
| `bgp down`, `ospf issues` | Routing adjacency findings |
| `what changed last 2h`, `config changes by jsmith` | Configuration changes |
| `auth failures on cmon200as1101` | Auth failures on that switch |
| `critical issues`, `mac moves`, `noisiest devices` | The matching findings or rankings |
| `host:x code:y iface:z sev:<=3 since:2h` | Explicit filters |

---

## Intelligence: how false alarms are avoided

| Detector | Rule (thresholds configurable in `config.yaml → intel`) |
|---|---|
| **Link flapping** | Needs **≥3 complete down→up cycles** on a non-access port. One down+up is recorded as a *bounce* (low). A down with no later up is *link down, no recovery seen*. Access ports need ≥5 cycles and are grouped per switch. |
| **Far-end inference** | If another device's interface goes down within 2 s on ≥60% of the occasions, it is shown as the *probable* far end. This is labelled as inferred from timing. |
| **Routing adjacency** | OSPF/BGP/EIGRP/IS-IS: down with no recovery, unstable (≥2 downs), or reset+recovered. A transport-interface loss in the preceding seconds (or within the BGP hold time) is reported as a **timing fact**. |
| **802.1X / MAB** | `DOT1X FAIL (No Response)` followed by success for the **same MAC within 120 s** is the expected fallback and is *excluded*. Only endpoints with ≥5 unresolved failures are raised. RADIUS dead/alive is tracked with the failures that happened during the outage. |
| **PoE** | Repeated detect→remove cycles or controller (Tstart) errors on one port point to a boot-looping PD. |
| **MAC moves** | ≥3 moves of one MAC. *Major* only at ≥20 moves in 5 min, or ≥10 across several switches. VMware/Hyper-V OUIs are noted (one vMotion is normal; a storm is not). |
| **Site-wide events** | ≥3 devices at one site losing infrastructure links within 60 s. Coincident PSU/ISDN events are attached as context, not as a cause. |
| **Clock / NTP** | Median device-timestamp vs server-receive offset ≥10 s, or `*`/`.` unsynchronised markers. |
| **What changed** | Configuration changes on the same device in the 30 min before an incident are attached. |
| **Recurring** | Similar warning-or-higher messages for the same interface or device on earlier days. |
| **New behaviour** | A message code not seen in the baseline period (requires enough history). Messages already explained by another finding are suppressed. |
| **Unusual volume** | A device's warning-or-higher rate is ≥5× its own baseline. |

What NetSignal will **not** do: estimate CRC rates, utilisation or optical levels it hasn't been given, or claim a root cause.
Where syslog can't answer, the UI says so (e.g. *Error counters: not in syslog – run `show interface … counters errors`*).

Every finding keeps the original syslog lines as evidence. Cisco's own severity is preserved alongside NetSignal's rating (`routine / info / warning / major / critical`).

---

## Architecture

```
 Primary syslog server (untouched)           NetSignal (Windows VDI or secondary Linux)
 /log/CISCO/log            ── SFTP read ──▶  LiveTailer   offset + fingerprint, rotation catch-up,
 /log/CISCO/logYYYYMMDD.gz ── SFTP read ──▶  ArchiveLoader   reconnect with back-off
                                                  │  parse (IOS / IOS-XE / NX-OS) → classify (YAML rules)
                                                  ▼
                                             SQLite (WAL + FTS5)   de-dup by line hash, N-day retention
                                                  │
                                    Intel engine (detectors, correlation, health)
                                                  │
                                    FastAPI  ── REST + Server-Sent Events ──▶ Browser UI (no build step)
```

* **Read-only by design.** Only the SFTP subsystem is used and files are only opened for reading. No remote commands are run, so the account can be restricted to read-only SFTP.
* **Rotation-safe.** Each read is tracked by byte offset plus a fingerprint of the file's first bytes. When `log` shrinks or changes identity, the unread tail of the old file is recovered from the new archive by skipping the bytes already read.
* **Disconnection-safe.** Reconnects with exponential back-off (1 s → 60 s) and resumes from the saved offset (persisted across restarts).
* **Duplicate-safe.** Each line is keyed by a hash of its raw text, so overlapping reads (live vs archive, retries) are ignored.
* **Two clocks.** Device timestamps (ms/µs precision) and server receive times are both kept. Their difference powers NTP drift detection.
* **Timezone-safe.** Times are shown exactly as they appear in `tail -f log`, whatever timezone the VDI uses.
* **Offline-friendly UI.** Plain HTML/CSS/JS with hand-built SVG charts: no CDN, no npm, works behind strict proxies.

### Deployment: recommendation

| | Option A: Windows VDI | Option B: secondary Linux server **(recommended for production)** |
|---|---|---|
| Ingestion | Only while the VDI session runs, so history has gaps | 24×7 (systemd), complete history and baselines |
| Users | One engineer | Whole team via browser (`server.host: 0.0.0.0`) |
| Load on primary | One SFTP session per engineer | One SFTP session in total |
| Setup | `pip install`, `run.bat` | `pip install`, `deploy/netsignal.service` |

Both run the **same code**. Start with Option A as a pilot, then move to Option B so the whole team shares one index.
Option B can also read a local copy (`source.mode: local`) if you already rsync or NFS-mount the directory.

For Option B, put it behind your standard reverse proxy and SSO if exposing it beyond localhost. v1 has no built-in authentication.

---

## Project structure

```
netsignal/
├── run.bat / run.sh                  launchers
├── config.example.yaml               every setting, documented (copy to config.yaml)
├── requirements.txt                  fastapi, uvicorn, PyYAML, paramiko (+ tzdata on Windows)
├── netsignal/
│   ├── __main__.py                   CLI: run | test-connection | analyze | generate-sample
│   ├── api.py                        REST API, SSE live stream, static UI
│   ├── parsers/cisco.py              IOS / IOS-XE / NX-OS line parser (vendor registry in parsers/__init__.py)
│   ├── classifier.py                 vendor-neutral YAML rules engine + plain-English explanations
│   ├── rules/categories.yaml         dashboard panels + playbooks (edit freely)
│   ├── rules/cisco_rules.yaml        ~70 classification rules (edit freely)
│   ├── netmodel.py                   interface normalisation, hostname/site decoding, OUI hints
│   ├── store.py                      SQLite schema, FTS5 search, filter builder
│   ├── ingest/access.py              LocalAccess / SFTPAccess (read-only)
│   ├── ingest/manager.py             live tailer, archive loader, rotation catch-up, deep search
│   ├── intel/findings.py             detectors, correlation, health scoring
│   ├── intel/search.py               smart search interpreter
│   └── simulate.py                   SIMULATED data generator + live writer (demo mode)
├── web/                              index.html, css/app.css, js/ (app, charts, components, views/*)
├── tests/test_netsignal.py           parser, de-dup, rotation, false-alarm guards, search
├── sample_data/examples/             real-format lines transcribed from the server screenshots
├── deploy/netsignal.service          systemd unit for Option B
└── docs/DESIGN.md                    research notes, design decisions, roadmap
```

Run the tests: `python -m unittest discover -s tests`

## Customising

* **Panels and categories**: `netsignal/rules/categories.yaml`
* **Classification and explanations**: `netsignal/rules/cisco_rules.yaml`, then *Rules → Reload rules*. Use *Parser lab* to test.
* **Hostname convention** (site and role decoding, which roles have end-user access ports): `config.yaml → hostnames`.
  The default pattern is **inferred** from your hostnames (e.g. `unyc787as0705` → site `unyc787`, role `as`), so please verify the role codes.
* **Thresholds**: `config.yaml → intel`
* **Other vendors**: add `parsers/<vendor>.py` and `rules/<vendor>_rules.yaml`, then register the parser (see `parsers/__init__.py`).
