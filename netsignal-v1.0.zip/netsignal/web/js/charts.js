// Lightweight SVG charts (no external libraries - works offline on locked-down VDIs).
import { esc, fmtTs, axisLabel, n, fmtShort } from './util.js';

const tipEl = () => document.getElementById('tip');
export function showTip(html, x, y) {
  const t = tipEl();
  t.innerHTML = html;
  t.classList.add('on');
  const w = t.offsetWidth, h = t.offsetHeight;
  let left = x + 14, top = y + 14;
  if (left + w > window.innerWidth - 8) left = x - w - 14;
  if (top + h > window.innerHeight - 8) top = y - h - 14;
  t.style.left = left + 'px';
  t.style.top = top + 'px';
}
export function hideTip() { tipEl().classList.remove('on'); }

export const SIG_COLORS = {
  critical: 'var(--s-critical)', major: 'var(--s-major)', warning: 'var(--s-warning)',
  info: 'var(--s-info)', routine: 'var(--s-routine)',
};
export const SIG_LABEL = { critical: 'Critical', major: 'Major', warning: 'Warning', info: 'Info', routine: 'Routine' };

// ---------------------------------------------------------------- sparkline
export function sparkline(values, { w = 160, h = 34, color = 'var(--accent)' } = {}) {
  const max = Math.max(1, ...values);
  const step = w / Math.max(1, values.length - 1);
  const pts = values.map((v, i) => [i * step, h - 2 - (v / max) * (h - 6)]);
  const line = pts.map((p, i) => `${i ? 'L' : 'M'}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join('');
  const area = `${line}L${w},${h}L0,${h}Z`;
  const any = values.some(v => v > 0);
  return `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" style="width:100%;height:${h}px;display:block">
    <path d="${area}" style="fill:${color};opacity:${any ? .12 : 0}"/>
    <path d="${line}" style="fill:none;stroke:${any ? color : 'var(--grid)'};stroke-width:1.6" vector-effect="non-scaling-stroke"/></svg>`;
}

// ---------------------------------------------------------------- stacked timeline
// hist = {t0, step, n, series:{signal:[counts]}}
export function timeline(el, hist, { signals = ['critical', 'major', 'warning', 'info'], height = 170, onSelect, now } = {}) {
  const W = Math.max(300, el.clientWidth || 800), H = height;
  const pad = { l: 40, r: 8, t: 8, b: 22 };
  const iw = W - pad.l - pad.r, ih = H - pad.t - pad.b;
  const nb = hist.n;
  const totals = Array.from({ length: nb }, (_, i) => signals.reduce((a, s) => a + (hist.series[s]?.[i] || 0), 0));
  const max = Math.max(1, ...totals);
  const nice = niceMax(max);
  const bw = iw / nb;
  const gap = bw > 6 ? 2 : (bw > 3 ? 1 : 0);
  let bars = '';
  for (let i = 0; i < nb; i++) {
    let y = pad.t + ih;
    const order = [...signals].reverse(); // stack bottom-up: lowest significance at the bottom
    for (const s of order) {
      const v = hist.series[s]?.[i] || 0;
      if (!v) continue;
      const hh = (v / nice) * ih;
      y -= hh;
      bars += `<rect x="${(pad.l + i * bw + gap / 2).toFixed(1)}" y="${y.toFixed(1)}" width="${Math.max(1, bw - gap).toFixed(1)}" height="${Math.max(0.5, hh - (hh > 3 ? 1 : 0)).toFixed(1)}" rx="${bw > 8 ? 2 : 0}" style="fill:${SIG_COLORS[s]}"/>`;
    }
  }
  let grid = '';
  for (let k = 0; k <= 3; k++) {
    const v = nice * k / 3, y = pad.t + ih - (v / nice) * ih;
    grid += `<line class="gridl" x1="${pad.l}" x2="${W - pad.r}" y1="${y}" y2="${y}"/><text x="${pad.l - 6}" y="${y + 3}" text-anchor="end">${compactN(v)}</text>`;
  }
  const span = hist.step * nb;
  const ticks = Math.min(8, Math.floor(iw / 90));
  let xl = '';
  for (let k = 0; k <= ticks; k++) {
    const t = hist.t0 + span * k / ticks;
    const x = pad.l + iw * k / ticks;
    xl += `<text x="${x}" y="${H - 6}" text-anchor="${k === 0 ? 'start' : k === ticks ? 'end' : 'middle'}">${axisLabel(t, span)}</text>`;
  }
  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" height="${H}">${grid}
    <line class="axis" x1="${pad.l}" x2="${W - pad.r}" y1="${pad.t + ih}" y2="${pad.t + ih}"/>${bars}${xl}
    <rect class="brush" x="0" y="${pad.t}" width="0" height="${ih}" style="fill:var(--accent);opacity:.15"/>
    <rect class="hit" x="${pad.l}" y="${pad.t}" width="${iw}" height="${ih}" style="fill:transparent;cursor:crosshair"/></svg>`;
  const svg = el.querySelector('svg'), hit = svg.querySelector('.hit'), brush = svg.querySelector('.brush');
  const idxAt = ev => {
    const r = svg.getBoundingClientRect();
    const x = (ev.clientX - r.left) * (W / r.width) - pad.l;
    return Math.max(0, Math.min(nb - 1, Math.floor(x / bw)));
  };
  let drag = null;
  hit.addEventListener('mousemove', ev => {
    const i = idxAt(ev);
    if (drag !== null) {
      const a = Math.min(drag, i), b = Math.max(drag, i);
      brush.setAttribute('x', pad.l + a * bw); brush.setAttribute('width', (b - a + 1) * bw);
    }
    const t = hist.t0 + i * hist.step;
    const rows = signals.map(s => `<div class="row"><span><i style="background:${SIG_COLORS[s]}"></i>${SIG_LABEL[s]}</span><b class="num">${n(hist.series[s]?.[i] || 0)}</b></div>`).join('');
    showTip(`<div class="tt">${fmtShort(t, now)} – ${fmtShort(t + hist.step, now)}</div>${rows}${onSelect ? '<div class="muted" style="margin-top:4px">click or drag to zoom</div>' : ''}`, ev.clientX, ev.clientY);
  });
  hit.addEventListener('mouseleave', () => { hideTip(); });
  if (onSelect) {
    hit.addEventListener('mousedown', ev => { drag = idxAt(ev); ev.preventDefault(); });
    window.addEventListener('mouseup', function up(ev) {
      window.removeEventListener('mouseup', up);
      if (drag === null) return;
      const i = idxAt(ev), a = Math.min(drag, i), b = Math.max(drag, i);
      drag = null; hideTip();
      onSelect(hist.t0 + a * hist.step, hist.t0 + (b + 1) * hist.step);
    });
  }
}

function niceMax(v) {
  const p = Math.pow(10, Math.floor(Math.log10(v)));
  for (const m of [1, 1.5, 2, 3, 5, 7.5, 10]) if (m * p >= v) return m * p;
  return 10 * p;
}
function compactN(v) { return v >= 1000 ? (v / 1000).toFixed(v >= 10000 ? 0 : 1) + 'k' : String(Math.round(v)); }

export function legend(signals) {
  return `<div class="legend">${signals.map(s => `<span><i style="background:${SIG_COLORS[s]}"></i>${SIG_LABEL[s]}</span>`).join('')}</div>`;
}

// ---------------------------------------------------------------- heatmap
// sequential single-hue ramp (blue), light->dark by magnitude
export function heatmap(el, hm, { onCell, onHost, now, healthColor } = {}) {
  const cols = hm.matrix[0]?.length || 0;
  const max = Math.max(1, ...hm.matrix.flat());
  const span = hm.step * cols;
  let html = `<div class="heat" style="grid-template-columns: 190px repeat(${cols}, minmax(0,1fr))">`;
  hm.hosts.forEach((h, r) => {
    const sc = hm.health?.[h];
    html += `<div class="hn" data-host="${esc(h)}">${sc != null ? `<span class="hscore" style="background:color-mix(in srgb, ${healthColor(sc)} 20%, transparent);color:${healthColor(sc)}">${sc}</span>` : ''}${esc(h)}</div>`;
    hm.matrix[r].forEach((v, c) => {
      const a = v ? 0.18 + 0.82 * Math.sqrt(v / max) : 0;
      html += `<div class="cell" data-r="${r}" data-c="${c}" style="${v ? `background:color-mix(in srgb, var(--s-info) ${Math.round(a * 100)}%, var(--surface-2))` : ''}"></div>`;
    });
  });
  html += `<div></div>`;
  const step = Math.max(1, Math.round(cols / 6));
  for (let c = 0; c < cols; c++) {
    html += `<div class="muted" style="font-size:10px;white-space:nowrap;overflow:visible">${c % step === 0 ? axisLabel(hm.t0 + c * hm.step, span) : ''}</div>`;
  }
  html += '</div>';
  el.innerHTML = html;
  el.querySelectorAll('.cell').forEach(c => {
    const r = +c.dataset.r, k = +c.dataset.c, v = hm.matrix[r][k], t = hm.t0 + k * hm.step;
    c.addEventListener('mousemove', ev => showTip(`<div class="tt">${esc(hm.hosts[r])}</div>${fmtShort(t, now)} – ${fmtShort(t + hm.step, now)}<div class="row"><span>Warning+ messages</span><b>${n(v)}</b></div>`, ev.clientX, ev.clientY));
    c.addEventListener('mouseleave', hideTip);
    c.addEventListener('click', () => { hideTip(); onCell && onCell(hm.hosts[r], t, t + hm.step); });
  });
  el.querySelectorAll('.hn').forEach(h => h.addEventListener('click', () => onHost && onHost(h.dataset.host)));
}

// ---------------------------------------------------------------- interface state bar
export function stateBar(el, segs, t0, t1) {
  const span = t1 - t0;
  el.innerHTML = `<div class="statebar">${segs.map(s => {
    const w = Math.max(0, (Math.min(s.t1, t1) - Math.max(s.t0, t0)) / span * 100);
    return `<div class="${esc(s.state)}" style="width:${w}%" data-tip="${esc(s.state)}: ${fmtTs(s.t0)} → ${fmtTs(s.t1)}"></div>`;
  }).join('')}</div>
  <div style="display:flex;justify-content:space-between" class="muted mono"><span>${fmtTs(t0)}</span><span>${fmtTs(t1)}</span></div>`;
  el.querySelectorAll('[data-tip]').forEach(d => {
    d.addEventListener('mousemove', ev => showTip(esc(d.dataset.tip), ev.clientX, ev.clientY));
    d.addEventListener('mouseleave', hideTip);
  });
}

// ---------------------------------------------------------------- evidence swimlanes
// rows grouped by "host interface", dots coloured by state/signal
export function swimlanes(el, events, { t0, t1, onClick, now } = {}) {
  const lanes = [];
  const idx = {};
  for (const e of events) {
    const key = e.host + (e.interface ? ' ' + shortIfLocal(e.interface) : '');
    if (!(key in idx)) { idx[key] = lanes.length; lanes.push(key); }
  }
  const W = Math.max(300, el.clientWidth || 800), rowH = 24, padL = 210, padR = 12;
  const H = lanes.length * rowH + 24;
  const a = t0 ?? Math.min(...events.map(e => e.ts)), b = t1 ?? Math.max(...events.map(e => e.ts));
  const span = Math.max(1, b - a);
  const x = t => padL + (t - a) / span * (W - padL - padR);
  let s = '';
  lanes.forEach((l, i) => {
    const y = i * rowH + rowH / 2;
    s += `<text x="${padL - 10}" y="${y + 4}" text-anchor="end" style="fill:var(--text-2);font-size:11.5px">${esc(l)}</text>
      <line class="gridl" x1="${padL}" x2="${W - padR}" y1="${y}" y2="${y}"/>`;
  });
  events.forEach((e, k) => {
    const key = e.host + (e.interface ? ' ' + shortIfLocal(e.interface) : '');
    const y = idx[key] * rowH + rowH / 2;
    const col = e.state === 'down' ? 'var(--s-critical)' : e.state === 'up' ? 'var(--s-good)' : SIG_COLORS[e.signal] || 'var(--s-info)';
    s += `<circle data-k="${k}" cx="${x(e.ts).toFixed(1)}" cy="${y}" r="5" style="fill:${col};stroke:var(--surface);stroke-width:2;cursor:pointer"/>`;
  });
  const ticks = Math.min(6, Math.floor((W - padL) / 110));
  for (let k = 0; k <= ticks; k++) {
    const t = a + span * k / ticks;
    s += `<text x="${x(t)}" y="${H - 4}" text-anchor="${k === 0 ? 'start' : k === ticks ? 'end' : 'middle'}">${fmtShort(t, now)}</text>`;
  }
  el.innerHTML = `<svg viewBox="0 0 ${W} ${H}" height="${H}">${s}</svg>`;
  el.querySelectorAll('circle').forEach(c => {
    const e = events[+c.dataset.k];
    c.addEventListener('mousemove', ev => showTip(`<div class="tt">${fmtTs(e.ts, true)}</div><div class="mono" style="max-width:420px">${esc(e.host)}: %${esc(e.code)}: ${esc(e.message)}</div>`, ev.clientX, ev.clientY));
    c.addEventListener('mouseleave', hideTip);
    c.addEventListener('click', () => { hideTip(); onClick && onClick(e); });
  });
}
function shortIfLocal(i) {
  return i.replace('TenGigabitEthernet', 'Te').replace('GigabitEthernet', 'Gi').replace('Port-channel', 'Po').replace('Ethernet', 'Eth');
}

// ---------------------------------------------------------------- horizontal bars
export function hbars(items, { color = 'var(--s-info)', label = x => x.label, value = x => x.value, onClick } = {}) {
  const max = Math.max(1, ...items.map(value));
  return `<div style="display:flex;flex-direction:column;gap:6px">${items.map((it, i) => `
    <div class="${onClick ? 'chip-row' : ''}" data-i="${i}" style="display:grid;grid-template-columns:minmax(0,1fr) 54px;gap:10px;align-items:center;${onClick ? 'cursor:pointer' : ''}">
      <div><div style="font-size:12.5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${label(it)}</div>
      <div style="height:6px;border-radius:3px;background:var(--surface-2);margin-top:3px"><div style="height:100%;width:${(value(it) / max * 100).toFixed(1)}%;background:${color};border-radius:3px"></div></div></div>
      <div class="num" style="text-align:right;font-size:12.5px">${n(value(it))}</div></div>`).join('')}</div>`;
}
