"""Validate the packaged folder and standalone editions with networking disabled."""
import os
import pathlib
import shutil
import sys
from playwright.sync_api import sync_playwright

release=pathlib.Path(sys.argv[1]).resolve() if len(sys.argv)>1 else pathlib.Path(__file__).resolve().parents[2]/'releases'/'IdeaBoard-v3.9.1'
with sync_playwright() as pw:
    browser=pw.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    file_policy_reported=False
    for edition in ['private','public']:
        folder=release/f'IdeaBoard-v3.9.1-{edition}'
        for entry in [folder/'index.html',release/f'IdeaBoard-v3.9.1-{edition}.html']:
            context=browser.new_context(offline=True)
            if edition=='public':
                context.add_init_script("try{localStorage.setItem('ideaboard:import:sites:v1','PRIVATE SENTINEL');localStorage.setItem('ideaboard:import:peers:v1','192.0.2.1 = PRIVATE-SENTINEL');}catch(e){}")
            page=context.new_page();errors=[];external=[]
            page.on('pageerror',lambda e:errors.append(str(e)))
            page.on('request',lambda r:external.append(r.url) if r.url.startswith(('http://','https://')) else None)
            try:
                page.goto(entry.as_uri())
                mode='file://'
            except Exception as error:
                if 'ERR_BLOCKED_BY_ADMINISTRATOR' not in str(error):raise
                if not file_policy_reported:
                    print('SKIP: direct file:// opening is blocked by managed Chromium policy; using local offline routing for bundle validation.',flush=True)
                    file_policy_reported=True
                # No DNS or HTTP connection: all requests are fulfilled from the package.
                origin='http://ideaboard.test/'
                def local_asset(route):
                    suffix=route.request.url.removeprefix(origin).split('?')[0]
                    if suffix=='api/health':
                        route.fulfill(status=200,content_type='application/json',body='{"app":"static"}');return
                    target=entry if suffix=='index.html' else folder/suffix
                    if not target.is_file():route.fulfill(status=404,body='Not found');return
                    mime={'.html':'text/html','.js':'text/javascript','.css':'text/css'}.get(target.suffix,'application/octet-stream')
                    route.fulfill(status=200,content_type=mime,body=target.read_bytes())
                context.route(origin+'**',local_asset)
                page.goto(origin+'index.html')
                mode='local offline routing'
            page.wait_for_function('window.IdeaImport && window.IdeaImportUI && window.ideaBoard && window.IdeaVisio')
            page.locator('#menuBtn').click();page.locator('[data-menu="cfgimport"]').click()
            if edition=='public':
                assert page.locator('#niSites').input_value()==''
                assert page.locator('#niPeers').input_value()==''
            page.locator('#niPaste').fill('EDEM001CL0101#show running-config\ninterface Gi1/0/1\n description UPLINK: EDEM001TL0101 Gi1/0/1\n!')
            page.locator('[data-act="paste"]').click()
            page.wait_for_function("document.querySelectorAll('#cfgImport .ni-name').length===1")
            page.locator('[data-act="draw"]').click()
            page.wait_for_function("document.querySelector('#boardName').value.startsWith('DEM network')")
            if edition=='public':assert page.evaluate("Object.keys(localStorage).some(k=>k.startsWith('ideaboard-public:b:'))")
            page.locator('#fileInput').set_input_files(folder/'Whole-network-demo.ideaboard.json')
            page.wait_for_function("document.querySelector('#boardName').value.startsWith('Synthetic network')")
            assert page.evaluate('ideaBoard.pages.length')==10
            assert not errors,errors
            assert not [url for url in external if not url.startswith('http://ideaboard.test/')],external
            print(f'PASS: {edition} {entry.name}; {mode}; offline import/demo; no external connections or JS errors',flush=True)
            context.close()
    browser.close()
