"""Network domain knowledge: interface names, hostname decoding, MAC/OUI helpers."""
from __future__ import annotations

import re
from functools import lru_cache

# Order matters: longer prefixes first.
_IF_PREFIXES = [
    ("twentyfivegige", "TwentyFiveGigE"), ("twe", "TwentyFiveGigE"),
    ("twogigabitethernet", "TwoGigabitEthernet"), ("tw", "TwoGigabitEthernet"),
    ("fivegigabitethernet", "FiveGigabitEthernet"), ("fi", "FiveGigabitEthernet"),
    ("tengigabitethernet", "TenGigabitEthernet"), ("tengige", "TenGigabitEthernet"), ("te", "TenGigabitEthernet"),
    ("fortygigabitethernet", "FortyGigabitEthernet"), ("fo", "FortyGigabitEthernet"),
    ("hundredgige", "HundredGigE"), ("hu", "HundredGigE"),
    ("gigabitethernet", "GigabitEthernet"), ("gi", "GigabitEthernet"), ("ge", "GigabitEthernet"),
    ("fastethernet", "FastEthernet"), ("fa", "FastEthernet"),
    ("appgigabitethernet", "AppGigabitEthernet"), ("ap", "AppGigabitEthernet"),
    ("ethernet", "Ethernet"), ("eth", "Ethernet"), ("et", "Ethernet"),
    ("port-channel", "Port-channel"), ("portchannel", "Port-channel"), ("po", "Port-channel"),
    ("vlan", "Vlan"), ("vl", "Vlan"),
    ("serial", "Serial"), ("se", "Serial"),
    ("loopback", "Loopback"), ("lo", "Loopback"),
    ("tunnel", "Tunnel"), ("tu", "Tunnel"),
    ("multilink", "Multilink"), ("mu", "Multilink"),
    ("mgmt", "mgmt"), ("bdi", "BDI"), ("dialer", "Dialer"), ("nve", "nve"),
]

_SHORT = {
    "TwentyFiveGigE": "Twe", "TwoGigabitEthernet": "Tw", "FiveGigabitEthernet": "Fi",
    "TenGigabitEthernet": "Te", "FortyGigabitEthernet": "Fo", "HundredGigE": "Hu",
    "GigabitEthernet": "Gi", "FastEthernet": "Fa", "AppGigabitEthernet": "Ap",
    "Ethernet": "Eth", "Port-channel": "Po", "Vlan": "Vl", "Serial": "Se",
    "Loopback": "Lo", "Tunnel": "Tu", "Multilink": "Mu",
}

IF_TOKEN_RE = re.compile(
    r"\b(?:TwentyFiveGigE|Twe|TwoGigabitEthernet|Tw|FiveGigabitEthernet|TenGigabitEthernet|Te|"
    r"FortyGigabitEthernet|Fo|HundredGigE|Hu|GigabitEthernet|Gi|FastEthernet|Fa|Ethernet|Eth|"
    r"Port-channel|port-channel|Po|Vlan|Serial|Se|Loopback|Tunnel|mgmt)\s?\d+(?:/\d+)*(?::\d+)?(?:\.\d+)?\b",
    re.I)


@lru_cache(maxsize=65536)
def normalize_interface(name: str | None) -> str | None:
    if not name:
        return None
    s = name.strip().rstrip(",.:;")
    m = re.match(r"^([A-Za-z-]+)\s*([\d/.:]+.*)$", s)
    if not m:
        return s
    prefix, rest = m.group(1).lower(), m.group(2)
    for p, full in _IF_PREFIXES:
        if prefix == p:
            return full + rest
    return s


def short_interface(name: str | None) -> str | None:
    if not name:
        return name
    for full, short in _SHORT.items():
        if name.startswith(full):
            return short + name[len(full):]
    return name


class NetModel:
    def __init__(self, cfg: dict):
        h = cfg.get("hostnames", {})
        self.host_re = re.compile(h.get("pattern") or r"^$")
        self.site_tpl = h.get("site_template", "{country}{city}{siteno}")
        self.roles = h.get("roles", {}) or {}
        self.access_roles = set(h.get("access_roles", []) or [])
        i = cfg.get("interfaces", {})
        self.edge_re = re.compile(i.get("edge_regex") or r"^$")
        self.uplink_re = re.compile(i.get("uplink_regex") or r"^$")

    @lru_cache(maxsize=8192)
    def decode_host(self, host: str) -> dict:
        short = host.split(".")[0].lower()
        m = self.host_re.match(short)
        if not m:
            return {"site": None, "role": None, "role_name": None, "country": None}
        g = m.groupdict()
        try:
            site = self.site_tpl.format(**g)
        except KeyError:
            site = None
        role = g.get("role")
        return {"site": site, "role": role, "role_name": self.roles.get(role, None),
                "country": g.get("country")}

    def iface_class(self, iface: str | None, role: str | None) -> str | None:
        """edge | uplink | portchannel | svi | wan | mgmt | infra"""
        if not iface:
            return None
        if iface.startswith("Port-channel") or iface.lower().startswith("port-channel"):
            return "portchannel"
        if iface.startswith("Vlan"):
            return "svi"
        if iface.startswith(("Serial", "Multilink", "Dialer", "Tunnel", "Cellular", "BDI", "T1 ", "E1 ")):
            return "wan"
        if iface.startswith(("Loopback", "mgmt", "Null")):
            return "mgmt"
        if role in self.access_roles:
            if self.uplink_re.search(iface):
                return "uplink"
            if self.edge_re.match(iface):
                return "edge"
            return "uplink"
        return "infra"


# Organisationally Unique Identifiers used for context only (not exhaustive).
# Only well-known virtualisation prefixes are included by default - extend with your own.
OUI = {
    "005056": "VMware", "000c29": "VMware", "000569": "VMware", "001c14": "VMware",
    "00155d": "Microsoft Hyper-V", "525400": "QEMU/KVM", "00163e": "Xen",
}
VIRTUAL_VENDORS = {"VMware", "Microsoft Hyper-V", "QEMU/KVM", "Xen"}


def normalize_mac(mac: str | None) -> str | None:
    if not mac:
        return None
    hexs = re.sub(r"[^0-9a-fA-F]", "", mac).lower()
    if len(hexs) != 12:
        return None
    return f"{hexs[0:4]}.{hexs[4:8]}.{hexs[8:12]}"


def mac_vendor(mac: str | None) -> str | None:
    m = normalize_mac(mac)
    if not m:
        return None
    return OUI.get(m.replace(".", "")[:6])
