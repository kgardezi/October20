"""Configuration loading with defaults (config.yaml overrides config.example.yaml)."""
from __future__ import annotations

import copy
import os
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent
RULES_DIR = Path(__file__).resolve().parent / "rules"


def _merge(base: dict, override: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (override or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(path: str | None = None) -> dict:
    defaults = yaml.safe_load((ROOT / "config.example.yaml").read_text(encoding="utf-8")) or {}
    candidate = Path(path) if path else ROOT / "config.yaml"
    user = {}
    if candidate.exists():
        user = yaml.safe_load(candidate.read_text(encoding="utf-8")) or {}
    cfg = _merge(defaults, user)
    cfg["_config_file"] = str(candidate) if candidate.exists() else "(defaults)"
    # resolve relative paths against project root
    for keypath in (("database", "path"), ("source", "local", "directory"), ("source", "demo", "directory")):
        node = cfg
        for k in keypath[:-1]:
            node = node[k]
        p = Path(os.path.expanduser(node[keypath[-1]]))
        node[keypath[-1]] = str(p if p.is_absolute() else ROOT / p)
    return cfg
