// All findings with filtering.
import { esc, icon, api, qs, n, loading } from '../util.js';
import { state, go } from '../state.js';
import { rangeSeg, bindRange, findingList, bindFindings, typeLabel } from '../components.js';

export async function render(main, { params }) {
  const interp = state.lastSearch;
  state.lastSearch = null;
  const p = { ...params };
  main.innerHTML = `<div class="page">${loading('Running detectors')}</div>`;
  const range = p.range || state.range;
  const r = await api('/api/findings?' + qs({ ...p, range }));
  const all = r.findings, now = state.now();
  let sevF = p.severity || '', typeF = '', statusF = '';

  function draw() {
    const SEV = ['critical', 'major', 'warning', 'low', 'info'];
    const rank = s => SEV.length - SEV.indexOf(s);
    const list = all.filter(f => (!sevF || rank(f.severity) >= rank(sevF)) && (!typeF || f.type === typeF) && (!statusF || f.status === statusF));
    const types = [...new Set(all.map(f => f.type))];
    const counts = Object.fromEntries(SEV.map(s => [s, all.filter(f => f.severity === s).length]));
    main.innerHTML = `<div class="page">
      <div class="ph"><div><h1>Findings</h1><div class="sub">Evidence-backed conclusions from the detection engine. Each finding states <i>why</i> it was raised and links to the original syslog lines.</div></div>
        <div class="grow"></div>${p.range ? `<span class="chip">range ${esc(p.range)}</span>` : rangeSeg()}</div>
      ${interp ? `<div class="interp">${icon('search', 'sm')} Interpreted <b>“${esc(interp.query)}”</b> as: ${esc(interp.explain.join(' · '))}</div>` : ''}
      ${Object.keys(params).filter(k => k !== 'range').length ? `<div style="margin-bottom:12px;display:flex;gap:8px;flex-wrap:wrap">${Object.entries(params).filter(([k]) => k !== 'range').map(([k, v]) => `<span class="chip filter">${esc(k)}: <b>${esc(v)}</b></span>`).join('')}<a class="btn sm" href="#/findings">Clear</a></div>` : ''}
      <div class="card"><div class="filterbar">
        <div class="seg" id="sev"><button data-v="" class="${!sevF ? 'on' : ''}">All ${all.length}</button>${['critical', 'major', 'warning'].map(s => `<button data-v="${s}" class="${sevF === s ? 'on' : ''}">${s}${s !== 'critical' ? '+' : ''} ${counts[s] ? `<b>${counts[s]}</b>` : ''}</button>`).join('')}</div>
        <select class="inp" id="type" style="width:auto"><option value="">All types</option>${types.map(t => `<option value="${esc(t)}" ${t === typeF ? 'selected' : ''}>${esc(typeLabel(t))} (${all.filter(f => f.type === t).length})</option>`).join('')}</select>
        <select class="inp" id="status" style="width:auto"><option value="">Any status</option><option value="active" ${statusF === 'active' ? 'selected' : ''}>Active</option><option value="recovered" ${statusF === 'recovered' ? 'selected' : ''}>Recovered</option></select>
        <span style="flex:1"></span><span class="muted">${n(list.length)} shown</span></div>
        <div style="padding:4px 0" id="fl">${findingList(list, now, 'No findings match - the network looks quiet for this filter')}</div></div>
      <p class="note" style="margin-top:12px">${icon('info', 'sm')} Thresholds (flap cycles, auth failures, MAC moves, clock skew…) are configurable in <span class="mono">config.yaml → intel</span>.
        Single events never become “flapping”; correlations are reported as timing facts, not root causes.</p></div>`;
    bindRange(main, () => go(location.hash));
    bindFindings(main.querySelector('#fl'));
    main.querySelectorAll('#sev button').forEach(b => b.onclick = () => { sevF = b.dataset.v; draw(); });
    main.querySelector('#type').onchange = e => { typeF = e.target.value; draw(); };
    main.querySelector('#status').onchange = e => { statusF = e.target.value; draw(); };
  }
  draw();
}
