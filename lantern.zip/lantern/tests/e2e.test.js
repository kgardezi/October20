// End-to-end checks for Lantern. Run: node tests/e2e.test.js   (needs playwright + chromium)
const {chromium}=require('playwright');const http=require('http');const fs=require('fs');const path=require('path');const assert=require('assert');
const ROOT=path.join(__dirname,'..');const PORT=8731;
const server=http.createServer((req,res)=>{const f=path.join(ROOT,req.url==='/'?'lantern.html':decodeURIComponent(req.url.split('?')[0]));if(!fs.existsSync(f)){res.writeHead(404);return res.end();}res.writeHead(200,{'Content-Type':f.endsWith('.html')?'text/html; charset=utf-8':'application/octet-stream'});fs.createReadStream(f).pipe(res);});
const results=[];const step=async(name,fn)=>{try{await fn();results.push(['PASS',name]);console.log('PASS',name);}catch(e){results.push(['FAIL',name,e.message]);console.log('FAIL',name,'\n   ',e.message.slice(0,1500));}};
const seed=JSON.parse(fs.readFileSync(path.join(ROOT,'src/noteforge-seed.json'),'utf8'));
(async()=>{
  await new Promise(r=>server.listen(PORT,r));
  const browser=await chromium.launch();
  const ctx=await browser.newContext({viewport:{width:1280,height:900}});
  const errors=[];const external=[];
  // Block every non-localhost request so we can prove the app works fully offline and record what it tried to reach.
  await ctx.route(/^https?:\/\/(?!localhost)/,route=>{external.push(route.request().url());route.abort();});
  const page=await ctx.newPage();page.on('pageerror',e=>errors.push('pageerror: '+e.message));page.on('console',m=>{if(m.type()==='error'&&!/Failed to load resource|net::ERR_FAILED/.test(m.text()))errors.push('console: '+m.text());});
  const URL='http://localhost:'+PORT+'/';
  const count=async()=>page.evaluate(()=>State.resources.filter(r=>!r.deletedAt&&!r.archived).length);
  const total=async()=>page.evaluate(()=>State.resources.length);
  const flush=()=>page.evaluate(()=>flushNow());

  await step('First run shows welcome and imports the embedded 1,362 links after preview',async()=>{
    await page.goto(URL);await page.waitForSelector('#modalWrap.open');
    assert.match(await page.textContent('#modalTitle'),/Welcome/);
    await page.click('#modalFoot button.btn-primary');
    await page.waitForSelector('#modalTitle:has-text("Import preview")');
    const txt=await page.textContent('#modalBody');assert.match(txt,/1,362/,'preview should show 1,362 new');
    await page.click('#modalFoot button.btn-primary');
    await page.waitForSelector('.rgrid .rcard');
    assert.strictEqual(await count(),1362);await flush();
    // every original field preserved
    const check=await page.evaluate(()=>{const r=State.resources.find(x=>x.url==='https://youtube.com/shorts/xlT_vK7QiQw?si=97ufv5wJ-75O_Szy');return r&&{savedAt:r.savedAt,time:r.legacy.time,plat:r.legacy.platform,c:r.legacy.timesShared,src:r.source};});
    assert.deepStrictEqual(check,{savedAt:'2023-09-03',time:'1:17 pm',plat:'YouTube',c:1,src:'whatsapp'});
    const noted=await page.evaluate(()=>State.resources.filter(r=>r.title).length);assert.strictEqual(noted,seed.filter(v=>v.n).length,'notes preserved as titles');
    const tagged=await page.evaluate(()=>State.resources.filter(r=>r.tags.length).length);assert.strictEqual(tagged,seed.filter(v=>v.g.length).length,'topics preserved as tags');
  });
  await step('Data persists after reload (IndexedDB), no welcome again',async()=>{
    await page.reload();await page.waitForSelector('.rcard,.empty');await page.waitForTimeout(300);
    assert.ok(!(await page.isVisible('#modalWrap.open')),'welcome must not reappear');assert.strictEqual(await count(),1362);
    assert.strictEqual(await page.evaluate(()=>Store.mode),'idb');
  });
  await step('NoteForge backup import: merges tracker entries, archives hidden links, skips malformed, dedups tracking params',async()=>{
    const seedUrl=seed[0].u;const hiddenUrl=seed[1].u;
    const backup={app:'NoteForge',version:6,preferences:{view:'cards'},exported:new Date().toISOString(),
      entries:[{id:'e1',date:'2025-01-05',task:'Learn hooks properly',notes:'Saved on Sep 3, 2023 from WhatsApp.\nMy takeaway: useEffect cleanup matters.',link:seedUrl,status:'In progress',picture:'',source:'video'},
               {id:'e2',date:'2024-06-01',task:'MDN Fetch API',notes:'Folder: Dev',link:'https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API',status:'Completed',picture:''},
               {id:'e3',date:'2024-06-02',task:'A plain note without link',notes:'Just thoughts',link:'',status:'Not started',picture:''},
               {bogus:true},null,{id:'e5',date:'not-a-date',task:'',notes:'',link:'javascript:alert(1)',status:'Weird'}],
      extraVideos:[{u:'https://youtu.be/dQw4w9WgXcQ?si=zzz',p:'YouTube',d:'2026-01-01',t:'9:00 am',n:'Never gonna',c:1,y:'dQw4w9WgXcQ',g:[]},
                   {u:seed[3].u.split('?')[0]+'?si=DIFFERENT_TRACKING',p:'YouTube',d:'2026-01-02',t:'9:00 am',n:'dup with other tracking param',c:1,y:seed[3].y,g:['AI']}],
      hiddenVideos:[hiddenUrl]};
    fs.writeFileSync('/tmp/nf-backup.json',JSON.stringify(backup));
    await page.goto(URL+'#/settings');await page.waitForSelector('#drop');
    const [fc]=await Promise.all([page.waitForEvent('filechooser'),page.click('#sRestore')]);await fc.setFiles('/tmp/nf-backup.json');
    await page.waitForSelector('#modalTitle:has-text("Import preview")');const txt=await page.textContent('#modalBody');
    assert.match(txt,/NoteForge backup v6/);assert.match(txt,/Skipped records \(3\)/,'3 malformed records flagged');
    await page.click('#modalFoot button.btn-primary');await page.waitForSelector('.rcard');await flush();
    const r=await page.evaluate((u)=>{const x=State.resources.find(r=>r.url===u);return {status:x.status,title:x.title,notes:x.notes,n:State.resources.filter(r=>r.key===x.key).length};},seedUrl);
    assert.strictEqual(r.status,'learning','tracker status merged into library item');assert.strictEqual(r.title,'Learn hooks properly');assert.match(r.notes,/useEffect cleanup/);assert.strictEqual(r.n,1,'no duplicate created for tracked video');
    assert.ok(await page.evaluate((u)=>State.resources.find(r=>r.url===u).archived,hiddenUrl),'hidden video archived');
    const dupN=await page.evaluate((k)=>State.resources.filter(r=>r.key===k).length,await page.evaluate((u)=>canon(u),seed[3].u));assert.strictEqual(dupN,1,'same YouTube id with different ?si= is one resource');
    const mdn=await page.evaluate(()=>State.resources.find(r=>r.url.includes('mozilla.org')));assert.strictEqual(mdn.status,'done');assert.strictEqual(mdn.folder,'Dev');assert.strictEqual(mdn.source,'bookmark');
    assert.ok(await page.evaluate(()=>State.resources.some(r=>!r.url&&r.title==='A plain note without link')),'link-less note kept');
    assert.strictEqual(await total(),1362+3,'1362 + rickroll + mdn + note');
    assert.ok((await page.evaluate(()=>State.snapshots.length))>=1,'snapshot taken before import');
  });
  await step('Malformed JSON import fails safely with a message and changes nothing',async()=>{
    fs.writeFileSync('/tmp/bad.json','{"entries": [ this is not json');const before=await total();await page.goto(URL+'#/settings');await page.waitForSelector('#sRestore');
    const [fc]=await Promise.all([page.waitForEvent('filechooser'),page.click('#sRestore')]);await fc.setFiles('/tmp/bad.json');
    await page.waitForSelector('#modalTitle:has-text("Import failed")');assert.match(await page.textContent('#modalBody'),/not valid JSON/);await page.click('#modalFoot button');
    assert.strictEqual(await total(),before);
  });
  await step('WhatsApp .txt and bookmarks .html imports are recognised and deduplicated',async()=>{
    fs.writeFileSync('/tmp/chat.txt',`[03/09/2023, 1:17:00 pm] Kashif: https://youtube.com/shorts/xlT_vK7QiQw?si=97ufv5wJ-75O_Szy\n[15/10/2026, 8:00:00 am] Kashif: Great SQL tutorial\nhttps://example.com/sql-tutorial?utm_source=wa\n[15/10/2026, 8:01:00 am] Kashif: https://example.com/sql-tutorial\n`);
    await page.goto(URL+'#/settings');await page.waitForSelector('#sRestore');let [fc]=await Promise.all([page.waitForEvent('filechooser'),page.click('#sRestore')]);await fc.setFiles('/tmp/chat.txt');
    await page.waitForSelector('#modalTitle:has-text("Import preview")');let txt=await page.textContent('#modalBody');
    assert.match(txt,/day\/month\/year/);assert.match(txt,/1Already in library/);assert.match(txt,/1Repeated in file/);await page.click('#modalFoot button.btn-primary');await page.waitForSelector('.rcard');
    const sql=await page.evaluate(()=>State.resources.filter(r=>r.url.includes('sql-tutorial')));assert.strictEqual(sql.length,1);assert.strictEqual(sql[0].title,'Great SQL tutorial');assert.strictEqual(sql[0].savedAt,'2026-10-15');
    fs.writeFileSync('/tmp/bm.html',`<!DOCTYPE NETSCAPE-Bookmark-file-1>\n<TITLE>Bookmarks</TITLE><H1>Bookmarks</H1>\n<DL><p>\n<DT><H3 ADD_DATE="1700000000">Learning</H3>\n<DL><p>\n<DT><A HREF="https://www.example.com/sql-tutorial/" ADD_DATE="1700000000">SQL tutorial (bookmark)</A>\n<DT><A HREF="https://docs.python.org/3/tutorial/" ADD_DATE="1700000100" TAGS="python,docs">Python tutorial</A>\n<DD>Official docs\n<DT><A HREF="javascript:void(0)">bad</A>\n</DL><p>\n</DL><p>`);
    await page.goto(URL+'#/settings');await page.waitForSelector('#drop');
    [fc]=await Promise.all([page.waitForEvent('filechooser'),page.click('#sRestore')]);await fc.setFiles('/tmp/bm.html');
    await page.waitForSelector('#modalTitle:has-text("Import preview")');txt=await page.textContent('#modalBody');
    assert.match(txt,/1New/);assert.match(txt,/1Already in library/,'www + trailing slash recognised as same URL');
    await page.click('#modalFoot button.btn-primary');await page.waitForSelector('.rcard');
    const py=await page.evaluate(()=>State.resources.find(r=>r.url.includes('python.org')));assert.deepStrictEqual(py.tags,['python','docs']);assert.strictEqual(py.folder,'Learning');assert.strictEqual(py.description,'Official docs');assert.strictEqual(py.savedAt,'2023-11-14');
  });
  await step('Quick save warns about duplicates; create, edit, tag, markdown notes, persist',async()=>{
    await page.goto(URL+'#/library');await page.waitForSelector('.rcard');
    await page.keyboard.press('n');await page.waitForSelector('#modalTitle:has-text("Save a resource")');
    await page.fill('#qsUrl','https://m.youtube.com/watch?v=dQw4w9WgXcQ&feature=share');await page.waitForSelector('#qsDup:has-text("Already saved")');
    await page.fill('#qsUrl','https://example.org/new-article');await page.fill('#qsTitle','Brand new article');await page.fill('#qsTags','reading, web');
    await page.click('#modalFoot button:has-text("Save & open")');await page.waitForSelector('#panelWrap.open');
    await page.fill('#dTitle','Brand new article (edited)');await page.fill('#dNotes','# Takeaways\n\n- **bold** point\n- [ ] todo item\n\n> quote');
    await page.click('[data-nm="preview"]');assert.ok(await page.isVisible('#dMd h1'));assert.ok(await page.isVisible('#dMd input[type=checkbox]'));
    await page.fill('#dTagIn','markdown');await page.keyboard.press('Enter');await page.selectOption('#dStatus','learning');await page.selectOption('#dPrio','3');
    await page.click('#dSave');await page.waitForSelector('.toast:has-text("Saved")');await page.keyboard.press('Escape');await flush();
    await page.reload();await page.waitForSelector('.rcard');
    const r=await page.evaluate(()=>State.resources.find(r=>r.url==='https://example.org/new-article'));
    assert.strictEqual(r.title,'Brand new article (edited)');assert.deepStrictEqual(r.tags,['reading','web','markdown']);assert.strictEqual(r.status,'learning');assert.strictEqual(r.priority,3);assert.match(r.notes,/todo item/);
  });
  await step('Search across title, url, notes, tags with operators',async()=>{
    await page.fill('#q','takeaways tag:markdown');await page.waitForTimeout(300);assert.strictEqual((await page.$$('.rcard')).length,1);
    await page.fill('#q','status:learning');await page.waitForTimeout(300);assert.strictEqual((await page.$$('.rcard')).length,2,'hooks + new article');
    await page.fill('#q','useEffect');await page.waitForTimeout(300);assert.strictEqual((await page.$$('.rcard')).length,1,'notes are searched');
    await page.fill('#q','site:youtube -status:learning is:untagged');await page.waitForTimeout(300);const n=await page.evaluate(()=>R.lastList.length);assert.ok(n>50&&n<90,'youtube untagged ~'+n);
    await page.fill('#q','');await page.waitForTimeout(300);
  });
  await step('Bulk: select, set status, undo; archive; trash restore; permanent delete',async()=>{
    await page.goto(URL+'#/library?status=learning');await page.waitForSelector('.rcard');
    const cards=await page.$$('.rcard');assert.strictEqual(cards.length,2);
    await page.click('.rcard:nth-child(1) .sel');await page.click('.rcard:nth-child(2) .sel');await page.waitForSelector('.bulkbar');
    await page.selectOption('#bStatus','done');await page.waitForSelector('.toast:has-text("Status set to Done")');
    assert.strictEqual(await page.evaluate(()=>State.resources.filter(r=>r.status==='learning').length),0);
    await page.click('.toast button:has-text("Undo")');await page.waitForTimeout(200);assert.strictEqual(await page.evaluate(()=>State.resources.filter(r=>r.status==='learning').length),2,'undo restored statuses');
    await page.goto(URL+'#/library?tag=markdown');await page.waitForSelector('.rcard');await page.click('.rcard .sel');await page.click('#bDel');await page.waitForSelector('.toast:has-text("Moved to trash")');
    assert.strictEqual(await page.evaluate(()=>State.resources.filter(r=>r.deletedAt).length),1);
    await page.goto(URL+'#/trash');await page.waitForSelector('.rrow:not(.head)');await page.click('.rrow:not(.head) .sel');await page.click('#bRestore');await page.waitForTimeout(200);
    assert.strictEqual(await page.evaluate(()=>State.resources.filter(r=>r.deletedAt).length),0,'restored from trash');
    await page.goto(URL+'#/library?tag=markdown');await page.waitForSelector('.rcard');await page.click('.rcard .sel');await page.click('#bDel');await page.waitForTimeout(200);
    await page.goto(URL+'#/trash');await page.waitForSelector('#emptyTrash');await page.click('#emptyTrash');await page.waitForSelector('#modalTitle:has-text("Empty trash")');await page.click('#modalFoot .btn-danger');await page.waitForTimeout(300);
    assert.ok(!(await page.evaluate(()=>State.resources.some(r=>r.url==='https://example.org/new-article'))),'permanently deleted');
    await flush();await page.reload();await page.waitForTimeout(400);assert.ok(!(await page.evaluate(()=>State.resources.some(r=>r.url==='https://example.org/new-article'))),'deletion persisted');
  });
  await step('Backup → wipe → restore round trip is lossless; CSV/MD/HTML exports download',async()=>{
    await page.goto(URL+'#/settings');await page.waitForSelector('#sBackup');
    const before=await page.evaluate(()=>JSON.stringify(State.resources.map(({_s,...r})=>r).sort((a,b)=>a.id.localeCompare(b.id))));
    const [dl]=await Promise.all([page.waitForEvent('download'),page.click('#sBackup')]);const bpath='/tmp/lantern-backup.json';await dl.saveAs(bpath);
    const bk=JSON.parse(fs.readFileSync(bpath,'utf8'));assert.strictEqual(bk.app,'Lantern');assert.strictEqual(bk.resources.length,await total());
    for(const [sel,rx] of [['[data-exp="csv"]',/^﻿id,title,url/],['[data-exp="md"]',/^# Lantern library export/],['[data-exp="html"]',/^<!DOCTYPE NETSCAPE-Bookmark-file-1>/]]){const [d]=await Promise.all([page.waitForEvent('download'),page.click(sel)]);const p='/tmp/exp-'+Date.now();await d.saveAs(p);const t=fs.readFileSync(p,'utf8');assert.match(t,rx);assert.ok(t.length>50000,'export has content');}
    // wipe via danger zone (typed confirmation)
    await page.click('#sWipe');await page.fill('#cfTyped','DELETE');await page.click('#modalFoot .btn-danger');await page.waitForSelector('#modalTitle:has-text("Welcome")',{timeout:8000});
    assert.strictEqual(await total(),0);
    await page.click('input[name=wl][value=empty]');await page.click('#modalFoot button.btn-primary');await page.waitForTimeout(200);
    await page.goto(URL+'#/settings');await page.waitForSelector('#drop');
    const [fc]=await Promise.all([page.waitForEvent('filechooser'),page.click('#sRestore')]);await fc.setFiles(bpath);
    await page.waitForSelector('#modalTitle:has-text("Import preview")');assert.match(await page.textContent('#modalBody'),/Lantern backup/);
    await page.click('input[name=impMode][value=replace]');await page.click('#modalFoot button.btn-primary');await page.waitForSelector('.rcard');await flush();
    const after=await page.evaluate(()=>JSON.stringify(State.resources.map(({_s,...r})=>r).sort((a,b)=>a.id.localeCompare(b.id))));
    assert.strictEqual(after.length,before.length);assert.strictEqual(after,before,'restored data identical to exported data');
  });
  await step('Original NoteForge .html file can be imported directly (dataset extracted)',async()=>{
    await page.goto(URL+'#/settings');await page.waitForSelector('#drop');
    const [fc]=await Promise.all([page.waitForEvent('filechooser'),page.click('#sRestore')]);await fc.setFiles(path.join(__dirname,'original-noteforge.html'));
    await page.waitForSelector('#modalTitle:has-text("Import preview")');const txt=await page.textContent('#modalBody');assert.match(txt,/1,362 saved links/);assert.match(txt,/1,362Already in library/,'all already present → nothing duplicated');
    await page.click('#modalFoot .btn-ghost');
  });
  await step('Review queue has due/stale/rediscover sections and actions work',async()=>{
    await page.evaluate(()=>{const r=State.resources.find(x=>x.status==='saved'&&!x.archived);r.reviewAt='2020-01-01';touch(r);});
    await page.goto(URL+'#/review');await page.waitForSelector('[data-rv="snooze1w"]');await page.click('[data-rv="snooze1w"]');await page.waitForTimeout(150);
    assert.strictEqual(await page.evaluate(()=>State.resources.filter(r=>r.reviewAt&&r.reviewAt<=today()).length),0);
    assert.ok((await page.$$('[data-rv="learn"]')).length>0,'rediscover sample shown');
  });
  await step('Keyboard: / focuses search, Esc closes modal, Tab is trapped in dialog, card keys work',async()=>{
    await page.goto(URL+'#/library');await page.waitForSelector('.rcard');
    await page.keyboard.press('/');assert.strictEqual(await page.evaluate(()=>document.activeElement.id),'q');await page.keyboard.press('Escape');
    await page.keyboard.press('?');await page.waitForSelector('#modalTitle:has-text("Keyboard shortcuts")');
    for(let i=0;i<6;i++)await page.keyboard.press('Tab');assert.ok(await page.evaluate(()=>document.getElementById('modal').contains(document.activeElement)),'focus stays inside modal');
    await page.keyboard.press('Escape');assert.ok(!(await page.isVisible('#modalWrap.open')));
    await page.focus('.rcard');await page.keyboard.press('f');await page.waitForTimeout(100);assert.ok(await page.evaluate(()=>R.lastList[0].favorite),'f toggles favorite');
    await page.focus('.rcard');await page.keyboard.press('Enter');await page.waitForSelector('#panelWrap.open');await page.keyboard.press('Escape');assert.ok(!(await page.isVisible('#panelWrap.open')));
    await page.keyboard.press('g');await page.keyboard.press('d');await page.waitForSelector('.hero');
  });
  await step('Mobile layout: drawer nav, 2-column grid, full-width panel, no horizontal scroll',async()=>{
    const mp=page;await mp.setViewportSize({width:390,height:844});
    await mp.goto(URL+'#/library');await mp.waitForSelector('.rcard');await mp.waitForTimeout(400);
    assert.ok(await mp.isVisible('#menuBtn'));assert.ok(!(await mp.evaluate(()=>{const s=document.getElementById('side');return s.getBoundingClientRect().right>0;})),'sidebar hidden');
    await mp.click('#menuBtn');await mp.waitForTimeout(300);assert.ok(await mp.evaluate(()=>document.getElementById('side').classList.contains('open')));await mp.click('#scrim',{position:{x:360,y:400}});await mp.waitForTimeout(300);
    const cols=await mp.evaluate(()=>getComputedStyle(document.querySelector('.rgrid')).gridTemplateColumns.split(' ').length);assert.ok(cols<=2,'phone grid is 1–2 columns, got '+cols);
    assert.ok(await mp.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+1),'no horizontal overflow');
    await mp.goto(URL+'#/dashboard');await mp.waitForSelector('.hero');assert.ok(await mp.evaluate(()=>document.documentElement.scrollWidth<=window.innerWidth+1),'dashboard: no horizontal overflow');await mp.goto(URL+'#/library');await mp.waitForSelector('.rcard');
    await mp.click('.rcard');await mp.waitForSelector('#panelWrap.open');const w=await mp.evaluate(()=>document.getElementById('panel').getBoundingClientRect().width);assert.ok(w>=389,'panel full width');
    await mp.keyboard.press('Escape');await mp.setViewportSize({width:1280,height:900});
  });
  await step('Offline: previews on, external requests all blocked, UI still renders without script errors',async()=>{
    await page.evaluate(()=>{settings().previews='youtube';saveSettings();});await page.goto(URL+'#/library?platform=YouTube');await page.waitForSelector('.rcard');await page.waitForTimeout(600);
    assert.ok(external.some(u=>u.includes('i.ytimg.com')),'thumbnail requests were attempted and blocked');
    assert.ok((await page.$$('.rcard .thumb .glyph')).length>0,'fallback glyphs shown when images fail');
    await page.evaluate(()=>{settings().previews='off';saveSettings();});
    const leaked=external.filter(u=>!u.includes('i.ytimg.com'));assert.deepStrictEqual(leaked,[],'no other external requests were made at any point');
  });
  await step('No uncaught page errors during the whole run',async()=>{assert.deepStrictEqual(errors,[],'errors: '+JSON.stringify(errors,null,1));});
  await browser.close();server.close();
  const fails=results.filter(r=>r[0]==='FAIL');console.log(`\n${results.length-fails.length}/${results.length} passed`);process.exit(fails.length?1:0);
})().catch(e=>{console.error(e);process.exit(1);});
