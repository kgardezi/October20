/* ───────────────────────── Lantern UI ───────────────────────── */
const UI={};
const R={page:'dashboard',params:{},shown:0,selected:new Set(),focusIdx:-1,lastList:[],reviewSample:null};
const F={status:'',tag:'',coll:'',fav:false,platform:'',year:'',has:'',q:''}; // library filters
const icon=(n,cls='i')=>`<svg class="${cls}" aria-hidden="true"><use href="#ic-${n}"/></svg>`;
const stLabel=s=>`<span class="status st-${s}">${STATUS_LABEL[s]}</span>`;
const prioLabel=p=>p?`<span class="prio prio-${p}" title="Priority ${PRIO_LABEL[p]}">${['','!','!!','!!!'][p]} ${PRIO_LABEL[p]}</span>`:'';

/* ───── toasts ───── */
function toast(msg,opts={}){
  const w=$('#toasts');const t=document.createElement('div');t.className='toast';
  t.innerHTML=`<span>${esc(msg)}</span>${opts.action?`<button type="button">${esc(opts.action.label)}</button>`:''}<button type="button" class="x" aria-label="Dismiss">${icon('x')}</button>`;
  const kill=()=>{t.remove();};
  if(opts.action)t.querySelector('button').onclick=()=>{opts.action.fn();kill();};
  t.querySelector('.x').onclick=kill;w.appendChild(t);
  if(!opts.sticky)setTimeout(kill,opts.action?7000:3500);
  while(w.children.length>3)w.firstChild.remove();
}
UI.onSaved=(ok,err)=>{if(!ok)toast(err?.message||'Could not save changes. Export a backup now.',{sticky:true});};

/* ───── routing ───── */
const PAGES={dashboard:'Dashboard',library:'Library',review:'Review',archive:'Archive',trash:'Trash',settings:'Settings & data'};
function go(page,params={}){R.page=PAGES[page]?page:'dashboard';R.params=params;R.shown=0;R.selected.clear();R.focusIdx=-1;
  if(page==='library'){Object.assign(F,{status:'',tag:'',coll:'',fav:false,platform:'',year:'',has:''},params);}
  const h='#/'+R.page+(Object.keys(params).length?'?'+new URLSearchParams(Object.entries(params).map(([k,v])=>[k,String(v)])):'' );
  if(location.hash!==h)history.pushState(null,'',h);
  closeSide();render();window.scrollTo({top:0});}
function readHash(){const m=location.hash.match(/^#\/(\w+)\??(.*)$/);if(!m)return;const p=Object.fromEntries(new URLSearchParams(m[2]));if(p.fav)p.fav=p.fav==='true';R.page=PAGES[m[1]]?m[1]:'dashboard';R.params=p;if(R.page==='library')Object.assign(F,{status:'',tag:'',coll:'',fav:false,platform:'',year:'',has:''},p);}
window.addEventListener('popstate',()=>{readHash();render();});

/* ───── side nav ───── */
function openSide(){$('#side').classList.add('open');$('#scrim').classList.add('open');$('#menuBtn').setAttribute('aria-expanded','true');}
function closeSide(){$('#side').classList.remove('open');$('#scrim').classList.remove('open');$('#menuBtn').setAttribute('aria-expanded','false');}
function renderNav(){
  const live=State.resources.filter(r=>!r.deletedAt&&!r.archived);
  const cnt=k=>live.filter(k).length;
  const cur=(p,test)=>R.page===p&&(test===undefined||test)?'aria-current="page"':'';
  const item=(label,ic,p,params,n,test)=>`<button class="nav-item" data-go="${p}" data-params='${esc(JSON.stringify(params||{}))}' ${cur(p,test)}>${icon(ic)}<span>${esc(label)}</span>${n!=null?`<span class="cnt">${n.toLocaleString()}</span>`:''}</button>`;
  const noFilter=!F.status&&!F.tag&&!F.coll&&!F.fav;
  const trash=State.resources.filter(r=>r.deletedAt).length,arch=State.resources.filter(r=>!r.deletedAt&&r.archived).length,due=reviewQueue().due.length;
  $('#nav').innerHTML=`
    ${item('Dashboard','home','dashboard',{},null)}
    ${item('Library','lib','library',{},live.length,noFilter)}
    ${item('Favorites','star','library',{fav:true},cnt(r=>r.favorite),F.fav&&!F.status)}
    ${item('Review queue','review','review',{},due||null)}
    <div class="nav-label">Learning status</div>
    ${STATUSES.map(([k,l])=>`<button class="nav-item" data-go="library" data-params='${esc(JSON.stringify({status:k}))}' ${cur('library',F.status===k)}><span class="dot st-${k}" style="background:currentColor" aria-hidden="true"></span><span class="status st-${k}" style="padding:0;background:none">${l}</span><span class="cnt">${cnt(r=>r.status===k)}</span></button>`).join('')}
    <div class="nav-label">Collections <button type="button" id="addColl" aria-label="New collection">+ New</button></div>
    ${State.collections.length?State.collections.map(c=>`<button class="nav-item" data-go="library" data-params='${esc(JSON.stringify({coll:c.id}))}' ${cur('library',F.coll===c.id)}>${icon('folder')}<span style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(c.name)}</span><span class="cnt">${cnt(r=>r.collection===c.id)}</span></button>`).join(''):'<div class="small muted" style="padding:4px 10px">Group resources into courses or projects.</div>'}
    <div class="nav-label">More</div>
    ${item('Archive','archive','archive',{},arch||null)}
    ${item('Trash','trash','trash',{},trash||null)}
    ${item('Settings & data','settings','settings',{},null)}`;
  $$('#nav [data-go]').forEach(b=>b.onclick=()=>go(b.dataset.go,JSON.parse(b.dataset.params||'{}')));
  $('#addColl').onclick=()=>promptCollection();
  const s=settings();$('#backupInfo').textContent=s.lastBackup?'Last backup '+relTime(s.lastBackup):'No backup yet';
  $('#storageInfo').textContent=Store.mode==='idb'?'Stored in this browser (IndexedDB)':'Stored in this browser (localStorage)';
}

/* ───── main render ───── */
function render(){
  renderNav();$('#pageTitle').textContent=PAGES[R.page];
  const c=$('#content');c.classList.toggle('selecting',R.selected.size>0);
  ({dashboard:renderDashboard,library:renderLibrary,review:renderReview,archive:renderArchive,trash:renderTrash,settings:renderSettings})[R.page](c);
}

/* ───── Dashboard ───── */
function renderDashboard(c){
  const live=State.resources.filter(r=>!r.deletedAt&&!r.archived);
  const learning=live.filter(r=>r.status==='learning').sort((a,b)=>b.updatedAt.localeCompare(a.updatedAt));
  const next=live.filter(r=>r.status==='next').sort((a,b)=>b.priority-a.priority||a.savedAt.localeCompare(b.savedAt)).slice(0,6);
  const rq=reviewQueue();const recent=[...live].sort((a,b)=>b.savedAt.localeCompare(a.savedAt)||b.createdAt.localeCompare(a.createdAt)).slice(0,8);
  const doneWeek=live.filter(r=>r.status==='done'&&r.completedAt&&daysSince(r.completedAt)<=7).length;
  const s=settings();const backupOld=!s.lastBackup||daysSince(s.lastBackup)>14;
  const greet=live.length?`${learning.length?`You have ${plural(learning.length,'resource')} in progress.`:'Nothing in progress yet.'} ${next.length?`${plural(next.length,'item')} queued up next.`:''}`:'Save a link or import your existing library to get started.';
  c.innerHTML=`
  <div class="dash-top">
    <section class="card hero"><h3>Continue learning</h3><p>${greet}</p>
      <div class="stats">
        <button class="stat" data-go="library" data-p='{"status":"learning"}'><div class="v">${learning.length}</div><div class="k">Learning now</div></button>
        <button class="stat" data-go="library" data-p='{"status":"next"}'><div class="v">${live.filter(r=>r.status==='next').length}</div><div class="k">To learn</div></button>
        <button class="stat" data-go="review" data-p='{}'><div class="v">${rq.due.length}</div><div class="k">Review due</div></button>
        <button class="stat" data-go="library" data-p='{"status":"done"}'><div class="v">${doneWeek}</div><div class="k">Done this week</div></button>
      </div></section>
    <section class="card pad"><div class="sec-head" style="margin:0 0 10px"><h3>Up next</h3><button class="link-btn small" data-go="library" data-p='{"status":"next"}'>All →</button></div>
      <div class="next-list">${next.length?next.map(r=>`<button class="next-item" data-open="${r.id}"><span class="t">${esc(r.title||r.url)}</span>${prioLabel(r.priority)}<span class="m">${esc(platformOf(r.url))}</span></button>`).join(''):`<div class="small muted">Mark saved items as <b>To learn</b> and set a priority to build your queue.</div>`}</div></section>
  </div>
  ${backupOld&&live.length?`<div class="notice warn" style="margin-top:16px">${icon('download')}<div><b>${s.lastBackup?'Your last backup is '+relTime(s.lastBackup)+'.':'No backup yet.'}</b> Everything lives in this browser only. Clearing site data or switching browsers loses it. <button class="link-btn small" id="dashBackup">Download a backup now</button></div></div>`:''}
  <div class="sec-head"><h3>In progress</h3>${learning.length>8?`<button class="link-btn small" data-go="library" data-p='{"status":"learning"}'>All ${learning.length} →</button>`:''}</div>
  ${learning.length?`<div class="rgrid">${learning.slice(0,8).map(r=>cardHtml(r)).join('')}</div>`:emptyHtml('Nothing in progress','Open any resource and set its status to <b>Learning</b>. It will show up here so you can pick up where you left off.','library','Browse library')}
  ${rq.due.length||rq.stale.length||rq.forgotten.length?`<div class="sec-head"><h3>Worth another look</h3><button class="link-btn small" data-go="review" data-p='{}'>Open review queue →</button></div>
  <div class="rgrid">${[...rq.due.slice(0,2),...rq.stale.slice(0,2),...shuffle(rq.forgotten.slice()).slice(0,4)].slice(0,4).map(r=>cardHtml(r,{compact:true})).join('')}</div>`:''}
  <div class="sec-head"><h3>Recently saved</h3><button class="link-btn small" data-go="library" data-p='{}'>Library →</button></div>
  ${recent.length?`<div class="rgrid">${recent.map(r=>cardHtml(r)).join('')}</div>`:emptyHtml('Your library is empty','Save a link with the <b>Save</b> button, or import a WhatsApp chat export, browser bookmarks or a NoteForge backup.','settings','Import data')}`;
  wireCommon(c);$('#dashBackup')?.addEventListener('click',doBackup);
}
function emptyHtml(h,p,page,label){return `<div class="empty"><h4>${h}</h4><p>${p}</p>${page?`<button class="btn btn-ghost" data-go="${page}" data-p='{}'>${label}</button>`:''}</div>`;}

/* ───── cards & lists ───── */
function thumbHtml(r){
  const s=settings();const yt=ytId(r.url);let img=safeImg(r.image);
  if(!img&&yt&&s.previews!=='off')img=`https://i.ytimg.com/vi/${yt}/hqdefault.jpg`;
  const emb=r.url?embedFor(r.url):null;const host=r.url?(platformOf(r.url)==='Web'?hostOf(r.url):platformOf(r.url)):'Note';
  return `<div class="thumb">${img?`<img src="${esc(img)}" alt="" loading="lazy" onerror="this.remove()">`:`<span class="glyph" aria-hidden="true">${esc(host.slice(0,1).toUpperCase())}</span>`}<span class="host">${esc(host)}</span>${emb?`<button type="button" class="play" data-play="${r.id}">${icon('play')}Play</button>`:''}</div>`;
}
function cardHtml(r,o={}){
  const title=r.title||(r.url?hostOf(r.url)+' link':'Untitled note');
  return `<article class="rcard ${o.compact?'compact':''} ${R.selected.has(r.id)?'selected':''}" data-id="${r.id}" tabindex="0" aria-label="${esc(title)}">
    <input type="checkbox" class="sel" aria-label="Select ${esc(title)}" ${R.selected.has(r.id)?'checked':''}>
    <button type="button" class="fav ${r.favorite?'on':''}" data-fav="${r.id}" aria-label="${r.favorite?'Remove from favorites':'Add to favorites'}" aria-pressed="${r.favorite}">${icon('star')}</button>
    ${o.compact?'':thumbHtml(r)}
    <div class="body"><div class="title ${r.title?'':'untitled'}">${esc(title)}</div>
      ${r.url?`<div class="url">${esc(r.url.replace(/^https?:\/\/(www\.)?/,''))}</div>`:''}
      ${r.notes?`<div class="notes-prev">${esc(r.notes.replace(/[#*>`_\-\[\]]/g,' ').trim().slice(0,160))}</div>`:(r.description?`<div class="notes-prev">${esc(r.description.slice(0,160))}</div>`:'')}
      <div class="meta">${stLabel(r.status)}${prioLabel(r.priority)}${r.collection?`<span class="tag coll">${esc(collName(r.collection))}</span>`:''}${r.tags.slice(0,2).map(t=>`<span class="tag">${esc(t)}</span>`).join('')}${r.tags.length>2?`<span class="tag">+${r.tags.length-2}</span>`:''}<span class="date" title="Saved ${fmtDate(r.savedAt)}">${fmtDate(r.savedAt)}</span></div></div></article>`;
}
function rowHtml(r){const title=r.title||(r.url?hostOf(r.url)+' link':'Untitled note');
  return `<div class="rrow ${R.selected.has(r.id)?'selected':''}" data-id="${r.id}" tabindex="0" role="row" aria-label="${esc(title)}">
    <input type="checkbox" class="sel" aria-label="Select" ${R.selected.has(r.id)?'checked':''}>
    <div style="min-width:0"><div class="t ${r.title?'':'muted'}">${r.favorite?'★ ':''}${esc(title)}</div>${r.url?`<div class="u">${esc(r.url.replace(/^https?:\/\/(www\.)?/,''))}</div>`:''}</div>
    <div class="tags">${r.collection?`<span class="tag coll">${esc(collName(r.collection))}</span>`:''}${r.tags.slice(0,3).map(t=>`<span class="tag">${esc(t)}</span>`).join('')}</div>
    <div class="st">${stLabel(r.status)}</div><div class="d">${fmtDate(r.savedAt)}</div>
    <button type="button" class="btn-icon fav ${r.favorite?'on':''}" data-fav="${r.id}" aria-label="Toggle favorite">${icon('star')}</button></div>`;}
function wireCommon(root){
  $$('[data-go]',root).forEach(b=>b.onclick=e=>{e.stopPropagation();go(b.dataset.go,JSON.parse(b.dataset.p||b.dataset.params||'{}'));});
  $$('[data-open]',root).forEach(b=>b.onclick=()=>openDetail(b.dataset.open));
  $$('.rcard,.rrow:not(.head)',root).forEach(el=>{
    el.addEventListener('click',e=>{if(e.target.closest('button,input,a'))return;if(e.shiftKey||e.ctrlKey||e.metaKey){toggleSelect(el.dataset.id);return;}openDetail(el.dataset.id);});
    el.addEventListener('keydown',e=>{if(e.target!==el)return;const r=State.byId.get(el.dataset.id);if(!r)return;
      if(e.key==='Enter'){e.preventDefault();openDetail(r.id);}else if(e.key==='o'&&r.url){window.open(r.url,'_blank','noopener');markOpened(r);}else if(e.key==='f'){e.preventDefault();toggleFav(r.id);}else if(e.key==='x'||e.key===' '){e.preventDefault();toggleSelect(r.id);}else if(e.key==='s'){e.preventDefault();cycleStatus(r);}else if(e.key==='j'||e.key==='ArrowDown'||e.key==='ArrowRight'){e.preventDefault();moveFocus(el,1);}else if(e.key==='k'||e.key==='ArrowUp'||e.key==='ArrowLeft'){e.preventDefault();moveFocus(el,-1);}});
    el.querySelector('.sel')?.addEventListener('change',()=>toggleSelect(el.dataset.id));});
  $$('[data-fav]',root).forEach(b=>b.onclick=e=>{e.stopPropagation();toggleFav(b.dataset.fav);});
  $$('[data-play]',root).forEach(b=>b.onclick=e=>{e.stopPropagation();openDetail(b.dataset.play,{play:true});});
}
function moveFocus(el,d){const all=$$('.rcard,.rrow:not(.head)',$('#content'));const i=all.indexOf(el);const n=all[i+d];if(n)n.focus();}
function toggleFav(id){const r=State.byId.get(id);if(!r)return;r.favorite=!r.favorite;touch(r);render();if($('#panelWrap').classList.contains('open')&&Detail.id===id)renderDetail();}
function cycleStatus(r){const order=['saved','next','learning','done'];const i=order.indexOf(r.status);setStatus(r,order[(i+1)%order.length]);render();toast('Status: '+STATUS_LABEL[r.status]);}
function setStatus(r,s){r.status=s;if(s==='done'&&!r.completedAt)r.completedAt=new Date().toISOString();if(s!=='done')r.completedAt='';touch(r);}
function markOpened(r){r.openedAt=new Date().toISOString();State.dirty.resources.add(r.id);scheduleFlush();}
function toggleSelect(id){if(R.selected.has(id))R.selected.delete(id);else R.selected.add(id);render();}

/* ───── Library ───── */
function libraryPool(){return State.resources.filter(r=>!r.deletedAt&&!r.archived);}
function filteredLibrary(pool){
  const f=parseQuery(F.q||'');
  return pool.filter(r=>(!F.status||r.status===F.status)&&(!F.tag||r.tags.includes(F.tag))&&(!F.coll||(F.coll==='none'?!r.collection:r.collection===F.coll))&&(!F.fav||r.favorite)&&(!F.platform||platformOf(r.url)===F.platform)&&(!F.year||r.savedAt.startsWith(F.year))&&(!F.has||(F.has==='notes'?!!r.notes.trim():F.has==='untagged'?!r.tags.length:F.has==='review'?!!r.reviewAt:true))&&matchQuery(r,f));
}
function sortList(list,sort){const s=sort||settings().sort;const cmp={'saved-desc':(a,b)=>b.savedAt.localeCompare(a.savedAt)||b.createdAt.localeCompare(a.createdAt),'saved-asc':(a,b)=>a.savedAt.localeCompare(b.savedAt)||a.createdAt.localeCompare(b.createdAt),'updated':(a,b)=>b.updatedAt.localeCompare(a.updatedAt),'title':(a,b)=>(a.title||a.url).localeCompare(b.title||b.url,undefined,{sensitivity:'base'}),'priority':(a,b)=>b.priority-a.priority||b.savedAt.localeCompare(a.savedAt),'status':(a,b)=>STATUSES.findIndex(x=>x[0]===a.status)-STATUSES.findIndex(x=>x[0]===b.status)||b.savedAt.localeCompare(a.savedAt),'notes':(a,b)=>(!!b.notes.trim()-!!a.notes.trim())||b.savedAt.localeCompare(a.savedAt)}[s]||((a,b)=>0);return list.sort(cmp);}
function renderLibrary(c,opts={}){
  const s=settings();const pool=opts.pool||libraryPool();const list=sortList(filteredLibrary(pool));R.lastList=list;
  const page=s.pageSize||60;if(!R.shown)R.shown=page;
  const chip=(k,v,l,n)=>`<button type="button" class="chip" data-f="${k}" data-v="${esc(v)}" aria-pressed="${String(F[k])===String(v)}">${esc(l)}${n!=null?`<span class="n">${n}</span>`:''}</button>`;
  const tags=tagCounts(pool).slice(0,14);const plats=[...new Set(pool.map(r=>platformOf(r.url)))].map(p=>[p,pool.filter(r=>platformOf(r.url)===p).length]).sort((a,b)=>b[1]-a[1]);
  const years=[...new Set(pool.map(r=>r.savedAt.slice(0,4)))].sort().reverse();
  const active=Object.entries(F).filter(([k,v])=>v&&k!=='q').length;
  const title=opts.title||(F.coll?collName(F.coll)||'Collection':F.fav?'Favorites':F.status?STATUS_LABEL[F.status]:F.tag?'#'+F.tag:'All resources');
  c.innerHTML=`
  <div class="row spread"><div><h3 style="font-size:20px;font-weight:700">${esc(title)}</h3><div class="small muted">${plural(list.length,'resource')}${active?` · ${active} filter${active>1?'s':''} <button class="link-btn small" id="clearF">Clear</button>`:''}</div></div>
    <div class="row">${F.coll&&F.coll!=='none'?`<button class="btn btn-ghost btn-sm" id="editColl">Rename / delete collection</button>`:''}
    <div class="seg" role="group" aria-label="View"><button type="button" data-view="cards" aria-pressed="${s.view==='cards'}" title="Card view">${icon('grid')}Cards</button><button type="button" data-view="list" aria-pressed="${s.view==='list'}" title="List view">${icon('list')}List</button></div></div></div>
  ${opts.noFilters?'':`<div class="toolbar" style="margin-bottom:6px"><div class="chips" role="group" aria-label="Status">${chip('status','','All')}${STATUSES.map(([k,l])=>chip('status',k,l,pool.filter(r=>r.status===k).length)).join('')}${chip('fav',true,'★ Favorites',pool.filter(r=>r.favorite).length)}</div></div>
  ${tags.length?`<div class="toolbar" style="margin-top:0;margin-bottom:6px"><div class="chips" role="group" aria-label="Tags">${icon('tag','i muted')}${tags.map(([t,n])=>chip('tag',t,t,n)).join('')}${F.tag&&!tags.some(([t])=>t===F.tag)?chip('tag',F.tag,F.tag):''}</div></div>`:''}
  <div class="toolbar" style="margin-top:0">
    <select class="sel" id="fPlat" aria-label="Platform"><option value="">All platforms</option>${plats.map(([p,n])=>`<option value="${esc(p)}" ${F.platform===p?'selected':''}>${esc(p)} (${n})</option>`).join('')}</select>
    <select class="sel" id="fYear" aria-label="Year saved"><option value="">All years</option>${years.map(y=>`<option ${F.year===y?'selected':''}>${y}</option>`).join('')}</select>
    <select class="sel" id="fColl" aria-label="Collection"><option value="">Any collection</option><option value="none" ${F.coll==='none'?'selected':''}>No collection</option>${State.collections.map(cl=>`<option value="${cl.id}" ${F.coll===cl.id?'selected':''}>${esc(cl.name)}</option>`).join('')}</select>
    <select class="sel" id="fHas" aria-label="More filters"><option value="">Anything</option><option value="notes" ${F.has==='notes'?'selected':''}>Has notes</option><option value="untagged" ${F.has==='untagged'?'selected':''}>Untagged</option><option value="review" ${F.has==='review'?'selected':''}>Has review date</option></select>
    <select class="sel" id="fSort" aria-label="Sort"><option value="saved-desc">Newest saved</option><option value="saved-asc">Oldest saved</option><option value="updated">Recently updated</option><option value="priority">Priority</option><option value="status">Status</option><option value="title">Title A–Z</option><option value="notes">With notes first</option></select>
    <span class="count">Showing ${Math.min(R.shown,list.length).toLocaleString()} of ${list.length.toLocaleString()}</span></div>`}
  <div id="results"></div><div class="more" id="more"></div><div id="bulk"></div>`;
  const res=$('#results');
  if(!list.length)res.innerHTML=pool.length?emptyHtml('Nothing matches',`Try fewer filters or a broader search.${F.q?' Search understands <code>tag:</code>, <code>status:</code>, <code>in:</code>, <code>is:fav</code>, <code>has:notes</code>, <code>site:youtube</code> and <code>-word</code>.':''}`,null):emptyHtml(opts.emptyTitle||'Nothing here yet',opts.emptyText||'Save a link with the <b>Save</b> button, or import your existing data from <b>Settings & data</b>.','settings','Import data');
  else{const slice=list.slice(0,R.shown);res.innerHTML=s.view==='list'?`<div class="rlist" role="table"><div class="rrow head" role="row"><span></span><span>Title</span><span>Tags</span><span>Status</span><span>Saved</span><span></span></div>${slice.map(rowHtml).join('')}</div>`:`<div class="rgrid">${slice.map(r=>cardHtml(r)).join('')}</div>`;}
  if(list.length>R.shown){$('#more').innerHTML=`<button class="btn btn-ghost" id="loadMore">Show ${Math.min(page,list.length-R.shown)} more</button>`;$('#loadMore').onclick=()=>{R.shown+=page;render();};}
  $$('.chip[data-f]',c).forEach(b=>b.onclick=()=>{const k=b.dataset.f;let v=b.dataset.v;if(k==='fav')F.fav=!F.fav;else F[k]=String(F[k])===v?'':v;R.shown=0;render();});
  $$('[data-view]',c).forEach(b=>b.onclick=()=>{settings().view=b.dataset.view;saveSettings();render();});
  const bind=(id,k)=>{const el=$(id);if(el)el.onchange=()=>{F[k]=el.value;R.shown=0;render();};};bind('#fPlat','platform');bind('#fYear','year');bind('#fColl','coll');bind('#fHas','has');
  const so=$('#fSort');if(so){so.value=s.sort;so.onchange=()=>{settings().sort=so.value;saveSettings();render();};}
  $('#clearF')?.addEventListener('click',()=>{Object.assign(F,{status:'',tag:'',coll:'',fav:false,platform:'',year:'',has:''});R.shown=0;render();});
  $('#editColl')?.addEventListener('click',()=>promptCollection(F.coll));
  renderBulk($('#bulk'),list);wireCommon(c);
}
function renderBulk(el,list){
  if(!R.selected.size){el.innerHTML='';return;}
  const ids=[...R.selected].filter(id=>State.byId.get(id));const inTrash=R.page==='trash',inArch=R.page==='archive';
  el.innerHTML=`<div class="bulkbar" role="toolbar" aria-label="Bulk actions"><b>${ids.length} selected</b>
    <button class="btn btn-ghost btn-sm" id="bSelAll">Select all ${list.length}</button>
    ${inTrash?`<button class="btn btn-ghost btn-sm" id="bRestore">Restore</button><button class="btn btn-danger btn-sm" id="bPurge">Delete permanently</button>`:
    `<select class="sel" id="bStatus" aria-label="Set status" style="height:30px"><option value="">Set status…</option>${STATUSES.map(([k,l])=>`<option value="${k}">${l}</option>`).join('')}</select>
    <select class="sel" id="bColl" aria-label="Move to collection" style="height:30px"><option value="">Move to…</option><option value="__none">No collection</option>${State.collections.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}<option value="__new">+ New collection</option></select>
    <button class="btn btn-ghost btn-sm" id="bTag">Add tag</button><button class="btn btn-ghost btn-sm" id="bFav">★ Favorite</button>
    <button class="btn btn-ghost btn-sm" id="bArch">${inArch?'Unarchive':'Archive'}</button><button class="btn btn-danger btn-sm" id="bDel">Delete</button>`}
    <button class="btn btn-ghost btn-sm" id="bClear">Cancel</button></div>`;
  const rs=()=>ids.map(id=>State.byId.get(id)).filter(Boolean);
  const act=(label,fn)=>{const before=rs();pushUndo(label,before);before.forEach(fn);indexAll();R.selected.clear();render();toast(`${label} · ${plural(before.length,'item')}`,{action:{label:'Undo',fn:()=>{applyUndo();render();}}});};
  $('#bSelAll').onclick=()=>{list.forEach(r=>R.selected.add(r.id));render();};
  $('#bClear').onclick=()=>{R.selected.clear();render();};
  if(inTrash){$('#bRestore').onclick=()=>act('Restored',r=>{r.deletedAt=null;touch(r);});$('#bPurge').onclick=()=>confirmModal('Delete permanently?',`${plural(ids.length,'item')} will be removed for good. This cannot be undone.`,'Delete permanently',async()=>{await takeSnapshot('Before permanent delete');ids.forEach(hardDelete);indexAll();R.selected.clear();render();toast('Deleted permanently');});return;}
  $('#bStatus').onchange=e=>{if(e.target.value)act('Status set to '+STATUS_LABEL[e.target.value],r=>setStatus(r,e.target.value));};
  $('#bColl').onchange=e=>{const v=e.target.value;if(!v)return;if(v==='__new'){promptCollection(null,c=>act('Moved to '+c.name,r=>{r.collection=c.id;touch(r);}));return;}act(v==='__none'?'Removed from collection':'Moved to '+collName(v),r=>{r.collection=v==='__none'?'':v;touch(r);});};
  $('#bTag').onclick=()=>promptModal('Add tag to selected','Tag name',t=>{if(t)act('Tagged #'+t,r=>{if(!r.tags.includes(t))r.tags.push(t);invalidateSearch(r);touch(r);});},{list:tagCounts().map(x=>x[0])});
  $('#bFav').onclick=()=>act('Favorited',r=>{r.favorite=true;touch(r);});
  $('#bArch').onclick=()=>act(inArch?'Unarchived':'Archived',r=>{r.archived=!inArch;touch(r);});
  $('#bDel').onclick=()=>act('Moved to trash',r=>{r.deletedAt=new Date().toISOString();touch(r);});
}

/* ───── Review queue ───── */
function reviewQueue(){
  const live=State.resources.filter(r=>!r.deletedAt&&!r.archived);const t=today();const stale=settings().staleDays||120;
  return {due:live.filter(r=>r.reviewAt&&r.reviewAt<=t).sort((a,b)=>a.reviewAt.localeCompare(b.reviewAt)),
    stale:live.filter(r=>r.status==='learning'&&daysSince(r.updatedAt)>=14).sort((a,b)=>a.updatedAt.localeCompare(b.updatedAt)),
    forgotten:live.filter(r=>r.status==='saved'&&!r.openedAt&&daysSince(r.savedAt)>=stale&&!r.reviewAt)};
}
function renderReview(c){
  const q=reviewQueue();if(!R.reviewSample)R.reviewSample=shuffle(q.forgotten.slice()).slice(0,8).map(r=>r.id);
  const sample=R.reviewSample.map(id=>State.byId.get(id)).filter(r=>r&&!r.deletedAt&&!r.archived&&r.status==='saved');
  const block=(title,desc,list,extra='')=>`<div class="sec-head"><div><h3>${title}</h3><p>${desc}</p></div>${extra}</div>${list.length?`<div class="rgrid">${list.map(r=>reviewCard(r)).join('')}</div>`:`<div class="small muted" style="padding:8px 0 4px">Nothing here. 🎉</div>`}`;
  c.innerHTML=`<div class="notice">${icon('review')}<div><b>The review queue resurfaces what you'd otherwise forget.</b> Set a review date on any resource, or let Lantern pick forgotten saves at random. Each card offers quick decisions: open it, keep it (snooze), mark done, or archive.</div></div>
  ${block('Due for review',`${plural(q.due.length,'resource')} with a review date of today or earlier.`,q.due.slice(0,24))}
  ${block('Stalled learning',`In <b>Learning</b> but untouched for 14+ days (${q.stale.length}).`,q.stale.slice(0,12))}
  ${block('Rediscover',`Saved ${settings().staleDays}+ days ago and never opened from here (${q.forgotten.length.toLocaleString()} total). A random sample:`,sample,`<button class="btn btn-ghost btn-sm" id="reshuffle">${icon('shuffle')} Shuffle</button>`)}`;
  $('#reshuffle').onclick=()=>{R.reviewSample=null;render();};wireCommon(c);
  $$('[data-rv]',c).forEach(b=>b.onclick=e=>{e.stopPropagation();const r=State.byId.get(b.dataset.id);if(!r)return;const a=b.dataset.rv;
    if(a==='snooze1w'){r.reviewAt=addDays(today(),7);toast('Review again in a week');}else if(a==='snooze1m'){r.reviewAt=addDays(today(),30);toast('Review again in a month');}else if(a==='done'){setStatus(r,'done');r.reviewAt='';toast('Marked done');}else if(a==='archive'){r.archived=true;toast('Archived',{action:{label:'Undo',fn:()=>{r.archived=false;touch(r);render();}}});}else if(a==='learn'){setStatus(r,'next');r.openedAt=r.openedAt||new Date().toISOString();toast('Added to your To learn queue');}else if(a==='clear'){r.reviewAt='';toast('Review date cleared');}
    touch(r);render();});
}
function reviewCard(r){return cardHtml(r,{compact:true}).replace('</article>',`<div class="row" style="padding:0 10px 10px;gap:6px">${r.reviewAt?`<button class="btn btn-ghost btn-sm" data-rv="snooze1w" data-id="${r.id}">+1 week</button><button class="btn btn-ghost btn-sm" data-rv="snooze1m" data-id="${r.id}">+1 month</button>`:`<button class="btn btn-ghost btn-sm" data-rv="learn" data-id="${r.id}">To learn</button><button class="btn btn-ghost btn-sm" data-rv="snooze1m" data-id="${r.id}">Remind in a month</button>`}<button class="btn btn-ghost btn-sm" data-rv="done" data-id="${r.id}">Done</button><button class="btn btn-ghost btn-sm" data-rv="archive" data-id="${r.id}">Archive</button></div></article>`);}

/* ───── Archive & Trash ───── */
function renderArchive(c){renderLibrary(c,{pool:State.resources.filter(r=>!r.deletedAt&&r.archived),title:'Archive',noFilters:false,emptyTitle:'Archive is empty',emptyText:'Archived resources stay searchable from here but leave the library, dashboard and review queue. The 1,362 links the original app hid are archived on import.'});}
function renderTrash(c){
  const list=State.resources.filter(r=>r.deletedAt).sort((a,b)=>b.deletedAt.localeCompare(a.deletedAt));R.lastList=list;
  c.innerHTML=`<div class="row spread"><div><h3 style="font-size:20px;font-weight:700">Trash</h3><div class="small muted">Items are kept for ${TRASH_DAYS} days, then removed automatically.</div></div>${list.length?`<button class="btn btn-danger btn-sm" id="emptyTrash">Empty trash</button>`:''}</div>
  <div id="results" style="margin-top:14px">${list.length?`<div class="rlist">${list.map(r=>rowHtml(r).replace('<div class="d">',`<div class="d">deleted ${relTime(r.deletedAt)} · `)).join('')}</div>`:emptyHtml('Trash is empty','Deleted resources land here first so mistakes are recoverable.',null)}</div><div id="bulk"></div>`;
  $('#emptyTrash')?.addEventListener('click',()=>confirmModal('Empty trash?',`${plural(list.length,'item')} will be removed permanently. A safety snapshot is taken first.`,'Empty trash',async()=>{await takeSnapshot('Before emptying trash');list.forEach(r=>hardDelete(r.id));indexAll();render();toast('Trash emptied');}));
  renderBulk($('#bulk'),list);wireCommon(c);
}

/* ───── Settings & data ───── */
async function renderSettings(c){
  const s=settings();const live=State.resources.filter(r=>!r.deletedAt);const est=await Store.estimate();
  const usage=est?`${(est.usage/1048576).toFixed(1)} MB used${est.quota?` of ~${Math.round(est.quota/1048576).toLocaleString()} MB available`:''}`:'usage unknown';
  c.innerHTML=`<div class="settings-grid">
    <section class="card pad"><h4>Backup</h4><p>Everything is stored in this browser only. Download a full backup regularly and keep it somewhere safe (cloud drive, email to yourself). ${s.lastBackup?`Last backup: <b>${fmtDate(s.lastBackup.slice(0,10))}</b>.`:'<b>No backup recorded yet.</b>'}</p>
      <div class="row"><button class="btn btn-primary" id="sBackup">${icon('download')} Download backup (.json)</button><button class="btn btn-ghost" id="sRestore">${icon('upload')} Restore / import a file</button></div>
      <p style="margin-top:12px">${plural(live.length,'resource')} · ${plural(State.collections.length,'collection')} · ${plural(tagCounts(live).length,'tag')} · ${usage} (${Store.mode==='idb'?'IndexedDB':'localStorage fallback'})</p></section>
    <section class="card pad"><h4>Import</h4><p>Drop a file or choose one. Lantern recognises the format and shows a preview with duplicate counts before anything is written. A safety snapshot is taken first.</p>
      <div class="drop" id="drop" tabindex="0" role="button" aria-label="Choose or drop a file to import">Drop a file here or <b>click to choose</b><br><span class="small">WhatsApp chat export (.txt / .zip) · Browser bookmarks (.html) · NoteForge backup (.json) · the original NoteForge .html · Lantern backup (.json)</span></div>
      ${NOTEFORGE_SEED.length?`<p style="margin-top:12px"><button class="link-btn small" id="loadSeed">Load the ${NOTEFORGE_SEED.length.toLocaleString()} links embedded from NoteForge</button> (safe to repeat: duplicates are skipped)</p>`:''}</section>
    <section class="card pad"><h4>Export</h4><p>Portable copies for other tools. ${F.q||F.status||F.tag?'':'Exports include the whole library (not trash).'}</p>
      <div class="row"><button class="btn btn-ghost btn-sm" data-exp="csv">CSV</button><button class="btn btn-ghost btn-sm" data-exp="md">Markdown</button><button class="btn btn-ghost btn-sm" data-exp="html">Bookmarks HTML</button><button class="btn btn-ghost btn-sm" data-exp="json">JSON backup</button></div></section>
    <section class="card pad"><h4>Safety snapshots</h4><p>Taken automatically before imports, restores and permanent deletes (last ${MAX_SNAPSHOTS} kept, stored in this browser).</p>
      <div class="data-list">${State.snapshots.length?[...State.snapshots].reverse().map(sn=>`<div class="data-item"><div class="t">${esc(sn.reason)}<small>${new Date(sn.createdAt).toLocaleString()} · ${plural(sn.counts.resources,'resource')}</small></div><button class="btn btn-ghost btn-sm" data-snap="${sn.id}">Restore</button><button class="btn btn-ghost btn-sm" data-snapdl="${sn.id}">Download</button></div>`).join(''):'<div class="small muted">No snapshots yet.</div>'}</div>
      <div class="row" style="margin-top:10px"><button class="btn btn-ghost btn-sm" id="snapNow">Take a snapshot now</button></div></section>
    <section class="card pad"><h4>Appearance</h4>
      <div class="field"><label for="sTheme">Theme</label><select class="sel" id="sTheme"><option value="">System</option><option value="light">Light</option><option value="dark">Dark</option></select></div>
      <div class="field" style="margin-top:10px"><label for="sPage">Items per page</label><select class="sel" id="sPage"><option>30</option><option>60</option><option>120</option><option>240</option></select></div></section>
    <section class="card pad"><h4>Previews & privacy</h4><p>Lantern makes <b>no network requests</b> unless you enable these. Nothing is sent anywhere else.</p>
      <div class="field"><label for="sPrev">YouTube thumbnails</label><select class="sel" id="sPrev"><option value="off">Off (no requests)</option><option value="youtube">Show thumbnails (loads images from i.ytimg.com)</option></select><span class="help">Playing a video inside Lantern always loads that site's embedded player on demand.</span></div>
      <div class="field" style="margin-top:10px"><label for="sMeta">Fetch page titles on demand</label><select class="sel" id="sMeta"><option value="off">Off</option><option value="microlink">Allow via microlink.io (free public API, URL is sent to that service)</option></select><span class="help">Adds a "Fetch title & description" button in the resource panel. Fails gracefully when offline or rate-limited.</span></div></section>
    <section class="card pad"><h4>Review & import behaviour</h4>
      <div class="field"><label for="sStale">"Rediscover" picks items saved more than</label><select class="sel" id="sStale"><option value="30">30 days ago</option><option value="90">90 days ago</option><option value="120">120 days ago</option><option value="365">1 year ago</option></select></div>
      <div class="field" style="margin-top:10px"><label for="sDate">WhatsApp date format</label><select class="sel" id="sDate"><option value="auto">Detect automatically</option><option value="dmy">Day / Month / Year</option><option value="mdy">Month / Day / Year</option></select></div></section>
    <section class="card pad"><h4>Tags</h4><p>Rename or remove tags everywhere at once.</p><div class="data-list" id="tagList">${tagCounts(live).map(([t,n])=>`<div class="data-item"><div class="t">${esc(t)}<small>${plural(n,'resource')}</small></div><button class="btn btn-ghost btn-sm" data-tagren="${esc(t)}">Rename</button><button class="btn btn-ghost btn-sm" data-tagdel="${esc(t)}">Remove</button></div>`).join('')||'<div class="small muted">No tags yet.</div>'}</div></section>
    <section class="card pad"><h4>Collections</h4><div class="data-list">${State.collections.map(cl=>`<div class="data-item"><div class="t">${esc(cl.name)}<small>${plural(live.filter(r=>r.collection===cl.id).length,'resource')}</small></div><button class="btn btn-ghost btn-sm" data-collren="${cl.id}">Rename</button><button class="btn btn-ghost btn-sm" data-colldel="${cl.id}">Delete</button></div>`).join('')||'<div class="small muted">No collections yet.</div>'}</div><div class="row" style="margin-top:10px"><button class="btn btn-ghost btn-sm" id="sAddColl">+ New collection</button></div></section>
    <section class="card pad"><h4>Keyboard shortcuts</h4><p>Press <kbd class="k">?</kbd> anywhere to see them.</p><button class="btn btn-ghost btn-sm" id="sKeys">Show shortcuts</button></section>
    <section class="card pad"><h4>Danger zone</h4><p>Remove everything stored by Lantern in this browser. A snapshot cannot survive this, so download a backup first.</p><button class="btn btn-danger btn-sm" id="sWipe">Delete all data…</button></section>
  </div>`;
  $('#sBackup').onclick=doBackup;$('#sRestore').onclick=()=>pickFile(importFile,'.json,.txt,.zip,.html,.htm');
  const drop=$('#drop');drop.onclick=()=>pickFile(importFile,'.json,.txt,.zip,.html,.htm');drop.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();drop.click();}};
  drop.ondragover=e=>{e.preventDefault();drop.classList.add('over');};drop.ondragleave=()=>drop.classList.remove('over');drop.ondrop=e=>{e.preventDefault();drop.classList.remove('over');const f=e.dataTransfer.files[0];if(f)importFile(f);};
  $('#loadSeed')?.addEventListener('click',()=>previewImport(seedToItems(NOTEFORGE_SEED),'NoteForge embedded library'));
  $$('[data-exp]',c).forEach(b=>b.onclick=()=>doExport(b.dataset.exp));
  $$('[data-snap]',c).forEach(b=>b.onclick=()=>restoreSnapshot(b.dataset.snap));
  $$('[data-snapdl]',c).forEach(b=>b.onclick=()=>{const sn=State.snapshots.find(x=>x.id===b.dataset.snapdl);download(`lantern-snapshot-${sn.createdAt.slice(0,19).replace(/[:T]/g,'-')}.json`,JSON.stringify({app:APP_NAME,schema:SCHEMA_VERSION,exportedAt:sn.createdAt,snapshotReason:sn.reason,settings:sn.data.meta.settings,collections:sn.data.collections,resources:sn.data.resources},null,1));});
  $('#snapNow').onclick=async()=>{await takeSnapshot('Manual snapshot');render();toast('Snapshot saved');};
  const sel=(id,key,cast=v=>v)=>{const el=$(id);el.value=String(s[key]??'');el.onchange=()=>{s[key]=cast(el.value);saveSettings();applyTheme();render();};};
  sel('#sTheme','theme');sel('#sPage','pageSize',Number);sel('#sPrev','previews');sel('#sMeta','metadataService');sel('#sStale','staleDays',Number);sel('#sDate','dateOrder');
  $$('[data-tagren]',c).forEach(b=>b.onclick=()=>promptModal('Rename tag',`New name for "${b.dataset.tagren}"`,v=>{if(v&&v!==b.dataset.tagren){const n=renameTag(b.dataset.tagren,v);render();toast(`Renamed on ${plural(n,'resource')}`);}},{value:b.dataset.tagren}));
  $$('[data-tagdel]',c).forEach(b=>b.onclick=()=>confirmModal('Remove tag?',`"${b.dataset.tagdel}" will be removed from every resource. Resources themselves are kept.`,'Remove tag',()=>{const n=deleteTag(b.dataset.tagdel);render();toast(`Removed from ${plural(n,'resource')}`);}));
  $$('[data-collren]',c).forEach(b=>b.onclick=()=>promptCollection(b.dataset.collren));
  $$('[data-colldel]',c).forEach(b=>b.onclick=()=>confirmModal('Delete collection?',`"${collName(b.dataset.colldel)}" will be deleted. Its resources stay in the library.`,'Delete collection',()=>{deleteCollection(b.dataset.colldel);render();}));
  $('#sAddColl').onclick=()=>promptCollection();$('#sKeys').onclick=showShortcuts;
  $('#sWipe').onclick=()=>confirmModal('Delete ALL data in this browser?','This removes every resource, collection, setting and snapshot stored by Lantern here. Download a backup first. Type DELETE below to confirm.','Delete everything',async()=>{try{await flushNow();Store.closed=true;if(Store.mode==='idb'){Store.db.close();await new Promise((ok,bad)=>{const r=indexedDB.deleteDatabase(DB_NAME);r.onsuccess=ok;r.onerror=bad;r.onblocked=ok;});}localStorage.removeItem(LS_KEY);}catch(e){console.error(e);}location.hash='';location.reload();},{typed:'DELETE'});
}
function applyTheme(){const t=settings().theme;if(t)document.documentElement.dataset.theme=t;else delete document.documentElement.dataset.theme;const dark=t==='dark'||(!t&&matchMedia('(prefers-color-scheme: dark)').matches);$('#themeBtn').innerHTML=icon(dark?'sun':'moon');}
function doBackup(){const s=settings();s.lastBackup=new Date().toISOString();saveSettings();download(`lantern-backup-${today()}.json`,exportBackupJson());render();toast('Backup downloaded. Keep the file somewhere safe.');}
function doExport(kind){const list=sortList(State.resources.filter(r=>!r.deletedAt),'saved-desc');const d=today();
  if(kind==='csv')download(`lantern-${d}.csv`,exportCsv(list),'text/csv;charset=utf-8');else if(kind==='md')download(`lantern-${d}.md`,exportMarkdown(list),'text/markdown');else if(kind==='html')download(`lantern-bookmarks-${d}.html`,exportBookmarksHtml(list),'text/html');else doBackup();}
function pickFile(cb,accept){const i=$('#fileInput');i.accept=accept||'';i.value='';i.onchange=()=>{const f=i.files[0];if(f)cb(f);};i.click();}
async function restoreSnapshot(id){const sn=State.snapshots.find(x=>x.id===id);if(!sn)return;
  confirmModal('Restore this snapshot?',`Your current library (${plural(State.resources.length,'resource')}) will be replaced by the snapshot from ${new Date(sn.createdAt).toLocaleString()} (${plural(sn.counts.resources,'resource')}). A snapshot of the current state is taken first, so you can switch back.`,'Restore snapshot',async()=>{
    await takeSnapshot('Before restoring snapshot');State.resources=JSON.parse(JSON.stringify(sn.data.resources));State.collections=JSON.parse(JSON.stringify(sn.data.collections));indexAll();invalidateSearch();await Store.writeAll();render();toast('Snapshot restored');});}

/* ───── Import flow ───── */
async function importFile(file){
  try{let parsed;
    if(/\.zip$/i.test(file.name)){const files=await unzipTextFiles(await readFileBuffer(file));const txt=files.find(f=>/\.txt$/i.test(f.name));if(!txt)throw new Error('No .txt chat file found inside the ZIP.');parsed=parseWhatsApp(txt.text,settings().dateOrder);parsed._text=txt.text;}
    else{const text=await readFileText(file);parsed=detectAndParse(file.name,text);if(parsed.kind==='whatsapp')parsed._text=text;}
    previewImport(parsed,file.name);
  }catch(e){console.warn('Import rejected:',e.message);modal('Import failed',`<div class="notice danger">${icon('x')}<div>${esc(e.message||String(e))}</div></div><p class="small muted">Nothing was changed.</p>`,[{label:'Close',cls:'btn-ghost',close:true}]);}
}
function previewImport(parsed,sourceName){
  const a=analyzeImport(parsed.items);const isLantern=parsed.kind==='lantern-backup';const isNF=parsed.kind==='noteforge-backup';
  const needSeed=isNF&&NOTEFORGE_SEED.length&&!NOTEFORGE_SEED.slice(0,50).some(v=>State.byKey.has(canon(v.u)));
  const sample=l=>l.slice(0,6).map(x=>{const r=Array.isArray(x)?x[0]:x;return `<div><span class="u">${esc(r.title||r.url)}</span><span class="small muted">${esc(r.savedAt)}</span></div>`;}).join('')+(l.length>6?`<div class="small muted">… and ${l.length-6} more</div>`:'');
  const body=`<div class="notice">${icon('upload')}<div><b>${esc(sourceName)}</b><br><span class="small">${esc(parsed.info)}</span></div></div>
    <div class="counts"><div><div class="v">${a.fresh.length.toLocaleString()}</div><div class="k">New</div></div><div><div class="v">${a.dupExisting.length.toLocaleString()}</div><div class="k">Already in library</div></div><div><div class="v">${a.dupInFile.length.toLocaleString()}</div><div class="k">Repeated in file</div></div><div><div class="v">${parsed.invalid.length.toLocaleString()}</div><div class="k">Skipped (invalid)</div></div></div>
    ${a.fresh.length?`<div><b class="small">New items (preview)</b><div class="import-list">${sample(a.fresh)}</div></div>`:''}
    ${a.dupExisting.length?`<label class="opt"><input type="checkbox" id="impEnrich" ${isNF||isLantern?'checked':''}><div><b>Merge details from the ${a.dupExisting.length.toLocaleString()} duplicates into the existing items</b><span>Adds missing titles, notes, tags, status and images to what you already have. Never removes anything. Unticked: duplicates are skipped entirely.</span></div></label>`:''}
    ${parsed.invalid.length?`<details><summary class="small">Skipped records (${parsed.invalid.length})</summary><div class="import-list">${parsed.invalid.slice(0,50).map(x=>`<div><span class="u">${esc(x)}</span></div>`).join('')}</div></details>`:''}
    ${isLantern?`<label class="opt"><input type="radio" name="impMode" value="merge" checked><div><b>Merge into current library</b><span>Keeps everything you have; adds new items and fills gaps.</span></div></label><label class="opt"><input type="radio" name="impMode" value="replace"><div><b>Replace current library with this backup</b><span>Current data is snapshotted first, then replaced by the ${parsed.items.length.toLocaleString()} resources in the file.</span></div></label>`:''}
    ${needSeed?`<label class="opt"><input type="checkbox" id="impSeed" checked><div><b>Also load the ${NOTEFORGE_SEED.length.toLocaleString()} links built into the original NoteForge app</b><span>NoteForge backups only contain your tracker entries, imported links and hidden links; the base library was embedded in the app itself. Hidden links are archived.</span></div></label>`:''}
    ${!isLantern?`<div class="grid2"><div class="field"><label for="impColl">Put new items in a collection (optional)</label><select class="sel" id="impColl"><option value="">None</option>${State.collections.map(c=>`<option value="${c.id}">${esc(c.name)}</option>`).join('')}<option value="__new">+ New collection…</option></select></div><div class="field"><label for="impTag">Add a tag to new items (optional)</label><input class="inp" id="impTag" placeholder="e.g. bookmarks-2026"></div></div>`:''}
    ${parsed.kind==='whatsapp'?`<div class="field"><label for="impDate">Dates were read as ${parsed.dateOrder==='dmy'?'day/month/year':'month/day/year'}. Wrong?</label><select class="sel" id="impDate"><option value="${parsed.dateOrder}">Keep</option><option value="${parsed.dateOrder==='dmy'?'mdy':'dmy'}">Re-read as ${parsed.dateOrder==='dmy'?'month/day/year':'day/month/year'}</option></select></div>`:''}
    <p class="small muted">A safety snapshot of the current library is saved before anything is written. Undo is available right after the import.</p>`;
  modal('Import preview',body,[{label:'Cancel',cls:'btn-ghost',close:true},{label:a.fresh.length||a.dupExisting.length||needSeed?`Import ${a.fresh.length.toLocaleString()} new`:'Nothing to import',cls:'btn-primary',disabled:!(a.fresh.length||a.dupExisting.length||needSeed||isLantern),fn:async()=>{
      const dateSel=$('#impDate');if(dateSel&&dateSel.value!==parsed.dateOrder&&parsed._text){closeModal();previewImport(parseWhatsApp(parsed._text,dateSel.value),sourceName);return;}
      const mode=$('input[name=impMode]:checked')?.value||'merge';const enrich=$('#impEnrich')?.checked;let collId=$('#impColl')?.value||'';const tag=($('#impTag')?.value||'').trim();
      if(collId==='__new'){closeModal();promptCollection(null,c=>{collId=c.id;finish();});return;}
      finish();
      async function finish(){
        await takeSnapshot('Before import: '+sourceName);
        if(mode==='replace'){State.resources=[];State.collections=[];indexAll();}
        if(isLantern){parsed.collections.forEach(c=>{if(!State.collections.some(x=>x.id===c.id))State.collections.push({id:c.id,name:c.name,createdAt:c.createdAt||new Date().toISOString()});State.dirty.collections.add(c.id);});if(parsed.settings&&mode==='replace'){Object.assign(settings(),parsed.settings);saveSettings();}}
        let seedRes={created:[],enriched:[]};
        if(needSeed&&$('#impSeed')?.checked){const seed=seedToItems(NOTEFORGE_SEED);seedRes=applyImport(analyzeImport(seed.items),{mode:'skip'});}
        if(parsed.hidden?.size){parsed.hidden.forEach(u=>{const r=State.byKey.get(canon(u));if(r&&!r.archived){r.archived=true;touch(r);}});}
        // NoteForge: tracker entries for a library video should merge, not duplicate
        const an=analyzeImport(parsed.items);
        if(isNF){an.dupExisting.forEach(([r,ex])=>{if(r.legacy?.kind==='entry'&&ex.source==='whatsapp'){mergeEntryIntoVideo(ex,r);invalidateSearch(ex);touch(ex);}});}
        const res=applyImport(an,{mode:enrich?'enrich':'skip',collection:collId,tags:tag?[tag]:[]});
        if(mode==='replace')await Store.writeAll();
        invalidateSearch();closeModal();R.reviewSample=null;go('library');
        const total=res.created.length+seedRes.created.length;
        toast(`Imported ${plural(total,'new resource')}${res.enriched.length?` · ${res.enriched.length} updated`:''}${a.dupExisting.length&&!enrich?` · ${a.dupExisting.length} duplicates skipped`:''}`,{action:total||res.enriched.length?{label:'Undo',fn:()=>{[...res.created,...seedRes.created].forEach(hardDelete);res.before.forEach(b=>{const cur=State.byId.get(b.id);if(cur)Object.assign(cur,b);State.dirty.resources.add(b.id);});indexAll();scheduleFlush();render();toast('Import undone');}}:null});
      }}}],{wide:true});
}

/* ───── Detail panel ───── */
const Detail={id:null,draft:null,preview:false,returnFocus:null};
function openDetail(id,o={}){const r=State.byId.get(id);if(!r)return;Detail.id=id;Detail.draft=JSON.parse(JSON.stringify(r));Detail.preview=!!r.notes.trim()&&!o.edit;Detail.play=!!o.play;Detail.returnFocus=document.activeElement;
  $('#panelWrap').classList.add('open');document.body.style.overflow='hidden';renderDetail();setTimeout(()=>$('#panelBody input,#panelBody textarea,#panelBody button')?.focus(),30);}
function closeDetail(){if(Detail.id&&isDirty()){if(!saveDetail(true))return;}$('#panelWrap').classList.remove('open');document.body.style.overflow='';Detail.id=null;Detail.returnFocus?.focus?.();render();}
function isDirty(){const r=State.byId.get(Detail.id);if(!r)return false;const d=Detail.draft;return ['url','title','description','notes','collection','status','priority','reviewAt','savedAt','image'].some(k=>r[k]!==d[k])||r.tags.join('\u0001')!==d.tags.join('\u0001');}
function renderDetail(){
  const r=State.byId.get(Detail.id);if(!r)return closeDetail();const d=Detail.draft;const s=settings();
  $('#panelTitle').textContent=d.title||d.url||'New resource';
  const fav=$('#panelFav');fav.classList.toggle('on',r.favorite);fav.setAttribute('aria-pressed',String(r.favorite));fav.onclick=()=>{r.favorite=!r.favorite;touch(r);renderDetail();};
  const op=$('#panelOpen');if(d.url){op.href=d.url;op.classList.remove('hidden');op.onclick=()=>markOpened(r);}else op.classList.add('hidden');
  const dup=d.url?findDuplicate(d.url,r.id):null;const emb=d.url?embedFor(d.url):null;const yt=ytId(d.url);const img=safeImg(d.image)||(yt&&s.previews!=='off'?`https://i.ytimg.com/vi/${yt}/hqdefault.jpg`:'');
  const tagsAll=tagCounts().map(x=>x[0]);const sugg=tagsAll.filter(t=>!d.tags.includes(t)).slice(0,8);
  $('#panelBody').innerHTML=`
    ${dup?`<div class="dup-warn">${icon('link')}<div>Looks like a duplicate of <button class="link-btn small" data-open-dup="${dup.id}">${esc(dup.title||dup.url)}</button> (saved ${fmtDate(dup.savedAt)}).</div></div>`:''}
    <div class="field"><label for="dTitle" class="sr-only">Title</label><input class="inp title-input" id="dTitle" placeholder="Title" value="${esc(d.title)}"></div>
    <div class="field"><label for="dUrl">Link</label><div class="inline-edit"><input class="inp" id="dUrl" type="url" placeholder="https://… (optional for a pure note)" value="${esc(d.url)}" style="flex:1">${d.url?`<button class="btn-icon" id="dCopyUrl" title="Copy link" aria-label="Copy link">${icon('copy')}</button>`:''}</div>${d.url&&!safeUrl(d.url)?'<span class="help" style="color:var(--danger)">Must start with http:// or https://</span>':''}</div>
    ${Detail.play&&emb?`<div class="preview-box ${emb.tall?'tall':''}"><iframe src="${esc(emb.src)}" title="${esc(emb.label)} player" allow="autoplay; encrypted-media; picture-in-picture; fullscreen" allowfullscreen referrerpolicy="strict-origin-when-cross-origin"></iframe></div><div class="small muted">Won't play? Some videos block embedding or are private. Use the open-link button above.</div>`:emb?`<div class="row"><button class="btn btn-ghost btn-sm" id="dPlay">${icon('play')} Play ${esc(emb.label)} here</button>${img?`<img src="${esc(img)}" alt="" style="height:36px;border-radius:6px" onerror="this.remove()">`:''}</div>`:(img?`<img src="${esc(img)}" alt="" style="max-height:160px;border-radius:8px;object-fit:cover;align-self:flex-start" onerror="this.remove()">`:'')}
    <div class="grid3">
      <div class="field"><label for="dStatus">Status</label><select class="sel" id="dStatus">${STATUSES.map(([k,l])=>`<option value="${k}" ${d.status===k?'selected':''}>${l}</option>`).join('')}</select></div>
      <div class="field"><label for="dPrio">Priority</label><select class="sel" id="dPrio">${PRIORITIES.map(([k,l])=>`<option value="${k}" ${d.priority===k?'selected':''}>${l}</option>`).join('')}</select></div>
      <div class="field"><label for="dColl">Collection</label><select class="sel" id="dColl"><option value="">None</option>${State.collections.map(c=>`<option value="${c.id}" ${d.collection===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}<option value="__new">+ New collection…</option></select></div>
      <div class="field"><label for="dSaved">Saved on</label><input class="inp" type="date" id="dSaved" value="${esc(d.savedAt)}"></div>
      <div class="field"><label for="dReview">Review on <span class="muted">(optional)</span></label><input class="inp" type="date" id="dReview" value="${esc(d.reviewAt)}"></div>
      <div class="field"><label>&nbsp;</label><div class="row" style="gap:4px"><button class="btn btn-ghost btn-sm" data-rv="7">+1w</button><button class="btn btn-ghost btn-sm" data-rv="30">+1m</button><button class="btn btn-ghost btn-sm" data-rv="90">+3m</button></div></div>
    </div>
    <div class="field"><label for="dTagIn">Tags</label><div class="tags-edit" id="dTags">${d.tags.map(t=>`<span class="tag">${esc(t)}<button type="button" data-rm="${esc(t)}" aria-label="Remove tag ${esc(t)}">×</button></span>`).join('')}<input id="dTagIn" list="tagOpts" placeholder="${d.tags.length?'Add tag…':'Add tags (Enter or comma)'}" autocomplete="off"><datalist id="tagOpts">${tagsAll.map(t=>`<option value="${esc(t)}">`).join('')}</datalist></div>${sugg.length?`<div class="sugg">${sugg.map(t=>`<button type="button" data-add="${esc(t)}">+ ${esc(t)}</button>`).join('')}</div>`:''}</div>
    <div class="field"><label for="dDesc">Description <span class="muted">(what is this?)</span></label><textarea class="inp" id="dDesc" rows="2" placeholder="One or two lines about this resource">${esc(d.description)}</textarea></div>
    <div class="field"><div class="row spread"><label for="dNotes">Notes & takeaways <span class="muted">(Markdown)</span></label><div class="seg"><button type="button" data-nm="edit" aria-pressed="${!Detail.preview}">Write</button><button type="button" data-nm="preview" aria-pressed="${Detail.preview}">Preview</button></div></div>
      ${Detail.preview?`<div class="md" id="dMd">${renderMarkdown(d.notes)}</div>`:`<textarea class="inp" id="dNotes" rows="9" placeholder="What did you learn? Key points, next steps, quotes…&#10;&#10;Supports # headings, **bold**, - lists, - [ ] tasks, > quotes, \`code\` and links.">${esc(d.notes)}</textarea>`}</div>
    ${s.metadataService==='microlink'&&d.url?`<div class="row"><button class="btn btn-ghost btn-sm" id="dFetch">Fetch title & description from the page</button><span class="small muted" id="dFetchMsg"></span></div>`:''}
    <div class="hist">${d.url?`<span>${esc(platformOf(d.url))}</span>`:''}<span>Source: ${esc(r.source)}${r.folder?` · ${esc(r.folder)}`:''}</span><span>Created ${fmtDate(r.createdAt.slice(0,10))}</span><span>Updated ${relTime(r.updatedAt.slice(0,10))}</span>${r.openedAt?`<span>Opened ${relTime(r.openedAt.slice(0,10))}</span>`:''}${r.completedAt?`<span>Done ${fmtDate(r.completedAt.slice(0,10))}</span>`:''}${r.legacy?.timesShared>1?`<span>Shared ${r.legacy.timesShared}× in WhatsApp</span>`:''}${r.legacy?.time?`<span>at ${esc(r.legacy.time)}</span>`:''}</div>`;
  $('#panelFoot').innerHTML=`<button class="btn btn-ghost btn-sm" id="dCopy" title="Copy title, link and notes as plain text">${icon('copy')} Copy as text</button><button class="btn btn-ghost btn-sm" id="dArch">${r.archived?'Unarchive':'Archive'}</button><button class="btn btn-danger btn-sm" id="dDel">${r.deletedAt?'Delete permanently':'Delete'}</button>${r.deletedAt?`<button class="btn btn-ghost btn-sm" id="dRestore">Restore from trash</button>`:''}<div class="right"><span class="small muted" id="dSaveMsg"></span><button class="btn btn-primary" id="dSave">Save</button></div>`;
  const B=$('#panelBody');
  const bindField=(id,k,cast=v=>v)=>{const el=$(id);if(!el)return;el.addEventListener('input',()=>{d[k]=cast(el.value);if(k==='title')$('#panelTitle').textContent=d.title||d.url||'New resource';markDirty();});};
  bindField('#dTitle','title',v=>v.trim().slice(0,500));bindField('#dUrl','url',v=>v.trim());bindField('#dDesc','description');bindField('#dNotes','notes');bindField('#dSaved','savedAt');bindField('#dReview','reviewAt');
  $('#dUrl').addEventListener('change',renderDetail);
  $('#dStatus').onchange=e=>{d.status=e.target.value;markDirty();};$('#dPrio').onchange=e=>{d.priority=+e.target.value;markDirty();};
  $('#dColl').onchange=e=>{if(e.target.value==='__new'){promptCollection(null,c=>{d.collection=c.id;markDirty();renderDetail();},()=>renderDetail());return;}d.collection=e.target.value;markDirty();};
  $$('[data-rv]',B).forEach(b=>b.onclick=()=>{d.reviewAt=addDays(today(),+b.dataset.rv);markDirty();renderDetail();});
  const tin=$('#dTagIn');const addTag=t=>{t=t.trim().replace(/^#/,'').slice(0,60);if(t&&!d.tags.includes(t)){d.tags.push(t);markDirty();renderDetail();setTimeout(()=>$('#dTagIn')?.focus(),0);}};
  tin.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===','){e.preventDefault();addTag(tin.value);tin.value='';}else if(e.key==='Backspace'&&!tin.value&&d.tags.length){d.tags.pop();markDirty();renderDetail();setTimeout(()=>$('#dTagIn')?.focus(),0);}});
  tin.addEventListener('blur',()=>{if(tin.value.trim())addTag(tin.value);});
  $$('[data-rm]',B).forEach(b=>b.onclick=()=>{d.tags=d.tags.filter(t=>t!==b.dataset.rm);markDirty();renderDetail();});
  $$('[data-add]',B).forEach(b=>b.onclick=()=>addTag(b.dataset.add));
  $$('[data-nm]',B).forEach(b=>b.onclick=()=>{Detail.preview=b.dataset.nm==='preview';renderDetail();});
  $('#dPlay')?.addEventListener('click',()=>{Detail.play=true;markOpened(r);renderDetail();});
  $('#dCopyUrl')?.addEventListener('click',()=>copyText(d.url,'Link copied'));
  $('[data-open-dup]',B)?.addEventListener('click',e=>{saveDetail(true);openDetail(e.target.dataset.openDup);});
  $('#dFetch')?.addEventListener('click',()=>fetchMetadata(d));
  $('#dCopy').onclick=()=>copyText(resourceToPlainText(d),'Copied as plain text');
  $('#dSave').onclick=()=>saveDetail();
  $('#dArch').onclick=()=>{r.archived=!r.archived;touch(r);toast(r.archived?'Archived':'Unarchived');closeDetail();};
  $('#dDel').onclick=()=>{if(r.deletedAt){confirmModal('Delete permanently?','This cannot be undone.','Delete permanently',()=>{hardDelete(r.id);indexAll();Detail.id=null;$('#panelWrap').classList.remove('open');document.body.style.overflow='';render();toast('Deleted permanently');});return;}
    r.deletedAt=new Date().toISOString();touch(r);Detail.id=null;$('#panelWrap').classList.remove('open');document.body.style.overflow='';render();toast('Moved to trash',{action:{label:'Undo',fn:()=>{r.deletedAt=null;touch(r);render();}}});};
  $('#dRestore')?.addEventListener('click',()=>{r.deletedAt=null;touch(r);toast('Restored');closeDetail();});
  markDirty(false);
}
function markDirty(force){const m=$('#dSaveMsg');if(!m)return;const dirty=force===false?isDirty():true;m.textContent=dirty?'Unsaved changes':'';}
function saveDetail(silent){const r=State.byId.get(Detail.id);if(!r)return;const d=Detail.draft;
  if(d.url&&!safeUrl(d.url)){toast('The link must start with http:// or https://');$('#dUrl')?.focus();return false;}
  if(!d.url&&!d.title.trim()&&!d.notes.trim()){toast('Add a title, a link or some notes first.');$('#dTitle')?.focus();return false;}
  if(!validDate(d.savedAt))d.savedAt=r.savedAt;if(d.reviewAt&&!validDate(d.reviewAt))d.reviewAt='';
  const wasDone=r.status==='done';Object.assign(r,{url:d.url,key:canon(d.url),title:d.title.trim(),description:d.description,notes:d.notes,tags:d.tags,collection:d.collection,status:d.status,priority:d.priority,reviewAt:d.reviewAt,savedAt:d.savedAt});
  if(r.status==='done'&&!wasDone)r.completedAt=new Date().toISOString();if(r.status!=='done')r.completedAt='';
  invalidateSearch(r);touch(r);indexAll();Detail.draft=JSON.parse(JSON.stringify(r));
  if(!silent){toast('Saved');markDirty(false);render();}return true;}
async function fetchMetadata(d){const msg=$('#dFetchMsg');msg.textContent='Fetching…';
  try{const ctl=new AbortController();const t=setTimeout(()=>ctl.abort(),8000);const res=await fetch(`https://api.microlink.io/?url=${encodeURIComponent(d.url)}&palette=false&audio=false&video=false&iframe=false&screenshot=false`,{signal:ctl.signal});clearTimeout(t);
    const j=res.ok?await res.json():null;if(!j||j.status!=='success')throw new Error(res.status===429?'Rate limit reached, try later.':'No metadata returned.');
    let changed=[];if(j.data.title&&(!d.title||d.title===hostOf(d.url)+' link')){d.title=j.data.title.slice(0,500);changed.push('title');}else if(j.data.title&&!d.description){d.description=j.data.title;changed.push('description');}
    if(j.data.description&&!d.description){d.description=j.data.description.slice(0,2000);changed.push('description');}else if(j.data.description&&!d.notes.includes(j.data.description)){d.notes=(d.notes?d.notes+'\n\n':'')+'> '+j.data.description;changed.push('notes');}
    if(j.data.image?.url&&!d.image)d.image=safeImg(j.data.image.url);
    markDirty();renderDetail();toast(changed.length?'Fetched '+changed.join(', ')+'. Review and save.':'Nothing new to add.');
  }catch(e){msg.textContent='Could not fetch ('+(e.name==='AbortError'?'timed out':e.message)+'). You can type a title yourself.';}}
async function copyText(text,okMsg){try{await navigator.clipboard.writeText(text);toast(okMsg);}catch(e){const ta=document.createElement('textarea');ta.value=text;document.body.appendChild(ta);ta.select();try{document.execCommand('copy');toast(okMsg);}catch(_){toast('Copy failed. Select the text manually.');}ta.remove();}}

/* ───── Quick save ───── */
function quickSave(prefill={}){
  const body=`<div class="field"><label for="qsUrl">Link</label><input class="inp" id="qsUrl" type="url" placeholder="https://… (leave empty for a plain note)" value="${esc(prefill.url||'')}"><span class="help" id="qsDup"></span></div>
    <div class="field"><label for="qsTitle">Title</label><input class="inp" id="qsTitle" placeholder="What is it?" value="${esc(prefill.title||'')}"></div>
    <div class="grid2"><div class="field"><label for="qsStatus">Status</label><select class="sel" id="qsStatus">${STATUSES.map(([k,l])=>`<option value="${k}" ${k==='next'?'selected':''}>${l}</option>`).join('')}</select></div><div class="field"><label for="qsColl">Collection</label><select class="sel" id="qsColl"><option value="">None</option>${State.collections.map(c=>`<option value="${c.id}" ${F.coll===c.id?'selected':''}>${esc(c.name)}</option>`).join('')}</select></div></div>
    <div class="field"><label for="qsTags">Tags <span class="muted">(comma separated)</span></label><input class="inp" id="qsTags" list="qsTagOpts" placeholder="ai, course" value="${esc(F.tag||'')}"><datalist id="qsTagOpts">${tagCounts().map(([t])=>`<option value="${esc(t)}">`).join('')}</datalist></div>
    <div class="field"><label for="qsNotes">Notes</label><textarea class="inp" id="qsNotes" rows="3" placeholder="Optional first thoughts…"></textarea></div>`;
  modal('Save a resource',body,[{label:'Cancel',cls:'btn-ghost',close:true},{label:'Save & open',cls:'btn-ghost',fn:()=>doQuick(true)},{label:'Save',cls:'btn-primary',fn:()=>doQuick(false)}]);
  const u=$('#qsUrl');const check=()=>{const v=u.value.trim();const dup=v?findDuplicate(v):null;const el=$('#qsDup');if(v&&!safeUrl(v)){el.textContent='Link must start with http:// or https://';el.style.color='var(--danger)';}else if(dup){el.innerHTML=`Already saved: <button class="link-btn small" id="qsOpenDup">${esc(dup.title||dup.url)}</button>`;el.style.color='var(--warn)';$('#qsOpenDup').onclick=()=>{closeModal();openDetail(dup.id);};}else{el.textContent='';}};
  u.addEventListener('input',debounce(check,150));check();setTimeout(()=>u.focus(),30);
  $('#modalBody').addEventListener('keydown',e=>{if(e.key==='Enter'&&e.target.tagName!=='TEXTAREA'&&(e.ctrlKey||e.metaKey||e.target.tagName==='INPUT'))doQuick(false);});
  function doQuick(open){const url=u.value.trim(),title=$('#qsTitle').value.trim(),notes=$('#qsNotes').value;
    if(url&&!safeUrl(url)){toast('Link must start with http:// or https://');return;}if(!url&&!title&&!notes.trim()){toast('Add a link, a title or a note.');return;}
    const dup=url?findDuplicate(url):null;if(dup&&!confirm('This link is already in your library. Save it again anyway?'))return;
    const r=newResource({url,title,notes,status:$('#qsStatus').value,collection:$('#qsColl').value,tags:[...new Set($('#qsTags').value.split(',').map(t=>t.trim()).filter(Boolean))]});
    upsertResource(r);indexAll();closeModal();render();if(open)openDetail(r.id,{edit:true});else toast('Saved',{action:{label:'Open',fn:()=>openDetail(r.id)}});}
}

/* ───── Modals ───── */
let modalReturn=null;
function modal(title,bodyHtml,buttons=[],o={}){modalReturn=document.activeElement;$('#modalTitle').textContent=title;$('#modalBody').innerHTML=bodyHtml;$('#modal').classList.toggle('wide',!!o.wide);
  $('#modalFoot').innerHTML=buttons.map((b,i)=>`<button class="btn ${b.cls||'btn-ghost'}" data-mb="${i}" ${b.disabled?'disabled':''}>${esc(b.label)}</button>`).join('');
  buttons.forEach((b,i)=>$(`[data-mb="${i}"]`).onclick=()=>{if(b.close)closeModal();else b.fn?.();});
  $('#modalWrap').classList.add('open');document.body.style.overflow='hidden';setTimeout(()=>($('#modalBody input:not([type=hidden]),#modalBody select,#modalBody textarea,#modalBody button')||$('#modalFoot button'))?.focus(),20);}
function closeModal(){$('#modalWrap').classList.remove('open');if(!$('#panelWrap').classList.contains('open'))document.body.style.overflow='';modalReturn?.focus?.();}
function confirmModal(title,text,label,fn,o={}){modal(title,`<p>${esc(text)}</p>${o.typed?`<input class="inp" id="cfTyped" placeholder="Type ${esc(o.typed)}" autocomplete="off" style="margin-top:8px">`:''}`,[{label:'Cancel',cls:'btn-ghost',close:true},{label,cls:'btn-danger',fn:()=>{if(o.typed&&$('#cfTyped').value.trim()!==o.typed){toast(`Type ${o.typed} to confirm.`);return;}closeModal();fn();}}]);}
function promptModal(title,label,fn,o={}){modal(title,`<div class="field"><label for="pmIn">${esc(label)}</label><input class="inp" id="pmIn" value="${esc(o.value||'')}" ${o.list?'list="pmList"':''} autocomplete="off">${o.list?`<datalist id="pmList">${o.list.map(v=>`<option value="${esc(v)}">`).join('')}</datalist>`:''}</div>`,[{label:'Cancel',cls:'btn-ghost',close:true},{label:o.ok||'OK',cls:'btn-primary',fn:()=>{const v=$('#pmIn').value.trim();closeModal();fn(v);}}]);$('#pmIn').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('[data-mb="1"]').click();}});}
function promptCollection(id,after,onCancel){const c=id?State.collections.find(x=>x.id===id):null;
  modal(c?'Rename collection':'New collection',`<div class="field"><label for="pmIn">Name</label><input class="inp" id="pmIn" value="${esc(c?.name||'')}" placeholder="e.g. Python course, Trading basics"></div>${c?`<div class="row"><button class="btn btn-danger btn-sm" id="pcDel">Delete collection</button><span class="small muted">Resources are kept.</span></div>`:''}`,[{label:'Cancel',cls:'btn-ghost',fn:()=>{closeModal();onCancel?.();}},{label:c?'Rename':'Create',cls:'btn-primary',fn:()=>{const v=$('#pmIn').value.trim();if(!v)return;closeModal();if(c){renameCollection(c.id,v);render();}else{const nc=addCollection(v);render();after?.(nc);}}}]);
  $('#pmIn').addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();$('[data-mb="1"]').click();}});
  $('#pcDel')?.addEventListener('click',()=>{closeModal();confirmModal('Delete collection?',`"${c.name}" will be deleted. Its resources stay in the library.`,'Delete collection',()=>{deleteCollection(c.id);if(F.coll===c.id)F.coll='';render();});});}
function showShortcuts(){modal('Keyboard shortcuts',`<div class="kbd-list">
  <kbd class="k">/</kbd><span>Focus search (also Ctrl/⌘ K)</span><kbd class="k">n</kbd><span>Save a new resource</span><kbd class="k">?</kbd><span>This help</span><kbd class="k">Esc</kbd><span>Close panel or dialog</span>
  <kbd class="k">g d</kbd><span>Go to Dashboard</span><kbd class="k">g l</kbd><span>Go to Library</span><kbd class="k">g r</kbd><span>Go to Review queue</span><kbd class="k">g s</kbd><span>Go to Settings & data</span>
  <kbd class="k">Tab / j / k</kbd><span>Move between cards</span><kbd class="k">Enter</kbd><span>Open the focused card</span><kbd class="k">o</kbd><span>Open its link in a new tab</span><kbd class="k">f</kbd><span>Toggle favorite</span><kbd class="k">s</kbd><span>Cycle status (Saved → To learn → Learning → Done)</span><kbd class="k">x</kbd><span>Select for bulk actions (Shift/Ctrl-click also works)</span>
  <kbd class="k">Ctrl/⌘ S</kbd><span>Save in the resource panel</span><kbd class="k">Ctrl/⌘ Z</kbd><span>Undo last bulk action (outside text fields)</span></div>`,[{label:'Close',cls:'btn-primary',close:true}]);}

/* ───── Welcome (first run) ───── */
function showWelcome(){
  modal('Welcome to Lantern',`<p>Lantern is a local-first learning library: save links, organise them, take notes and let the review queue bring forgotten finds back. Everything stays in this browser until you export it.</p>
    <p class="small muted">How do you want to start?</p>
    ${NOTEFORGE_SEED.length?`<label class="opt"><input type="radio" name="wl" value="seed" checked><div><b>Load the ${NOTEFORGE_SEED.length.toLocaleString()} links embedded from the NoteForge app</b><span>Your WhatsApp-saved library, with original notes, dates and topics kept. Then import a NoteForge backup to add your tracker entries and hidden links.</span></div></label>`:''}
    <label class="opt"><input type="radio" name="wl" value="file" ${NOTEFORGE_SEED.length?'':'checked'}><div><b>Import a file now</b><span>NoteForge backup (.json), WhatsApp export (.txt/.zip), browser bookmarks (.html) or a Lantern backup.</span></div></label>
    <label class="opt"><input type="radio" name="wl" value="empty"><div><b>Start empty</b><span>You can import anything later from Settings & data.</span></div></label>
    <label class="opt"><input type="checkbox" id="wlPrev"><div><b>Show YouTube thumbnails</b><span>Loads preview images from i.ytimg.com (Google). Off by default; no other network requests are made.</span></div></label>`,
    [{label:'Continue',cls:'btn-primary',fn:()=>{const v=$('input[name=wl]:checked').value;settings().onboarded=true;settings().previews=$('#wlPrev').checked?'youtube':'off';saveSettings();closeModal();
      if(v==='seed')previewImport(seedToItems(NOTEFORGE_SEED),'NoteForge embedded library');else if(v==='file')pickFile(importFile,'.json,.txt,.zip,.html,.htm');else render();}}]);
}

/* ───── Global wiring ───── */
function wireGlobal(){
  $('#menuBtn').onclick=()=>$('#side').classList.contains('open')?closeSide():openSide();$('#scrim').onclick=closeSide;
  $('#newBtn').onclick=()=>quickSave();$('#footBackup').onclick=doBackup;
  $('#themeBtn').onclick=()=>{const s=settings();const dark=s.theme==='dark'||(!s.theme&&matchMedia('(prefers-color-scheme: dark)').matches);s.theme=dark?'light':'dark';saveSettings();applyTheme();};
  const q=$('#q');q.addEventListener('input',debounce(()=>{F.q=q.value;R.shown=0;if(R.page!=='library'&&R.page!=='archive'&&q.value.trim())go('library',{...Object.fromEntries(Object.entries(F).filter(([k,v])=>v&&k!=='q'))});else render();},140));
  q.addEventListener('keydown',e=>{if(e.key==='Escape'){q.value='';F.q='';render();q.blur();}});
  $$('[data-close="panel"]').forEach(b=>b.onclick=closeDetail);$$('[data-close="modal"]').forEach(b=>b.onclick=closeModal);
  $('#modalWrap').addEventListener('click',e=>{if(e.target.id==='modalWrap')closeModal();});
  let gPending=false;
  document.addEventListener('keydown',e=>{
    const tag=document.activeElement?.tagName;const typing=/INPUT|TEXTAREA|SELECT/.test(tag)||document.activeElement?.isContentEditable;
    const modalOpen=$('#modalWrap').classList.contains('open'),panelOpen=$('#panelWrap').classList.contains('open');
    if(e.key==='Escape'){if(modalOpen)closeModal();else if(panelOpen)closeDetail();else if($('#side').classList.contains('open'))closeSide();return;}
    if(e.key==='Tab'&&(modalOpen||panelOpen)){trapTab(e,modalOpen?$('#modal'):$('#panel'));return;}
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='s'&&panelOpen){e.preventDefault();saveDetail();return;}
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();$('#q').focus();$('#q').select();return;}
    if(typing||modalOpen||panelOpen)return;
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){const l=applyUndo();if(l){e.preventDefault();render();toast('Undid: '+l);}return;}
    if(e.ctrlKey||e.metaKey||e.altKey)return;
    if(gPending){gPending=false;const m={d:'dashboard',l:'library',r:'review',s:'settings',a:'archive',t:'trash'}[e.key];if(m){e.preventDefault();go(m);}return;}
    if(e.key==='/'){e.preventDefault();$('#q').focus();}else if(e.key==='n'){e.preventDefault();quickSave();}else if(e.key==='?'){e.preventDefault();showShortcuts();}else if(e.key==='g'){gPending=true;setTimeout(()=>gPending=false,900);}
  });
  window.addEventListener('beforeunload',()=>{if(Detail.id&&isDirty())saveDetail(true);if(State.flushTimer){clearTimeout(State.flushTimer);flush();}});
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&State.flushTimer)flushNow();});
  window.addEventListener('dragover',e=>{if(e.dataTransfer?.types?.includes('Files'))e.preventDefault();});
  window.addEventListener('drop',e=>{if(e.dataTransfer?.files?.length&&!e.target.closest('#drop')){e.preventDefault();importFile(e.dataTransfer.files[0]);}});
}
function trapTab(e,root){const els=$$('button,input,select,textarea,a[href],[tabindex="0"]',root).filter(x=>!x.disabled&&x.offsetParent!==null);if(!els.length)return;const first=els[0],last=els[els.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}else if(!e.shiftKey&&(document.activeElement===last||!root.contains(document.activeElement))){e.preventDefault();first.focus();}}

/* ───── Boot ───── */
(async function boot(){
  try{await Store.open();const data=await Store.loadAll();
    if(data){State.resources=data.resources.map(x=>sanitizeResource(x)).filter(s=>s.ok).map(s=>s.value);State.collections=data.collections.filter(c=>c&&c.id&&c.name);State.meta=data.meta||{};State.snapshots=(data.snapshots||[]).sort((a,b)=>a.createdAt.localeCompare(b.createdAt));}
    State.meta.settings={...DEFAULT_SETTINGS,...(State.meta.settings||{})};migrateData();indexAll();
    const purged=purgeOldTrash();if(purged)console.info('Purged',purged,'old trash items');
  }catch(e){console.error(e);document.body.insertAdjacentHTML('afterbegin',`<div class="notice danger" style="margin:16px">Could not open browser storage: ${esc(e.message)}. The app will work for this session only.</div>`);Store.mode='none';}
  applyTheme();wireGlobal();readHash();render();
  if(!settings().onboarded&&!State.resources.length)showWelcome();
})();
