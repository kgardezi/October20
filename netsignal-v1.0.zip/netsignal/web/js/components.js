// Reusable UI pieces: event table, finding rows, event drawer, range selector.
import { esc, icon, fmtTs, fmtTime, fmtShort, sevBadge, sigDot, hlMsg, api, copyText, shortIf, n, ago, $, emptyState, loading } from './util.js';
import { state, go } from './state.js';

export const RANGES = [['1h', '1h'], ['6h', '6h'], ['24h', '24h'], ['today', 'Today'], ['3d', '3d'], ['7d', '7d']];

export function rangeSeg(cur = state.range) {
  return `<div class="seg" data-range>${RANGES.map(([v, l]) => `<button data-v="${v}" class="${v === cur ? 'on' : ''}">${l}</button>`).join('')}</div>`;
}
export function bindRange(root, onChange) {
  root.querySelectorAll('[data-range] button').forEach(b => b.addEventListener('click', () => {
    state.setRange(b.dataset.v);
    onChange(b.dataset.v);
  }));
}

const EXPAND = [['Twe', 'TwentyFiveGigE'], ['Tw', 'TwoGigabitEthernet'], ['Te', 'TenGigabitEthernet'], ['Fo', 'FortyGigabitEthernet'],
  ['Hu', 'HundredGigE'], ['Gi', 'GigabitEthernet'], ['Fa', 'FastEthernet'], ['Eth', 'Ethernet'], ['Po', 'Port-channel'], ['Se', 'Serial']];
export function expandIf(i) {
  if (!i) return i;
  if (/^port-channel/i.test(i)) return 'Port-channel' + i.replace(/^port-channel/i, '');
  for (const [s, l] of EXPAND) {
    if (i.startsWith(l)) return i;
    if (i.startsWith(s) && /^\d/.test(i.slice(s.length))) return l + i.slice(s.length);
  }
  return i;
}

// Delegated handler for entity pivots inside messages
export function bindPivots(root) {
  root.addEventListener('click', ev => {
    const p = ev.target.closest('[data-pivot]');
    if (!p) return;
    ev.stopPropagation();
    const v = p.dataset.v;
    closeDrawer();
    if (p.dataset.pivot === 'iface' && p.dataset.host) go(`#/interface?host=${encodeURIComponent(p.dataset.host)}&iface=${encodeURIComponent(expandIf(v))}`);
    else if (p.dataset.pivot === 'mac') go(`#/investigate?mac=${encodeURIComponent(v)}`);
    else if (p.dataset.pivot === 'ip') go(`#/investigate?ip=${encodeURIComponent(v)}`);
    else if (p.dataset.pivot === 'host') go(`#/device/${encodeURIComponent(v)}`);
  });
}

// ---------------------------------------------------------------- events table
export function eventRows(events, { showHost = true, now } = {}) {
  return events.map(e => `<tr class="click ${esc(e.signal)}" data-id="${e.id ?? ''}">
    <td class="ts" title="${esc(fmtTs(e.ts, true))}">${esc(fmtShort(e.ts, now))}<span class="muted">.${String(Math.floor((e.ts % 1) * 1000)).padStart(3, '0')}</span></td>
    <td>${sigDot(e.signal)}</td>
    ${showHost ? `<td class="host"><span class="hl-if" style="color:inherit" data-pivot="host" data-v="${esc(e.host)}">${esc(e.host)}</span></td>` : ''}
    <td><span class="code">${esc(e.code || '—')}</span>${e.repeat > 1 ? ` <span class="chip" title="message repeated">×${e.repeat}</span>` : ''}</td>
    <td class="msg">${hlMsg(e.message, e.host)}</td></tr>`).join('');
}
export function eventTable(events, opts = {}) {
  if (!events.length) return emptyState(opts.empty || 'No matching messages in this time range', 'search');
  return `<div class="scroll" style="${opts.maxh ? `max-height:${opts.maxh}px` : ''}"><table class="tbl evt"><thead><tr>
    <th>Time</th><th></th>${opts.showHost === false ? '' : '<th>Device</th>'}<th>Code</th><th>Message</th></tr></thead>
    <tbody>${eventRows(events, opts)}</tbody></table></div>`;
}
export function bindEventTable(root) {
  root.addEventListener('click', ev => {
    if (ev.target.closest('[data-pivot]')) return;
    const tr = ev.target.closest('tr[data-id]');
    if (tr && tr.dataset.id) openEvent(+tr.dataset.id);
  });
  bindPivots(root);
}

// ---------------------------------------------------------------- findings
const TYPE_LABEL = {
  link_flap: 'Link flapping', link_down: 'Link down', link_bounce: 'Link bounce', edge_flap: 'Access port flaps',
  adj_down: 'Adjacency down', adj_unstable: 'Unstable adjacency', adj_reset: 'Adjacency reset', fhrp_change: 'FHRP change',
  auth_repeat: 'Auth failures', radius_down: 'RADIUS', poe_cycle: 'PoE', mac_move: 'MAC moves', site_event: 'Site-wide',
  clock_skew: 'Clock / NTP', clock_unsynced: 'Clock / NTP', first_seen: 'New message type', volume_spike: 'Unusual volume',
  psu: 'Power supply', buffer: 'Buffers', optic_alarm: 'Optics', errdisable: 'Err-disable', stack_link: 'Stack', reload: 'Reload',
  lag_member: 'Port-channel', isdn_l2: 'ISDN', login_fail: 'Logins', unclassified: 'Unclassified', license: 'Licensing',
  mismatch: 'Mismatch', environment: 'Environment', module: 'Module', resource: 'Resources', stp: 'Spanning tree', vpc: 'vPC',
  dup_ip: 'Duplicate IP', storm: 'Storm control', optic_bad: 'Optics', ntp: 'NTP', stack_member: 'Stack',
};
export const typeLabel = t => TYPE_LABEL[t] || t;

export function findingRow(f, now) {
  const ctx = f.context || [];
  const ic = [];
  if (ctx.some(c => c.type === 'change')) ic.push(`<span title="A configuration change preceded this">${icon('git', 'sm')} change</span>`);
  if (ctx.some(c => c.type === 'correlation' || c.type === 'coincident' || c.type === 'related')) ic.push(`<span title="Correlated events found">${icon('layers', 'sm')} correlated</span>`);
  if (ctx.some(c => c.type === 'recurring')) ic.push(`<span title="Seen on previous days">${icon('repeat', 'sm')} recurring</span>`);
  return `<div class="fi" data-fid="${esc(f.id)}">
    <div class="bar ${esc(f.severity)}"></div>
    <div style="min-width:0">
      <div class="t">${sevBadge(f.severity)} <span>${esc(f.title)}</span>${f.status === 'recovered' ? '<span class="recovered">recovered</span>' : ''}</div>
      <div class="d">${esc(f.summary)}</div>
      <div class="m"><span class="chip">${esc(typeLabel(f.type))}</span>${f.site ? `<span>${icon('target', 'sm')} ${esc(f.site)}</span>` : ''}
        <span>${icon('clock', 'sm')} ${esc(fmtShort(f.first, now))}${f.last - f.first > 1 ? ' → ' + esc(fmtShort(f.last, now)) : ''}</span>
        <span class="ctxicons">${ic.join('')}</span></div>
    </div>
    <div class="r"><span class="n num">${n(f.count)}</span>msgs<br>${esc(ago(f.last, now))}</div></div>`;
}
export function findingList(fs, now, empty = 'Nothing needs attention') {
  if (!fs.length) return emptyState(empty, 'check');
  return `<div class="flist">${fs.map(f => findingRow(f, now)).join('')}</div>`;
}
export function bindFindings(root) {
  root.addEventListener('click', ev => {
    const el = ev.target.closest('[data-fid]');
    if (el) go(`#/finding/${el.dataset.fid}`);
  });
}

// ---------------------------------------------------------------- event drawer
export function closeDrawer() {
  $('#drawer').classList.remove('on');
  $('#scrim').classList.remove('on');
}
export async function openEvent(id) {
  const d = $('#drawer');
  d.innerHTML = `<div class="dh"><h2>Event</h2></div><div class="db">${loading()}</div>`;
  d.classList.add('on');
  $('#scrim').classList.add('on');
  let r;
  try { r = await api(`/api/event/${id}`); } catch (e) { d.querySelector('.db').innerHTML = emptyState(e.message, 'alert'); return; }
  const e = r.event, x = r.explain;
  const now = state.now();
  const fields = [
    ['Device', `<a href="#/device/${esc(e.host)}">${esc(e.host)}</a> <span class="muted">${esc(e.fqdn || '')}</span>`],
    ['Site / role', `${e.site ? `<a href="#/investigate?site=${esc(e.site)}">${esc(e.site)}</a>` : '—'} · ${esc(e.role || '—')}`],
    ['Platform', esc(e.platform || 'unknown') + ' <span class="muted">(inferred from message format)</span>'],
    ['Device time', e.dev_ts ? esc(fmtTs(e.dev_ts, true)) + (e.clock_flag ? ` <span class="sev warning">${esc(e.clock_flag)}</span>` : '') : '<span class="muted">not present</span>'],
    ['Server received', esc(fmtTs(e.rx_ts)) + (e.skew != null ? ` <span class="muted">(offset ${e.skew > 0 ? '+' : ''}${e.skew.toFixed(2)} s)</span>` : '')],
    ['Cisco severity', `${e.severity ?? '—'} ${r.severity_name ? `(${esc(r.severity_name)})` : ''}`],
    ['NetSignal rating', `${sevBadge(e.signal)} <span class="muted">category: ${esc(r.category?.name || e.category)}</span>`],
  ];
  if (e.interface) fields.push(['Interface', `<a href="#/interface?host=${esc(e.host)}&iface=${encodeURIComponent(e.interface)}">${esc(e.interface)}</a> <span class="muted">${esc(e.iface_class || '')}</span>`]);
  if (e.state) fields.push(['State', esc(e.state)]);
  if (e.mac) fields.push(['MAC', `<a href="#/investigate?mac=${esc(e.mac)}">${esc(e.mac)}</a>${r.vendor ? ` <span class="muted">${esc(r.vendor)}</span>` : ''}`]);
  if (e.neighbor) fields.push(['Neighbor', `<a href="#/investigate?neighbor=${esc(e.neighbor)}">${esc(e.neighbor)}</a> ${esc(e.protocol || '')}`]);
  if (e.ip) fields.push(['IP', `<a href="#/investigate?ip=${esc(e.ip)}">${esc(e.ip)}</a>`]);
  if (e.vlan) fields.push(['VLAN', esc(e.vlan)]);
  if (e.user) fields.push(['User', esc(e.user)]);
  if (e.reason) fields.push(['Reason', esc(e.reason)]);
  for (const [k, v] of Object.entries(e.attrs || {})) fields.push([k.replace(/_/g, ' '), esc(k.endsWith('_if') ? shortIf(v) : v)]);
  fields.push(['Source file', `<span class="mono">${esc(e.source)}</span>`]);

  const mini = (rows, meId) => rows.length ? `<div class="mini">${rows.map(o => `<div class="row ${o.id === meId ? 'me' : ''}" data-eid="${o.id}">
      <span class="mono muted">${esc(fmtTime(o.ts, true))}</span><span><span class="sigdot ${esc(o.signal)}"></span> ${esc(o.host)}</span>
      <span class="m" title="${esc(o.message)}">%${esc(o.code)}: ${esc(o.message)}</span></div>`).join('')}</div>` : '<div class="muted mini">None</div>';
  const around = [...r.around, e].sort((a, b) => a.ts - b.ts);

  d.innerHTML = `<div class="dh">
      <div style="flex:1;min-width:0"><div class="muted mono" style="font-size:12px">${esc(fmtTs(e.ts, true))}</div>
        <h2 style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><span class="code" style="font-size:13px">%${esc(e.code || 'unparsed')}</span>${sevBadge(e.signal)}</h2></div>
      <button class="iconbtn" id="dclose" title="Close (Esc)">${icon('x')}</button></div>
    <div class="db">
      <div class="dsec"><h4>${icon('info', 'sm')} What this means</h4><div class="explain">${esc(x.text)}</div>
        <div class="note" style="margin-top:6px">Explanation generated from rule <span class="mono">${esc(x.rule || 'none')}</span>. The original message below is the evidence.</div></div>
      <div class="dsec"><h4>Original syslog (evidence)</h4><div class="raw">${esc(e.raw)}<button class="iconbtn copy" data-copy="raw" title="Copy">${icon('copy', 'sm')}</button></div></div>
      ${x.guidance?.length ? `<div class="dsec"><h4>${icon('terminal', 'sm')} Next steps</h4><div class="cmds">${x.guidance.map(g => cmdLine(g)).join('')}</div></div>` : ''}
      <div class="dsec"><h4>Parsed fields</h4><div class="kv">${fields.map(([k, v]) => `<div class="k">${esc(k)}</div><div class="v">${v}</div>`).join('')}</div></div>
      <div class="dsec"><h4>${icon('clock', 'sm')} Same device ±2 minutes</h4>${mini(around, e.id)}</div>
      ${e.interface ? `<div class="dsec"><h4>${icon('link', 'sm')} Interface history (latest 40) <a class="btn sm" style="margin-left:auto" href="#/interface?host=${esc(e.host)}&iface=${encodeURIComponent(e.interface)}">Open timeline</a></h4>${mini(r.interface_history, e.id)}</div>` : ''}
      ${e.mac ? `<div class="dsec"><h4>MAC ${esc(e.mac)} history</h4>${mini(r.mac_history, e.id)}</div>` : ''}
      ${e.site ? `<div class="dsec"><h4>${icon('target', 'sm')} Other devices at site ${esc(e.site)} (±60 s, warning+)</h4>${mini(r.site_related, e.id)}</div>` : ''}
      <div class="dsec"><h4>Pivot</h4><div style="display:flex;gap:8px;flex-wrap:wrap">
        <a class="btn sm" href="#/device/${esc(e.host)}">${icon('server', 'sm')} Device view</a>
        ${e.code ? `<a class="btn sm" href="#/investigate?code=${esc(e.code)}">${icon('filter', 'sm')} All %${esc(e.code)}</a>` : ''}
        <a class="btn sm" href="#/investigate?host=${esc(e.host)}&t0=${e.ts - 600}&t1=${e.ts + 600}">±10 min on device</a>
        ${e.site ? `<a class="btn sm" href="#/investigate?site=${esc(e.site)}&t0=${e.ts - 300}&t1=${e.ts + 300}">±5 min at site</a>` : ''}
        <a class="btn sm" href="#/category/${esc(e.category)}">${esc(r.category?.name || e.category)}</a></div></div>
    </div>`;
  $('#dclose', d).onclick = closeDrawer;
  d.querySelector('[data-copy="raw"]').onclick = () => copyText(e.raw);
  d.querySelectorAll('.cmd .copy').forEach(c => c.onclick = () => copyText(c.dataset.t));
  d.querySelectorAll('[data-eid]').forEach(rw => rw.onclick = () => openEvent(+rw.dataset.eid));
  d.querySelectorAll('a[href^="#"]').forEach(a => a.addEventListener('click', closeDrawer));
}

export function cmdLine(g) {
  const isCmd = /^(show|test|dir|ping|traceroute|clear)\b/.test(g);
  return `<div class="cmd ${isCmd ? '' : 'text'}">${isCmd ? '<span class="muted">#</span>' : icon('arrow', 'sm')}<span>${esc(g)}</span>
    ${isCmd ? `<span class="copy" data-t="${esc(g.replace(/\s{2,}\(.*\)$/, ''))}" title="Copy">${icon('copy', 'sm')}</span>` : ''}</div>`;
}
