# Physical link speeds for management

1. Collect one session per device, keeping hostnames and command headings.
2. Include `show interfaces status`. If unsupported, include `show interfaces` or `show interfaces <physical-port>` with an explicit duplex/speed line.
3. Include `show cdp neighbors detail` and/or `show lldp neighbors detail` to identify the endpoints. Interface configuration/description output provides additional connection evidence. A speed table alone does not identify which other device is connected.
4. Import the files, review endpoints, generate diagrams, then choose **Physical link speeds**. Only connections with uploaded files for both devices appear. Additional uploaded devices remain visible even if no connection is established.
5. Review unknown and orange labels before presenting. Select each connection to inspect the exact source files, commands and speed values.

| Label | Meaning |
| --- | --- |
| 100 Mb/s, 1 Gb/s, 10 Gb/s | Both ends report the displayed operating rate |
| 1 Gb/s (one end) | Only one endpoint provides a usable numeric operating rate |
| Speed unknown | No usable active operating rate was collected |
| Rates differ / Speed conflict | Endpoint or source speeds disagree; no bottleneck capacity is assumed |
| State conflict | Collected operational states disagree |
| Down / Admin down | The connection is not shown as active capacity |

Numeric auto-negotiated values such as `a-1000` mean 1000 Mb/s. The word `auto` alone does not establish a speed. A 10G-capable interface operating at 100 Mb/s is labeled 100 Mb/s. Configured BW and speed settings are not substituted for an observation.

The page keeps rate labels visible and omits port tags; select a connection to see its ports. Physical port-channel members are drawn individually; their labels are not a summed bundle capacity. Circuit handoff port rates describe the Ethernet ports; committed provider bandwidth may be different. Rates describe the uploaded snapshot and do not measure traffic utilization. Regenerate from fresh outputs for an updated view.

The private and public editions have identical speed-page behavior. Existing boards need regeneration from their device files to add the new page; opening an old board alone cannot recover command outputs that were never stored in it.
