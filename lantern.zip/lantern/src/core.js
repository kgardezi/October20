/* ───────────────────────── Lantern core: utils, storage, model, import/export ───────────────────────── */
'use strict';
const APP_NAME='Lantern', SCHEMA_VERSION=1, DB_NAME='lantern-db', LS_KEY='lantern:data', TRASH_DAYS=30, MAX_SNAPSHOTS=6;
const STATUSES=[['saved','Saved'],['next','To learn'],['learning','Learning'],['done','Done'],['blocked','Blocked']];
const STATUS_LABEL=Object.fromEntries(STATUSES);
const PRIORITIES=[[0,'None'],[1,'Low'],[2,'Medium'],[3,'High']];
const PRIO_LABEL=Object.fromEntries(PRIORITIES);

/* utils */
const $=(s,r=document)=>r.querySelector(s);
const $$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const uid=()=>Date.now().toString(36)+'-'+Math.random().toString(36).slice(2,9);
const pad=n=>String(n).padStart(2,'0');
const isoDate=d=>`${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}`;
const today=()=>isoDate(new Date());
const addDays=(iso,n)=>{const d=new Date(iso+'T00:00:00');d.setDate(d.getDate()+n);return isoDate(d);};
const MONTHS=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
const fmtDate=iso=>{if(!iso||!/^\d{4}-\d{2}-\d{2}/.test(iso))return '—';const [y,m,d]=iso.slice(0,10).split('-');return `${MONTHS[+m-1]} ${+d}, ${y}`;};
const daysSince=iso=>iso?Math.floor((Date.now()-new Date(iso.slice(0,10)+'T00:00:00').getTime())/864e5):Infinity;
const relTime=iso=>{const d=daysSince(iso);if(!isFinite(d))return 'never';if(d<=0)return 'today';if(d===1)return 'yesterday';if(d<30)return d+' days ago';if(d<365)return Math.round(d/30)+' mo ago';return Math.round(d/365)+' yr ago';};
const validDate=s=>typeof s==='string'&&/^\d{4}-\d{2}-\d{2}$/.test(s)&&!isNaN(new Date(s+'T00:00:00'));
const plural=(n,w)=>`${n.toLocaleString()} ${w}${n===1?'':'s'}`;
const debounce=(fn,ms)=>{let t;return(...a)=>{clearTimeout(t);t=setTimeout(()=>fn(...a),ms);};};
const shuffle=a=>{for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;};
function download(name,text,type='application/json'){const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([text],{type}));a.download=name;document.body.appendChild(a);a.click();setTimeout(()=>{URL.revokeObjectURL(a.href);a.remove();},800);}
function readFileText(file){return new Promise((ok,bad)=>{const r=new FileReader();r.onload=()=>ok(r.result);r.onerror=()=>bad(r.error);r.readAsText(file);});}
function readFileBuffer(file){return new Promise((ok,bad)=>{const r=new FileReader();r.onload=()=>ok(r.result);r.onerror=()=>bad(r.error);r.readAsArrayBuffer(file);});}
function readFileDataUrl(file){return new Promise((ok,bad)=>{const r=new FileReader();r.onload=()=>ok(r.result);r.onerror=()=>bad(r.error);r.readAsDataURL(file);});}

/* URLs */
const safeUrl=u=>/^https?:\/\/\S+$/i.test(u||'')?u:'';
const safeImg=u=>/^(https:\/\/|data:image\/(png|jpe?g|gif|webp);base64,)/i.test(u||'')?u:'';
function hostOf(u){try{return new URL(u).hostname.replace(/^(www|m|mobile)\./,'');}catch(e){return '';}}
function platformOf(u){
  const h=hostOf(u).toLowerCase(); if(!h)return 'Note';
  if(/(^|\.)youtube\.com$|^youtu\.be$/.test(h))return 'YouTube';
  if(/tiktok\.com$/.test(h))return 'TikTok';
  if(/facebook\.com$|^fb\.watch$|^fb\.com$/.test(h))return 'Facebook';
  if(/instagram\.com$/.test(h))return 'Instagram';
  if(/(^|\.)x\.com$|twitter\.com$/.test(h))return 'X';
  if(/linkedin\.com$/.test(h))return 'LinkedIn';
  if(/reddit\.com$/.test(h))return 'Reddit';
  if(/github\.com$/.test(h))return 'GitHub';
  return 'Web';
}
function ytId(u){try{const p=new URL(u);const h=p.hostname.replace(/^(www|m)\./,'');
  if(h==='youtu.be')return (p.pathname.split('/')[1]||'').slice(0,11)||null;
  if(!/youtube\.com$/.test(h))return null;
  const m=p.pathname.match(/\/(shorts|embed|live|v)\/([\w-]{11})/);if(m)return m[2];
  const v=p.searchParams.get('v');return v&&/^[\w-]{11}$/.test(v)?v:null;}catch(e){return null;}}
const TRACKING_PARAMS=/^(utm_\w+|si|sfnsn|mibextid|fbclid|igshid|igsh|gclid|dclid|mc_cid|mc_eid|_ga|ref|ref_src|ref_url|feature|rdid|share_url|source|cmpid|spm|pp|_r|__tn__)$/i;
/** Canonical key used for duplicate detection. Same video/post with different tracking params → same key. */
function canon(url){
  if(!url)return '';
  try{const u=new URL(url.trim());let h=u.hostname.toLowerCase().replace(/^(www|m|mobile|web|mbasic)\./,'');
    const id=ytId(url); if(id)return 'yt:'+id;
    if(/(^|\.)x\.com$|twitter\.com$/.test(h)){const m=u.pathname.match(/\/status\/(\d+)/);if(m)return 'x:'+m[1];}
    if(/tiktok\.com$/.test(h)){const m=u.pathname.match(/\/video\/(\d+)/);if(m)return 'tt:'+m[1];}
    if(/instagram\.com$/.test(h)){const m=u.pathname.match(/\/(p|reel|reels|tv)\/([\w-]+)/);if(m)return 'ig:'+m[2];}
    if(/facebook\.com$/.test(h)){const m=u.pathname.match(/\/(reel|videos|watch|share\/[rvp]|share)\/([\w.-]+)/)||u.pathname.match(/\/(\d{6,})\/?$/);if(m)return 'fb:'+(m[2]||m[1]);}
    const keep=[...u.searchParams.entries()].filter(([k])=>!TRACKING_PARAMS.test(k)).sort((a,b)=>a[0].localeCompare(b[0]));
    const qs=keep.length?'?'+keep.map(([k,v])=>k+'='+v).join('&'):'';
    return h+u.pathname.replace(/\/+$/,'').toLowerCase()+qs;
  }catch(e){return url.trim().toLowerCase();}
}
function embedFor(u){
  const p=platformOf(u);
  if(p==='YouTube'){const id=ytId(u);if(id)return{src:`https://www.youtube-nocookie.com/embed/${id}?rel=0`,tall:/\/shorts\//.test(u),label:'YouTube'};}
  if(p==='TikTok'){const m=u.match(/\/video\/(\d+)/);if(m)return{src:`https://www.tiktok.com/embed/v2/${m[1]}`,tall:true,label:'TikTok'};}
  if(p==='Facebook'&&/\/(reel|videos?|watch|share\/[rv])\b|fb\.watch|story\.php/.test(u))return{src:`https://www.facebook.com/plugins/video.php?href=${encodeURIComponent(u)}&show_text=false`,tall:/reel|share\/r/.test(u),label:'Facebook'};
  return null;
}

/* Minimal safe Markdown → HTML (headings, emphasis, code, links, lists, quotes, task boxes). */
function renderMarkdown(src){
  const lines=String(src||'').replace(/\r\n?/g,'\n').split('\n');let out='',i=0;
  const inline=t=>{t=esc(t);
    t=t.replace(/`([^`]+)`/g,'<code>$1</code>');
    t=t.replace(/\*\*([^*]+)\*\*/g,'<strong>$1</strong>').replace(/(^|[^*])\*([^*\n]+)\*/g,'$1<em>$2</em>').replace(/(^|\W)_([^_\n]+)_(?=\W|$)/g,'$1<em>$2</em>');
    t=t.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g,'<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
    t=t.replace(/(^|[\s(])(https?:\/\/[^\s<)]+)/g,'$1<a href="$2" target="_blank" rel="noopener noreferrer">$2</a>');
    return t;};
  while(i<lines.length){const l=lines[i];
    if(/^```/.test(l)){let b=[];i++;while(i<lines.length&&!/^```/.test(lines[i]))b.push(lines[i++]);i++;out+=`<pre><code>${esc(b.join('\n'))}</code></pre>`;continue;}
    const h=l.match(/^(#{1,3})\s+(.*)/);if(h){out+=`<h${h[1].length}>${inline(h[2])}</h${h[1].length}>`;i++;continue;}
    if(/^\s*([-*+]|\d+[.)])\s+/.test(l)){const ol=/^\s*\d/.test(l);let items=[];
      while(i<lines.length&&/^\s*([-*+]|\d+[.)])\s+/.test(lines[i])){let t=lines[i].replace(/^\s*([-*+]|\d+[.)])\s+/,'');const task=t.match(/^\[( |x|X)\]\s*(.*)/);
        items.push(task?`<li><input type="checkbox" disabled ${task[1]!==' '?'checked':''}>${inline(task[2])}</li>`:`<li>${inline(t)}</li>`);i++;}
      out+=`<${ol?'ol':'ul'}>${items.join('')}</${ol?'ol':'ul'}>`;continue;}
    if(/^>\s?/.test(l)){let q=[];while(i<lines.length&&/^>\s?/.test(lines[i]))q.push(lines[i++].replace(/^>\s?/,''));out+=`<blockquote>${inline(q.join(' '))}</blockquote>`;continue;}
    if(/^\s*(---|\*\*\*)\s*$/.test(l)){out+='<hr>';i++;continue;}
    if(!l.trim()){i++;continue;}
    let p=[];while(i<lines.length&&lines[i].trim()&&!/^(#{1,3}\s|```|>\s?|\s*([-*+]|\d+[.)])\s+|\s*(---|\*\*\*)\s*$)/.test(lines[i]))p.push(lines[i++]);
    out+=`<p>${inline(p.join('\n')).replace(/\n/g,'<br>')}</p>`;}
  return out||'<p class="muted">No notes yet.</p>';
}

/* ───────────────────────── Storage (IndexedDB, localStorage fallback) ───────────────────────── */
const Store={
  db:null,mode:'idb',closed:false,
  async open(){
    if(!('indexedDB' in window)){this.mode='ls';return;}
    try{this.db=await new Promise((ok,bad)=>{const r=indexedDB.open(DB_NAME,1);
      r.onupgradeneeded=()=>{const d=r.result;for(const s of ['resources','collections','meta','snapshots'])if(!d.objectStoreNames.contains(s))d.createObjectStore(s,{keyPath:s==='meta'?'key':'id'});};
      r.onsuccess=()=>ok(r.result);r.onerror=()=>bad(r.error);r.onblocked=()=>bad(new Error('blocked'));});
    }catch(e){console.warn('IndexedDB unavailable, falling back to localStorage',e);this.mode='ls';}
  },
  tx(stores,mode,fn){return new Promise((ok,bad)=>{const t=this.db.transaction(stores,mode);const res=fn(t);t.oncomplete=()=>ok(res);t.onerror=()=>bad(t.error);t.onabort=()=>bad(t.error||new Error('aborted'));});},
  getAll(store){return new Promise((ok,bad)=>{const r=this.db.transaction(store).objectStore(store).getAll();r.onsuccess=()=>ok(r.result);r.onerror=()=>bad(r.error);});},
  async loadAll(){
    if(this.mode==='ls'){try{const d=JSON.parse(localStorage.getItem(LS_KEY)||'null');return d&&typeof d==='object'?{resources:d.resources||[],collections:d.collections||[],meta:d.meta||{},snapshots:d.snapshots||[]}:null;}catch(e){return null;}}
    const [resources,collections,metaRows,snapshots]=await Promise.all(['resources','collections','meta','snapshots'].map(s=>this.getAll(s)));
    const meta={};metaRows.forEach(r=>meta[r.key]=r.value);
    return {resources,collections,meta,snapshots};
  },
  /** Write changed/deleted records. ops = {resources:{put:[],del:[]},collections:{...},meta:{...}} */
  async write(ops){
    if(this.closed)return;if(this.mode==='ls'){return this._writeLs();}
    await this.tx(['resources','collections','meta'],'readwrite',t=>{
      for(const s of ['resources','collections']){const os=t.objectStore(s);(ops[s]?.put||[]).forEach(r=>os.put(r));(ops[s]?.del||[]).forEach(id=>os.delete(id));}
      const m=t.objectStore('meta');Object.entries(ops.meta||{}).forEach(([k,v])=>m.put({key:k,value:v}));
    });
  },
  _writeLs(){
    const payload={resources:State.resources,collections:State.collections,meta:State.meta,snapshots:State.snapshots};
    try{localStorage.setItem(LS_KEY,JSON.stringify(payload));return true;}catch(e){throw new Error('Browser storage is full or blocked. Export a backup now; the latest change was not saved.');}
  },
  async writeAll(){
    if(this.mode==='ls')return this._writeLs();
    await this.tx(['resources','collections','meta','snapshots'],'readwrite',t=>{
      for(const s of ['resources','collections','snapshots']){const os=t.objectStore(s);os.clear();State[s].forEach(r=>os.put(r));}
      const m=t.objectStore('meta');m.clear();Object.entries(State.meta).forEach(([k,v])=>m.put({key:k,value:v}));
    });
  },
  async putSnapshot(snap){if(this.mode==='ls')return this._writeLs();await this.tx(['snapshots'],'readwrite',t=>{const os=t.objectStore('snapshots');os.put(snap);});},
  async delSnapshot(id){if(this.mode==='ls')return this._writeLs();await this.tx(['snapshots'],'readwrite',t=>t.objectStore('snapshots').delete(id));},
  async estimate(){try{if(navigator.storage?.estimate){const e=await navigator.storage.estimate();return e;}}catch(_){}return null;}
};

/* ───────────────────────── State & model ───────────────────────── */
const State={resources:[],collections:[],meta:{},snapshots:[],byId:new Map(),byKey:new Map(),dirty:{resources:new Set(),collections:new Set(),deletedResources:new Set(),deletedCollections:new Set(),meta:new Set()},flushTimer:null,undo:[]};
const DEFAULT_SETTINGS={theme:'',view:'cards',sort:'saved-desc',previews:'off',metadataService:'off',pageSize:60,lastBackup:'',staleDays:120,onboarded:false,dateOrder:'auto'};
const settings=()=>State.meta.settings||(State.meta.settings={...DEFAULT_SETTINGS});

function newResource(p={}){
  const now=new Date().toISOString();
  const r={id:uid(),url:'',key:'',title:'',description:'',notes:'',tags:[],collection:'',favorite:false,status:'saved',priority:0,reviewAt:'',savedAt:today(),createdAt:now,updatedAt:now,openedAt:'',completedAt:'',source:'manual',folder:'',image:'',archived:false,deletedAt:null,legacy:null,...p};
  r.url=(r.url||'').trim();r.key=canon(r.url);return r;
}
/** Validate + coerce an arbitrary object into a resource. Returns {ok, value|error}. Never throws. */
function sanitizeResource(x){
  if(!x||typeof x!=='object')return{ok:false,error:'not an object'};
  const url=typeof x.url==='string'?x.url.trim():'';
  if(url&&!safeUrl(url))return{ok:false,error:'invalid URL: '+url.slice(0,80)};
  const title=typeof x.title==='string'?x.title.trim().slice(0,500):'';
  if(!url&&!title&&!(typeof x.notes==='string'&&x.notes.trim()))return{ok:false,error:'empty record (no url, title or notes)'};
  const r=newResource({id:typeof x.id==='string'&&x.id?x.id:uid(),url,title,
    description:typeof x.description==='string'?x.description.slice(0,2000):'',
    notes:typeof x.notes==='string'?x.notes:'',
    tags:Array.isArray(x.tags)?[...new Set(x.tags.filter(t=>typeof t==='string').map(t=>t.trim().slice(0,60)).filter(Boolean))]:[],
    collection:typeof x.collection==='string'?x.collection:'',favorite:!!x.favorite,
    status:STATUS_LABEL[x.status]?x.status:'saved',priority:[0,1,2,3].includes(x.priority)?x.priority:0,
    reviewAt:validDate(x.reviewAt)?x.reviewAt:'',savedAt:validDate(x.savedAt)?x.savedAt:(validDate((x.createdAt||'').slice(0,10))?x.createdAt.slice(0,10):today()),
    createdAt:typeof x.createdAt==='string'&&!isNaN(Date.parse(x.createdAt))?x.createdAt:new Date().toISOString(),
    updatedAt:typeof x.updatedAt==='string'&&!isNaN(Date.parse(x.updatedAt))?x.updatedAt:new Date().toISOString(),
    openedAt:typeof x.openedAt==='string'?x.openedAt:'',completedAt:typeof x.completedAt==='string'?x.completedAt:'',
    source:typeof x.source==='string'?x.source.slice(0,40):'import',folder:typeof x.folder==='string'?x.folder.slice(0,200):'',
    image:safeImg(x.image)||'',archived:!!x.archived,deletedAt:typeof x.deletedAt==='string'?x.deletedAt:null,
    legacy:x.legacy&&typeof x.legacy==='object'?x.legacy:null});
  return{ok:true,value:r};
}
function indexAll(){State.byId=new Map(State.resources.map(r=>[r.id,r]));State.byKey=new Map();State.resources.forEach(r=>{if(r.key&&!r.deletedAt){if(!State.byKey.has(r.key))State.byKey.set(r.key,r);}});}
function findDuplicate(url,exceptId){const k=canon(url);if(!k)return null;const r=State.byKey.get(k);return r&&r.id!==exceptId?r:State.resources.find(x=>x.key===k&&!x.deletedAt&&x.id!==exceptId)||null;}
function touch(r){r.updatedAt=new Date().toISOString();State.dirty.resources.add(r.id);scheduleFlush();}
function upsertResource(r){if(!State.byId.has(r.id))State.resources.push(r);State.byId.set(r.id,r);if(r.key&&!r.deletedAt&&!State.byKey.has(r.key))State.byKey.set(r.key,r);State.dirty.resources.add(r.id);scheduleFlush();}
function hardDelete(id){const i=State.resources.findIndex(r=>r.id===id);if(i<0)return;const [r]=State.resources.splice(i,1);State.byId.delete(id);if(State.byKey.get(r.key)===r)State.byKey.delete(r.key);State.dirty.deletedResources.add(id);State.dirty.resources.delete(id);scheduleFlush();}
function setMeta(k,v){State.meta[k]=v;State.dirty.meta.add(k);scheduleFlush();}
function saveSettings(){State.dirty.meta.add('settings');scheduleFlush();}
let flushPromise=null;
function scheduleFlush(){clearTimeout(State.flushTimer);State.flushTimer=setTimeout(flush,120);}
async function flush(){
  const d=State.dirty;const ops={resources:{put:[...d.resources].map(id=>State.byId.get(id)).filter(Boolean),del:[...d.deletedResources]},collections:{put:[...d.collections].map(id=>State.collections.find(c=>c.id===id)).filter(Boolean),del:[...d.deletedCollections]},meta:Object.fromEntries([...d.meta].map(k=>[k,State.meta[k]]))};
  d.resources.clear();d.deletedResources.clear();d.collections.clear();d.deletedCollections.clear();d.meta.clear();
  try{flushPromise=Store.write(ops);await flushPromise;UI?.onSaved?.(true);}catch(e){console.error(e);UI?.onSaved?.(false,e);}
}
async function flushNow(){clearTimeout(State.flushTimer);await flush();}

/* collections */
function addCollection(name){name=name.trim().slice(0,80);if(!name)return null;const ex=State.collections.find(c=>c.name.toLowerCase()===name.toLowerCase());if(ex)return ex;const c={id:uid(),name,createdAt:new Date().toISOString()};State.collections.push(c);State.dirty.collections.add(c.id);scheduleFlush();return c;}
function renameCollection(id,name){const c=State.collections.find(x=>x.id===id);if(!c||!name.trim())return;c.name=name.trim().slice(0,80);State.dirty.collections.add(id);scheduleFlush();}
function deleteCollection(id){const i=State.collections.findIndex(c=>c.id===id);if(i<0)return;State.collections.splice(i,1);State.dirty.deletedCollections.add(id);State.resources.forEach(r=>{if(r.collection===id){r.collection='';touch(r);}});scheduleFlush();}
const collName=id=>State.collections.find(c=>c.id===id)?.name||'';

/* tags */
function tagCounts(pool=State.resources.filter(r=>!r.deletedAt&&!r.archived)){const m=new Map();pool.forEach(r=>r.tags.forEach(t=>m.set(t,(m.get(t)||0)+1)));return [...m.entries()].sort((a,b)=>b[1]-a[1]||a[0].localeCompare(b[0]));}
function renameTag(from,to){to=to.trim();if(!to)return 0;let n=0;State.resources.forEach(r=>{if(r.tags.includes(from)){r.tags=[...new Set(r.tags.map(t=>t===from?to:t))];touch(r);n++;}});return n;}
function deleteTag(t){let n=0;State.resources.forEach(r=>{if(r.tags.includes(t)){r.tags=r.tags.filter(x=>x!==t);touch(r);n++;}});return n;}

/* snapshots: safety copies taken before risky operations */
async function takeSnapshot(reason){
  const snap={id:uid(),createdAt:new Date().toISOString(),reason,counts:{resources:State.resources.length,collections:State.collections.length},data:{resources:State.resources,collections:State.collections,meta:{settings:settings()}}};
  State.snapshots.push(snap);State.snapshots.sort((a,b)=>a.createdAt.localeCompare(b.createdAt));
  const extra=State.snapshots.splice(0,Math.max(0,State.snapshots.length-MAX_SNAPSHOTS));
  try{await Store.putSnapshot(snap);for(const s of extra)await Store.delSnapshot(s.id);}catch(e){console.warn('snapshot failed',e);}
  return snap;
}

/* undo stack: stores previous copies of affected resources */
function pushUndo(label,before,created=[]){State.undo.push({label,before:before.map(r=>JSON.parse(JSON.stringify(r))),created:[...created]});if(State.undo.length>20)State.undo.shift();}
function applyUndo(){const u=State.undo.pop();if(!u)return null;u.created.forEach(id=>hardDelete(id));u.before.forEach(r=>{const cur=State.byId.get(r.id);if(cur)Object.assign(cur,r);else{State.resources.push(r);State.byId.set(r.id,r);}State.dirty.resources.add(r.id);});indexAll();scheduleFlush();return u.label;}

/* ───────────────────────── Search ───────────────────────── */
function parseQuery(q){
  const f={words:[],tags:[],status:[],coll:[],is:[],has:[],not:[],platform:[],year:[]};
  (q.match(/"[^"]+"|\S+/g)||[]).forEach(tok=>{const neg=tok.startsWith('-');if(neg)tok=tok.slice(1);const m=tok.match(/^(tag|status|in|is|has|site|year|platform|prio|priority):(.+)$/i);
    if(m){const k=m[1].toLowerCase(),v=m[2].replace(/^"|"$/g,'').toLowerCase();if(neg){f.not.push([k,v]);return;}
      if(k==='tag')f.tags.push(v);else if(k==='status')f.status.push(v);else if(k==='in')f.coll.push(v);else if(k==='is')f.is.push(v);else if(k==='has')f.has.push(v);else if(k==='site'||k==='platform')f.platform.push(v);else if(k==='year')f.year.push(v);else if(k==='prio'||k==='priority')f.is.push('prio-'+v);}
    else{const w=tok.replace(/^"|"$/g,'').toLowerCase();if(w)(neg?f.not:f.words).push(neg?['word',w]:w);}});
  return f;
}
const searchText=r=>(r._s??(r._s=[r.title,r.url,r.description,r.notes,r.tags.join(' '),collName(r.collection),r.folder,hostOf(r.url),platformOf(r.url),r.legacy?.autoTopics?.join(' ')||''].join(' ').toLowerCase()));
function matchQuery(r,f){
  const st=searchText(r);
  if(!f.words.every(w=>st.includes(w)))return false;
  if(f.tags.length&&!f.tags.every(t=>r.tags.some(x=>x.toLowerCase()===t||x.toLowerCase().includes(t))))return false;
  if(f.status.length&&!f.status.some(s=>r.status===s||STATUS_LABEL[r.status].toLowerCase().startsWith(s)))return false;
  if(f.coll.length&&!f.coll.some(c=>collName(r.collection).toLowerCase().includes(c)))return false;
  if(f.platform.length&&!f.platform.some(p=>platformOf(r.url).toLowerCase()===p||hostOf(r.url).toLowerCase().includes(p)))return false;
  if(f.year.length&&!f.year.includes(r.savedAt.slice(0,4)))return false;
  for(const i of f.is){if(i==='fav'||i==='favorite'){if(!r.favorite)return false;}else if(i==='untagged'){if(r.tags.length)return false;}else if(i==='archived'){if(!r.archived)return false;}else if(i==='note'){if(r.url)return false;}else if(i.startsWith('prio-')){const v=i.slice(5);const n={none:0,low:1,medium:2,high:3}[v]??+v;if(r.priority!==n)return false;}}
  for(const h of f.has){if(h==='notes'&&!r.notes.trim())return false;if(h==='review'&&!r.reviewAt)return false;if(h==='link'&&!r.url)return false;if(h==='image'&&!r.image)return false;}
  for(const [k,v] of f.not){if(k==='word'&&st.includes(v))return false;if(k==='tag'&&r.tags.some(x=>x.toLowerCase()===v))return false;if(k==='status'&&r.status===v)return false;if(k==='in'&&collName(r.collection).toLowerCase().includes(v))return false;if((k==='site'||k==='platform')&&platformOf(r.url).toLowerCase()===v)return false;}
  return true;
}
function invalidateSearch(r){if(r)delete r._s;else State.resources.forEach(x=>delete x._s);}

/* ───────────────────────── Converters from other formats ───────────────────────── */
const NF_STATUS={'Not started':'next','In progress':'learning','Completed':'done','Blocked':'blocked'};
/** NoteForge library video {u,p,d,t,n,c,y,g} → resource (all original fields preserved under legacy). */
function fromNoteForgeVideo(v){
  if(!v||typeof v.u!=='string'||!safeUrl(v.u))return null;
  return newResource({url:v.u,title:typeof v.n==='string'?v.n.trim():'',tags:Array.isArray(v.g)?v.g.filter(x=>typeof x==='string'):[],
    savedAt:validDate(v.d)?v.d:today(),createdAt:validDate(v.d)?new Date(v.d+'T12:00:00').toISOString():new Date().toISOString(),source:'whatsapp',status:'saved',
    legacy:{app:'NoteForge',kind:'video',time:v.t||'',timesShared:v.c||1,platform:v.p||'',autoTopics:Array.isArray(v.g)?v.g:[]}});
}
/** NoteForge tracker entry {id,date,task,notes,link,status,picture,source} → resource */
function fromNoteForgeEntry(e){
  if(!e||typeof e!=='object')return null;const url=typeof e.link==='string'&&safeUrl(e.link.trim())?e.link.trim():'';const title=typeof e.task==='string'?e.task.trim():'';
  if(!url&&!title)return null;
  const img=typeof e.picture==='string'&&/^data:image\//.test(e.picture)?e.picture:'';
  return newResource({url,title,notes:typeof e.notes==='string'?e.notes:'',status:NF_STATUS[e.status]||'next',savedAt:validDate(e.date)?e.date:today(),createdAt:validDate(e.date)?new Date(e.date+'T12:00:00').toISOString():new Date().toISOString(),
    image:img,source:e.source==='video'?'whatsapp':(typeof e.notes==='string'&&/^Folder: /.test(e.notes)?'bookmark':'noteforge'),folder:(typeof e.notes==='string'&&e.notes.match(/^Folder: (.+)$/m)||[])[1]||'',
    completedAt:e.status==='Completed'&&validDate(e.date)?new Date(e.date+'T12:00:00').toISOString():(e.status==='Completed'?new Date().toISOString():''),legacy:{app:'NoteForge',kind:'entry',id:e.id,status:e.status,date:e.date,externalPicture:typeof e.picture==='string'&&!img?e.picture:''}});
}
/** Merge a tracker entry into a library video of the same URL (NoteForge kept both). Entry data wins for status/title/notes. */
function mergeEntryIntoVideo(video,entry){
  if(entry.title&&entry.title!==video.title){if(video.title&&!entry.title.includes(video.title)&&!/ video saved /.test(entry.title))video.description=video.title;if(!/ video saved /.test(entry.title)||!video.title)video.title=entry.title;}
  const n=(entry.notes||'').replace(/^Saved on .* from WhatsApp\.( Topics: .*\.)?$/,'').trim();if(n)video.notes=video.notes?video.notes+'\n\n'+n:n;
  video.status=entry.status;video.completedAt=entry.completedAt;if(entry.image)video.image=entry.image;video.legacy={...video.legacy,trackerDate:entry.savedAt,trackerId:entry.legacy?.id};
  return video;
}
/** Parse a NoteForge backup JSON (v6: {app:'NoteForge',entries,extraVideos,hiddenVideos,preferences}) or a bare entries array. */
function parseNoteForgeBackup(obj){
  const entries=Array.isArray(obj)?obj:Array.isArray(obj?.entries)?obj.entries:null;if(!entries)throw new Error('Not a NoteForge backup: missing "entries" array.');
  const extra=Array.isArray(obj?.extraVideos)?obj.extraVideos:[];const hidden=new Set(Array.isArray(obj?.hiddenVideos)?obj.hiddenVideos.filter(x=>typeof x==='string'):[]);
  const items=[],invalid=[];
  extra.forEach((v,i)=>{const r=fromNoteForgeVideo(v);if(r){if(hidden.has(v.u))r.archived=true;items.push(r);}else invalid.push(`extraVideos[${i}]: invalid`);});
  entries.forEach((e,i)=>{const r=fromNoteForgeEntry(e);if(r)items.push(r);else invalid.push(`entries[${i}]: missing title and link`);});
  return {items,invalid,hidden,info:`NoteForge backup v${obj?.version??'?'} · ${plural(entries.length,'tracker entry')} · ${plural(extra.length,'imported link')} · ${plural(hidden.size,'hidden link')}`,kind:'noteforge-backup',preferences:obj?.preferences||null};
}
/** Extract BASE_VIDEOS from the original NoteForge HTML file. */
function parseNoteForgeHtml(text){
  const m=text.match(/const BASE_VIDEOS\s*=\s*(\[[\s\S]*?\]);\s*\n/);if(!m)throw new Error('This HTML file does not contain a NoteForge BASE_VIDEOS dataset.');
  let arr;try{arr=JSON.parse(m[1]);}catch(e){throw new Error('The embedded dataset could not be parsed as JSON.');}
  return seedToItems(arr,'noteforge-html');
}
function seedToItems(arr,kind='noteforge-seed'){const items=[],invalid=[];arr.forEach((v,i)=>{const r=fromNoteForgeVideo(v);if(r)items.push(r);else invalid.push(`item ${i}: invalid URL`);});return {items,invalid,info:`${plural(arr.length,'saved link')} from the NoteForge library`,kind};}
/** Our own backup */
function parseLanternBackup(obj){
  if(!obj||obj.app!==APP_NAME||!Array.isArray(obj.resources))throw new Error('Not a Lantern backup (expected {"app":"Lantern","resources":[…]}).');
  const items=[],invalid=[];obj.resources.forEach((x,i)=>{const s=sanitizeResource(x);if(s.ok)items.push(s.value);else invalid.push(`resources[${i}]: ${s.error}`);});
  const collections=Array.isArray(obj.collections)?obj.collections.filter(c=>c&&typeof c.id==='string'&&typeof c.name==='string'):[];
  return {items,invalid,collections,settings:obj.settings&&typeof obj.settings==='object'?obj.settings:null,info:`Lantern backup from ${fmtDate((obj.exportedAt||'').slice(0,10))} · ${plural(obj.resources.length,'resource')} · ${plural(collections.length,'collection')}`,kind:'lantern-backup'};
}
/** Netscape bookmark HTML (Chrome/Edge/Firefox/Safari export) */
function parseBookmarksHtml(text){
  const doc=new DOMParser().parseFromString(text,'text/html');const items=[],invalid=[];
  const walk=(node,folder)=>{for(const el of node.children){
    if(el.tagName==='DT'){const first=el.firstElementChild;if(!first)continue;
      if(first.tagName==='H3'){const dl=el.querySelector(':scope > dl')||el.nextElementSibling?.tagName==='DL'&&el.nextElementSibling;const name=first.textContent.trim();if(dl)walk(dl,folder?folder+' / '+name:name);}
      else if(first.tagName==='A'){const url=(first.getAttribute('href')||'').trim();if(!safeUrl(url)){if(url&&!/^(javascript|place|chrome|about|file):/i.test(url))invalid.push(url.slice(0,80));continue;}
        const ad=first.getAttribute('add_date');let date=today(),created=new Date().toISOString();if(ad&&/^\d+$/.test(ad)&&+ad>0){const ms=+ad>1e12?+ad/1000:+ad*1000;const dt=new Date(ms);if(!isNaN(dt)){date=isoDate(dt);created=dt.toISOString();}}
        const tags=(first.getAttribute('tags')||'').split(',').map(s=>s.trim()).filter(Boolean);
        const dd=el.querySelector(':scope > dd')||(el.nextElementSibling?.tagName==='DD'?el.nextElementSibling:null);
        items.push(newResource({url,title:first.textContent.trim().slice(0,500)||hostOf(url),savedAt:date,createdAt:created,source:'bookmark',folder:folder||'',tags,description:dd?dd.textContent.trim().slice(0,2000):'',status:'saved'}));}
    }else if(el.tagName==='DL'||el.tagName==='DD'||el.tagName==='P')walk(el,folder);}};
  walk(doc.body,'');
  if(!items.length&&!/<DL|<DT|<A /i.test(text))throw new Error('No bookmarks found. Expected a browser bookmarks export (Netscape bookmark HTML).');
  return {items,invalid,info:`${plural(items.length,'bookmark')} in ${new Set(items.map(i=>i.folder)).size} folders`,kind:'bookmarks'};
}
/** WhatsApp chat export (.txt). Handles "[dd/mm/yy, hh:mm:ss] Name: msg" and "dd/mm/yy, hh:mm - Name: msg". dateOrder: 'auto'|'dmy'|'mdy' */
function parseWhatsApp(text,dateOrder='auto'){
  text=text.replace(/‎|‏|‪|‬/g,'');
  const hdr=/^\[?(\d{1,4})[-/.](\d{1,2})[-/.](\d{1,4}),?\s+(\d{1,2}:\d{2})(?::\d{2})?\s*([ap]\.?\s?m\.?)?\]?\s*(?:-\s*)?([^:\n]{1,80}):\s?/gim;
  const marks=[];let m;while((m=hdr.exec(text)))marks.push({i:m.index,end:hdr.lastIndex,m});
  if(!marks.length)throw new Error('No WhatsApp message headers found. Export the chat as a .txt (without media) and try again.');
  let order=dateOrder;if(order==='auto'){const dayFirst=marks.some(k=>k.m[1].length<=2&&+k.m[1]>12),monthFirst=marks.some(k=>k.m[1].length<=2&&+k.m[2]>12);order=dayFirst&&!monthFirst?'dmy':monthFirst&&!dayFirst?'mdy':'dmy';}
  const urlRx=/https?:\/\/[^\s<>"'`]+/g,items=[],invalid=[];
  marks.forEach((k,j)=>{
    const body=text.slice(k.end,j+1<marks.length?marks[j+1].i:text.length).trim();const urls=body.match(urlRx);if(!urls)return;
    const [,a,b,c]=k.m;let y,mo,d;
    if(a.length===4){y=a;mo=b;d=c;}else{y=c.length===2?'20'+c:c;if(order==='mdy'){mo=a;d=b;}else{d=a;mo=b;}}
    let date=`${y}-${pad(mo)}-${pad(d)}`;if(!validDate(date))date=today();
    const note=body.replace(urlRx,'').replace(/▶️ ?Watch this reel|📸 ?(Watch this video|Look at this (post|reel)) on Facebook|<This message was edited>/gi,'').replace(/\s*\n\s*/g,' · ').replace(/(\s*·\s*)+/g,' · ').replace(/^[\s·]+|[\s·]+$/g,'').trim();
    urls.forEach(raw=>{const u=raw.replace(/[.,)\]>]+$/,'');if(!safeUrl(u)){invalid.push(u.slice(0,80));return;}
      items.push(newResource({url:u,title:note.slice(0,500),savedAt:date,createdAt:new Date(date+'T12:00:00').toISOString(),source:'whatsapp',status:'saved',legacy:{app:'WhatsApp',time:k.m[4]+(k.m[5]?' '+k.m[5]:''),sender:k.m[6].trim()}}));});
  });
  return {items,invalid,info:`${plural(marks.length,'message')} scanned · ${plural(items.length,'link')} · dates read as ${order==='dmy'?'day/month/year':'month/day/year'}`,kind:'whatsapp',dateOrder:order};
}
/** Minimal ZIP reader (stored or deflate entries) using DecompressionStream — no dependency. */
async function unzipTextFiles(buffer){
  const dv=new DataView(buffer),u8=new Uint8Array(buffer);let eocd=-1;for(let i=buffer.byteLength-22;i>=Math.max(0,buffer.byteLength-70000);i--){if(dv.getUint32(i,true)===0x06054b50){eocd=i;break;}}
  if(eocd<0)throw new Error('Not a valid ZIP file.');
  const n=dv.getUint16(eocd+10,true);let off=dv.getUint32(eocd+16,true);const out=[];const td=new TextDecoder();
  for(let k=0;k<n;k++){if(dv.getUint32(off,true)!==0x02014b50)break;const method=dv.getUint16(off+10,true),csize=dv.getUint32(off+20,true),nlen=dv.getUint16(off+28,true),elen=dv.getUint16(off+30,true),clen=dv.getUint16(off+32,true),lho=dv.getUint32(off+42,true);
    const name=td.decode(u8.subarray(off+46,off+46+nlen));off+=46+nlen+elen+clen;
    if(!/\.txt$/i.test(name))continue;
    const lnlen=dv.getUint16(lho+26,true),lelen=dv.getUint16(lho+28,true);const data=u8.subarray(lho+30+lnlen+lelen,lho+30+lnlen+lelen+csize);
    let text;if(method===0)text=td.decode(data);else if(method===8){if(!('DecompressionStream' in window))throw new Error('This browser cannot unzip files. Unzip the export and choose the .txt file instead.');
      const ds=new DecompressionStream('deflate-raw');const stream=new Blob([data]).stream().pipeThrough(ds);text=await new Response(stream).text();}else continue;
    out.push({name,text});}
  return out;
}
function detectAndParse(name,text){
  const trimmed=text.replace(/^[\u200e\u200f\ufeff]+/,'').trimStart();
  if(/^\[?\d{1,4}[-/.]\d{1,2}[-/.]\d{1,4},?\s+\d{1,2}:\d{2}/.test(trimmed))return parseWhatsApp(text,settings().dateOrder);
  if(/^[\[{]/.test(trimmed)){let obj;try{obj=JSON.parse(trimmed);}catch(e){throw new Error('The file is not valid JSON: '+e.message);}
    if(obj&&obj.app===APP_NAME)return parseLanternBackup(obj);
    if(Array.isArray(obj)||(obj&&(Array.isArray(obj.entries)||obj.app==='NoteForge')))return parseNoteForgeBackup(obj);
    throw new Error('Unrecognised JSON. Supported: Lantern backup, NoteForge backup.');}
  if(/const BASE_VIDEOS\s*=/.test(text))return parseNoteForgeHtml(text);
  if(/<!DOCTYPE NETSCAPE-Bookmark|<DL>|<DT>/i.test(text))return parseBookmarksHtml(text);
  if(/^\[?\d{1,4}[-/.]\d{1,2}[-/.]\d{1,4},?\s+\d{1,2}:\d{2}/m.test(text))return parseWhatsApp(text,settings().dateOrder);
  throw new Error(`Could not recognise "${name}". Supported: WhatsApp chat export (.txt/.zip), browser bookmarks (.html), NoteForge backup (.json), the original NoteForge .html, Lantern backup (.json).`);
}
/** Classify parsed items against the library: new / duplicate (of existing) / duplicate within file. */
function analyzeImport(items){
  const seen=new Map(),fresh=[],dupExisting=[],dupInFile=[];
  for(const r of items){const k=r.key||('t:'+r.title.toLowerCase());
    if(seen.has(k)){dupInFile.push([r,seen.get(k)]);continue;}seen.set(k,r);
    const ex=r.key?State.byKey.get(r.key)||State.resources.find(x=>x.key===r.key&&!x.deletedAt):null;
    if(ex)dupExisting.push([r,ex]);else fresh.push(r);}
  return {fresh,dupExisting,dupInFile};
}
/** Apply an import. opts: {mode:'skip'|'enrich', collection, tags[], status} */
function applyImport(analysis,opts={}){
  const created=[],enriched=[];const before=[];
  const decorate=r=>{if(opts.collection)r.collection=opts.collection;if(opts.tags?.length)r.tags=[...new Set([...r.tags,...opts.tags])];if(opts.status)r.status=opts.status;return r;};
  for(const r of analysis.fresh){decorate(r);upsertResource(r);created.push(r.id);}
  for(const [r,ex] of analysis.dupExisting){
    // merge title/notes/tags from the same file duplicates first
    if(opts.mode!=='enrich')continue;
    before.push(JSON.parse(JSON.stringify(ex)));let changed=false;
    if(!ex.title&&r.title){ex.title=r.title;changed=true;}else if(r.title&&r.title!==ex.title&&!(ex.notes||'').includes(r.title)&&ex.title!==r.title&&!ex.description){ex.description=r.title;changed=true;}
    if(r.notes&&!(ex.notes||'').includes(r.notes)){ex.notes=ex.notes?ex.notes+'\n\n'+r.notes:r.notes;changed=true;}
    const nt=r.tags.filter(t=>!ex.tags.includes(t));if(nt.length){ex.tags=[...ex.tags,...nt];changed=true;}
    if(r.status!=='saved'&&ex.status==='saved'){ex.status=r.status;ex.completedAt=r.completedAt;changed=true;}
    if(r.image&&!ex.image){ex.image=r.image;changed=true;}
    if(r.savedAt<ex.savedAt){ex.savedAt=r.savedAt;changed=true;}
    if(ex.deletedAt){ex.deletedAt=null;changed=true;}
    if(changed){invalidateSearch(ex);touch(ex);enriched.push(ex.id);}else before.pop();}
  indexAll();
  return {created,enriched,before};
}

/* ───────────────────────── Exports ───────────────────────── */
function exportBackupJson(){
  return JSON.stringify({app:APP_NAME,schema:SCHEMA_VERSION,exportedAt:new Date().toISOString(),counts:{resources:State.resources.length,collections:State.collections.length},settings:settings(),collections:State.collections,resources:State.resources.map(r=>{const {_s,...rest}=r;return rest;})},null,1);
}
const csvCell=v=>{const s=String(v??'');return /[",\n\r]/.test(s)?'"'+s.replace(/"/g,'""')+'"':s;};
function exportCsv(list){
  const cols=['id','title','url','status','priority','favorite','tags','collection','description','notes','savedAt','reviewAt','completedAt','openedAt','source','folder','archived'];
  return '﻿'+cols.join(',')+'\n'+list.map(r=>cols.map(c=>csvCell(c==='tags'?r.tags.join('; '):c==='collection'?collName(r.collection):c==='priority'?PRIO_LABEL[r.priority]:c==='status'?STATUS_LABEL[r.status]:r[c])).join(',')).join('\n');
}
function exportMarkdown(list){
  const groups=new Map();list.forEach(r=>{const g=collName(r.collection)||'Uncollected';if(!groups.has(g))groups.set(g,[]);groups.get(g).push(r);});
  let out=`# ${APP_NAME} library export\n\nExported ${new Date().toISOString().slice(0,10)} · ${plural(list.length,'resource')}\n`;
  for(const [g,rs] of groups){out+=`\n## ${g}\n`;for(const r of rs){out+=`\n### ${r.title||r.url||'Untitled'}\n`;if(r.url)out+=`- Link: ${r.url}\n`;out+=`- Status: ${STATUS_LABEL[r.status]}${r.priority?` · Priority: ${PRIO_LABEL[r.priority]}`:''}${r.favorite?' · ★ Favorite':''}\n- Saved: ${r.savedAt}${r.reviewAt?` · Review: ${r.reviewAt}`:''}\n`;if(r.tags.length)out+=`- Tags: ${r.tags.map(t=>'#'+t.replace(/\s+/g,'-')).join(' ')}\n`;if(r.description)out+=`\n${r.description}\n`;if(r.notes)out+=`\n${r.notes}\n`;}}
  return out;
}
function exportBookmarksHtml(list){
  const ts=r=>Math.floor(new Date(r.createdAt||r.savedAt+'T12:00:00').getTime()/1000);
  const groups=new Map();list.filter(r=>r.url).forEach(r=>{const g=collName(r.collection)||r.folder||'Lantern';if(!groups.has(g))groups.set(g,[]);groups.get(g).push(r);});
  let out='<!DOCTYPE NETSCAPE-Bookmark-file-1>\n<!-- This is an automatically generated file. It will be read and overwritten. DO NOT EDIT! -->\n<META HTTP-EQUIV="Content-Type" CONTENT="text/html; charset=UTF-8">\n<TITLE>Bookmarks</TITLE>\n<H1>Bookmarks</H1>\n<DL><p>\n';
  for(const [g,rs] of groups){out+=`    <DT><H3 ADD_DATE="${Math.floor(Date.now()/1000)}">${esc(g)}</H3>\n    <DL><p>\n`;for(const r of rs){out+=`        <DT><A HREF="${esc(r.url)}" ADD_DATE="${ts(r)}"${r.tags.length?` TAGS="${esc(r.tags.join(','))}"`:''}>${esc(r.title||r.url)}</A>\n`;if(r.description||r.notes)out+=`        <DD>${esc((r.description||r.notes).slice(0,1000))}\n`;}out+='    </DL><p>\n';}
  return out+'</DL><p>\n';
}
function resourceToPlainText(r){return [r.title,r.url,r.description,r.tags.length?'Tags: '+r.tags.join(', '):'',r.notes].filter(Boolean).join('\n\n');}

/* ───────────────────────── Housekeeping ───────────────────────── */
function purgeOldTrash(){const cutoff=Date.now()-TRASH_DAYS*864e5;let n=0;[...State.resources].forEach(r=>{if(r.deletedAt&&new Date(r.deletedAt).getTime()<cutoff){hardDelete(r.id);n++;}});return n;}
function migrateData(){const v=State.meta.schema||0;if(v<SCHEMA_VERSION){setMeta('schema',SCHEMA_VERSION);}}
