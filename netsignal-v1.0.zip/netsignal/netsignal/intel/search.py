"""Smart search: interpret what the engineer typed and route to the right view.

Examples
  unyc787as0705                          -> device view
  unyc787as0705 Gi1/0/16                 -> interface history
  10.255.1.2 / 845c.315d.dfcf / 8456-...  -> events mentioning that IP / MAC
  %LINK-3-UPDOWN, LINK-3-UPDOWN          -> code filter
  bsao190                                -> site filter
  interfaces that flapped 3 times today  -> findings (link/edge flaps, threshold 3, today)
  bgp down / ospf issues                 -> routing findings
  auth failures on cmon200as1101         -> auth investigation filtered to host
  what changed last 2h                   -> configuration changes
  host:x code:y iface:z sev:<=3 since:2h -> explicit filters
  anything else                          -> full-text search
"""
from __future__ import annotations

import re

from ..netmodel import normalize_interface, normalize_mac, IF_TOKEN_RE

IP_RE = re.compile(r"^\d{1,3}(?:\.\d{1,3}){3}$")
MAC_RE = re.compile(r"^(?:[0-9a-f]{4}[.-][0-9a-f]{4}[.-][0-9a-f]{4}|(?:[0-9a-f]{2}[:-]){5}[0-9a-f]{2}|[0-9a-f]{12})$", re.I)
CODE_RE = re.compile(r"^%?([A-Z][A-Z0-9_]+-[0-7]-[A-Z0-9_]+)$", re.I)
TIME_RE = re.compile(r"\b(today|last\s+(\d+)\s*(m|min|mins|minutes?|h|hrs?|hours?|d|days?)|(?:in\s+the\s+)?past\s+(\d+)\s*(m|h|d)\w*|since\s+(\d+)\s*(m|h|d))\b", re.I)
KV_RE = re.compile(r"\b(host|site|iface|interface|code|cat|category|mac|ip|vlan|sev|signal|kind|user|neighbor|since|platform|role):(\S+)", re.I)

CATEGORY_WORDS = [
    (r"\b(bgp|ospf|eigrp|is-?is|routing|neighbou?rs?|adjacenc\w*|hsrp|vrrp|bfd)\b", "routing"),
    (r"\b(auth\w*|dot1x|802\.1x|mab|radius|ise|nac)\b", "auth"),
    (r"\b(poe|power|psu|pem|inline)\b", "power"),
    (r"\b(mac\s*moves?|mac\s*flap\w*|loop|spanning|stp|lacp|port-?channel|vpc)\b", "l2"),
    (r"\b(optic\w*|sfp|transceiver|dom|rx\s*power|tx\s*power)\b", "optics"),
    (r"\b(err-?disabled?|bpdu\s*guard|storm|udld|stack|crc|duplex)\b", "errors"),
    (r"\b(buffer|tcam|cpu|memory|fan|temperature|module|hardware)\b", "hardware"),
    (r"\b(config\w*|changes?|login|reload\w*|ntp|license|isdn|voice)\b", "system"),
    (r"\b(uplinks?|links?|interfaces?|ports?)\b", "links"),
]

PROTO_WORDS = {"bgp": "BGP", "ospf": "OSPF", "eigrp": "EIGRP", "isis": "IS-IS", "is-is": "IS-IS"}


def _range_from(text: str) -> str | None:
    m = TIME_RE.search(text)
    if not m:
        return None
    if m.group(1).lower() == "today":
        return "today"
    n = m.group(2) or m.group(4) or m.group(6)
    u = (m.group(3) or m.group(5) or m.group(7) or "h")[0].lower()
    return f"{int(n)}{u}"


def interpret(q: str, hosts: set[str], sites: set[str]) -> dict:
    raw = (q or "").strip()
    text = raw
    low = raw.lower()
    res: dict = {"query": raw, "filters": {}, "view": "investigate", "explain": []}
    rng = _range_from(low)
    if rng:
        res["range"] = rng
        res["explain"].append(f"time range {rng}")
        text = TIME_RE.sub(" ", text)

    # ---------- natural-language intents
    m = re.search(r"(interfaces?|ports?|links?|uplinks?)\s+(?:that\s+)?(?:have\s+)?flapp?(?:ed|ing|s)?"
                  r"(?:\s+(?:more\s+than|at\s+least|over|>=?)?\s*(\d+)\s*(?:times?|x))?", low)
    if m or re.search(r"\bflapp?(ing|ed|s)\b", low):
        n = int(m.group(2)) if m and m.group(2) else None
        res.update(view="findings", ftype="link_flap,edge_flap,link_bounce", min_cycles=n or 3)
        res["explain"].append(f"interfaces with at least {n or 3} down->up cycles")
        host = _find_host(low, hosts)
        if host:
            res["host"] = host
            res["explain"].append(f"on {host}")
        return res
    m = re.search(r"\b(bgp|ospf|eigrp|is-?is)\b.*\b(down|flap\w*|issues?|problems?|resets?|unstable|neighbou?rs?)\b", low) \
        or re.search(r"\b(?:down|unstable)\s+(bgp|ospf|eigrp|is-?is)\b", low)
    if m:
        proto = PROTO_WORDS.get(m.group(1).replace("-", ""), m.group(1).upper())
        res.update(view="findings", ftype="adj_down,adj_unstable,adj_reset", protocol=proto)
        res["explain"].append(f"{proto} adjacency problems")
        return res
    if re.search(r"\bwhat\s+changed\b|\bconfig(uration)?\s+changes?\b|\bwho\s+changed\b", low):
        res["filters"]["kind"] = "config_change"
        res["explain"].append("configuration changes")
        m = re.search(r"\bby\s+(\S+)", low)
        if m:
            res["filters"]["user"] = m.group(1)
            res["explain"].append(f"by {m.group(1)}")
        host = _find_host(low, hosts)
        if host:
            res["filters"]["host"] = host
        return res
    if re.search(r"\b(noisiest|top|busiest)\s+(devices?|hosts?|switches)\b", low):
        res.update(view="devices", sort="events")
        res["explain"].append("devices ranked by message volume")
        return res
    if re.search(r"\b(critical|major)\b.*\b(findings?|issues?|problems?|alerts?)\b|\bwhat('?s| is)\s+(wrong|broken)\b", low):
        res.update(view="findings", severity="major")
        res["explain"].append("major and critical findings")
        return res
    if re.search(r"\bmac\s*(moves?|flap\w*)\b|\bloops?\b", low):
        res.update(view="findings", ftype="mac_move")
        res["explain"].append("MAC move findings")
        return res

    # ---------- explicit key:value filters
    for k, v in KV_RE.findall(text):
        k = k.lower()
        if k in ("iface", "interface"):
            res["filters"]["iface"] = normalize_interface(v)
        elif k in ("cat", "category"):
            res["filters"]["category"] = v
        elif k == "sev":
            res["filters"]["sev_max"] = re.sub(r"[^\d]", "", v)
        elif k == "since":
            res["range"] = v
        elif k == "mac":
            res["filters"]["mac"] = normalize_mac(v) or v
        elif k == "code":
            res["filters"]["code"] = v.lstrip("%").upper()
        else:
            res["filters"][k] = v
        res["explain"].append(f"{k} = {v}")
    text = KV_RE.sub(" ", text)

    # ---------- entity detection
    leftovers = []
    tokens = text.split()
    i = 0
    while i < len(tokens):
        tok = tokens[i].strip(",;()")
        tl = tok.lower()
        if not tok:
            i += 1
            continue
        host = _match_host(tl, hosts)
        if host:
            res["filters"]["host"] = host
            res["explain"].append(f"device {host}")
        elif tl in sites:
            res["filters"]["site"] = tl
            res["explain"].append(f"site {tl}")
        elif IP_RE.match(tok):
            res["filters"]["ip"] = tok
            res["explain"].append(f"IP {tok}")
        elif MAC_RE.match(tok) and normalize_mac(tok):
            res["filters"]["mac"] = normalize_mac(tok)
            res["explain"].append(f"MAC {normalize_mac(tok)}")
        elif CODE_RE.match(tok) and "-" in tok:
            res["filters"]["code"] = CODE_RE.match(tok).group(1).upper()
            res["explain"].append(f"code {res['filters']['code']}")
        elif IF_TOKEN_RE.fullmatch(tok) or (i + 1 < len(tokens) and IF_TOKEN_RE.fullmatch(tok + tokens[i + 1])):
            if not IF_TOKEN_RE.fullmatch(tok):
                tok = tok + tokens[i + 1]
                i += 1
            res["filters"]["iface"] = normalize_interface(tok)
            res["explain"].append(f"interface {res['filters']['iface']}")
        elif tl in ("on", "for", "with", "show", "me", "all", "the", "in", "at", "events", "logs", "messages", "and"):
            pass
        else:
            leftovers.append(tok)
        i += 1

    # category words (only if nothing more specific is left)
    rest = " ".join(leftovers).lower()
    for rx, cat in CATEGORY_WORDS:
        if re.search(rx, rest):
            res["filters"]["category"] = cat
            res["explain"].append(f"category {cat}")
            rest = re.sub(rx, " ", rest)
            leftovers = rest.split()
            break
    for w in ("failures", "failure", "failed", "fails", "fail", "errors", "error", "issues", "problems", "alerts",
              "down", "events", "today"):
        if w in leftovers and res["filters"].get("category"):
            leftovers.remove(w)
            if w.startswith("fail") and res["filters"]["category"] == "auth":
                res["filters"]["kind"] = "auth_fail"
    if leftovers:
        res["filters"]["q"] = " ".join(leftovers)
        res["explain"].append(f"text \"{' '.join(leftovers)}\"")

    f = res["filters"]
    if set(f) == {"host"}:
        res["view"] = "device"
        res["host"] = f["host"]
    elif set(f) == {"host", "iface"}:
        res["view"] = "interface"
        res["host"], res["iface"] = f["host"], f["iface"]
    elif set(f) == {"category"}:
        res["view"] = "category"
        res["category"] = f["category"]
    if not res["explain"]:
        res["explain"].append("everything")
    return res


def _match_host(tok: str, hosts: set[str]) -> str | None:
    short = tok.split(".")[0]
    if short in hosts:
        return short
    if len(short) >= 7:
        cands = [h for h in hosts if h.startswith(short)]
        if len(cands) == 1:
            return cands[0]
    return None


def _find_host(text: str, hosts: set[str]) -> str | None:
    for tok in text.split():
        h = _match_host(tok.strip(",;"), hosts)
        if h:
            return h
    return None


def suggestions(prefix: str, store, limit: int = 8) -> list[dict]:
    p = (prefix or "").strip().lower()
    out: list[dict] = []
    if len(p) < 2:
        return out
    for r in store.q("SELECT host, MIN(site) site, MIN(role) role, COUNT(*) n FROM events WHERE host LIKE ? "
                     "GROUP BY host ORDER BY n DESC LIMIT ?", (p + "%", limit)):
        out.append({"type": "device", "value": r["host"], "label": r["host"], "hint": f"{r['n']} msgs · site {r['site']}"})
    if len(out) < limit:
        for r in store.q("SELECT site, COUNT(DISTINCT host) d FROM events WHERE site LIKE ? GROUP BY site LIMIT 3",
                         (p + "%",)):
            out.append({"type": "site", "value": r["site"], "label": f"site {r['site']}", "hint": f"{r['d']} devices"})
    if len(out) < limit and re.match(r"^%?[a-z]", p):
        pp = p.lstrip("%").upper()
        for r in store.q("SELECT code, COUNT(*) n FROM events WHERE code LIKE ? GROUP BY code ORDER BY n DESC LIMIT 5",
                         (pp + "%",)):
            out.append({"type": "code", "value": r["code"], "label": "%" + r["code"], "hint": f"{r['n']} msgs"})
    if len(out) < limit and re.match(r"^[0-9a-f]{4}\.", p):
        for r in store.q("SELECT mac, COUNT(*) n FROM events WHERE mac LIKE ? GROUP BY mac LIMIT 4", (p + "%",)):
            out.append({"type": "mac", "value": r["mac"], "label": r["mac"], "hint": f"{r['n']} msgs"})
    return out[:limit]
