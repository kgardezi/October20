"""Regenerate the synthetic Visio examples and an optional layout screenshot."""
import os
import pathlib
import shutil
from playwright.sync_api import sync_playwright

root=pathlib.Path(__file__).resolve().parents[1]
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium'),headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':1600,'height':1100},accept_downloads=True)
    page.goto(os.environ.get('IDEABOARD_URL','http://127.0.0.1:8000/'))
    page.wait_for_function('window.ideaBoard')
    page.locator('#fileInput').set_input_files(root/'Whole-network-demo.ideaboard.json')
    page.wait_for_function("document.querySelector('#boardName').value.startsWith('Synthetic network')")
    # Visio look (the default) plus the canvas look on light and black gradient backgrounds
    for name,look,bg,gradient,grid in [('Example-Visio-look','visio','none',False,'screen'),('Example-canvas-light-gradient','ideaboard','light',True,'none'),('Example-canvas-black-gradient','ideaboard','black',True,'none')]:
        page.locator('#menuBtn').click();page.locator('[data-menu="visio"]').click()
        page.locator('#visioStyle').select_option(look);page.locator('#visioBg').select_option(bg)
        page.locator('#visioGradient').set_checked(gradient);page.locator('#visioGrid').select_option(grid)
        with page.expect_download() as d:page.locator('#visioDownload').click()
        d.value.save_as(root/f'{name}.vsdx')
        page.locator('#visioClose').click()
    page.locator('#pageBtn').click();page.locator('#pagesPanel .pp-name').filter(has_text='Physical link speeds').click()
    page.locator('#canvas').focus();page.keyboard.press('Shift+F')
    page.wait_for_function("document.body.classList.contains('clean')")
    page.evaluate('ideaBoard.zoomFit()')
    page.wait_for_timeout(500)
    screenshot=os.environ.get('IDEABOARD_PREVIEW')
    if screenshot:page.screenshot(path=screenshot)
    print('Generated synthetic Visio-look and canvas-look Visio examples.')
    browser.close()
