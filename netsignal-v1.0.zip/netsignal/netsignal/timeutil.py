"""Time handling.

All timestamps are stored as *wall-clock epochs*: the local wall time written by the
syslog server, encoded as if it were UTC (calendar.timegm). This keeps displayed
times identical to what engineers see with `tail -f log`, regardless of the
timezone of the machine running NetSignal (e.g. a Windows VDI in another region).
"""
from __future__ import annotations

import calendar
import re
import time
from datetime import datetime, timedelta

try:
    from zoneinfo import ZoneInfo
except ImportError:  # pragma: no cover
    ZoneInfo = None

_TZ = None

MONTHS = {m: i for i, m in enumerate(
    ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1)}


def set_timezone(name: str | None) -> None:
    global _TZ
    _TZ = None
    if name and ZoneInfo:
        try:
            _TZ = ZoneInfo(name)
        except Exception:
            _TZ = None


def now_dt() -> datetime:
    if _TZ is not None:
        return datetime.now(_TZ).replace(tzinfo=None)
    return datetime.now()


def to_wall(dt: datetime) -> float:
    return calendar.timegm(dt.timetuple()) + dt.microsecond / 1e6


def now_wall() -> float:
    return to_wall(now_dt())


def from_wall(ts: float) -> datetime:
    return datetime(1970, 1, 1) + timedelta(seconds=ts)


def fmt(ts: float | None, ms: bool = False) -> str:
    if ts is None:
        return ""
    d = from_wall(ts)
    return d.strftime("%Y-%m-%d %H:%M:%S") + (f".{d.microsecond // 1000:03d}" if ms else "")


def start_of_day(ts: float) -> float:
    return ts - (ts % 86400)


_RANGE_RE = re.compile(r"^(\d+)\s*([smhdw])$")


def parse_range(r: str | None, default: str = "24h") -> float:
    """'15m' -> seconds.  'today' handled by caller."""
    r = (r or default).strip().lower()
    m = _RANGE_RE.match(r)
    if not m:
        m = _RANGE_RE.match(default)
    n, unit = int(m.group(1)), m.group(2)
    return n * {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}[unit]


def window(range_: str | None = None, t0: float | None = None, t1: float | None = None) -> tuple[float, float]:
    now = now_wall()
    if t0 is not None:
        return float(t0), float(t1 if t1 is not None else now)
    if (range_ or "").lower() == "today":
        return start_of_day(now), now
    return now - parse_range(range_), now


def monotonic() -> float:
    return time.monotonic()
