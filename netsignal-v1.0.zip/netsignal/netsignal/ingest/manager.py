"""Ingestion: live tail of the active `log` file + import of daily .gz archives.

Reliability features
- Offset-based tailing with a content fingerprint (first bytes of the file) so a
  restart or reconnect resumes exactly where it stopped.
- Rotation detection (file shrank or fingerprint changed). The unread tail of the
  rotated file is recovered from the newest archive by skipping the bytes that
  were already read - nothing is lost between the last poll and the rotation.
- Automatic reconnect with exponential back-off (1s .. 60s) on SSH/SFTP errors.
- Every line is identified by a hash of its raw text; the database ignores
  duplicates, so overlapping reads (archive vs live, retries) are harmless.
"""
from __future__ import annotations

import gzip
import hashlib
import io
import queue
import re
import threading
import time
import traceback
from datetime import datetime

from ..classifier import Classifier
from ..parsers import get_parser
from ..store import Store
from ..timeutil import now_dt, now_wall
from .access import make_access

CHUNK = 4 * 1024 * 1024
BATCH = 4000
FP_LEN = 256


def _fp(data: bytes) -> str:
    return hashlib.sha1(data).hexdigest()


class Pipeline:
    """parse -> classify -> store -> publish"""

    def __init__(self, store: Store, classifier: Classifier, vendor: str = "cisco"):
        self.store = store
        self.cls = classifier
        self.parser = get_parser(vendor)
        self.subscribers: list = []
        self.sub_lock = threading.Lock()
        self.parsed = 0
        self.unparsed = 0

    def process(self, lines: list[str], source: str, ref_dt: datetime, publish: bool = True) -> int:
        evs = []
        for ln in lines:
            ev = self.parser.parse_line(ln, ref_dt)
            if ev is None:
                continue
            if ev.get("unparsed"):
                self.unparsed += 1
                continue
            evs.append(self.cls.classify(ev))
        self.parsed += len(evs)
        new = self.store.insert_events(evs, source)
        if publish and new:
            self.publish(new[-500:])
        return len(new)

    def publish(self, events: list[dict]):
        slim = [{k: v for k, v in e.items() if k != "raw"} | {"raw": e.get("raw")} for e in events]
        with self.sub_lock:
            subs = list(self.subscribers)
        for loop, q in subs:
            try:
                loop.call_soon_threadsafe(_put_nowait, q, slim)
            except RuntimeError:
                pass

    def subscribe(self, loop, q):
        with self.sub_lock:
            self.subscribers.append((loop, q))

    def unsubscribe(self, loop, q):
        with self.sub_lock:
            self.subscribers = [s for s in self.subscribers if s[1] is not q]


def _put_nowait(q, item):
    try:
        q.put_nowait(item)
    except Exception:
        pass  # slow client - drop


class IngestManager:
    def __init__(self, cfg: dict, store: Store, pipeline: Pipeline):
        self.cfg = cfg
        self.src = cfg["source"]
        self.store = store
        self.pipe = pipeline
        self.stop_ev = threading.Event()
        self.archive_re = re.compile(self.src.get("archive_pattern") or r"^log(\d{8})\.gz$")
        self.live_name = self.src.get("live_file", "log")
        self.jobs: "queue.Queue[tuple[str, int]]" = queue.Queue()
        self.job_status: dict[str, dict] = {}
        self.status = {
            "mode": self.src.get("mode"), "target": None, "connected": False, "last_error": None,
            "reconnects": 0, "live": {"offset": 0, "size": 0, "lag_bytes": 0, "lines": 0,
                                       "last_read": None, "rotations": 0, "rate": 0.0},
            "started": now_wall(),
        }
        self.known_archives: set[str] = set()
        self._pending_catchup: list[dict] = []
        self._threads: list[threading.Thread] = []

    # ------------------------------------------------------------------ control
    def start(self):
        for target in (self._live_loop, self._archive_loop, self._maintenance_loop):
            t = threading.Thread(target=target, daemon=True, name=target.__name__)
            t.start()
            self._threads.append(t)

    def stop(self):
        self.stop_ev.set()

    def queue_archive(self, name: str, skip_bytes: int = 0):
        if not self.archive_re.match(name):
            raise ValueError("not an archive file name")
        self.job_status[name] = {"state": "queued", "progress": 0.0}
        self.store.file_set(name, status="queued")
        self.jobs.put((name, skip_bytes))

    # ------------------------------------------------------------------ helpers
    def _archive_day(self, name: str) -> str | None:
        m = self.archive_re.match(name)
        return m.group(1) if m else None

    def list_files(self, access) -> list[dict]:
        out = []
        for name, size, mtime in access.listdir():
            day = self._archive_day(name)
            if name == self.live_name or day:
                out.append({"name": name, "size": size, "mtime": mtime, "day": day,
                            "live": name == self.live_name})
        out.sort(key=lambda f: (not f["live"], -(int(f["day"]) if f["day"] else 0)))
        return out

    # ------------------------------------------------------------------ live tail
    def _live_loop(self):
        access = None
        backoff = 1.0
        poll = float(self.src.get("poll_interval", 1.0))
        state = self.store.kv_get("live_state", {}) or {}
        offset = None
        fp_len, fp = 0, None
        partial = b""
        rate_win: list[tuple[float, int]] = []
        first_listing = True
        while not self.stop_ev.is_set():
            try:
                if access is None:
                    access = make_access(self.cfg)
                    self.status["target"] = access.describe()
                    access.connect()
                    self.status["connected"] = True
                    self.status["last_error"] = None
                    backoff = 1.0
                    if first_listing:
                        self._initial_backfill(access)
                        first_listing = False
                path = access.join(self.live_name)
                size, mtime = access.stat(path)

                if offset is None:  # first contact with the live file
                    head = access.read_range(path, 0, FP_LEN)
                    fp_len, fp = len(head), _fp(head)
                    if state.get("fp") == fp and state.get("fp_len") == fp_len and state.get("offset", 0) <= size:
                        offset = state["offset"]
                    else:
                        offset = self._initial_offset(access, path, size)
                    partial = b""

                # ---- rotation / truncation detection
                rotated = size < offset
                if not rotated and fp_len > 0:
                    head = access.read_range(path, 0, fp_len)
                    rotated = _fp(head) != fp
                if rotated:
                    self.status["live"]["rotations"] += 1
                    self._pending_catchup.append({"skip": offset, "since": time.time(),
                                                  "known": set(self.known_archives)})
                    offset, partial = 0, b""
                    head = access.read_range(path, 0, FP_LEN)
                    fp_len, fp = len(head), _fp(head)
                elif fp_len < FP_LEN and size > fp_len:
                    head = access.read_range(path, 0, FP_LEN)
                    fp_len, fp = len(head), _fp(head)

                # ---- read new data
                if size > offset:
                    data = access.read_range(path, offset, min(CHUNK, size - offset))
                    offset += len(data)
                    data = partial + data
                    cut = data.rfind(b"\n")
                    if cut < 0:
                        partial = data
                        lines = []
                    else:
                        partial = data[cut + 1:]
                        lines = data[:cut].decode("utf-8", "replace").split("\n")
                    backlog = size - offset
                    for i in range(0, len(lines), BATCH):
                        self.pipe.process(lines[i:i + BATCH], self.live_name, now_dt(),
                                          publish=backlog < 2 * 1024 * 1024)
                    lv = self.status["live"]
                    lv["lines"] += len(lines)
                    rate_win.append((time.time(), len(lines)))
                    self.store.kv_set("live_state", {"fp": fp, "fp_len": fp_len, "offset": offset - len(partial)})
                    lv["last_read"] = now_wall()
                    if backlog > 0:
                        continue  # keep draining without sleeping
                lv = self.status["live"]
                lv.update(offset=offset, size=size, lag_bytes=max(0, size - offset))
                cutoff = time.time() - 60
                rate_win = [r for r in rate_win if r[0] >= cutoff]
                lv["rate"] = round(sum(n for _, n in rate_win) / 60.0, 2)
                self._process_catchups(access)
                self.stop_ev.wait(poll)
            except Exception as e:  # network drop, permission, etc.
                self.status["connected"] = False
                self.status["last_error"] = f"{type(e).__name__}: {e}"
                self.status["reconnects"] += 1
                try:
                    access and access.close()
                except Exception:
                    pass
                access = None
                offset = None  # re-validate fingerprint after reconnect
                state = self.store.kv_get("live_state", {}) or {}
                self.stop_ev.wait(backoff)
                backoff = min(60.0, backoff * 2)

    def _initial_offset(self, access, path, size) -> int:
        mode = str(self.src.get("initial_read", "full")).lower()
        if mode == "end":
            return size
        if mode.startswith("tail:"):
            nbytes = int(float(mode.split(":", 1)[1]) * 1024 * 1024)
            start = max(0, size - nbytes)
            if start == 0:
                return 0
            chunk = access.read_range(path, start, 65536)
            nl = chunk.find(b"\n")
            return start + nl + 1 if nl >= 0 else start
        return 0

    def _initial_backfill(self, access):
        files = self.list_files(access)
        loaded = self.store.files()
        archives = [f for f in files if f["day"]]
        self.known_archives = {f["name"] for f in archives}
        n = int(self.src.get("backfill_days", 2))
        for f in archives[:n]:
            st = loaded.get(f["name"], {})
            if st.get("status") == "loaded" and st.get("size") == f["size"]:
                continue
            self.queue_archive(f["name"])

    def _process_catchups(self, access):
        """After a rotation, import the unread tail of the rotated file from its archive."""
        if not self._pending_catchup:
            return
        files = self.list_files(access)
        for pc in list(self._pending_catchup):
            new = [f for f in files if f["day"] and f["name"] not in pc["known"]]
            if new:
                newest = new[0]
                # wait for compression to finish (size stable across polls)
                if pc.get("last_size") != newest["size"]:
                    pc["last_size"] = newest["size"]
                    continue
                self.known_archives.add(newest["name"])
                self.queue_archive(newest["name"], skip_bytes=pc["skip"])
                self._pending_catchup.remove(pc)
            elif time.time() - pc["since"] > 1800:
                self._pending_catchup.remove(pc)  # give up after 30 min

    # ------------------------------------------------------------------ archives
    def _archive_loop(self):
        access = None
        while not self.stop_ev.is_set():
            try:
                name, skip = self.jobs.get(timeout=1.0)
            except queue.Empty:
                continue
            js = self.job_status.setdefault(name, {})
            js.update(state="loading", progress=0.0, started=time.time())
            self.store.file_set(name, status="loading", error=None)
            try:
                if access is None:
                    access = make_access(self.cfg)
                    access.connect()
                self._import_archive(access, name, skip, js)
            except Exception as e:
                js.update(state="error", error=f"{type(e).__name__}: {e}")
                self.store.file_set(name, status="error", error=str(e))
                traceback.print_exc()
                try:
                    access and access.close()
                except Exception:
                    pass
                access = None

    def _import_archive(self, access, name: str, skip: int, js: dict):
        path = access.join(name)
        size, mtime = access.stat(path)
        day = self._archive_day(name)
        try:
            ref = datetime.strptime(day, "%Y%m%d")
        except (TypeError, ValueError):
            ref = now_dt()
        raw = access.open_read(path)
        counter = _CountingReader(raw)
        stream = gzip.GzipFile(fileobj=counter) if name.endswith(".gz") else counter
        text = io.TextIOWrapper(stream, encoding="utf-8", errors="replace", newline="\n")
        n_lines = n_new = 0
        consumed = 0
        batch: list[str] = []
        try:
            for line in text:
                if skip and consumed < skip:
                    consumed += len(line.encode("utf-8", "replace"))
                    continue
                batch.append(line)
                if len(batch) >= BATCH:
                    n_new += self.pipe.process(batch, name, ref, publish=False)
                    n_lines += len(batch)
                    batch = []
                    js["progress"] = round(min(1.0, counter.n / max(1, size)), 3)
                    js["lines"] = n_lines
                if self.stop_ev.is_set():
                    return
            if batch:
                n_new += self.pipe.process(batch, name, ref, publish=False)
                n_lines += len(batch)
        finally:
            try:
                raw.close()
            except Exception:
                pass
        js.update(state="loaded", progress=1.0, lines=n_lines, inserted=n_new, finished=time.time())
        self.store.file_set(name, day=day, size=size, mtime=mtime, status="loaded", lines=n_lines,
                            inserted=n_new, loaded_at=now_wall(), error=None)

    # ------------------------------------------------------------------ maintenance
    def _maintenance_loop(self):
        days = int(self.cfg["database"].get("retention_days", 7))
        while not self.stop_ev.is_set():
            try:
                self.store.purge_before(now_wall() - days * 86400)
            except Exception:
                traceback.print_exc()
            self.stop_ev.wait(6 * 3600)

    # ------------------------------------------------------------------ deep search
    def deep_search(self, names: list[str], terms: str, limit: int = 500, max_seconds: float = 90) -> dict:
        """Scan archives on the fly WITHOUT importing them (historical search beyond retention)."""
        needles = [t.lower() for t in terms.split() if t]
        access = make_access(self.cfg)
        access.connect()
        results, scanned, started = [], 0, time.time()
        truncated = False
        try:
            for name in names:
                if not (self.archive_re.match(name) or name == self.live_name):
                    continue
                day = self._archive_day(name)
                ref = datetime.strptime(day, "%Y%m%d") if day else now_dt()
                raw = access.open_read(access.join(name))
                stream = gzip.GzipFile(fileobj=raw) if name.endswith(".gz") else raw
                text = io.TextIOWrapper(stream, encoding="utf-8", errors="replace", newline="\n")
                try:
                    for line in text:
                        scanned += 1
                        low = line.lower()
                        if all(n in low for n in needles):
                            ev = self.pipe.parser.parse_line(line, ref)
                            if ev and not ev.get("unparsed"):
                                ev = self.pipe.cls.classify(ev)
                                ev["source"] = name
                                results.append(ev)
                                if len(results) >= limit:
                                    truncated = True
                                    break
                        if scanned % 20000 == 0 and time.time() - started > max_seconds:
                            truncated = True
                            break
                finally:
                    raw.close()
                if truncated:
                    break
        finally:
            access.close()
        return {"events": results, "scanned": scanned, "truncated": truncated,
                "seconds": round(time.time() - started, 2)}


class _CountingReader(io.RawIOBase):
    """Wraps a binary file object and counts compressed bytes read (for progress)."""

    def __init__(self, f):
        self.f = f
        self.n = 0

    def readable(self):
        return True

    def readinto(self, b):
        data = self.f.read(len(b))
        n = len(data)
        b[:n] = data
        self.n += n
        return n

    def read(self, size=-1):
        data = self.f.read(size)
        self.n += len(data)
        return data
