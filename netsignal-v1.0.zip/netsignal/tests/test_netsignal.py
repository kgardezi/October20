"""NetSignal tests - run with:  python -m unittest discover -s tests   (or pytest)"""
import gzip
import os
import shutil
import sys
import tempfile
import time
import unittest
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from netsignal.classifier import Classifier          # noqa: E402
from netsignal.config import load_config             # noqa: E402
from netsignal.ingest.manager import IngestManager, Pipeline  # noqa: E402
from netsignal.intel.findings import Intel           # noqa: E402
from netsignal.intel.search import interpret         # noqa: E402
from netsignal.parsers import cisco                  # noqa: E402
from netsignal.store import Store                    # noqa: E402
from netsignal.timeutil import from_wall             # noqa: E402

REF = datetime(2026, 10, 19)
CFG = load_config()

# Lines copied verbatim from the production server screenshots
REAL = {
    "lineproto": "Oct 19 15:44:47 unyc787as0705.us.net.intra Oct 19 2026 15:44:46.647 EDST: %LINEPROTO-5-UPDOWN: Line protocol on Interface GigabitEthernet1/0/16, changed state to down",
    "dot1x_fail": "Oct 19 15:44:47 cmon200as1901.us.net.intra Oct 19 2026 15:44:46.409 EDST: %DOT1X-5-FAIL: Switch 1 R0/0: sessmgrd: Authentication failed for client (1865.71f1.3eaf) with reason (No Response from Client) on Interface Gi2/0/24 AuditSessionID 1373710A0001967B55B1B2B1",
    "mab_ok": "Oct 19 15:44:47 cmon200as1901.us.net.intra Oct 19 2026 15:44:46.439 EDST: %MAB-5-SUCCESS: Switch 1 R0/0: sessmgrd: Authentication successful for client (1865.71f1.3eaf) on Interface Gi2/0/24 AuditSessionID 1373710A0001967B55B1B2B1",
    "poe_err": "Oct 19 15:44:49 mmex340as0201.us.net.intra Oct 19 2026 15:44:48.821 EDST: %ILPOWER-3-CONTROLLER_PORT_ERR: Controller port error, Interface Gi4/0/41: Power Controller reports power Tstart error detected",
    "mac_move": "Oct 19 15:50:32 usec755sf0160.us.net.intra 2026 Oct 19 15:50:32.921215 EDST: %L2FM-4-L2FM_MAC_MOVE2: Mac 0050.568d.51fb in vlan 507 has moved from Po2 to Eth1/38",
    "tahusd": "Oct 19 15:48:27 bsan249sf0209.br.net.intra 2026 Oct 19 15:48:27.058550 EDST: %TAHUSD-SLOT1-4-BUFFER_THRESHOLD_EXCEEDED: Module 1 Instance 1 Pool-group buffer 90 percent threshold is exceeded! Please see http://cisco.com/go/n9k-tahusd-buffer for more information (message repeated 3 times)",
    "isdn": "Oct 19 15:50:30 bsao190vg1101.br.net.intra Oct 19 2026 15:50:29.140 EDST: %ISDN-6-CONNECT: Interface Serial0/2/2:2 is now connected to 5513100 5593012 Receptionist SPCT",
    "budget": "Oct 19 15:44:48 bsao190as0802.br.net.intra Oct 19 2026 15:44:47.297 EDST: %ILPOWER-6-SET_AVAILABLE_ILPOWER: Available POE budget for switch 2 is updated. New available POE budget = 1138.0 Watts",
}


def parse(line):
    cls = Classifier(CFG)
    return cls.classify(cisco.parse_line(line, REF))


class ParserTests(unittest.TestCase):
    def test_iosxe_format(self):
        e = parse(REAL["lineproto"])
        self.assertEqual(e["host"], "unyc787as0705")
        self.assertEqual(e["site"], "unyc787")
        self.assertEqual(e["code"], "LINEPROTO-5-UPDOWN")
        self.assertEqual(e["interface"], "GigabitEthernet1/0/16")
        self.assertEqual(e["state"], "down")
        self.assertEqual(e["iface_class"], "edge")
        self.assertEqual(e["signal"], "routine")      # access-port bounce is routine
        self.assertAlmostEqual(e["dev_ts"] % 1, 0.647, places=3)

    def test_nxos_format_and_mac_move(self):
        e = parse(REAL["mac_move"])
        self.assertEqual(e["platform"], "nx-os")
        self.assertEqual(e["mac"], "0050.568d.51fb")
        self.assertEqual(e["vlan"], 507)
        self.assertEqual(e["kind"], "mac_move")
        self.assertIn("Port-channel2", e["attrs"])

    def test_slot_and_repeat(self):
        e = parse(REAL["tahusd"])
        self.assertEqual(e["code"], "TAHUSD-4-BUFFER_THRESHOLD_EXCEEDED")
        self.assertEqual(e["slot"], "SLOT1")
        self.assertEqual(e["repeat"], 3)
        self.assertEqual(e["category"], "hardware")

    def test_auth_and_poe(self):
        f = parse(REAL["dot1x_fail"])
        self.assertEqual((f["kind"], f["mac"], f["interface"]), ("auth_fail", "1865.71f1.3eaf", "GigabitEthernet2/0/24"))
        self.assertEqual(f["signal"], "routine")      # first step of expected fallback
        p = parse(REAL["poe_err"])
        self.assertEqual((p["category"], p["kind"], p["interface"]), ("power", "poe_error", "GigabitEthernet4/0/41"))
        self.assertEqual(parse(REAL["budget"])["signal"], "routine")
        self.assertEqual(parse(REAL["isdn"])["signal"], "routine")

    def test_ios_unsynced_clock_and_unknown(self):
        e = parse("Oct 19 15:44:47 r1.x 123: *Oct 19 15:44:46.111: %FOO-2-BAR_BAZ: something odd")
        self.assertEqual(e["clock_flag"], "unsynced")
        self.assertEqual(e["category"], "other")
        self.assertEqual(e["signal"], "major")        # severity 2 fallback

    def test_year_rollover(self):
        e = cisco.parse_line("Dec 31 23:59:59 h.x Dec 31 2025 23:59:58.000 EDST: %SYS-5-CONFIG_I: x", datetime(2026, 1, 1))
        self.assertEqual(from_wall(e["rx_ts"]).year, 2025)


class StoreFixture(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.mkdtemp()
        self.store = Store(os.path.join(self.tmp, "t.db"))
        self.cls = Classifier(CFG)
        self.pipe = Pipeline(self.store, self.cls)

    def tearDown(self):
        shutil.rmtree(self.tmp, ignore_errors=True)


class IngestTests(StoreFixture):
    def test_dedup(self):
        lines = list(REAL.values())
        self.assertEqual(self.pipe.process(lines, "log", REF), len(lines))
        self.assertEqual(self.pipe.process(lines, "log20261019.gz", REF), 0)  # archive overlap ignored

    def test_tail_rotation_and_resume(self):
        d = Path(self.tmp) / "CISCO"
        d.mkdir()
        cfg = dict(CFG)
        cfg["source"] = dict(CFG["source"], mode="local", backfill_days=0, poll_interval=0.1,
                             local={"directory": str(d)})
        a = [REAL["lineproto"], REAL["mac_move"]]
        b = [REAL["poe_err"], REAL["tahusd"]]
        c = [REAL["isdn"], REAL["budget"]]
        (d / "log").write_text("\n".join(a) + "\n")
        mgr = IngestManager(cfg, self.store, self.pipe)
        mgr.start()
        try:
            self._wait(lambda: self._count() == 2)
            with open(d / "log", "a") as f:       # lines written just before rotation
                f.write("\n".join(b) + "\n")
            # logrotate: rename + compress, new empty live file (before the tailer reads b)
            data = (d / "log").read_bytes()
            (d / "log").write_text("")
            with gzip.open(d / "log20261019.gz", "wb") as g:
                g.write(data)
            with open(d / "log", "a") as f:
                f.write("\n".join(c) + "\n")
            self._wait(lambda: self._count() == 6, timeout=15)
        finally:
            mgr.stop()
        self.assertEqual(self._count(), 6, "rotated tail recovered from archive, no duplicates")

    def _count(self):
        return self.store.one("SELECT COUNT(*) n FROM events")["n"]

    def _wait(self, cond, timeout=8):
        end = time.time() + timeout
        while time.time() < end:
            if cond():
                return
            time.sleep(0.1)


def L(t, host, code, msg, nx=False):
    """Build a syslog line at wall time t."""
    d = from_wall(t)
    mon = d.strftime("%b")
    dev = (f"{d.year} {mon} {d.day:02d} {d:%H:%M:%S}.000000 EDST" if nx else f"{mon} {d.day:2d} {d.year} {d:%H:%M:%S}.000 EDST")
    return f"{mon} {d.day:2d} {d:%H:%M:%S} {host}.us.net.intra {dev}: %{code}: {msg}"


class IntelTests(StoreFixture):
    T = 1792400000.0

    def findings(self, lines):
        self.pipe.process(lines, "log", from_wall(self.T))
        return Intel(self.store, self.cls, CFG).findings(self.T - 3600, self.T + 7200)

    def test_single_down_is_not_flapping(self):
        t = self.T
        fs = self.findings([L(t, "unyc787as0705", "LINK-3-UPDOWN", "Interface TenGigabitEthernet1/1/1, changed state to down"),
                            L(t + 30, "unyc787as0705", "LINK-3-UPDOWN", "Interface TenGigabitEthernet1/1/1, changed state to up")])
        self.assertFalse([f for f in fs if f["type"] == "link_flap"])
        self.assertTrue([f for f in fs if f["type"] == "link_bounce"])

    def test_three_cycles_is_flapping(self):
        lines = []
        for i in range(3):
            lines += [L(self.T + i * 100, "unyc787as0705", "LINK-3-UPDOWN", "Interface TenGigabitEthernet1/1/1, changed state to down"),
                      L(self.T + i * 100 + 10, "unyc787as0705", "LINK-3-UPDOWN", "Interface TenGigabitEthernet1/1/1, changed state to up")]
        fl = [f for f in self.findings(lines) if f["type"] == "link_flap"]
        self.assertEqual(len(fl), 1)
        self.assertEqual(fl[0]["metrics"]["down_up_cycles"], 3)

    def test_dot1x_fallback_is_not_a_failure(self):
        lines = []
        for i in range(10):
            lines += [L(self.T + i * 60, "cmon200as1901", "DOT1X-5-FAIL", "Switch 1 R0/0: sessmgrd: Authentication failed for client (1865.71f1.3eaf) with reason (No Response from Client) on Interface Gi2/0/24 AuditSessionID A"),
                      L(self.T + i * 60 + 1, "cmon200as1901", "MAB-5-SUCCESS", "Switch 1 R0/0: sessmgrd: Authentication successful for client (1865.71f1.3eaf) on Interface Gi2/0/24 AuditSessionID A")]
        self.assertFalse([f for f in self.findings(lines) if f["type"] == "auth_repeat"])

    def test_routing_correlation_is_timing_only(self):
        t = self.T
        fs = self.findings([
            L(t, "unyc787rt0101", "LINK-3-UPDOWN", "Interface GigabitEthernet0/0/1, changed state to down"),
            L(t + 1, "unyc787rt0101", "OSPF-5-ADJCHG", "Process 1, Nbr 10.255.1.2 on GigabitEthernet0/0/1 from FULL to DOWN, Neighbor Down: Interface down or detached")])
        adj = [f for f in fs if f["type"] == "adj_down"][0]
        self.assertTrue(any("went down" in c["text"] and "before" in c["text"] for c in adj["context"]))


class SearchTests(unittest.TestCase):
    H = {"unyc787as0705", "cmon200as1101"}

    def test_intents(self):
        r = interpret("interfaces that flapped 3 times today", self.H, set())
        self.assertEqual((r["view"], r["min_cycles"], r["range"]), ("findings", 3, "today"))
        self.assertEqual(interpret("unyc787as0705 Te1/1/1", self.H, set())["iface"], "TenGigabitEthernet1/1/1")
        self.assertEqual(interpret("845C-315D-DFCF", self.H, set())["filters"]["mac"], "845c.315d.dfcf")
        self.assertEqual(interpret("bgp down", self.H, set())["protocol"], "BGP")


if __name__ == "__main__":
    unittest.main()
