# Changes in 3.8.0

Focus: a Visio export that looks and behaves like a native Visio drawing, better PNG/SVG exports, and features from earlier builds that 3.7.0 had lost.

## Visio export
- **Things stay together when you edit in Visio.** Port names were loose rectangles and stayed behind when a device moved; they are now tied to their link by ShapeSheet formulas (same distance from the port, same offset) and follow it when Visio reroutes. Link labels ride on the middle of the path the same way. Rack-unit info lines are the rack group's own text instead of a separate text box, and the group's parts scale with it.
- **Calmer rerouting.** Site frames, port names, notes, text, pictures and pencil marks no longer act as obstacles for Visio's connector router (they caused long detours when a device moved). Port names no longer have connection points that links could accidentally glue to. Straight links use Visio's Straight route style; no line jumps where links cross.
- **Site frames are Visio containers**: moving a frame moves the devices in it, as on the canvas.
- **Layers** on every page: Sites, Annotations, Pictures, Pipes, Links, Devices, Port labels, Notes, Shapes and text.
- **Visio look** (new default): white page, standard Visio line weights, port names as small text, thin solid frames, Calibri/Segoe UI/Arial. The previous appearance remains as **Canvas look**, with Light/Black gradient backgrounds.
- Device Shape Data uses Visio's network field names (Network Name, IP Address, Subnet Mask) so Visio reports and data graphics recognise them.
- Grid choice: Visio's own on-screen grid (not printed), printed graph paper, or none. Graph paper now also works with the plain white page.
- Visio opens on the first page zoomed to fit. Files are deflate-compressed like Visio's own (1.3 MB → about 90 KB for the 10-page example).
- Import: port names typed into the port tags in Visio come back as the link's port labels; hostnames are also read from Network Name.
- The export window remembers its choices and has two switches (labels follow links; frames as containers) for falling back to plain behaviour.

## PNG and SVG
- New Menu ▸ Image export options…: area, background (canvas, white, transparent), colours (current or always light), PNG resolution 1×–4×, SVG text (outlined or editable), grid on/off. Export PNG / Export SVG use the remembered choices.
- PNG files record their resolution, so Office and Visio insert them at drawing size instead of twice as large. Pages too large for a browser canvas are reduced automatically with a message instead of failing silently.
- Editable SVG for Visio, PowerPoint and Inkscape: real text, no filters, and line positions that do not rely on browser-only attributes.
- Outlined SVG no longer embeds the font when every word is already outlined.

## Restored from earlier builds
- **3.6.1 Nexus/ASR parsing** (3.7.0 was built from 3.6.0 and lost it): NX-OS `show lldp neighbors detail`, NX-OS `show interface description` sections, truncated NX-OS status states (`notconnec`, `xcvrAbsen`…), `show interface brief`, `show ip ospf neighbor(s) detail`, per-VRF `router ospf` blocks and interface `ip ospf passive-interface`, and Problems-page notes for commands that produced no rows and for OSPF neighbours hidden by the VRF/SVI/suffix filters. Missing Nexus status rows were a likely cause of unknown speed labels.
- **3.6.1 drawing extras:** Lines grid style, Include grid in PNG/SVG/PDF toggle, laser glow, a bright dot at the laser pointer, seven laser colours and 1/2/3-second trails (alongside 3.7.0's Spot/Trail, 5/7/10 s and Keep until cleared).
- **Team server** (September build): zero-dependency Node.js server for shared team boards and private boards with live editing, cursors, shared laser and presence, packaged for Docker or systemd. The 3.7.0 app still contained the client side; the server files were missing.

## Tests
- New: tests/visio.test.cjs (formula values, simulated device moves, containers, layers, element order, compression), tests/nxos.test.cjs (restored parsers), tests/exports.py (PNG/SVG options); browser.py checks Visio port-name edits on import. Fixed a timing race in presentation.py (it read anchor positions during the 260 ms zoom animation).
- All 63 node checks and the browser, presentation, export and offline suites pass. A live two-browser test confirmed team-board editing through the restored server.

Not verified here: Microsoft Visio itself (rendering checked with LibreOffice; behaviour checked by evaluating the formulas), physical stylus hardware, and actual device captures.

Earlier releases remain unchanged in their own archives.
