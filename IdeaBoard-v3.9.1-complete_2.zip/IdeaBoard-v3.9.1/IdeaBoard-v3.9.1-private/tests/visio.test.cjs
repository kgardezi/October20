const {test} = require('node:test');
const assert = require('node:assert/strict');
const V = require('../js/visio-export.js');

/* Checks of the .vsdx writer that run without Visio:
   - every formula the writer adds evaluates (with the documented meaning of the ShapeSheet functions) to the value stored beside it,
     so nothing jumps when Visio first recalculates;
   - port tags and link labels follow their link when a glued device moves;
   - containers, layers, obstacles and element order are consistent. */

const icon = 'M11 19h24M30 14l5 5-5 5M37 29H13M18 24l-5 5 5 5';
function snapshot(style = 'visio'){
  const shapes = [
    {id: 'z1', type: 'zone', x: 0, y: 0, w: 900, h: 600, text: 'Campus', color: '#1f6feb', fillColor: '#f4f8fe', lineWidth: 1.5, fontSize: 18, dash: 'dashed', ib: '{"type":"zone"}'},
    {id: 'd1', type: 'device', x: 100, y: 100, w: 290, h: 64, color: '#c92a2a', lineWidth: 2.5, hostname: 'EDEM001CL0101', role: 'CL', kindName: 'L3 Switch', icon, view: 'rack', infoLines: ['Campus · floor 01'], infoBox: {x: 100, y: 168, w: 290, h: 21}, connectionPoints: [{x: .5, y: 1}, {x: .25, y: 1}], ib: '{"type":"device"}'},
    {id: 'd2', type: 'device', x: 500, y: 400, w: 64, h: 64, color: '#2b8a3e', lineWidth: 2.5, hostname: 'EDEM001AS0101', role: 'AS', kindName: 'Switch', icon, fillMode: 'solid', infoLines: ['10.0.0.1'], ib: '{"type":"device"}'},
    {id: 'n1', type: 'note', x: 1000, y: 0, w: 200, h: 120, text: 'Legend', color: '#ffd400', fillColor: '#fff3b0', ib: '{"type":"note"}'},
    {id: 'c1', type: 'connector', x: 0, y: 0, w: 0, h: 0, points: [{x: 172.5, y: 164}, {x: 172.5, y: 432}, {x: 500, y: 432}], start: {id: 'd1', anchor: {x: .25, y: 1}}, end: {id: 'd2', anchor: {x: 0, y: .5}},
      route: 'elbow', color: '#1d1d1d', lineWidth: 2.5, text: '10G · trunk', fontSize: 13, startLabel: 'Te1/0/1', endLabel: 'Te1/1/1', labelCenter: {x: 172.5, y: 300}, ib: '{"type":"connector"}'},
    {id: 'c2', type: 'connector', x: 0, y: 0, w: 0, h: 0, points: [{x: 390, y: 132}, {x: 1000, y: 60}], start: {id: 'd1', anchor: {x: 1, y: .5}}, end: {id: 'n1'}, route: 'straight', color: '#1d1d1d', lineWidth: 1.5, text: '', ib: '{"type":"connector"}'},
    {id: 'p1', type: 'rect', role: 'portTag', bind: {conn: 'c1', end: 'start'}, x: 172.5 - 30, y: 190, w: 60, h: 20, text: 'Te1/0/1', color: '#1d1d1d', fillColor: '#ffffff', fontSize: 12, lineWidth: 1.2, vname: 'Port label', ib: '{"type":"portLabel"}'},
    {id: 'p2', type: 'rect', role: 'portTag', bind: {conn: 'c1', end: 'end'}, x: 440, y: 418, w: 60, h: 20, text: 'Te1/1/1', color: '#1d1d1d', fillColor: '#ffffff', fontSize: 12, lineWidth: 1.2, vname: 'Port label', ib: '{"type":"portLabel"}'},
  ];
  return {name: 'Test', pages: [{name: 'L1/L2', shapes}], style, font: 'Calibri', bg: 'none', grid: 'screen', gradient: false};
}
const page1 = files => files.find(([n]) => n === 'visio/pages/page1.xml')[1];
const shapesOf = xml => { const out = []; const re = /<Shape ID='(\d+)'([^>]*)>/g; let m; while ((m = re.exec(xml))){ const start = m.index; let depth = 0, i = start; const tag = /<Shape\b|<\/Shape>/g; tag.lastIndex = start; let t; while ((t = tag.exec(xml))){ depth += t[0] === '</Shape>' ? -1 : 1; if (!depth){ i = t.index + 8; break; } } out.push({id: m[1], attrs: m[2], xml: xml.slice(start, i)}); } return out; };
const cell = (x, n) => { const m = new RegExp(`<Cell N='${n}' V='([^']*)'(?: U='[^']*')?(?: F='([^']*)')?`).exec(x); return m ? {v: m[1], f: m[2] && m[2].replace(/&apos;/g, "'")} : null; };
const ownCells = x => x.replace(/<Section[\s\S]*?<\/Section>/g, '').replace(/<Shapes>[\s\S]*<\/Shapes>/, '');

/* ---- a tiny ShapeSheet evaluator for the functions the writer uses ---- */
function sheetModel(xml){
  const byId = new Map();
  for (const s of shapesOf(xml)){
    const own = ownCells(s.xml), n = k => { const c = cell(own, k); return c ? parseFloat(c.v) : 0; };
    const geom = /<Section N='Geometry' IX='0'>([\s\S]*?)<\/Section>/.exec(s.xml);
    const path = geom ? [...geom[1].matchAll(/<Row T='(MoveTo|LineTo)' IX='\d+'>(<Cell N='X' V='([^']*)'[^>]*\/>)(<Cell N='Y' V='([^']*)'[^>]*\/>)<\/Row>/g)].map(r => ({x: +r[3], y: +r[5]})) : [];
    byId.set(s.id, {PinX: n('PinX'), PinY: n('PinY'), LocPinX: n('LocPinX'), LocPinY: n('LocPinY'), Width: n('Width'), Height: n('Height'), path, xml: s.xml});
  }
  return byId;
}
function evaluate(formula, self, model){
  let i = 0; const src = formula.replace(/\s+/g, '');
  const peek = () => src[i], eat = c => { if (src[i] !== c) throw Error(`expected ${c} at ${i} in ${src}`); i++; };
  const len = P => { let L = 0; for (let k = 1; k < P.length; k++) L += Math.hypot(P[k].x - P[k - 1].x, P[k].y - P[k - 1].y); return L; };
  const along = (P, t) => { let d = Math.max(0, Math.min(1, t)) * len(P); for (let k = 1; k < P.length; k++){ const a = P[k - 1], b = P[k], l = Math.hypot(b.x - a.x, b.y - a.y); if (d <= l || k === P.length - 1){ const q = l ? Math.min(1, d / l) : 0; return {x: a.x + (b.x - a.x) * q, y: a.y + (b.y - a.y) * q}; } d -= l; } return P[0]; };
  const fns = {
    PNTX: p => p.x, PNTY: p => p.y, MIN: Math.min, MAX: Math.max,
    PATHLENGTH: ref => len(ref.sheet.path),
    POINTALONGPATH: (ref, t) => along(ref.sheet.path, t),
    LOCTOPAR: (p, src) => ({x: p.x + src.sheet.PinX - src.sheet.LocPinX, y: p.y + src.sheet.PinY - src.sheet.LocPinY}),   // Angle 0, no flip
  };
  function primary(){
    if (peek() === '('){ eat('('); const v = expr(); eat(')'); return v; }
    if (peek() === '-'){ eat('-'); return -primary(); }
    const num = /^\d*\.?\d+(?:e[-+]?\d+)?/i.exec(src.slice(i)); if (num){ i += num[0].length; return parseFloat(num[0]); }
    const ref = /^(?:Sheet\.(\d+)!)?(Geometry1\.Path|Width|Height)/.exec(src.slice(i));
    if (ref){ i += ref[0].length; const sheet = ref[1] ? model.get(ref[1]) : self; return ref[2] === 'Geometry1.Path' ? {sheet} : ref[2] === 'Width' ? Object.assign(new Number(sheet.Width), {sheet}) : sheet.Height; }
    const fn = /^[A-Z]+/.exec(src.slice(i)); if (!fn || !fns[fn[0]]) throw Error('unknown token at ' + src.slice(i));
    i += fn[0].length; eat('('); const args = [expr()]; while (peek() === ','){ eat(','); args.push(expr()); } eat(')');
    return fns[fn[0]](...args);
  }
  function term(){ let v = primary(); while (peek() === '*' || peek() === '/'){ const o = src[i++], r = primary(); v = o === '*' ? v * r : v / r; } return v; }
  function expr(){ let v = term(); while (peek() === '+' || peek() === '-'){ const o = src[i++], r = term(); v = o === '+' ? v + r : v - r; } return v; }
  const v = expr(); if (i !== src.length) throw Error('trailing input in ' + src); return v;
}

for (const style of ['visio', 'ideaboard']){
  const {files} = V.build(snapshot(style)), xml = page1(files), model = sheetModel(xml), shapes = shapesOf(xml).filter(s => !/^ ?NameU='(Chassis|DeviceIcon|Hostname|RoleBadge)\./.test(s.attrs));

  test(`${style}: port tags and link label formulas evaluate to their stored values`, () => {
    let checked = 0;
    for (const s of shapes){
      const own = ownCells(s.xml);
      for (const k of ['PinX', 'PinY']){ const c = cell(own, k); if (c && c.f && /POINTALONGPATH/.test(c.f)){ assert.ok(Math.abs(evaluate(c.f, model.get(s.id), model) - parseFloat(c.v)) < 1e-4, `${k} of ${s.id}`); checked++; } }
      const ctl = /<Row N='TextPosition'>([\s\S]*?)<\/Row>/.exec(s.xml);
      if (ctl) for (const k of ['X', 'Y']){ const c = cell(ctl[1], k); assert.ok(c.f, 'label control has a formula'); assert.ok(Math.abs(evaluate(c.f, model.get(s.id), model) - parseFloat(c.v)) < 1e-4, `label ${k} of ${s.id}`); checked++; }
    }
    assert.ok(checked >= 4 + 4, 'two tags and two connector labels checked');
  });

  test(`${style}: a port tag keeps its distance from the port when the device moves and Visio reroutes`, () => {
    const tag = shapes.find(s => /Port label/.test(s.attrs) && /&quot;tag&quot;:&quot;start&quot;/.test(s.xml)), own = ownCells(tag.xml), fx = cell(own, 'PinX').f, fy = cell(own, 'PinY').f;
    const conn = model.get(/Sheet\.(\d+)!/.exec(fx)[1]);
    const begin = {x: conn.PinX - conn.LocPinX, y: conn.PinY - conn.LocPinY}, before = {x: evaluate(fx, null, model), y: evaluate(fy, null, model)};
    const d0 = Math.hypot(before.x - begin.x, before.y - begin.y);
    // simulate the CL moving 2 in left and Visio drawing a new right-angle route from the new begin point
    const moved = new Map(model), end = {x: begin.x + conn.path[conn.path.length - 1].x, y: begin.y + conn.path[conn.path.length - 1].y}, nb = {x: begin.x - 2, y: begin.y};
    const W = end.x - nb.x, H = end.y - nb.y;
    moved.set(String([...model.entries()].find(([, v]) => v === conn)[0]), {...conn, PinX: (nb.x + end.x) / 2, PinY: (nb.y + end.y) / 2, LocPinX: W / 2, LocPinY: H / 2, Width: W, Height: H, path: [{x: 0, y: 0}, {x: 0, y: H}, {x: W, y: H}]});
    const after = {x: evaluate(fx, null, moved), y: evaluate(fy, null, moved)}, d1 = Math.hypot(after.x - nb.x, after.y - nb.y);
    assert.ok(Math.abs(after.x - (before.x - 2)) < 1e-6, 'the tag moved with the port');
    assert.ok(Math.abs(d1 - d0) < 1e-6, 'same distance from the port');
  });

  test(`${style}: the site frame is a Visio container holding the devices; frames, notes and tags do not block routing`, () => {
    const zone = shapes.find(s => /NameU='zone\./.test(s.attrs));
    assert.match(zone.xml, /<Row N='msvStructureType'><Cell N='Value' V='Container' U='STR'\/>/);
    const members = [...cell(ownCells(zone.xml), 'Relationships').f.matchAll(/Sheet\.(\d+)!SheetRef\(\)/g)].map(m => m[1]);
    const devices = shapes.filter(s => /NameU=.device\./.test(s.attrs)).map(s => s.id);
    assert.deepEqual(members.sort(), devices.sort());
    for (const d of devices) assert.equal(cell(ownCells(shapes.find(s => s.id === d).xml), 'Relationships').f, `SUM(DEPENDSON(4,Sheet.${zone.id}!SheetRef()))`);
    assert.equal(cell(ownCells(zone.xml), 'ObjType').v, '4');
    for (const s of shapes.filter(s => /Port label|note\./.test(s.attrs))){ assert.equal(cell(ownCells(s.xml), 'ObjType').v, '4'); assert.equal(cell(ownCells(s.xml), 'ShapePermeableX').v, '1'); assert.doesNotMatch(s.xml, /<Section N='Connection'>/); }
    for (const d of devices) assert.equal(cell(ownCells(shapes.find(s => s.id === d).xml), 'ObjType').v, '1');
  });

  test(`${style}: layers are declared on the page and every shape uses one`, () => {
    const layers = [...xml.length ? files.find(([n]) => n === 'visio/pages/pages.xml')[1].matchAll(/<Cell N='Name' V='([^']*)'\/>/g) : []].map(m => m[1]);
    assert.deepEqual(layers, ['Sites', 'Links', 'Devices', 'Port labels', 'Notes']);
    for (const s of shapes){ const c = cell(ownCells(s.xml), 'LayerMember'); assert.ok(c && +c.v < layers.length, 'layer for ' + s.id); }
  });

  test(`${style}: cells come before sections, then text, then sub-shapes in every shape`, () => {
    for (const s of shapesOf(xml)){
      const body = s.xml.replace(/^<Shape[^>]*>/, '').replace(/<\/Shape>$/, '').replace(/<Shapes>[\s\S]*<\/Shapes>$/, '');
      const firstSection = body.indexOf('<Section'), lastCell = body.replace(/<Section[\s\S]*?<\/Section>/g, m => ' '.repeat(m.length)).lastIndexOf('<Cell'), text = body.indexOf('<Text>');
      if (firstSection >= 0) assert.ok(lastCell < firstSection, 'cells before sections in ' + s.id);
      if (text >= 0) assert.ok(body.lastIndexOf('</Section>') < text, 'text after sections in ' + s.id);
    }
  });

  test(`${style}: the rack unit carries its info lines as its own text and its parts scale with it`, () => {
    const rack = shapes.find(s => /Type='Group'/.test(s.attrs));
    assert.match(rack.xml, /<Text>Campus · floor 01<\/Text>/);
    assert.match(rack.xml, /<Cell N='Width' V='[^']*' F='Sheet\.\d+!Width\*1'\/>/);
    assert.doesNotMatch(xml, /NameU='Device info/);
  });
}

test('connector route styles: straight → 2, elbow → right angle, no line jumps', () => {
  const xml = page1(V.build(snapshot()).files);
  assert.match(xml, /<Cell N='ShapeRouteStyle' V='2'\/><Cell N='ConLineRouteExt' V='1'\/><Cell N='ConLineJumpCode' V='1'\/>/);
  assert.match(xml, /<Cell N='ShapeRouteStyle' V='1'\/><Cell N='ConLineRouteExt' V='1'\/>/);
});
test('screen grid turns on Visio\'s own grid; printed graph paper uses the background page', () => {
  const screen = V.build(snapshot()).files, print = V.build({...snapshot(), grid: 'print'}).files;
  assert.match(screen.find(([n]) => n === 'visio/windows.xml')[1], /<ShowGrid>1<\/ShowGrid>/);
  assert.ok(!screen.some(([n]) => n === 'visio/pages/page2.xml'));
  assert.match(print.find(([n]) => n === 'visio/pages/page2.xml')[1], /GraphPaperMinor/);
  assert.match(print.find(([n]) => n === 'visio/pages/pages.xml')[1], /Background='1'/);
});
test('the chosen font is written into the text formatting', () => {
  assert.match(page1(V.build({...snapshot(), font: 'Arial'}).files), /<Cell N='Font' V='Arial'\/>/);
});
test('Visio look uses lighter line weights than the canvas look', () => {
  const w = st => +cell(shapesOf(page1(V.build(snapshot(st)).files)).find(s => /Dynamic connector/.test(s.attrs)).xml, 'LineWeight').v;
  assert.ok(w('visio') < w('ideaboard'));
});
test('switches: labels can stay fixed and frames can stay plain shapes', () => {
  const xml = page1(V.build({...snapshot(), followLinks: false, containers: false}).files);
  assert.doesNotMatch(xml, /POINTALONGPATH|DEPENDSON|msvStructureType/);
  assert.match(xml, /&quot;tag&quot;:&quot;start&quot;/);    // edited tags are still read back on import
});
test('compressed package unzips to the same parts (Visio saves deflated parts too)', async () => {
  const r = await V.buildAsync(snapshot()), plain = V.build(snapshot());
  assert.ok(r.bytes.length < plain.bytes.length / 3);
  const parts = await V.unzip(r.bytes), dec = new TextDecoder();
  for (const [name, content] of plain.files) if (typeof content === 'string' && name !== 'docProps/core.xml') assert.equal(dec.decode(parts.get(name)), content, name);
});
