"""Vendor-neutral rules engine: turns parsed syslog lines into classified events."""
from __future__ import annotations

import json
import re
from pathlib import Path

import yaml

from .config import RULES_DIR
from .netmodel import NetModel, normalize_interface, normalize_mac, IF_TOKEN_RE

SIGNALS = ["routine", "info", "warning", "major", "critical"]
SIGNAL_RANK = {s: i for i, s in enumerate(SIGNALS)}

FIRST_CLASS = {"interface", "state", "neighbor", "mac", "vlan", "ip", "user", "reason", "protocol"}

STATE_MAP = {
    "up": "up", "down": "down", "administratively down": "admin_down", "admin_down": "admin_down",
    "full": "up", "established": "up",
    "init": "init", "2way": "init", "twoway": "init", "exstart": "init", "exchange": "init",
    "loading": "init", "attempt": "init", "resync": "init",
    "suspended": "suspended", "individual": "down",
}


def _norm_state(v: str | None) -> str | None:
    if not v:
        return None
    k = v.strip().lower()
    return STATE_MAP.get(k, k)


class Rule:
    def __init__(self, d: dict):
        self.id = d["id"]
        self.code_re = re.compile(d["code"]) if d.get("code") else None
        self.msg_re = re.compile(d["message"], re.I) if d.get("message") else None
        ex = d.get("extract") or []
        if isinstance(ex, str):
            ex = [ex]
        self.extract = [re.compile(x) for x in ex]
        self.kind = d.get("kind", "event")
        self.category = d.get("category", "other")
        self.edge_category = d.get("edge_category")
        self.signal = d.get("signal", "info")
        self.signal_by_state = d.get("signal_by_state") or {}
        self.signal_if = [(c["field"], re.compile(c["match"], re.I), c["signal"], c.get("state"))
                          for c in d.get("signal_if", [])]
        self.edge_signal = d.get("edge_signal")
        self.set = d.get("set") or {}
        self.explain = d.get("explain", "")
        self.guidance = d.get("guidance") or []

    def matches(self, ev: dict) -> bool:
        if self.code_re is not None:
            if not ev.get("code") or not self.code_re.search(ev["code"]):
                return False
        if self.msg_re is not None and not self.msg_re.search(ev.get("message") or ""):
            return False
        return True


class Classifier:
    def __init__(self, cfg: dict, vendor: str = "cisco"):
        self.cfg = cfg
        self.vendor = vendor
        self.net = NetModel(cfg)
        self.reload()

    def reload(self):
        cats = yaml.safe_load((RULES_DIR / "categories.yaml").read_text(encoding="utf-8"))
        self.categories = cats["categories"]
        self.cat_by_id = {c["id"]: c for c in self.categories}
        data = yaml.safe_load((RULES_DIR / f"{self.vendor}_rules.yaml").read_text(encoding="utf-8"))
        self.rules = [Rule(r) for r in data["rules"]]
        self.rule_by_id = {r.id: r for r in self.rules}

    # ------------------------------------------------------------------
    def classify(self, ev: dict) -> dict:
        host = ev.get("host")
        hinfo = self.net.decode_host(host) if host else {}
        ev["site"] = hinfo.get("site")
        ev["role"] = hinfo.get("role")
        attrs: dict = {}
        rule = None
        if ev.get("code"):
            for r in self.rules:
                if r.matches(ev):
                    rule = r
                    break
        fields: dict = {}
        if rule:
            msg = ev.get("message") or ""
            for rx in rule.extract:
                mm = rx.search(msg)
                if mm:
                    fields = {k: v for k, v in mm.groupdict().items() if v is not None}
                    break
            for k, v in rule.set.items():
                fields.setdefault(k, v)
        else:
            mm = IF_TOKEN_RE.search(ev.get("message") or "")
            if mm:
                fields["interface"] = mm.group(0)

        iface = normalize_interface(fields.pop("interface", None))
        state_raw = fields.get("state")
        state = _norm_state(state_raw)
        fields.pop("state", None)
        if state_raw and state_raw != state:
            attrs["state_raw"] = state_raw
        mac = normalize_mac(fields.pop("mac", None))
        for k in ("from_if", "to_if", "portchannel", "peer_interface"):
            if fields.get(k):
                fields[k] = normalize_interface(fields[k])
        iclass = self.net.iface_class(iface, ev.get("role"))

        ev["interface"] = iface
        ev["iface_class"] = iclass
        ev["state"] = state
        ev["mac"] = mac
        for k in ("neighbor", "ip", "user", "reason", "protocol"):
            ev[k] = fields.pop(k, None)
        vlan = fields.pop("vlan", None)
        ev["vlan"] = int(vlan) if vlan and str(vlan).isdigit() else None
        attrs.update(fields)

        if rule:
            ev["rule"] = rule.id
            ev["kind"] = rule.kind
            cat = rule.category
            sig = rule.signal
            if state and state in rule.signal_by_state:
                sig = rule.signal_by_state[state]
            for field, rx, s, need_state in rule.signal_if:
                if need_state and state != need_state:
                    continue
                val = ev.get(field) if field in ev else attrs.get(field)
                if val is not None and rx.search(str(val)):
                    sig = s
                    break
            if iclass == "edge":
                if rule.edge_category:
                    cat = rule.edge_category
                if rule.edge_signal:
                    sig = rule.edge_signal
            ev["category"] = cat
            ev["signal"] = sig
        else:
            ev["rule"] = None
            ev["kind"] = ev.pop("kind_hint", None) or ("unclassified" if ev.get("code") else "raw")
            ev["category"] = "other"
            sev = ev.get("severity")
            ev["signal"] = ("major" if sev is not None and sev <= 2 else
                            "warning" if sev == 3 else "info")
            if ev["kind"] == "repeat":
                ev["signal"] = "routine"
        ev.pop("kind_hint", None)
        ev["attrs"] = json.dumps(attrs, separators=(",", ":")) if attrs else None
        return ev

    # ------------------------------------------------------------------
    def explain(self, ev: dict) -> dict:
        """Plain-English explanation + guidance for one stored event row."""
        rule = self.rule_by_id.get(ev.get("rule") or "")
        attrs = ev.get("attrs") or {}
        if isinstance(attrs, str):
            attrs = json.loads(attrs or "{}")
        vals = {k: v for k, v in ev.items() if v is not None and not isinstance(v, (dict, list))}
        vals.update({k: v for k, v in attrs.items() if v is not None})
        vals.setdefault("state_raw", ev.get("state"))
        if ev.get("state") == "admin_down":
            vals["state"] = "administratively down"
        vals["user_suffix"] = f" (username {ev['user']})" if ev.get("user") else ""
        vals["ip_suffix"] = f" ({ev['ip']})" if ev.get("ip") else ""
        vals["code_word"] = "disconnected from" if "DISCONNECT" in (ev.get("code") or "") else "connected to"
        if not rule:
            sev = ev.get("severity")
            text = ("No classification rule matches this message yet. "
                    f"Cisco severity {sev} ({SEV_NAMES.get(sev, '?')}). "
                    "Look up the mnemonic in the Cisco System Message Guide for this platform/release, "
                    "then add a rule in rules/cisco_rules.yaml.") if ev.get("code") else \
                   "This line did not contain a Cisco %FACILITY-SEVERITY-MNEMONIC code."
            return {"text": text, "guidance": [], "rule": None}
        return {
            "text": _fill(rule.explain, vals),
            "guidance": [_fill(g, vals) for g in rule.guidance],
            "rule": rule.id,
        }

    def category_list(self) -> list[dict]:
        return self.categories

    def rules_summary(self) -> list[dict]:
        return [{"id": r.id, "code": r.code_re.pattern if r.code_re else None, "kind": r.kind,
                 "category": r.category, "signal": r.signal,
                 "signal_by_state": r.signal_by_state, "edge_signal": r.edge_signal,
                 "explain": r.explain} for r in self.rules]


SEV_NAMES = {0: "emergency", 1: "alert", 2: "critical", 3: "error", 4: "warning",
             5: "notice", 6: "informational", 7: "debug"}

_PH = re.compile(r"\{(\w+)\}")


def _fill(tpl, vals: dict) -> str:
    if not isinstance(tpl, str):
        tpl = " ".join(f"{k} {v}" if v is not None else str(k) for k, v in tpl.items()) if isinstance(tpl, dict) else str(tpl)
    out = _PH.sub(lambda m: str(vals.get(m.group(1), "") if vals.get(m.group(1)) is not None else ""), tpl)
    out = re.sub(r"\(\s*\)", "", out)
    out = re.sub(r"\s{2,}", " ", out).strip()
    return out
