// Sources & archives: ingestion health, daily .gz files, deep (non-indexed) historical search.
import { esc, icon, api, qs, n, fmtTs, ago, loading, emptyState } from '../util.js';
import { state } from '../state.js';
import { eventTable, bindEventTable } from '../components.js';

const mb = b => (b / 1e6).toFixed(b > 1e8 ? 0 : 1) + ' MB';

export async function render(main) {
  main.innerHTML = `<div class="page">${loading('Listing source directory')}</div>`;
  let files = [], err = null, retention = 7;

  async function load() {
    const [a, s] = await Promise.all([api('/api/archives'), api('/api/status')]);
    files = a.files; err = a.error; retention = a.retention_days;
    draw(s);
  }

  function draw(s) {
    const now = state.now();
    const lv = s.live;
    main.innerHTML = `<div class="page">
      <div class="ph"><div><h1>Sources & archives</h1><div class="sub">Read-only access to the syslog server's CISCO directory. Nothing is written to the source server.</div></div>
        <div class="grow"></div><button class="btn" id="refresh">${icon('refresh', 'sm')} Refresh</button></div>
      <div class="card"><div class="hd"><h3>Ingestion health</h3><span class="grow"></span>
        <span class="sev ${s.connected ? 'good' : 'critical'}">${s.connected ? 'connected' : 'disconnected'}</span></div>
        <div class="bd"><div class="statgrid">
          <div class="stat"><div class="l">Source</div><div class="v mono" style="font-size:13px">${esc(s.target || '—')}</div></div>
          <div class="stat"><div class="l">Mode</div><div class="v">${esc(s.mode)}${s.simulated ? ' <span class="pill-sim">SIMULATED</span>' : ''}</div></div>
          <div class="stat"><div class="l">Live file position</div><div class="v num">${mb(lv.offset)} / ${mb(lv.size)}</div></div>
          <div class="stat"><div class="l">Lag</div><div class="v num">${lv.lag_bytes < 1024 ? 'none' : mb(lv.lag_bytes)}</div></div>
          <div class="stat"><div class="l">Rate (1 min)</div><div class="v num">${lv.rate.toFixed(1)} msg/s</div></div>
          <div class="stat"><div class="l">Last read</div><div class="v">${lv.last_read ? esc(ago(lv.last_read, now)) : '—'}</div></div>
          <div class="stat"><div class="l">Rotations handled</div><div class="v num">${lv.rotations}</div></div>
          <div class="stat"><div class="l">Reconnects</div><div class="v num">${s.reconnects}</div></div>
          <div class="stat"><div class="l">Indexed messages</div><div class="v num">${n(s.db_events)}</div></div>
          <div class="stat"><div class="l">Duplicates ignored</div><div class="v num">${n(s.duplicates)}</div></div>
          <div class="stat"><div class="l">Unparseable lines</div><div class="v num">${n(s.unparsed)}</div></div>
          <div class="stat"><div class="l">Index covers</div><div class="v" style="font-size:13px">${s.db_first ? esc(fmtTs(s.db_first)) + '<br>→ ' + esc(fmtTs(s.db_last)) : '—'}</div></div>
        </div>
        ${s.last_error ? `<div class="ctx change" style="margin-top:12px">${icon('alert')}<div><b>Last error:</b> <span class="mono">${esc(s.last_error)}</span><div class="muted">The tailer retries automatically with back-off (1 s → 60 s) and resumes from the last byte offset.</div></div></div>` : ''}
        </div></div>

      <div class="grid" style="margin-top:16px">
      <div class="card c7"><div class="hd"><h3>Files in source directory</h3><span class="grow"></span><span class="muted" style="font-size:12px">index retention ${retention} days</span></div>
        <div class="bd" style="padding-top:4px">${err ? emptyState(err, 'alert') : `<table class="tbl"><thead><tr><th></th><th>File</th><th>Day</th><th class="r">Size</th><th>Indexed</th><th></th></tr></thead><tbody>
        ${files.map(f => {
          const j = f.job, db = f.db;
          let st = f.live ? '<span class="sev good">live tail</span>' : '<span class="muted">not imported</span>';
          if (j?.state === 'loading') st = `<div class="progress" title="${Math.round(j.progress * 100)}%"><div style="width:${j.progress * 100}%"></div></div>`;
          else if (j?.state === 'queued') st = '<span class="sev info">queued</span>';
          else if (db?.status === 'loaded') st = `<span class="sev good">${n(db.lines)} lines</span>`;
          else if (db?.status === 'error' || j?.state === 'error') st = `<span class="sev critical" title="${esc(db?.error || j?.error)}">error</span>`;
          return `<tr><td><input type="checkbox" data-f="${esc(f.name)}" ${f.live ? '' : ''}></td><td class="mono">${esc(f.name)}</td><td>${esc(f.day || 'today')}</td><td class="r num">${mb(f.size)}</td><td>${st}</td>
            <td class="r">${f.live ? '' : `<button class="btn sm" data-load="${esc(f.name)}">${db?.status === 'loaded' ? 'Re-import' : 'Import'}</button>`}</td></tr>`;
        }).join('')}</tbody></table>`}</div></div>

      <div class="card c5"><div class="hd"><h3>${icon('search', 'sm')} Deep archive search</h3></div><div class="bd">
        <p class="note" style="margin-top:0">Scans the selected files directly (streamed &amp; decompressed on this machine, read-only) without importing them - use it for days older than the index retention. All words must match.</p>
        <input class="inp" id="dq" placeholder="e.g. unyc787as0705 Te1/1/1 down">
        <div style="display:flex;gap:8px;margin-top:8px"><button class="btn primary" id="dgo">Search selected files</button><span class="muted" id="dinfo" style="align-self:center"></span></div>
        <p class="note">Tip: tick files in the list on the left first.</p></div></div>
      </div>
      <div class="card hidden" id="dres" style="margin-top:16px"></div></div>`;

    main.querySelector('#refresh').onclick = () => load();
    main.querySelectorAll('[data-load]').forEach(b => b.onclick = async () => {
      b.disabled = true;
      await api(`/api/archives/${encodeURIComponent(b.dataset.load)}/load`, { method: 'POST' });
      setTimeout(load, 600);
    });
    main.querySelector('#dgo').onclick = async () => {
      const sel = [...main.querySelectorAll('[data-f]:checked')].map(c => c.dataset.f);
      const q = main.querySelector('#dq').value.trim();
      const info = main.querySelector('#dinfo');
      if (!sel.length || !q) { info.textContent = 'Select at least one file and enter search terms.'; return; }
      info.innerHTML = '<span class="spin" style="display:inline-block;vertical-align:middle"></span> scanning…';
      try {
        const r = await api('/api/archives/search?' + qs({ files: sel.join(','), q, limit: 500 }));
        info.textContent = `${n(r.events.length)} matches · ${n(r.scanned)} lines scanned in ${r.seconds}s${r.truncated ? ' (truncated)' : ''}`;
        const box = main.querySelector('#dres');
        box.classList.remove('hidden');
        box.innerHTML = `<div class="hd"><h3>Deep search results</h3><span class="muted">not indexed - click-through details unavailable; import the file for full analysis</span></div>
          <div class="bd" style="padding:0">${eventTable(r.events.map(e => ({ ...e, id: '' })), { now: state.now(), maxh: 600 })}</div>`;
      } catch (e) { info.textContent = e.message; }
    };
  }
  await load();
  const t = setInterval(() => {
    if (Object.values(state.status?.jobs || {}).some(j => j.state === 'loading' || j.state === 'queued')) load();
  }, 3000);
  return () => clearInterval(t);
}
