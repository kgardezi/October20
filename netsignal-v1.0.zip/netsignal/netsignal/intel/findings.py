"""Intelligence engine: turns classified events into evidence-backed *findings*.

Design principles (avoid false alarms / unsupported root-cause claims):
- A finding is only raised when an explicit, documented condition is met (see `why`).
- Every finding links to the exact syslog lines (evidence ids) that triggered it.
- Correlations are phrased as timing facts ("went down 0.4 s before"), never as proven causes.
- A single interface-down is a "bounce", not a "flap"; flapping needs N down->up cycles.
- Metrics that syslog cannot provide (CRC rates, utilisation) are never estimated.
"""
from __future__ import annotations

import hashlib
import json
import statistics
import threading
import time
from collections import defaultdict

from ..netmodel import mac_vendor, short_interface, VIRTUAL_VENDORS
from ..store import Store
from ..timeutil import fmt, now_wall

SEVERITIES = ["info", "low", "warning", "major", "critical"]
SEV_RANK = {s: i for i, s in enumerate(SEVERITIES)}
HEALTH_WEIGHT = {"critical": 35, "major": 18, "warning": 6, "low": 2, "info": 0}

EV_COLS = ("id, ts, host, site, role, interface, iface_class, state, kind, code, mac, vlan, neighbor, protocol, "
           "reason, attrs, user, ip, category, signal, message, skew, clock_flag, repeat, rule, severity")


def _fid(*parts) -> str:
    return hashlib.sha1("|".join(str(p) for p in parts).encode()).hexdigest()[:12]


def dur(sec: float | None) -> str:
    if sec is None:
        return "?"
    sec = abs(sec)
    if sec < 1:
        return f"{sec * 1000:.0f} ms"
    if sec < 60:
        return f"{sec:.1f} s"
    if sec < 3600:
        return f"{int(sec // 60)}m {int(sec % 60):02d}s"
    if sec < 86400:
        return f"{int(sec // 3600)}h {int(sec % 3600 // 60):02d}m"
    return f"{sec / 86400:.1f} days"


def _attrs(r):
    a = r.get("attrs")
    if isinstance(a, str):
        try:
            return json.loads(a)
        except ValueError:
            return {}
    return a or {}


class Intel:
    CACHE_TTL = 15

    def __init__(self, store: Store, classifier, cfg: dict):
        self.store = store
        self.cls = classifier
        self.cfg = cfg
        self.t = cfg.get("intel", {})
        self._cache: dict = {}
        self._lock = threading.Lock()

    # ------------------------------------------------------------------ data
    def rows(self, t0, t1, kinds=None, where="", params=()):
        sql = f"SELECT {EV_COLS} FROM events e WHERE ts BETWEEN ? AND ?"
        p = [t0, t1]
        if kinds:
            sql += f" AND kind IN ({','.join('?' * len(kinds))})"
            p += list(kinds)
        if where:
            sql += " AND " + where
            p += list(params)
        sql += " ORDER BY ts, id"
        return self.store.q(sql, p)

    # ------------------------------------------------------------------ main
    def findings(self, t0: float, t1: float, use_cache: bool = True) -> list[dict]:
        # Live data changes every second; recompute a given window at most every CACHE_TTL seconds.
        key = (round(t1 - t0), round(t1 / 3600) if t1 < now_wall() - 120 else "now")
        with self._lock:
            hit = self._cache.get(key)
            if use_cache and hit and time.time() - hit[0] < self.CACHE_TTL and abs(hit[1] - t1) < 3600:
                return hit[2]
        out: list[dict] = []
        for det in (self.detect_links, self.detect_routing, self.detect_auth, self.detect_poe,
                    self.detect_mac_moves, self.detect_generic, self.detect_site_bursts,
                    self.detect_clock, self.detect_new_codes, self.detect_volume):
            try:
                out.extend(det(t0, t1))
            except Exception as e:  # one detector failing must not break the dashboard
                import traceback
                traceback.print_exc()
                out.append(self._f("engine_error", det.__name__, "info", "other", f"Detector {det.__name__} failed",
                                   str(e), None, None, None, t0, t1, [], why="internal error"))
        # a "first seen" code fully explained by another finding adds nothing
        covered = {i for f in out if f["type"] != "first_seen" for i in f["evidence"]}
        out = [f for f in out if f["type"] != "first_seen" or not set(f["evidence"]) <= covered]
        self._attach_changes(out, t1)
        self._attach_recurrence(out, t0)
        out.sort(key=lambda f: (-SEV_RANK[f["severity"]], -f["last"]))
        with self._lock:
            if len(self._cache) > 20:
                self._cache.clear()
            self._cache[key] = (time.time(), t1, out)
        return out

    def _f(self, ftype, key, severity, category, title, summary, host, site, iface, first, last, evidence,
           why="", metrics=None, next_steps=None, status="active", count=None):
        return {
            "id": _fid(ftype, key), "type": ftype, "severity": severity, "category": category,
            "title": title, "summary": summary, "host": host, "site": site, "interface": iface,
            "first": first, "last": last, "count": count if count is not None else len(evidence),
            "evidence": evidence[-400:], "why": why, "metrics": metrics or {},
            "next_steps": next_steps or [], "context": [], "status": status,
        }

    def _steps(self, rule_id: str, **vals) -> list[str]:
        rule = self.cls.rule_by_id.get(rule_id)
        if not rule:
            return []
        from ..classifier import _fill
        return [_fill(g, vals) for g in rule.guidance]

    # ------------------------------------------------------------------ interfaces
    def detect_links(self, t0, t1):
        t = self.t
        # 1) cheap SQL pre-aggregation to find candidate interfaces (scales to millions of lines/day)
        edge_min = t.get("edge_flap_min_cycles", 5)
        cands = self.store.q(
            "SELECT host, interface FROM events WHERE ts BETWEEN ? AND ? AND kind IN ('link_state','proto_state','errdisable') "
            "AND interface IS NOT NULL GROUP BY host, interface "
            "HAVING SUM(state='down') >= CASE WHEN MIN(iface_class)='edge' THEN ? ELSE 1 END OR SUM(kind='errdisable') > 0",
            (t0, t1, edge_min))
        rows = []
        for i in range(0, len(cands), 400):
            chunk = cands[i:i + 400]
            vals = ",".join("(?,?)" for _ in chunk)
            rows += self.rows(t0, t1, ("link_state", "proto_state", "errdisable"), f"(host, interface) IN (VALUES {vals})",
                              [x for c in chunk for x in (c["host"], c["interface"])])
        rows.sort(key=lambda r: (r["ts"], r["id"]))
        by: dict[tuple, dict] = defaultdict(lambda: {"link": [], "proto": [], "err": []})
        for r in rows:
            if not r["interface"]:
                continue
            slot = {"link_state": "link", "proto_state": "proto", "errdisable": "err"}[r["kind"]]
            by[(r["host"], r["interface"])][slot].append(r)

        # infra downs for far-end matching
        infra_downs = [r for r in rows if r["kind"] == "link_state" and r["state"] == "down"
                       and r["iface_class"] not in ("edge", None)]

        related = defaultdict(list)
        for o in self.rows(t0, t1, ("optic_alarm", "optic_bad", "errdisable", "lag_member", "storm", "mismatch")):
            related[(o["host"], o["interface"])].append(o)

        out, edge_by_host = [], defaultdict(list)
        for (host, iface), g in by.items():
            seq = g["link"] or g["proto"]
            if not seq:
                continue
            first_row = seq[0]
            iclass = first_row["iface_class"]
            downs = [r for r in seq if r["state"] == "down"]
            cycles, outages, down_at = 0, [], None
            for r in seq:
                if r["state"] == "down" and down_at is None:
                    down_at = r["ts"]
                elif r["state"] == "up" and down_at is not None:
                    cycles += 1
                    outages.append(r["ts"] - down_at)
                    down_at = None
            last_state = seq[-1]["state"]
            ev_ids = [r["id"] for r in g["link"] + g["proto"] + g["err"]]
            site = first_row["site"]
            if iclass == "edge":
                if cycles >= t.get("edge_flap_min_cycles", 5):
                    edge_by_host[host].append({"iface": iface, "cycles": cycles, "ids": ev_ids,
                                               "first": seq[0]["ts"], "last": seq[-1]["ts"],
                                               "errdisabled": bool(g["err"]), "site": site})
                continue
            if not downs:
                continue
            metrics = {"down_up_cycles": cycles, "down_events": len(downs), "last_state": last_state,
                       "iface_class": iclass}
            if outages:
                metrics.update(total_downtime=dur(sum(outages)), longest_outage=dur(max(outages)),
                               shortest_outage=dur(min(outages)))
            steps = self._steps("link_updown", interface=iface)
            peer = self._far_end(host, [d["ts"] for d in downs], infra_downs)
            ctx = []
            if peer:
                metrics["probable_far_end"] = peer
                ctx.append({"type": "correlation", "text": "Far end: " + peer["note"]})
            for o in related.get((host, iface), [])[-3:]:
                ctx.append({"type": "related", "text": f"Same interface, {fmt(o['ts'])}: %{o['code']}: {o['message']}",
                            "event_id": o["id"]})
            label = {"portchannel": "Port-channel", "uplink": "Uplink", "wan": "WAN interface",
                     "svi": "SVI", "infra": "Interface"}.get(iclass, "Interface")
            if cycles >= t.get("flap_min_cycles", 3):
                sev = "critical" if cycles >= 10 else "major"
                out.append(self._f(
                    "link_flap", (host, iface), sev, "links",
                    f"{label} {short_interface(iface)} on {host} flapped {cycles}x",
                    f"{iface} went down {len(downs)} time(s) and recovered {cycles} time(s) between "
                    f"{fmt(seq[0]['ts'])} and {fmt(seq[-1]['ts'])}. Current state from logs: {last_state}."
                    + (f" Total time down {metrics['total_downtime']}." if outages else ""),
                    host, site, iface, seq[0]["ts"], seq[-1]["ts"], ev_ids,
                    why=f"Raised because the interface completed {cycles} down->up cycles "
                        f"(threshold {t.get('flap_min_cycles', 3)}) on a non-access port.",
                    metrics=metrics, next_steps=steps))
                out[-1]["context"].extend(ctx)
            elif last_state == "down":
                sev = "major" if iclass in ("portchannel", "uplink", "wan", "infra") else "warning"
                out.append(self._f(
                    "link_down", (host, iface), sev, "links",
                    f"{label} {short_interface(iface)} on {host} is down",
                    f"{iface} went down at {fmt(downs[-1]['ts'])} and no 'up' message was logged afterwards "
                    f"(as of {fmt(t1)}).",
                    host, site, iface, seq[0]["ts"], seq[-1]["ts"], ev_ids,
                    why="Last logged state for this non-access interface is DOWN with no subsequent recovery message.",
                    metrics=metrics, next_steps=steps))
                out[-1]["context"].extend(ctx)
            elif iclass in ("uplink", "portchannel", "wan"):
                out.append(self._f(
                    "link_bounce", (host, iface), "low", "links",
                    f"{label} {short_interface(iface)} on {host} bounced {cycles}x",
                    f"{iface} went down and came back up {cycles} time(s). "
                    + (f"Longest outage {metrics.get('longest_outage')}." if outages else "")
                    + " Below the flapping threshold - recorded for context.",
                    host, site, iface, seq[0]["ts"], seq[-1]["ts"], ev_ids,
                    why=f"{cycles} down->up cycle(s) - fewer than the {t.get('flap_min_cycles', 3)} needed to call it flapping.",
                    metrics=metrics, next_steps=steps))
                out[-1]["context"].extend(ctx)

        for host, ports in edge_by_host.items():
            ports.sort(key=lambda p: -p["cycles"])
            worst = ports[0]
            sev = "warning" if worst["cycles"] >= 10 or any(p["errdisabled"] for p in ports) else "low"
            ids = [i for p in ports for i in p["ids"]]
            names = ", ".join(f"{short_interface(p['iface'])} ({p['cycles']}x)" for p in ports[:6])
            out.append(self._f(
                "edge_flap", host, sev, "access",
                f"{len(ports)} access port{'s' if len(ports) > 1 else ''} flapping on {host}",
                f"Access ports with repeated up/down: {names}. Typical causes - damaged patch cable, NIC "
                f"power-saving, or a PoE device rebooting." + (" At least one port was err-disabled." if any(
                    p["errdisabled"] for p in ports) else ""),
                host, worst["site"], worst["iface"] if len(ports) == 1 else None,
                min(p["first"] for p in ports), max(p["last"] for p in ports), ids,
                why=f"Access ports bounce routinely, so only ports with >= {t.get('edge_flap_min_cycles', 5)} "
                    f"down->up cycles are reported.",
                metrics={"ports": [{"interface": p["iface"], "cycles": p["cycles"]} for p in ports]},
                next_steps=[f"show interface {worst['iface']}", f"show power inline {worst['iface']}",
                            "Replace the patch cable / check the endpoint NIC."]))
        return out

    def _far_end(self, host, down_ts: list[float], infra_downs: list[dict]):
        """Find an interface on another device that went down within 2 s of most of these downs."""
        if not down_ts:
            return None
        hits = defaultdict(int)
        for ts in down_ts:
            seen = set()
            for r in infra_downs:
                if r["host"] != host and abs(r["ts"] - ts) <= 2.0:
                    k = (r["host"], r["interface"])
                    if k not in seen and not (r["interface"] or "").startswith("Port-channel"):
                        hits[k] += 1
                        seen.add(k)
        if not hits:
            return None
        (h, i), n = max(hits.items(), key=lambda kv: kv[1])
        if n >= max(1, int(0.6 * len(down_ts))):
            return {"host": h, "interface": i, "matched": n, "of": len(down_ts),
                    "note": f"{h} {short_interface(i)} went down within 2 s on {n} of {len(down_ts)} occasions "
                            f"- probably the other end of this link (inferred from timing, verify with CDP/LLDP)."}
        return None

    # ------------------------------------------------------------------ routing
    def detect_routing(self, t0, t1):
        rows = self.rows(t0, t1, ("routing_adj", "bgp_notification", "bfd", "fhrp"))
        links = self.rows(t0 - 300, t1, ("link_state", "proto_state"), "state='down' AND iface_class != 'edge'")
        adj, notes = defaultdict(list), defaultdict(list)
        out = []
        for r in rows:
            if r["kind"] == "routing_adj":
                adj[(r["host"], r["protocol"], r["neighbor"])].append(r)
            elif r["kind"] == "bgp_notification":
                notes[(r["host"], r["neighbor"])].append(r)
            elif r["kind"] == "fhrp" and r["signal"] in ("warning", "major"):
                a = _attrs(r)
                out.append(self._f("fhrp_change", (r["host"], r["interface"], a.get("group"), r["ts"]), "warning", "routing",
                                   f"Gateway redundancy change on {r['host']} {short_interface(r['interface'])}",
                                   r["message"], r["host"], r["site"], r["interface"], r["ts"], r["ts"], [r["id"]],
                                   why="HSRP/VRRP group changed to Active/Init - this device took over (or lost) the gateway role.",
                                   next_steps=self._steps("hsrp")))
        for (host, proto, nbr), seq in adj.items():
            downs = [r for r in seq if r["state"] == "down"]
            ups = [r for r in seq if r["state"] == "up"]
            if not downs:
                continue
            last = [r for r in seq if r["state"] in ("down", "up")]
            last_state = last[-1]["state"] if last else "?"
            ids = [r["id"] for r in seq] + [n["id"] for n in notes.get((host, nbr), [])]
            vrf = _attrs(downs[0]).get("vrf")
            iface = next((r["interface"] for r in seq if r["interface"]), None)
            nreasons = sorted({n["reason"] for n in notes.get((host, nbr), []) if n["reason"]})
            reasons = sorted({r["reason"] for r in downs if r["reason"]}) + nreasons
            metrics = {"protocol": proto, "neighbor": nbr, "vrf": vrf, "down_events": len(downs),
                       "up_events": len(ups), "last_state": last_state, "reasons": reasons}
            outages = []
            for d in downs:
                u = next((x for x in ups if x["ts"] > d["ts"]), None)
                if u:
                    outages.append(u["ts"] - d["ts"])
            if outages:
                metrics["longest_outage"] = dur(max(outages))
            # timing correlation with interface loss on the same device
            ctx = []
            d0 = downs[0]
            window = 200 if proto == "BGP" else 60
            cands = [l for l in links if l["host"] == host and d0["ts"] - window <= l["ts"] <= d0["ts"] + 1
                     and l["iface_class"] != "edge"]
            if iface:
                same = [l for l in cands if l["interface"] == iface]
                cands = same or cands
            if cands:
                c = cands[-1] if not iface else cands[0]
                gap = d0["ts"] - c["ts"]
                txt = (f"{c['interface']} went down {dur(gap)} {'before' if gap >= 0 else 'after'} this adjacency loss")
                if proto == "BGP" and gap > 30:
                    txt += " - consistent with the BGP hold timer expiring after transport loss (default 180 s)"
                ctx.append({"type": "correlation", "text": txt + ".", "event_id": c["id"]})
            steps = self._steps({"OSPF": "ospf_ios", "BGP": "bgp_adj", "EIGRP": "eigrp", "IS-IS": "isis"}.get(proto, "bgp_adj"),
                                neighbor=nbr, interface=iface or "<interface>")
            name = f"{proto} neighbor {nbr}" + (f" (vrf {vrf})" if vrf and vrf != "default" else "")
            if last_state == "down":
                sev = "critical" if proto == "BGP" else "major"
                f = self._f("adj_down", (host, proto, nbr), sev, "routing", f"{name} on {host} is down",
                            f"{name} went down at {fmt(downs[-1]['ts'])}" + (f" ({'; '.join(reasons)})" if reasons else "")
                            + f" and no re-establishment was logged (as of {fmt(t1)}).",
                            host, seq[0]["site"], iface, seq[0]["ts"], seq[-1]["ts"], ids,
                            why="Last logged adjacency state is DOWN with no subsequent UP/FULL message.",
                            metrics=metrics, next_steps=steps)
            elif len(downs) >= 2:
                f = self._f("adj_unstable", (host, proto, nbr), "major", "routing", f"{name} on {host} is unstable",
                            f"{name} went down {len(downs)} times and recovered each time.",
                            host, seq[0]["site"], iface, seq[0]["ts"], seq[-1]["ts"], ids,
                            why="Two or more adjacency losses within the time window.", metrics=metrics,
                            next_steps=steps)
            else:
                f = self._f("adj_reset", (host, proto, nbr), "warning", "routing", f"{name} on {host} reset and recovered",
                            f"{name} went down at {fmt(downs[0]['ts'])}" + (f" ({'; '.join(reasons)})" if reasons else "")
                            + (f" and recovered after {metrics.get('longest_outage')}." if outages else "."),
                            host, seq[0]["site"], iface, seq[0]["ts"], seq[-1]["ts"], ids,
                            why="A single adjacency loss followed by recovery.", metrics=metrics, next_steps=steps,
                            status="recovered")
            f["context"].extend(ctx)
            out.append(f)
        return out

    # ------------------------------------------------------------------ auth
    def detect_auth(self, t0, t1):
        t = self.t
        win = t.get("auth_fallback_window", 120)
        rows = self.rows(t0, t1 + win, ("auth_fail", "radius"))
        failed = sorted({r["mac"] for r in rows if r["mac"]})
        for i in range(0, len(failed), 500):  # successes only for MACs that failed (successes dominate volume)
            chunk = failed[i:i + 500]
            rows += self.rows(t0, t1 + win, ("auth_success",), f"mac IN ({','.join('?' * len(chunk))})", chunk)
        rows.sort(key=lambda r: (r["ts"], r["id"]))
        by_mac = defaultdict(list)
        radius = defaultdict(list)
        for r in rows:
            if r["kind"] == "radius":
                radius[(r["host"], r["ip"])].append(r)
            elif r["mac"]:
                by_mac[r["mac"]].append(r)
        out = []
        self.auth_stats = {"fail_events": 0, "resolved_by_fallback": 0, "unresolved": 0}
        unresolved_all = []
        for mac, seq in by_mac.items():
            succ = [r["ts"] for r in seq if r["kind"] == "auth_success"]
            bad = []
            for r in seq:
                if r["kind"] != "auth_fail" or r["ts"] > t1:
                    continue
                self.auth_stats["fail_events"] += 1
                if any(r["ts"] <= s <= r["ts"] + win for s in succ):
                    self.auth_stats["resolved_by_fallback"] += 1
                    continue
                bad.append(r)
            # one attempt = DOT1X fail + MAB fail pair; count MAB/authz fails or lone DOT1X fails
            attempts = [r for r in bad if _attrs(r).get("method") != "dot1x"] or bad
            self.auth_stats["unresolved"] += len(bad)
            unresolved_all.extend(bad)
            if len(attempts) >= t.get("auth_fail_min", 5):
                hosts = sorted({r["host"] for r in bad})
                ifs = sorted({short_interface(r["interface"]) for r in bad if r["interface"]})
                reasons = sorted({r["reason"] for r in bad if r["reason"]})
                vendor = mac_vendor(mac)
                out.append(self._f(
                    "auth_repeat", mac, "warning", "auth",
                    f"Endpoint {mac} keeps failing authentication",
                    f"{mac}{f' ({vendor})' if vendor else ''} failed {len(attempts)} authentication attempts on "
                    f"{', '.join(hosts)} {', '.join(ifs)} with reason(s): {', '.join(reasons)}. No successful "
                    f"authentication was logged for it.",
                    hosts[0], bad[0]["site"], bad[0]["interface"], bad[0]["ts"], bad[-1]["ts"], [r["id"] for r in bad],
                    why=f"{len(attempts)} failed attempts without a success within {win} s "
                        f"(threshold {t.get('auth_fail_min', 5)}). 802.1X->MAB fallbacks that succeed are excluded.",
                    metrics={"mac": mac, "attempts": len(attempts), "reasons": reasons, "vendor": vendor},
                    next_steps=self._steps("mab_fail", mac=mac, interface=bad[0]["interface"])))
        for (host, ip), seq in radius.items():
            dead = [r for r in seq if r["state"] == "down"]
            if not dead:
                continue
            alive = [r for r in seq if r["state"] == "up" and r["ts"] > dead[0]["ts"]]
            end = alive[0]["ts"] if alive else t1
            during = [r for r in unresolved_all if r["site"] == seq[0]["site"] and dead[0]["ts"] <= r["ts"] <= end]
            sev = "critical" if not alive else "major"
            out.append(self._f(
                "radius_down", (host, ip), sev, "auth",
                f"RADIUS server {ip} unreachable from {host}" + ("" if not alive else f" for {dur(end - dead[0]['ts'])}"),
                f"{host} marked RADIUS server {ip} dead at {fmt(dead[0]['ts'])}"
                + (f" and alive again at {fmt(alive[0]['ts'])}." if alive else "; no recovery logged.")
                + (f" {len(during)} unresolved authentication failures were logged at site {seq[0]['site']} during this period."
                   if during else ""),
                host, seq[0]["site"], None, dead[0]["ts"], (alive[0]["ts"] if alive else dead[-1]["ts"]),
                [r["id"] for r in seq] + [r["id"] for r in during][:100],
                why="RADIUS_DEAD logged by the switch.", status="recovered" if alive else "active",
                metrics={"server": ip, "failures_during": len(during)},
                next_steps=self._steps("radius_dead", ip=ip)))
        return out

    # ------------------------------------------------------------------ PoE
    def detect_poe(self, t0, t1):
        rows = self.rows(t0, t1, ("poe", "poe_error"))
        by = defaultdict(list)
        for r in rows:
            if r["interface"]:
                by[(r["host"], r["interface"])].append(r)
        out = []
        for (host, iface), seq in by.items():
            det = sum(1 for r in seq if r["state"] == "detect")
            rem = sum(1 for r in seq if r["state"] == "removed")
            errs = [r for r in seq if r["kind"] == "poe_error"]
            denied = [r for r in errs if r["signal"] in ("major", "critical")]
            cycles = min(det, rem)
            if cycles < self.t.get("poe_cycle_min", 3) and len(errs) < 2 and not denied:
                continue
            reasons = sorted({r["reason"] for r in errs if r["reason"]})
            sev = "major" if denied else "warning"
            out.append(self._f(
                "poe_cycle", (host, iface), sev, "power",
                f"PoE device on {host} {short_interface(iface)} is power-cycling" if cycles >= 2 else
                f"PoE faults on {host} {short_interface(iface)}",
                f"{iface}: {det} power-device detections, {rem} removals and {len(errs)} controller error(s)"
                + (f" ({'; '.join(reasons)})" if reasons else "") + ". A device that is detected and removed repeatedly "
                "is most likely boot-looping or drawing too much inrush current (bad cable or faulty PD).",
                host, seq[0]["site"], iface, seq[0]["ts"], seq[-1]["ts"], [r["id"] for r in seq],
                why=f"{cycles} detect/remove cycles and {len(errs)} PoE controller errors on one port.",
                metrics={"detections": det, "removals": rem, "errors": len(errs), "reasons": reasons},
                next_steps=self._steps("poe_controller_err", interface=iface)))
        return out

    # ------------------------------------------------------------------ MAC moves
    def detect_mac_moves(self, t0, t1):
        rows = self.rows(t0, t1, ("mac_move",))
        by = defaultdict(list)
        for r in rows:
            by[(r["mac"], r["vlan"])].append(r)
        out = []
        for (mac, vlan), seq in by.items():
            n = len(seq)
            if n < self.t.get("mac_move_min", 3):
                continue
            hosts = sorted({r["host"] for r in seq})
            ts = [r["ts"] for r in seq]
            j, peak = 0, 0
            for i in range(n):
                while ts[i] - ts[j] > 300:
                    j += 1
                peak = max(peak, i - j + 1)
            vendor = mac_vendor(mac)
            ports = defaultdict(int)
            for r in seq:
                a = _attrs(r)
                ports[f"{r['host']}: {short_interface(a.get('from_if'))} -> {short_interface(a.get('to_if'))}"] += 1
            sev = "major" if peak >= 20 or (len(hosts) >= 2 and peak >= 10) else "warning"
            note = ""
            if vendor in VIRTUAL_VENDORS:
                note = (f" The address belongs to {vendor}; a VM migration (vMotion) explains a single move, but "
                        f"{peak} moves in 5 minutes is not normal migration behaviour.")
            out.append(self._f(
                "mac_move", (mac, vlan), sev, "l2",
                f"MAC {mac} moving repeatedly in VLAN {vlan}" + (f" across {len(hosts)} switches" if len(hosts) > 1 else ""),
                f"{n} moves logged between {fmt(ts[0])} and {fmt(ts[-1])} (peak {peak} within 5 min) on "
                f"{', '.join(hosts)}.{note} Rapid moves between the same ports are consistent with a layer-2 loop or a "
                f"dual-attached host; check spanning-tree and the host's NIC teaming.",
                hosts[0], seq[0]["site"], None, ts[0], ts[-1], [r["id"] for r in seq],
                why=f"{n} moves of one MAC (threshold {self.t.get('mac_move_min', 3)}); severity 'major' requires >=20 moves "
                    f"in 5 min, or >=10 across several switches.",
                metrics={"mac": mac, "vlan": vlan, "moves": n, "peak_5min": peak, "switches": hosts, "vendor": vendor,
                         "paths": dict(sorted(ports.items(), key=lambda kv: -kv[1])[:8])},
                next_steps=self._steps("nxos_mac_move", mac=mac, vlan=vlan)))
        return out

    # ------------------------------------------------------------------ generic per-kind
    GENERIC = {
        # kind: (key fields, category, title template, min signal)
        "psu": (("host",), "power", "Power supply fault on {host}"),
        "environment": (("host",), "hardware", "Environmental alarm on {host}"),
        "module": (("host",), "hardware", "Module/process fault on {host}"),
        "resource": (("host",), "hardware", "Resource exhaustion alert on {host}"),
        "stack_member": (("host",), "hardware", "Stack membership change on {host}"),
        "stack_link": (("host",), "errors", "Stack cable/port instability on {host}"),
        "buffer": (("host",), "hardware", "Packet buffer threshold exceeded on {host}"),
        "optic_alarm": (("host", "interface"), "optics", "Optical power alarm on {host} {iface}"),
        "optic_bad": (("host", "interface"), "optics", "Unsupported/faulty transceiver on {host} {iface}"),
        "errdisable": (("host", "interface"), "errors", "{iface} on {host} err-disabled"),
        "storm": (("host", "interface"), "errors", "Traffic storm on {host} {iface}"),
        "mismatch": (("host", "interface"), "errors", "Duplex/VLAN mismatch on {host} {iface}"),
        "stp": (("host",), "l2", "Spanning-tree event on {host}"),
        "vpc": (("host",), "l2", "vPC problem on {host}"),
        "dup_ip": (("host", "ip"), "l2", "Duplicate IP address seen on {host}"),
        "lag_member": (("host", "interface"), "l2", "Port-channel member {iface} on {host} left the bundle"),
        "reload": (("host",), "system", "{host} reloaded"),
        "isdn_l2": (("host", "interface"), "system", "ISDN D-channel {iface} on {host} went down"),
        "login_fail": (("host", "ip"), "system", "Repeated login failures on {host} from {ip}"),
        "license": (("host",), "system", "Licensing problem on {host}"),
        "ntp": (("host",), "system", "Time synchronisation problem on {host}"),
        "unclassified": (("host", "code"), "other", "Unclassified message {code} on {host}"),
    }
    SIG2SEV = {"critical": "critical", "major": "major", "warning": "warning", "info": "info", "routine": "info"}

    def detect_generic(self, t0, t1):
        rows = self.rows(t0, t1, tuple(self.GENERIC))
        groups = defaultdict(list)
        for r in rows:
            keyf = self.GENERIC[r["kind"]][0]
            groups[(r["kind"],) + tuple(r.get(k) for k in keyf)].append(r)
        out = []
        for key, seq in groups.items():
            kind = key[0]
            _, cat, tpl = self.GENERIC[kind]
            sig = max((r["signal"] for r in seq), key=lambda s: ["routine", "info", "warning", "major", "critical"].index(s))
            if sig in ("routine", "info") and kind != "unclassified":
                continue
            bad = [r for r in seq if r["signal"] in ("warning", "major", "critical")] or seq
            if kind == "login_fail" and len(bad) < self.t.get("login_fail_min", 5):
                continue
            if kind == "lag_member" and not any(r["state"] in ("down", "suspended") for r in seq):
                continue
            last_bad = bad[-1]
            recovered = any(r["signal"] == "info" and r["ts"] > last_bad["ts"] for r in seq)
            sev = self.SIG2SEV[sig]
            if recovered and sev in ("major", "critical"):
                sev = "warning"
            r0 = bad[0]
            iface = r0["interface"]
            title = tpl.format(host=r0["host"], iface=short_interface(iface) or "", ip=r0["ip"] or "?", code=r0["code"])
            nrep = sum(r["repeat"] or 1 for r in bad)
            uniq_msgs = list(dict.fromkeys(r["message"] for r in bad))[:3]
            summary = (f"{nrep} occurrence(s) between {fmt(bad[0]['ts'])} and {fmt(last_bad['ts'])}. "
                       f"Latest: {last_bad['message']}" + (" - a later message indicates recovery." if recovered else ""))
            if kind == "lag_member":
                downs = sum(1 for r in seq if r["state"] == "down")
                summary = f"{iface} left its port-channel {downs} time(s). " + summary
            if kind == "unclassified":
                sev = "warning" if (r0["severity"] is not None and r0["severity"] <= 3) else "info"
            steps = self._steps(r0["rule"] or "", interface=iface or "", ip=r0["ip"] or "", vlan=r0["vlan"] or "")
            out.append(self._f(
                kind, key, sev, cat, title, summary, r0["host"], r0["site"], iface, seq[0]["ts"], seq[-1]["ts"],
                [r["id"] for r in seq], count=nrep,
                why=f"{len(bad)} message(s) rated '{sig}' by rule '{r0['rule'] or 'severity fallback'}'.",
                metrics={"occurrences": nrep, "examples": uniq_msgs, "code": r0["code"]},
                next_steps=steps, status="recovered" if recovered else "active"))
        return out

    # ------------------------------------------------------------------ site bursts
    def detect_site_bursts(self, t0, t1):
        win = self.t.get("site_burst_window", 60)
        need = self.t.get("site_burst_min_devices", 3)
        rows = self.rows(t0, t1, ("link_state",), "state='down' AND site IS NOT NULL AND iface_class != 'edge'")
        by_site = defaultdict(list)
        for r in rows:
            by_site[r["site"]].append(r)
        out = []
        for site, seq in by_site.items():
            i = 0
            while i < len(seq):
                j = i
                while j + 1 < len(seq) and seq[j + 1]["ts"] - seq[i]["ts"] <= win:
                    j += 1
                grp = seq[i:j + 1]
                hosts = sorted({r["host"] for r in grp})
                if len(hosts) >= need:
                    a, b = grp[0]["ts"], grp[-1]["ts"]
                    others = self.rows(a - 120, b + 120, None,
                                       "site=? AND signal IN ('warning','major','critical') AND kind NOT IN ('link_state','proto_state')",
                                       (site,))
                    ctx = [{"type": "coincident", "text": f"{fmt(o['ts'])} {o['host']}: %{o['code']}: {o['message']}",
                            "event_id": o["id"]} for o in others[:8]]
                    f = self._f(
                        "site_event", (site, round(a)), "major", "links",
                        f"Simultaneous link loss on {len(hosts)} devices at site {site}",
                        f"{len(grp)} infrastructure link-down events on {len(hosts)} devices ({', '.join(hosts)}) within "
                        f"{dur(b - a)} starting {fmt(a)}. Events this close together often share a cause (upstream "
                        f"device, power, maintenance) - this is a timing observation, not a confirmed root cause.",
                        hosts[0], site, None, a, b, [r["id"] for r in grp] + [o["id"] for o in others[:20]],
                        why=f">= {need} devices at the same site logged infrastructure link-down within {win} s.",
                        metrics={"devices": hosts, "events": len(grp)},
                        next_steps=["Check the common upstream (distribution) device and its logs at this time.",
                                    "Check for power events (PSU/PEM) at the site.",
                                    "Check change calendar for planned work."])
                    f["context"].extend(ctx)
                    out.append(f)
                    i = j + 1
                else:
                    i += 1
        return out

    # ------------------------------------------------------------------ clocks
    def detect_clock(self, t0, t1):
        rows = self.store.q(
            "SELECT host, site, skew, clock_flag, id FROM events WHERE ts BETWEEN ? AND ? AND skew IS NOT NULL "
            "ORDER BY id DESC LIMIT 200000", (max(t0, t1 - 6 * 3600), t1))
        by = defaultdict(list)
        flags = defaultdict(list)
        for r in rows:
            by[r["host"]].append(r)
            if r["clock_flag"]:
                flags[r["host"]].append(r)
        lim = self.t.get("clock_skew_seconds", 10)
        out = []
        for host, seq in by.items():
            if len(seq) < 3:
                continue
            med = statistics.median(r["skew"] for r in seq)
            if abs(med) >= lim:
                out.append(self._f(
                    "clock_skew", host, "warning", "system",
                    f"Clock on {host} is {dur(med)} {'behind' if med < 0 else 'ahead of'} the syslog server",
                    f"Median offset between the device timestamp and the server receive time is {med:+.1f} s over "
                    f"{len(seq)} messages. Event times from this device will not line up with other devices - "
                    f"check NTP.", host, seq[0]["site"], None, t0, t1, [r["id"] for r in seq[:20]],
                    why=f"|median offset| >= {lim} s.", metrics={"median_offset_s": round(med, 1), "samples": len(seq)},
                    next_steps=["show ntp associations", "show ntp status", "show clock detail"]))
        for host, seq in flags.items():
            out.append(self._f(
                "clock_unsynced", host, "warning", "system", f"{host} reports an unsynchronised clock",
                "Device timestamps are prefixed with '*' or '.', meaning the clock is not (or no longer) NTP-synchronised.",
                host, seq[0]["site"], None, t0, t1, [r["id"] for r in seq[:20]], why="Timestamp flag '*' or '.'.",
                next_steps=["show ntp associations", "show clock detail"]))
        return out

    # ------------------------------------------------------------------ novelty
    def detect_new_codes(self, t0, t1):
        base_t0 = t0 - 7 * 86400
        base = self.store.one("SELECT COUNT(*) n, MIN(ts) m FROM events WHERE ts BETWEEN ? AND ?", (base_t0, t0))
        if not base or base["n"] < 2000 or base["m"] is None or t0 - base["m"] < 6 * 3600:
            return []
        seen = {r["code"] for r in self.store.q(
            "SELECT DISTINCT code FROM events WHERE ts BETWEEN ? AND ? AND code IS NOT NULL", (base_t0, t0))}
        cur = self.store.q(
            "SELECT code, COUNT(*) n, MIN(ts) a, MAX(ts) b, GROUP_CONCAT(DISTINCT host) hosts, MIN(id) i, "
            "MAX(signal) sig, MIN(category) cat FROM events WHERE ts BETWEEN ? AND ? AND code IS NOT NULL GROUP BY code",
            (t0, t1))
        days = dur(t0 - base["m"])
        out = []
        for r in cur:
            if r["code"] in seen:
                continue
            ids = [x["id"] for x in self.store.q("SELECT id FROM events WHERE code=? AND ts BETWEEN ? AND ? LIMIT 100",
                                                 (r["code"], t0, t1))]
            hosts = (r["hosts"] or "").split(",")
            out.append(self._f(
                "first_seen", r["code"], "info", r["cat"] or "other", f"First occurrence of %{r['code']}",
                f"{r['n']} message(s) on {', '.join(hosts[:4])}{' ...' if len(hosts) > 4 else ''}. This message type "
                f"did not appear in the preceding {days} of indexed logs.",
                hosts[0], None, None, r["a"], r["b"], ids,
                why="Message code absent from the baseline period - new behaviour is worth a look even when low severity.",
                metrics={"code": r["code"], "baseline": days}))
        return out

    def detect_volume(self, t0, t1):
        span = t1 - t0
        if span > 2 * 86400 or span < 600:
            return []
        base_t0 = t0 - 7 * 86400
        b = self.store.one("SELECT MIN(ts) m FROM events WHERE ts BETWEEN ? AND ?", (base_t0, t0))
        if not b or b["m"] is None or t0 - b["m"] < 12 * 3600:
            return []
        base_span = t0 - b["m"]
        q = ("SELECT host, MIN(site) site, COUNT(*) n FROM events WHERE ts BETWEEN ? AND ? "
             "AND signal IN ('warning','major','critical') GROUP BY host")
        cur = {r["host"]: r for r in self.store.q(q, (t0, t1))}
        base = {r["host"]: r["n"] for r in self.store.q(q, (b["m"], t0))}
        out = []
        for host, r in cur.items():
            rate_now = r["n"] / span
            rate_base = base.get(host, 0) / base_span
            if r["n"] >= 30 and rate_now >= 5 * max(rate_base, 1 / base_span):
                ratio = rate_now / max(rate_base, 1e-9) if rate_base else None
                out.append(self._f(
                    "volume_spike", host, "warning", "other", f"Unusual volume of significant messages from {host}",
                    f"{r['n']} warning-or-higher messages in this window - "
                    + (f"{ratio:.1f}x its normal rate" if ratio else "none were logged in the baseline period")
                    + f" (baseline {dur(base_span)}).",
                    host, r["site"], None, t0, t1, [], count=r["n"],
                    why="Rate of warning+ messages >= 5x the device's own baseline (minimum 30 messages).",
                    metrics={"window_count": r["n"], "baseline_count": base.get(host, 0)}))
        return out

    # ------------------------------------------------------------------ context
    # finding types for which a preceding configuration change is relevant context
    CHANGE_TYPES = {"link_flap", "link_down", "link_bounce", "adj_down", "adj_unstable", "adj_reset", "site_event",
                    "errdisable", "stp", "vpc", "lag_member", "reload", "fhrp_change", "mismatch", "radius_down",
                    "storm", "dup_ip"}

    def _attach_changes(self, findings, t1):
        look = self.t.get("change_lookback_minutes", 30) * 60
        hosts = {f["host"] for f in findings if f["host"] and SEV_RANK[f["severity"]] >= SEV_RANK["warning"]}
        if not hosts:
            return
        t0 = min(f["first"] for f in findings) - look
        rows = self.rows(t0, t1, ("config_change", "reload", "admin_state"))
        by = defaultdict(list)
        for r in rows:
            by[r["host"]].append(r)
        for f in findings:
            if SEV_RANK[f["severity"]] < SEV_RANK["warning"] or f["host"] not in by or f["type"] not in self.CHANGE_TYPES:
                continue
            for c in by[f["host"]]:
                if f["first"] - look <= c["ts"] <= f["first"] + 5 and c["id"] not in f["evidence"]:
                    who = f" by {c['user']}" if c["user"] else ""
                    f["context"].append({
                        "type": "change",
                        "text": f"What changed: %{c['code']}{who} at {fmt(c['ts'])} "
                                f"({dur(f['first'] - c['ts'])} before this started) - {c['message']}",
                        "event_id": c["id"]})

    def _attach_recurrence(self, findings, t0):
        for f in findings:
            if f["type"] not in ("link_flap", "link_bounce", "poe_cycle", "buffer", "psu", "auth_repeat", "edge_flap",
                                 "stack_link", "optic_alarm", "mac_move"):
                continue
            where, p = "host=?", [f["host"]]
            if f["type"] == "mac_move":
                where, p = "mac=?", [f["metrics"].get("mac")]
            elif f["type"] == "auth_repeat":
                where, p = "mac=?", [f["metrics"].get("mac")]
            elif f["interface"]:
                where += " AND interface=?"
                p.append(f["interface"])
            days = self.store.q(
                f"SELECT CAST(ts/86400 AS INT) d, COUNT(*) n FROM events WHERE ts BETWEEN ? AND ? AND {where} "
                f"AND signal IN ('warning','major','critical') GROUP BY d", [t0 - 7 * 86400, t0 - 1] + p)
            if days:
                f["context"].append({"type": "recurring",
                                     "text": f"Recurring: similar warning+ messages for this "
                                             f"{'interface' if f['interface'] else 'device'} on {len(days)} earlier day(s) "
                                             f"in the indexed history."})
                f["metrics"]["recurring_days"] = len(days)


def health(findings: list[dict]) -> dict[str, dict]:
    """Per-device health score (100 = nothing noteworthy)."""
    out: dict[str, dict] = {}
    for f in findings:
        h = f.get("host")
        if not h:
            continue
        d = out.setdefault(h, {"score": 100, "findings": 0, "worst": "info"})
        if f["status"] == "recovered":
            d["score"] -= HEALTH_WEIGHT[f["severity"]] // 2
        else:
            d["score"] -= HEALTH_WEIGHT[f["severity"]]
        d["findings"] += 1
        if SEV_RANK[f["severity"]] > SEV_RANK[d["worst"]]:
            d["worst"] = f["severity"]
    for d in out.values():
        d["score"] = max(0, d["score"])
    return out
