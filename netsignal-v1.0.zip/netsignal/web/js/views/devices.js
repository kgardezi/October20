// Device inventory ranked by health.
import { esc, api, n, loading, healthColor, ago, sevBadge } from '../util.js';
import { state, go } from '../state.js';
import { rangeSeg, bindRange } from '../components.js';

export async function render(main) {
  main.innerHTML = `<div class="page">${loading()}</div>`;
  const d = await api(`/api/devices?range=${state.range}`);
  const now = state.now();
  let sort = 'score', dir = 1, filter = '';
  const cols = [['score', 'Health'], ['host', 'Device'], ['site', 'Site'], ['role_name', 'Role'], ['platform', 'Platform'],
    ['n', 'Messages'], ['sig', 'Warning+'], ['routine', 'Routine'], ['findings', 'Findings'], ['last', 'Last message']];

  function draw() {
    let rows = d.devices.filter(r => !filter || (r.host + ' ' + (r.site || '') + ' ' + (r.role_name || '') + ' ' + (r.platform || '')).toLowerCase().includes(filter));
    rows = rows.sort((a, b) => {
      const x = a[sort], y = b[sort];
      return (typeof x === 'number' && typeof y === 'number' ? x - y : String(x ?? '').localeCompare(String(y ?? ''))) * dir;
    });
    main.innerHTML = `<div class="page">
      <div class="ph"><div><h1>Devices</h1><div class="sub">${n(d.devices.length)} devices reporting. Health starts at 100 and drops with each finding (recovered findings count half).</div></div>
        <div class="grow"></div><input class="inp" id="flt" placeholder="Filter devices, sites, roles…" value="${esc(filter)}" style="width:240px">${rangeSeg()}</div>
      <div class="card"><div class="scroll"><table class="tbl"><thead><tr>${cols.map(([k, l]) => `<th class="sortable ${['n', 'sig', 'routine', 'findings', 'score'].includes(k) ? 'r' : ''}" data-k="${k}">${l}${sort === k ? (dir > 0 ? ' ▲' : ' ▼') : ''}</th>`).join('')}</tr></thead>
      <tbody>${rows.map(r => `<tr class="click" data-h="${esc(r.host)}">
        <td class="r"><span class="hscore" style="background:color-mix(in srgb, ${healthColor(r.score)} 18%, transparent);color:${healthColor(r.score)};font-size:12px">${r.score}</span></td>
        <td><b>${esc(r.host)}</b></td><td>${esc(r.site || '—')}</td><td class="t2">${esc(r.role_name || r.role || '—')}</td><td class="t2">${esc(r.platform || '—')}</td>
        <td class="r num">${n(r.n)}</td><td class="r num">${r.sig ? `<b>${n(r.sig)}</b>` : 0}</td><td class="r num muted">${n(r.routine)}</td>
        <td class="r">${r.findings ? sevBadge(r.worst, r.findings + ' · ' + r.worst) : '<span class="muted">0</span>'}</td>
        <td class="muted nowrap">${esc(ago(r.last, now))}</td></tr>`).join('')}</tbody></table></div></div></div>`;
    bindRange(main, () => go(location.hash));
    main.querySelectorAll('th[data-k]').forEach(th => th.onclick = () => { if (sort === th.dataset.k) dir = -dir; else { sort = th.dataset.k; dir = ['n', 'sig', 'findings', 'last'].includes(sort) ? -1 : 1; } draw(); });
    main.querySelectorAll('tr[data-h]').forEach(tr => tr.onclick = () => go(`#/device/${tr.dataset.h}`));
    const f = main.querySelector('#flt');
    f.oninput = () => { filter = f.value.toLowerCase(); const pos = f.selectionStart; draw(); const nf = main.querySelector('#flt'); nf.focus(); nf.setSelectionRange(pos, pos); };
  }
  draw();
}
