// Investigation workspace: filters, facets, histogram, evidence table. Also exported as a reusable explorer.
import { esc, icon, api, qs, n, fmtTs, shortIf, loading, emptyState } from '../util.js';
import { state, go } from '../state.js';
import { rangeSeg, bindRange, eventRows, bindEventTable } from '../components.js';
import { timeline, legend } from '../charts.js';

const LABEL = { host: 'device', site: 'site', iface: 'interface', code: 'code', category: 'category', kind: 'type', mac: 'MAC',
  ip: 'IP', vlan: 'VLAN', neighbor: 'neighbor', user: 'user', q: 'text', signal: 'rating', signal_min: 'rating ≥',
  sev_max: 'Cisco sev ≤', protocol: 'protocol', platform: 'platform', role: 'role', ids: 'events', iface_class: 'port class' };
const FACETS = [['host', 'Devices'], ['code', 'Event codes'], ['interface', 'Interfaces'], ['category', 'Categories'], ['signal', 'Rating'], ['site', 'Sites']];

export async function render(main, { params }) {
  const p = { ...params };
  const interp = state.lastSearch;
  state.lastSearch = null;
  const title = p.category && Object.keys(p).length === 1 ? 'Investigate' : 'Investigate';
  main.innerHTML = `<div class="page">
    <div class="ph"><div><h1>${title}</h1><div class="sub">Every row is an original syslog line. Click a row for explanation, context and next steps.</div></div>
      <div class="grow"></div>${p.t0 ? '' : rangeSeg()}</div>
    ${interp ? `<div class="interp">${icon('search', 'sm')} Interpreted <b>“${esc(interp.query)}”</b> as: ${esc(interp.explain.join(' · '))}</div>` : ''}
    <div id="exp"></div></div>`;
  bindRange(main, () => go(location.hash));
  return explorer(main.querySelector('#exp'), p, { editable: true });
}

/**
 * Event explorer.
 * base: filters (host, code, category, t0, t1, ...). editable: filters are reflected into the URL.
 */
export function explorer(root, base, { editable = false, fixed = [], title = '' } = {}) {
  let f = { ...base };
  if (f.signal_min === undefined && !f.signal && !f.ids && !f.kind && !f.mac && !f.code && !f.q) f.signal_min = state.hideRoutine ? 'info' : '';
  let events = [], total = 0, offset = 0, follow = false, buffer = [];
  const PAGE = 200;

  root.innerHTML = `<div class="card" style="margin-bottom:16px"><div class="hd"><h3>${esc(title || 'Message volume')}</h3><span class="grow"></span>
      ${legend(['critical', 'major', 'warning', 'info', 'routine'])}</div><div class="bd"><div class="chart" id="hist"></div>
      <div class="note">Drag to zoom into a time slice.</div></div></div>
    <div class="inv"><div class="card pad facets" id="facets">${loading()}</div>
    <div class="card" style="min-width:0"><div class="filterbar" id="fbar"></div><div id="tbl">${loading()}</div>
      <div style="padding:10px 14px;display:flex;gap:10px;align-items:center" id="more"></div></div></div>`;

  const fbar = root.querySelector('#fbar');

  function params(extra = {}) {
    const out = { ...f, ...extra };
    if (!out.t0) out.range = out.range || state.range;
    return out;
  }

  function chips() {
    const keys = Object.keys(f).filter(k => f[k] !== '' && f[k] != null && !['t0', 't1', 'range'].includes(k));
    let html = keys.map(k => `<span class="chip filter">${esc(LABEL[k] || k)}: <b>${esc(k === 'ids' ? f[k].split(',').length + ' selected' : k === 'iface' ? shortIf(f[k]) : f[k])}</b>
      ${fixed.includes(k) ? '' : `<span class="x" data-rm="${esc(k)}">${icon('x', 'sm')}</span>`}</span>`).join('');
    if (f.t0) html += `<span class="chip filter">${icon('clock', 'sm')} ${esc(fmtTs(+f.t0))} → ${esc(fmtTs(+f.t1))}<span class="x" data-rm="t0">${icon('x', 'sm')}</span></span>`;
    const hide = f.signal_min === 'info';
    fbar.innerHTML = `${html || '<span class="muted">No filters - showing everything</span>'}
      <span style="flex:1"></span>
      <input class="inp" id="within" placeholder="Filter text…" value="${esc(f.q || '')}" style="width:180px;padding:5px 9px">
      <label class="toggle ${hide ? 'on' : ''}" id="tgHide" title="Hide routine messages (successful auth, access-port bounces, PoE budget updates…)"><span class="sw"></span>Hide routine</label>
      ${f.t0 ? '' : `<label class="toggle ${follow ? 'on' : ''}" id="tgFollow" title="Prepend new matching messages as they arrive"><span class="sw"></span>Follow live</label>`}
      <a class="btn sm" href="/api/export?${qs(params())}" title="Export matching messages as CSV (original lines included)">${icon('download', 'sm')} CSV</a>`;
    fbar.querySelectorAll('[data-rm]').forEach(x => x.addEventListener('click', () => {
      const k = x.dataset.rm;
      if (k === 't0') { delete f.t0; delete f.t1; } else delete f[k];
      update();
    }));
    fbar.querySelector('#tgHide').addEventListener('click', () => {
      f.signal_min = f.signal_min === 'info' ? '' : 'info';
      state.setHideRoutine(f.signal_min === 'info');
      update();
    });
    fbar.querySelector('#tgFollow')?.addEventListener('click', () => { follow = !follow; chips(); });
    const w = fbar.querySelector('#within');
    w.addEventListener('keydown', ev => { if (ev.key === 'Enter') { f.q = w.value.trim(); update(); } });
  }

  function update() {
    if (editable) {
      const h = '#/investigate?' + qs(Object.fromEntries(Object.entries(f).filter(([k, v]) => v !== '' && v != null)));
      history.replaceState(null, '', h);
    }
    load();
  }

  async function load(append = false) {
    if (!append) { offset = 0; root.querySelector('#tbl').innerHTML = loading(); }
    const r = await api('/api/events?' + qs(params({ limit: PAGE, offset, facets: append ? 0 : 1, hist: append ? 0 : 1 })));
    total = r.total;
    events = append ? events.concat(r.events) : r.events;
    if (!append) { drawFacets(r.facets); drawHist(r.histogram); chips(); }
    drawTable();
  }

  function drawTable() {
    const now = state.now();
    const tbl = root.querySelector('#tbl');
    tbl.innerHTML = events.length ? `<div class="scroll"><table class="tbl evt"><thead><tr><th>Time</th><th></th><th>Device</th><th>Code</th><th>Message</th></tr></thead>
      <tbody>${eventRows(events, { now })}</tbody></table></div>` : emptyState('No matching messages. Try a wider time range or remove a filter.', 'search');
    root.querySelector('#more').innerHTML = `<span class="muted">Showing ${n(events.length)} of ${n(total)}</span>
      ${events.length < total ? `<button class="btn sm" id="loadmore">Load ${Math.min(PAGE, total - events.length)} more</button>` : ''}`;
    root.querySelector('#loadmore')?.addEventListener('click', () => { offset += PAGE; load(true); });
  }

  function drawFacets(fc) {
    const el = root.querySelector('#facets');
    el.innerHTML = FACETS.map(([k, label]) => {
      const rows = fc?.[k] || [];
      if (!rows.length) return '';
      const max = Math.max(...rows.map(r => r.n));
      const fk = k === 'interface' ? 'iface' : k;
      return `<div class="facet"><h4>${esc(label)}</h4>${rows.slice(0, 8).map(r => `<div class="fr" data-k="${fk}" data-v="${esc(r.v)}" title="${esc(r.v)}">
        <span class="lbl">${esc(k === 'interface' ? shortIf(r.v) : r.v)}</span><span class="bar" style="width:${Math.max(4, r.n / max * 50)}px"></span><span class="cnt">${n(r.n)}</span></div>`).join('')}</div>`;
    }).join('') || '<div class="muted">No facets</div>';
    el.querySelectorAll('.fr').forEach(r => r.addEventListener('click', () => {
      if (r.dataset.k === 'host' && !f.host && Object.keys(f).filter(x => !['t0', 't1', 'signal_min', 'range'].includes(x)).length === 0) {
        go(`#/device/${r.dataset.v}`); return;
      }
      f[r.dataset.k] = r.dataset.v;
      if (r.dataset.k === 'signal') delete f.signal_min;
      update();
    }));
  }

  function drawHist(h) {
    const el = root.querySelector('#hist');
    if (!h) return;
    root._hist = h;
    timeline(el, h, {
      signals: ['critical', 'major', 'warning', 'info', 'routine'].filter(s => f.signal_min !== 'info' || s !== 'routine'),
      height: 130, now: state.now(),
      onSelect: (a, b) => { f.t0 = Math.floor(a); f.t1 = Math.ceil(b); update(); },
    });
  }

  // follow live
  const matches = e => {
    for (const [k, v] of Object.entries(f)) {
      if (v === '' || v == null) continue;
      if (k === 'signal_min') { if (v === 'info' && e.signal === 'routine') return false; continue; }
      if (k === 'iface') { if (e.interface !== v) return false; continue; }
      if (k === 'code') { if (!(e.code || '').startsWith(v.replace('*', ''))) return false; continue; }
      if (k === 'q') { if (!(e.raw || '').toLowerCase().includes(v.toLowerCase())) return false; continue; }
      if (['host', 'site', 'category', 'kind', 'mac', 'signal', 'user', 'neighbor', 'ip', 'protocol'].includes(k) && String(e[k] ?? '') !== String(v)) return false;
    }
    return true;
  };
  const onLive = batch => {
    if (!follow || f.t0) return;
    const m = batch.filter(matches);
    if (!m.length) return;
    events = m.reverse().concat(events).slice(0, 1000);
    total += m.length;
    drawTable();
    root.querySelectorAll('#tbl tbody tr').forEach((tr, i) => { if (i < m.length) tr.style.animation = 'flash 1.2s ease'; });
  };
  state.listeners.add(onLive);

  bindEventTable(root.querySelector('#tbl'));
  const onResize = () => root._hist && drawHist(root._hist);
  window.addEventListener('resize', onResize);
  load().catch(e => { root.querySelector('#tbl').innerHTML = emptyState(e.message, 'alert'); });
  return () => { state.listeners.delete(onLive); window.removeEventListener('resize', onResize); };
}
