"""Vendor parser registry.

A parser turns one raw syslog line into a dict of *syntactic* fields
(timestamps, host, facility/severity/mnemonic, message). Semantic
classification is done afterwards by the vendor-neutral rules engine
(netsignal.classifier) using the vendor's YAML rule file.

To add a vendor (Juniper, ADVA, Metamako ...):
  1. create parsers/<vendor>.py exposing `parse_line(line, ref_dt) -> dict | None`
  2. create rules/<vendor>_rules.yaml
  3. register it in PARSERS below.
"""
from . import cisco

PARSERS = {
    "cisco": cisco,
}


def get_parser(vendor: str = "cisco"):
    return PARSERS[vendor]
