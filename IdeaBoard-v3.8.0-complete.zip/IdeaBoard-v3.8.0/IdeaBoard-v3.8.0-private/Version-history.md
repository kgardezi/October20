# IdeaBoard version history and feature check (3.8.0)

Every earlier build found in the kgardezi repositories (October10, October1, October14, October17) was compared with 3.7.0. Features 3.7.0 had lost are restored in 3.8.0.

| Build | Main additions | In 3.7.0? | In 3.8.0 |
|---|---|---|---|
| Sept · first builds | Infinite canvas, network library, glued links, link types (SMF yellow, MMF orange…), A/B port labels, rack view, role badges, zones as frames, pencil/eraser, boards, pages, pictures, laser, guides, align/distribute, PNG/SVG export, dark mode, four fonts | Yes | Yes |
| Sept · team server | Node.js server with team and private boards, live editing, cursors, shared laser, presence; Docker, install.sh/systemd, nginx example | Client only; server files missing | **Restored** (team-server folder) |
| 2.1 | Smart routing, keyboard navigation, search/outline, PDF, annotations, bounded undo | Yes | Yes |
| 2.2 / 2.2.1 | First Visio export (preview) | Superseded | Superseded |
| 2.3.0 | Visio export rebuilt (Visio masters, glued dynamic connectors, Shape Data), Visio import, arrowheads, Alt-drag from centre, 15° snap | Yes | Yes, export reworked again |
| 2.6.0 / 2.6.1 | Device-file importer, highlighter, ink-only eraser, pressure/uniform width, clean/hand-drawn import look | Yes | Yes |
| 3.0.0 | WAN/PW/OSPF pages, Problems report, safe debug summary, page layout rules | Yes | Yes |
| 3.3.1 | Folder build, pipes/flow, draggable labels, fullscreen, Visio themes | Yes | Yes |
| 3.4.0 | Whole-network L1/L2, country/DC overrides, Light/Black Visio gradients, grouped rack units in Visio | Yes | Yes |
| 3.5.0 | Four role rows, LLDP priority, NX-OS `show ospf`, OSPF overview/per-site, private/public builds | Yes | Yes |
| 3.6.0 | Physical link speeds page | Yes | Yes |
| 3.6.1 | NX-OS LLDP detail, NX-OS interface description, truncated status states, `show interface brief`, OSPF neighbor detail, per-VRF OSPF blocks, Problems notes; lines grid, grid-in-export toggle, laser glow/colours/short trails | **No** (3.7.0 was built from 3.6.0) | **Restored** |
| 3.7.0 | Layered site layout, 12+ handles on shapes, outlined export fonts, graph paper, laser Spot/Trail, platform command guide | Yes | Yes |
| 3.8.0 | Native-feeling Visio export (formulas, containers, layers, Visio look), PNG/SVG options | — | New |
