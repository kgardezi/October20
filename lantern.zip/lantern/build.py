#!/usr/bin/env python3
"""Assemble src/ into a single self-contained lantern.html"""
import json,pathlib
root=pathlib.Path(__file__).parent
html=(root/'src/index.html').read_text()
css=(root/'src/style.css').read_text()
js=(root/'src/core.js').read_text()+'\n'+(root/'src/ui.js').read_text()
seed=json.dumps(json.loads((root/'src/noteforge-seed.json').read_text()),ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
out=html.replace('/*__CSS__*/',css).replace('/*__SEED__*/[]',seed).replace('/*__JS__*/',js.replace('</script','<\\/script'))
(root/'lantern.html').write_text(out)
# also a seed-free variant for people starting fresh
(root/'lantern-empty.html').write_text(html.replace('/*__CSS__*/',css).replace('/*__SEED__*/[]','[]').replace('/*__JS__*/',js.replace('</script','<\\/script')))
print('built',len(out),'bytes')
