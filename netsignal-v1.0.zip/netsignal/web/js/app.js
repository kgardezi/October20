// App shell: navigation, routing, global search, live status, theme.
import { $, esc, icon, api, qs, toast, fmtTime } from './util.js';
import { state, go, parseHash } from './state.js';
import { closeDrawer, openEvent } from './components.js';
import * as overview from './views/overview.js';
import * as investigate from './views/investigate.js';
import * as findings from './views/findings.js';
import * as finding from './views/finding.js';
import * as category from './views/category.js';
import * as device from './views/device.js';
import * as devices from './views/devices.js';
import * as iface from './views/interface.js';
import * as live from './views/live.js';
import * as archive from './views/archive.js';
import * as rules from './views/rules.js';

const ROUTES = { overview, investigate, findings, finding, category, device, devices, interface: iface, live, archive, rules };
const NAV = [
  ['overview', '#/', 'home', 'Command Center'],
  ['findings', '#/findings', 'target', 'Findings'],
  ['investigate', '#/investigate', 'list', 'Investigate'],
  ['devices', '#/devices', 'server', 'Devices'],
  ['live', '#/live', 'terminal', 'Live tail'],
  ['sep'],
  ['archive', '#/archive', 'archive', 'Sources & archives'],
  ['rules', '#/rules', 'sliders', 'Rules & parser lab'],
];

let cleanup = null;

function renderNav(active) {
  $('#nav').innerHTML = NAV.map(([id, href, ic, label]) => id === 'sep' ? '<div class="sep"></div>' :
    `<a href="${href}" class="${active === id ? 'active' : ''}" aria-label="${esc(label)}">${icon(ic)}<span class="tip">${esc(label)}</span></a>`).join('');
}

async function route() {
  const { route, arg, params } = parseHash();
  const view = ROUTES[route] || overview;
  const navActive = { finding: 'findings', category: 'overview', device: 'devices', interface: 'devices' }[route] || route;
  renderNav(navActive);
  closeDrawer();
  if (cleanup) { try { cleanup(); } catch (e) { console.error(e); } cleanup = null; }
  const main = $('#main');
  main.scrollTop = 0;
  try {
    cleanup = await view.render(main, { arg, params }) || null;
  } catch (e) {
    console.error(e);
    main.innerHTML = `<div class="page"><div class="card pad">${icon('alert')} <b>Could not load this view.</b><div class="muted mono" style="margin-top:6px">${esc(e.message)}</div></div></div>`;
  }
}

// ---------------------------------------------------------------- theme
function themeIcon() {
  const dark = document.documentElement.dataset.theme === 'dark' ||
    (!document.documentElement.dataset.theme && matchMedia('(prefers-color-scheme: dark)').matches);
  $('#theme').innerHTML = icon(dark ? 'sun' : 'moon');
  return dark;
}
$('#theme').addEventListener('click', () => {
  const dark = themeIcon();
  const next = dark ? 'light' : 'dark';
  document.documentElement.dataset.theme = next;
  try { localStorage.setItem('ns.theme', next); } catch (e) { /* ignore */ }
  themeIcon();
  window.dispatchEvent(new Event('themechange'));
});
themeIcon();

// ---------------------------------------------------------------- search
const q = $('#q'), sug = $('#suggest');
let sugItems = [], sugIdx = -1, sugTimer = null;
const EXAMPLES = [
  'interfaces that flapped 3 times today', 'bgp down', 'what changed last 2h', 'auth failures on cmon200as1101',
  'mac moves', 'unyc787as0705 Te1/1/1', 'critical issues', '845c.315d.dfcf', 'LINK-3-UPDOWN', 'bsao190 power',
];
function showSuggest(items, header) {
  sugItems = items; sugIdx = -1;
  if (!items.length) { sug.classList.add('hidden'); return; }
  sug.innerHTML = (header ? `<div class="hdr">${esc(header)}</div>` : '') + items.map((it, i) =>
    `<div class="sg" data-i="${i}"><span class="k">${esc(it.type)}</span><span>${esc(it.label)}</span><span class="h">${esc(it.hint || '')}</span></div>`).join('');
  sug.classList.remove('hidden');
  sug.querySelectorAll('.sg').forEach(el => el.addEventListener('mousedown', ev => { ev.preventDefault(); pick(sugItems[+el.dataset.i]); }));
}
function pick(it) {
  sug.classList.add('hidden');
  if (it.type === 'device') go(`#/device/${encodeURIComponent(it.value)}`);
  else if (it.type === 'site') go(`#/investigate?site=${encodeURIComponent(it.value)}`);
  else if (it.type === 'code') go(`#/investigate?code=${encodeURIComponent(it.value)}`);
  else if (it.type === 'mac') go(`#/investigate?mac=${encodeURIComponent(it.value)}`);
  else { q.value = it.value; doSearch(it.value); }
  if (it.type !== 'try') q.value = it.label;
  q.blur();
}
q.addEventListener('focus', () => { if (!q.value.trim()) showSuggest(EXAMPLES.map(e => ({ type: 'try', label: e, value: e })), 'Try asking'); });
q.addEventListener('blur', () => setTimeout(() => sug.classList.add('hidden'), 120));
q.addEventListener('input', () => {
  clearTimeout(sugTimer);
  const v = q.value.trim();
  if (!v) return showSuggest(EXAMPLES.map(e => ({ type: 'try', label: e, value: e })), 'Try asking');
  sugTimer = setTimeout(async () => {
    try { const r = await api('/api/suggest?' + qs({ q: v })); showSuggest(r.items, r.items.length ? 'Matches' : ''); } catch (e) { /* ignore */ }
  }, 140);
});
q.addEventListener('keydown', ev => {
  const open = !sug.classList.contains('hidden') && sugItems.length;
  if (ev.key === 'ArrowDown' && open) { sugIdx = Math.min(sugItems.length - 1, sugIdx + 1); mark(); ev.preventDefault(); }
  else if (ev.key === 'ArrowUp' && open) { sugIdx = Math.max(-1, sugIdx - 1); mark(); ev.preventDefault(); }
  else if (ev.key === 'Enter') {
    ev.preventDefault();
    if (open && sugIdx >= 0) pick(sugItems[sugIdx]);
    else { sug.classList.add('hidden'); doSearch(q.value); q.blur(); }
  } else if (ev.key === 'Escape') { sug.classList.add('hidden'); q.blur(); }
});
function mark() { sug.querySelectorAll('.sg').forEach((el, i) => el.classList.toggle('active', i === sugIdx)); }

async function doSearch(text) {
  if (!text.trim()) return;
  const r = await api('/api/search?' + qs({ q: text }));
  state.lastSearch = r;
  const rng = r.range;
  if (rng && ['1h', '6h', '24h', 'today', '3d', '7d'].includes(rng)) state.setRange(rng);
  const rangeQ = rng && !['1h', '6h', '24h', 'today', '3d', '7d'].includes(rng) ? { range: rng } : {};
  if (r.view === 'device') go(`#/device/${encodeURIComponent(r.host)}`);
  else if (r.view === 'interface') go(`#/interface?${qs({ host: r.host, iface: r.iface })}`);
  else if (r.view === 'category') go(`#/category/${r.category}`);
  else if (r.view === 'devices') go('#/devices');
  else if (r.view === 'findings') go(`#/findings?${qs({ type: r.ftype, min_cycles: r.min_cycles, protocol: r.protocol, severity: r.severity, host: r.host, ...rangeQ })}`);
  else go(`#/investigate?${qs({ ...r.filters, ...rangeQ })}`);
}

document.addEventListener('keydown', ev => {
  if (ev.key === '/' && !['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement.tagName)) { ev.preventDefault(); q.focus(); }
  if (ev.key === 'Escape') closeDrawer();
});
$('#scrim').addEventListener('click', closeDrawer);

// ---------------------------------------------------------------- live status
async function pollStatus() {
  try {
    const s = await api('/api/status');
    state.status = s;
    state.serverOffset = s.now - Date.now() / 1000;
    const dot = $('#livedot'), txt = $('#livetxt');
    const loadingJobs = Object.values(s.jobs || {}).filter(j => j.state === 'loading' || j.state === 'queued');
    if (!s.connected) { dot.className = 'dot bad'; txt.textContent = s.last_error ? 'Disconnected – retrying' : 'Connecting…'; }
    else if (s.live.lag_bytes > 2e6 || loadingJobs.length) {
      dot.className = 'dot warn';
      txt.textContent = loadingJobs.length ? `Importing ${loadingJobs.length} archive(s)…` : `Catching up (${(s.live.lag_bytes / 1e6).toFixed(0)} MB)`;
    } else { dot.className = 'dot ok'; txt.textContent = `LIVE · ${s.live.rate.toFixed(1)} msg/s`; }
    $('#live').title = `${s.target || ''}\nlast read ${s.live.last_read ? fmtTime(s.live.last_read) : '—'} · reconnects ${s.reconnects} · rotations ${s.live.rotations}${s.last_error ? '\nlast error: ' + s.last_error : ''}`;
  } catch (e) {
    $('#livedot').className = 'dot bad';
    $('#livetxt').textContent = 'Dashboard offline';
  }
}
$('#live').addEventListener('click', () => go('#/archive'));

// ---------------------------------------------------------------- live stream (SSE)
let lastToast = 0, pendingToast = [];
function startStream() {
  const es = new EventSource('/api/stream');
  es.onmessage = m => {
    let batch;
    try { batch = JSON.parse(m.data); } catch (e) { return; }
    for (const fn of state.listeners) { try { fn(batch); } catch (e) { console.error(e); } }
    const hot = batch.filter(e => e.signal === 'critical' || e.signal === 'major');
    if (hot.length) {
      pendingToast.push(...hot);
      const now = Date.now();
      if (now - lastToast > 8000) {
        lastToast = now;
        const e = pendingToast[pendingToast.length - 1];
        const extra = pendingToast.length > 1 ? ` (+${pendingToast.length - 1} more)` : '';
        toast({ title: `${e.host} %${e.code}${extra}`, msg: e.message, sev: e.signal, onClick: () => openEvent(e.id) });
        pendingToast = [];
      }
    }
  };
}

// ---------------------------------------------------------------- boot
(async function boot() {
  try {
    state.meta = await api('/api/meta');
    state.serverOffset = state.meta.now - Date.now() / 1000;
    if (state.meta.simulated) $('#simpill').classList.remove('hidden');
  } catch (e) { console.error(e); }
  pollStatus();
  setInterval(pollStatus, 5000);
  startStream();
  window.addEventListener('hashchange', route);
  route();
})();
