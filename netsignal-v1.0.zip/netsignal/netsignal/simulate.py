"""SIMULATED Cisco syslog generator (demo mode).

Produces files laid out exactly like the production CISCO directory:
    log               - active file (keeps growing while the app runs)
    logYYYYMMDD.gz    - previous days

Formats copy the real server output (receive time + FQDN + device timestamp):
  IOS-XE: Oct 19 15:44:47 unyc787as0705.us.net.intra Oct 19 2026 15:44:46.647 EDST: %LINK-3-UPDOWN: ...
  NX-OS:  Oct 19 15:50:32 usec755sf0160.us.net.intra 2026 Oct 19 15:50:32.921215 EDST: %L2FM-4-...

All hostnames/patterns are modelled on screenshots of the real server, but every
event is synthetic. Scripted incident scenarios exercise the intelligence engine.
"""
from __future__ import annotations

import gzip
import os
import random
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path

from .timeutil import from_wall, now_wall, to_wall, now_dt

MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
TZ = "EDST"

# host -> (domain, os, members)
HOSTS = {
    # access switches (Catalyst 9200/9300, IOS-XE)
    "unyc787as0705": ("us", "xe", 2), "unyc787as0703": ("us", "xe", 2), "unyc787as0702": ("us", "xe", 5),
    "unyc787as0804": ("us", "xe", 4), "unyc787vs0202": ("us", "xe", 1), "unyc012as3001": ("us", "xe", 4),
    "bsao190as0901": ("br", "xe", 1), "bsao190as0802": ("br", "xe", 4), "bsao190as1002": ("br", "xe", 1),
    "bsao190as0902": ("br", "xe", 4), "bsao190as1101": ("br", "xe", 1), "bsao222as0201": ("br", "xe", 2),
    "cmon200as1901": ("us", "xe", 2), "cmon200as0901": ("us", "xe", 1), "cmon200as0401": ("us", "xe", 3),
    "cmon200as1402": ("us", "xe", 2), "cmon200as1101": ("us", "xe", 2),
    "mmex340as0201": ("us", "xe", 4), "mmex453as1001": ("us", "xe", 2), "mmex453as0101": ("us", "xe", 1),
    "mmex453as1101": ("us", "xe", 3),
    "ujcn525as0802": ("us", "xe", 1), "ujcn525as0702": ("us", "xe", 1), "ujcn525as0804": ("us", "xe", 1),
    "ujcn525as0601": ("us", "xe", 4), "ujcn525as0402": ("us", "xe", 6),
    "cbog766as0601": ("co", "xe", 1), "cbog766as1001": ("co", "xe", 2),
    "plim380as1101": ("pe", "xe", 1), "uchi155as0901": ("us", "xe", 1), "csan267as1401": ("us", "xe", 2),
    # distribution / routers / voice (IOS-XE)
    "unyc787dl0101": ("us", "xe-core", 1), "bsao190dl0101": ("br", "xe-core", 1),
    "unyc787rt0101": ("us", "xe-rtr", 1), "bsao190vg1101": ("br", "xe-rtr", 1),
    # Nexus (NX-OS)
    "usec755sf0160": ("us", "nx", 1), "usec755sf0161": ("us", "nx", 1), "unwk165sf0263": ("us", "nx", 1),
    "usec800dl0109": ("us", "nx", 1), "unwk165dl0209": ("us", "nx", 1), "bsan249sf0209": ("br", "nx", 1),
}
ACCESS = [h for h, v in HOSTS.items() if v[1] == "xe" and "as" in h[7:9]]
NEXUS = [h for h, v in HOSTS.items() if v[1] == "nx"]
USERS = ["jsmith", "mgarcia", "netops", "akhan", "lchen"]


class Gen:
    def __init__(self, seed: int = 7):
        self.r = random.Random(seed)
        self.out: list[tuple[float, str]] = []
        self.skew = {"csan267as1401": -197.0}  # device clock ~3 min behind (NTP problem)

    # ---------------------------------------------------------------- formatting
    def line(self, t: float, host: str, code: str, msg: str):
        dom, os_, _ = HOSTS[host]
        r = self.r
        dev = t + self.skew.get(host, 0.0)
        rx = t + r.uniform(0.05, 1.1)
        d, x = from_wall(dev), from_wall(rx)
        rx_s = f"{MON[x.month - 1]} {x.day:2d} {x:%H:%M:%S}"
        fq = f"{host}.{dom}.net.intra"
        if os_ == "nx":
            dev_s = f"{d.year} {MON[d.month - 1]} {d.day:02d} {d:%H:%M:%S}.{d.microsecond:06d} {TZ}"
        else:
            dev_s = f"{MON[d.month - 1]} {d.day:2d} {d.year} {d:%H:%M:%S}.{d.microsecond // 1000:03d} {TZ}"
        self.out.append((rx, f"{rx_s} {fq} {dev_s}: %{code}: {msg}"))

    def xe_prefix(self, host):
        return "Switch 1 R0/0: " if HOSTS[host][1] == "xe" else ""

    def mac(self):
        r = self.r
        pre = r.choice(["a8b1.3b", "845c.31", "c85a.cf", "0018.1c", "2c58.b9", "706b.b9", "f87b.20",
                        "0024.9b", "4ccc.6a", "0029.c2", "1865.71", "001b.0c"])
        return f"{pre}{r.randrange(16):x}{r.randrange(16):x}.{r.randrange(65536):04x}"

    def edge_port(self, host, short=False):
        members = HOSTS[host][2]
        sw = self.r.randint(1, members)
        p = self.r.randint(1, 48)
        return f"{'Gi' if short else 'GigabitEthernet'}{sw}/0/{p}"

    def sess(self):
        return "".join(self.r.choice("0123456789ABCDEF") for _ in range(24))

    # ---------------------------------------------------------------- primitives
    def link(self, t, host, iface, state, proto_delay=0.9, link=True):
        if HOSTS[host][1] == "nx":
            if state == "down":
                self.line(t, host, "ETHPORT-5-IF_DOWN_LINK_FAILURE", f"Interface {iface} is down (Link failure)")
            else:
                self.line(t, host, "ETHPORT-5-SPEED", f"Interface {iface}, operational speed changed to 10 Gbps")
                self.line(t + 0.01, host, "ETHPORT-5-IF_UP", f"Interface {iface} is up in mode trunk")
            return
        if link:
            self.line(t, host, "LINK-3-UPDOWN", f"Interface {iface}, changed state to {state}")
        self.line(t + proto_delay, host, "LINEPROTO-5-UPDOWN",
                  f"Line protocol on Interface {iface}, changed state to {state}")

    def auth_ok(self, t, host, method="DOT1X", iface=None, mac=None, user=None):
        iface = iface or self.edge_port(host, short=True)
        mac = mac or self.mac()
        user = user or self.r.choice([f"host/NYCM000{self.r.randint(20000, 29999)}.amer.net.intra",
                                      f"host/SAOM000{self.r.randint(20000, 29999)}.amer.net.intra",
                                      f"CP-8851-SEP{mac.replace('.', '').upper()}"])
        tail = f" Username {user}" if method == "DOT1X" else ""
        self.line(t, host, f"{method}-5-SUCCESS",
                  f"{self.xe_prefix(host)}sessmgrd: Authentication successful for client ({mac}) on Interface "
                  f"{iface} AuditSessionID {self.sess()}{tail}")

    def auth_fail(self, t, host, method, iface, mac, reason):
        self.line(t, host, f"{method}-5-FAIL",
                  f"{self.xe_prefix(host)}sessmgrd: Authentication failed for client ({mac}) with reason ({reason}) "
                  f"on Interface {iface} AuditSessionID {self.sess()}")

    # ---------------------------------------------------------------- background
    def background(self, t0: float, t1: float, per_day: int):
        r = self.r
        dur = t1 - t0
        n = int(per_day * dur / 86400)
        for _ in range(n):
            t = t0 + r.random() * dur
            hour = from_wall(t).hour
            if not (7 <= hour <= 19) and r.random() < 0.55:
                continue  # quieter at night
            self.one_background(t)

    def one_background(self, t: float):
        r = self.r
        x = r.random()
        host = r.choice(ACCESS)
        if x < 0.34:  # access port bounce (PC sleep / phone reboot)
            iface = self.edge_port(host)
            if r.random() < 0.5:
                self.link(t, host, iface, "down")
                self.link(t + r.uniform(3, 900), host, iface, "up")
            else:
                self.link(t, host, iface, "up")
        elif x < 0.58:
            self.auth_ok(t, host, "DOT1X")
        elif x < 0.66:  # expected fallback: 802.1X no response -> MAB success
            iface, mac = self.edge_port(host, True), self.mac()
            self.auth_fail(t, host, "DOT1X", iface, mac, "No Response from Client")
            self.auth_ok(t + r.uniform(0.01, 0.05), host, "MAB", iface, mac)
        elif x < 0.73:
            sw = r.randint(1, HOSTS[host][2])
            self.line(t, host, "ILPOWER-6-SET_AVAILABLE_ILPOWER",
                      f"Available POE budget for switch {sw} is updated. New available POE budget = "
                      f"{r.uniform(900, 1250):.1f} Watts")
        elif x < 0.77:
            p = self.edge_port(host, short=True).replace("Gi", "Gi")
            if r.random() < 0.5:
                self.line(t, host, "ILPOWER-5-DETECT", f"Interface {p}: Power Device detected: "
                          f"{r.choice(['Cisco PD', 'IEEE PD'])}")
            else:
                self.line(t, host, "ILPOWER-5-IEEE_DISCONNECT", f"Interface {p}: PD removed")
        elif x < 0.81:  # voice gateway calls
            se = f"Serial0/2/{r.choice([1, 2])}:{r.randint(1, 23)}"
            num = r.choice(["5513100", "5513101", "5521000", "5593012"])
            self.line(t, "bsao190vg1101", "ISDN-6-CONNECT",
                      f"Interface {se} is now connected to {num} {r.randint(5500000, 5599999)} "
                      f"{r.choice(['Receptionist SPCT', 'N/A', 'Conference Room', 'Sales Desk'])}")
            self.line(t + r.uniform(20, 600), "bsao190vg1101", "ISDN-6-DISCONNECT",
                      f"Interface {se}  disconnected from {num} , call lasted {r.randint(20, 600)} seconds")
        elif x < 0.84:  # single vMotion-style MAC move (normal)
            h = r.choice(NEXUS)
            self.line(t, h, "L2FM-4-L2FM_MAC_MOVE2",
                      f"Mac 0050.56{r.randrange(256):02x}.{r.randrange(65536):04x} in vlan {r.choice([507, 510, 220])} "
                      f"has moved from Po{r.randint(1, 12)} to Eth1/{r.randint(1, 48)}")
        elif x < 0.843:  # NX-OS server port bounce (rare)
            h = r.choice(NEXUS)
            ifc = f"Ethernet1/{r.randint(1, 48)}"
            self.link(t, h, ifc, "down")
            self.link(t + r.uniform(5, 300), h, ifc, "up")
        elif x < 0.846:
            u = r.choice(USERS)
            self.line(t, host, "SYS-5-CONFIG_I", f"Configured from console by {u} on vty0 (10.20.{r.randint(1, 9)}.{r.randint(10, 99)})")
        elif x < 0.86:
            self.line(t, host, "SEC_LOGIN-5-LOGIN_SUCCESS",
                      f"Login Success [user: {r.choice(USERS)}] [Source: 10.20.1.{r.randint(10, 60)}] [localport: 22] at {from_wall(t):%H:%M:%S} {TZ} {from_wall(t):%a %b %d %Y}")
        elif x < 0.87:
            self.line(t, host, "SPANTREE-5-TOPOTRAP", f"Topology Change Trap for vlan {r.choice([10, 20, 100, 200])}")
        else:  # extra auth successes (dominant routine volume)
            self.auth_ok(t, host, r.choice(["DOT1X", "MAB"]))

    # ---------------------------------------------------------------- scenarios
    def scenarios(self, now: float, t_start: float):
        r = self.r
        H = 3600

        def at(offset):  # seconds before now
            return now - offset

        # A. Uplink flapping on an access switch + far-end optic warning
        base = at(3 * H)
        for i in range(6):
            t = base + i * r.uniform(120, 300)
            self.link(t, "unyc787as0705", "TenGigabitEthernet1/1/1", "down")
            self.line(t + 0.4, "unyc787dl0101", "LINK-3-UPDOWN", "Interface TenGigabitEthernet1/0/5, changed state to down")
            self.line(t + 1.2, "unyc787dl0101", "LINEPROTO-5-UPDOWN", "Line protocol on Interface TenGigabitEthernet1/0/5, changed state to down")
            self.line(t + 1.1, "unyc787as0705", "EC-5-UNBUNDLE", "Interface TenGigabitEthernet1/1/1 left the port-channel Port-channel1")
            up = t + r.uniform(6, 40)
            self.link(up, "unyc787as0705", "TenGigabitEthernet1/1/1", "up")
            self.line(up + 0.5, "unyc787dl0101", "LINK-3-UPDOWN", "Interface TenGigabitEthernet1/0/5, changed state to up")
            self.line(up + 2.5, "unyc787as0705", "EC-5-BUNDLE", "Interface TenGigabitEthernet1/1/1 joined port-channel Port-channel1")
        for k in range(5):
            self.line(base - 1800 + k * 1500, "unyc787dl0101", "SFF8472-5-THRESHOLD_VIOLATION",
                      f"Te1/0/5: Rx power low warning; Operating value: {-13.2 - r.random():.1f} dBm, Threshold value: -13.0 dBm.")

        # B. WAN router: link loss -> OSPF + BGP down, recovered; second BGP peer down after a config change
        t = at(5 * H + 600)
        self.line(t, "unyc787rt0101", "LINK-3-UPDOWN", "Interface GigabitEthernet0/0/1, changed state to down")
        self.line(t + 0.1, "unyc787rt0101", "LINEPROTO-5-UPDOWN", "Line protocol on Interface GigabitEthernet0/0/1, changed state to down")
        self.line(t + 0.15, "unyc787rt0101", "OSPF-5-ADJCHG", "Process 1, Nbr 10.255.1.2 on GigabitEthernet0/0/1 from FULL to DOWN, Neighbor Down: Interface down or detached")
        self.line(t + 0.3, "unyc787dl0101", "OSPF-5-ADJCHG", "Process 1, Nbr 10.255.1.1 on TenGigabitEthernet1/0/1 from FULL to DOWN, Neighbor Down: Dead timer expired")
        self.line(t + 172, "unyc787rt0101", "BGP-3-NOTIFICATION", "sent to neighbor 172.16.250.1 4/0 (hold time expired) 0 bytes")
        self.line(t + 172.1, "unyc787rt0101", "BGP-5-NBR_RESET", "Neighbor 172.16.250.1 reset (BGP Notification sent)")
        self.line(t + 172.2, "unyc787rt0101", "BGP-5-ADJCHANGE", "neighbor 172.16.250.1 Down BGP Notification sent")
        u = t + 260
        self.line(u, "unyc787rt0101", "LINK-3-UPDOWN", "Interface GigabitEthernet0/0/1, changed state to up")
        self.line(u + 1, "unyc787rt0101", "LINEPROTO-5-UPDOWN", "Line protocol on Interface GigabitEthernet0/0/1, changed state to up")
        self.line(u + 38, "unyc787rt0101", "OSPF-5-ADJCHG", "Process 1, Nbr 10.255.1.2 on GigabitEthernet0/0/1 from LOADING to FULL, Loading Done")
        self.line(u + 38.4, "unyc787dl0101", "OSPF-5-ADJCHG", "Process 1, Nbr 10.255.1.1 on TenGigabitEthernet1/0/1 from LOADING to FULL, Loading Done")
        self.line(u + 61, "unyc787rt0101", "BGP-5-ADJCHANGE", "neighbor 172.16.250.1 Up")
        c = at(46 * 60)
        self.line(c, "unyc787rt0101", "SYS-5-CONFIG_I", "Configured from console by akhan on vty0 (10.20.4.31)")
        self.line(c + 380, "unyc787rt0101", "BGP-5-ADJCHANGE", "neighbor 172.16.250.9 vpn vrf GUEST Down Peer closed the session")
        self.line(c + 380.2, "unyc787rt0101", "BGP-3-NOTIFICATION", "received from neighbor 172.16.250.9 6/4 (Administrative Reset) 0 bytes")

        # C. PoE device boot-looping (from screenshots: mmex340as0201 Gi4/0/41)
        t = max(t_start, at(26 * H))
        while t < now:
            self.line(t, "mmex340as0201", "ILPOWER-5-DETECT", "Interface Gi4/0/41: Power Device detected: Cisco PD")
            self.line(t + 4.9, "mmex340as0201", "ILPOWER-3-CONTROLLER_PORT_ERR",
                      "Controller port error, Interface Gi4/0/41: Power Controller reports power Tstart error detected")
            self.line(t + 5.0, "mmex340as0201", "ILPOWER-5-IEEE_DISCONNECT", "Interface Gi4/0/41: PD removed")
            self.line(t + 5.1, "mmex340as0201", "ILPOWER-6-SET_AVAILABLE_ILPOWER",
                      "Available POE budget for switch 4 is updated. New available POE budget = 1189.5 Watts")
            t += r.uniform(240, 600)

        # D. MAC move storm across the data-centre fabric (0050.568d.51fb vlan 507)
        t = at(50 * 60)
        path = [("usec755sf0160", "Po2", "Eth1/38"), ("unwk165sf0263", "Eth1/22", "Po2"),
                ("usec800dl0109", "Po10", "Po5"), ("unwk165dl0209", "Po6", "Po10")]
        for i in range(28):
            h, a, b = path[i % 4]
            if i % 8 >= 4:
                a, b = b, a
            self.line(t + i * r.uniform(3, 8), h, "L2FM-4-L2FM_MAC_MOVE2", f"Mac 0050.568d.51fb in vlan 507 has moved from {a} to {b}")

        # E. Nexus buffer threshold (microbursts) with NX-OS repeat suffix
        for k in range(14):
            t = at(r.uniform(0, 30 * H))
            rep = r.choice(["", "", " (message repeated 3 times)", " (message repeated 2 times)"])
            self.line(t, "bsan249sf0209", "TAHUSD-SLOT1-4-BUFFER_THRESHOLD_EXCEEDED",
                      "Module 1 Instance 1 Pool-group buffer 90 percent threshold is exceeded! Please see "
                      "http://cisco.com/go/n9k-tahusd-buffer for more information" + rep)

        # F. Site-wide event at bsao190: distribution PSU failure + uplinks on 5 access switches + PRI down
        t = at(7 * H + 1234)
        self.line(t - 2, "bsao190dl0101", "IOSXE_PEM-3-PEMFAIL", "The PEM in slot P1 is switched off or encountering a failure condition.")
        for i, h in enumerate(["bsao190as0901", "bsao190as0802", "bsao190as1002", "bsao190as0902", "bsao190as1101"]):
            tt = t + i * r.uniform(1, 4)
            self.link(tt, h, "TenGigabitEthernet1/1/1", "down")
            self.line(tt + 0.2, h, "LINK-3-UPDOWN", "Interface Port-channel1, changed state to down")
            self.line(tt + 1.0, h, "LINEPROTO-5-UPDOWN", "Line protocol on Interface Port-channel1, changed state to down")
            up = t + 190 + i * r.uniform(1, 5)
            self.link(up, h, "TenGigabitEthernet1/1/1", "up")
            self.line(up + 0.3, h, "LINK-3-UPDOWN", "Interface Port-channel1, changed state to up")
            self.line(up + 1.3, h, "LINEPROTO-5-UPDOWN", "Line protocol on Interface Port-channel1, changed state to up")
        self.line(t + 3, "bsao190vg1101", "ISDN-6-LAYER2DOWN", "Layer 2 for Interface Se0/2/2:15, TEI 0 changed to down")
        self.line(t + 205, "bsao190vg1101", "ISDN-6-LAYER2UP", "Layer 2 for Interface Se0/2/2:15, TEI 0 changed to up")

        # G. Nexus PSU failure (no recovery)
        self.line(at(2 * H + 777), "usec755sf0161", "PLATFORM-2-PS_FAIL", "Power supply 2 failed or shut down (Serial number LIT2345ABCD)")

        # H. BPDU guard + link-flap err-disable on access ports
        t = at(9 * H)
        self.line(t, "cbog766as1001", "SPANTREE-2-BLOCK_BPDUGUARD", "Received BPDU on port Gi2/0/14 with BPDU Guard enabled. Disabling port.")
        self.line(t + 0.01, "cbog766as1001", "PM-4-ERR_DISABLE", "bpduguard error detected on Gi2/0/14, putting Gi2/0/14 in err-disable state")
        self.link(t + 0.02, "cbog766as1001", "GigabitEthernet2/0/14", "down")
        t = at(4 * H)
        for i in range(7):
            self.link(t + i * 9, "plim380as1101", "GigabitEthernet1/0/22", "down")
            self.link(t + i * 9 + 4, "plim380as1101", "GigabitEthernet1/0/22", "up")
        self.line(t + 66, "plim380as1101", "PM-4-ERR_DISABLE", "link-flap error detected on Gi1/0/22, putting Gi1/0/22 in err-disable state")
        self.link(t + 66.01, "plim380as1101", "GigabitEthernet1/0/22", "down")

        # I. Nexus optic Rx low on a fabric uplink
        for k in range(6):
            self.line(at(r.uniform(0.5 * H, 20 * H)), "unwk165dl0209", "ETHPORT-3-IF_SFP_WARNING",
                      "Interface Ethernet1/49, Low Rx Power Warning")
        self.line(at(1.5 * H), "unwk165dl0209", "ETHPORT-3-IF_SFP_ALARM", "Interface Ethernet1/49, Low Rx Power Alarm")

        # J. Persistent unauthorised endpoint + RADIUS outage
        t = max(t_start, at(10 * H))
        while t < now:
            self.auth_fail(t, "cmon200as1101", "DOT1X", "Gi2/0/37", "845c.315d.dfcf", "No Response from Client")
            self.auth_fail(t + 0.02, "cmon200as1101", "MAB", "Gi2/0/37", "845c.315d.dfcf", "Cred Fail")
            t += r.uniform(300, 900)
        t = at(9 * H + 1500)
        self.line(t, "ujcn525as0804", "RADIUS-4-RADIUS_DEAD", "RADIUS server 10.20.30.41:1812,1813 is not responding.")
        for i in range(12):
            h = r.choice(["ujcn525as0804", "ujcn525as0802", "ujcn525as0702"])
            p, m = self.edge_port(h, True), self.mac()
            self.auth_fail(t + 5 + i * 25, h, "DOT1X", p, m, "No Response from Client")
            self.auth_fail(t + 5.05 + i * 25, h, "MAB", p, m, "AAA Server Down")
        self.line(t + 380, "ujcn525as0804", "RADIUS-4-RADIUS_ALIVE", "RADIUS server 10.20.30.41:1812,1813 is being marked alive.")

        # L. Stack cable instability
        t = at(6 * H)
        for i in range(3):
            tt = t + i * r.uniform(600, 1800)
            self.line(tt, "mmex453as1001", "STACKMGR-4-STACK_LINK_CHANGE", "Switch 2 R0/0: stack_mgr: Stack port 1 on Switch 2 is down")
            self.line(tt + r.uniform(20, 90), "mmex453as1001", "STACKMGR-4-STACK_LINK_CHANGE", "Switch 2 R0/0: stack_mgr: Stack port 1 on Switch 2 is up")

        # M. Repeated login failures
        t = at(12 * H)
        for i in range(9):
            self.line(t + i * r.uniform(5, 30), "cbog766as0601", "SEC_LOGIN-4-LOGIN_FAILED",
                      f"Login failed [user: admin] [Source: 10.44.12.9] [localport: 22] [Reason: Login Authentication Failed] at {from_wall(t):%H:%M:%S} {TZ} {from_wall(t):%a %b %d %Y}")

        # N. Device reload
        t = at(20 * H)
        self.line(t, "ujcn525as0402", "SYS-5-RELOAD", "Reload requested by lchen on vty0 (10.20.4.12). Reload Reason: Reload Command.")
        self.line(t + 420, "ujcn525as0402", "SYS-5-RESTART", "System restarted --")
        for p in range(1, 15):
            self.link(t + 450 + p * 0.3, "ujcn525as0402", f"GigabitEthernet1/0/{p}", "up")

        # O. Edge port flapping (bad patch cable)
        t = at(2 * H)
        for i in range(9):
            tt = t + i * r.uniform(60, 400)
            self.link(tt, "unyc787as0703", "GigabitEthernet2/0/26", "down")
            self.link(tt + r.uniform(2, 20), "unyc787as0703", "GigabitEthernet2/0/26", "up")

        # P. Rare / unclassified messages
        self.line(at(1 * H + 300), "unyc012as3001", "PKI-3-CERTIFICATE_INVALID_EXPIRED",
                  "Certificate chain validation has failed. The certificate (SN: 4A2B9C) has expired.")
        self.line(at(3 * H + 100), "uchi155as0901", "SMART_LIC-3-AUTH_RENEW_FAILED",
                  "Authorization renewal with the Cisco Smart Software Manager (CSSM) : No Response from server")
        self.line(at(8 * H), "unyc787dl0101", "HSRP-5-STATECHANGE", "Vlan100 Grp 100 state Standby -> Active")
        self.line(at(8 * H) + 1, "unyc787dl0101", "CDP-4-NATIVE_VLAN_MISMATCH",
                  "Native VLAN mismatch discovered on TenGigabitEthernet1/0/7 (1), with unyc787as0804 TenGigabitEthernet1/1/1 (99).")

    # ---------------------------------------------------------------- history
    def history_scenarios(self, day_start: float):
        r = self.r
        # recurring problems on previous days (supports "recurring" detection)
        t = day_start + 10 * 3600
        for i in range(4):
            self.link(t + i * 200, "unyc787as0705", "TenGigabitEthernet1/1/1", "down")
            self.link(t + i * 200 + 15, "unyc787as0705", "TenGigabitEthernet1/1/1", "up")
        for k in range(8):
            self.line(day_start + r.uniform(0, 86000), "bsan249sf0209", "TAHUSD-SLOT1-4-BUFFER_THRESHOLD_EXCEEDED",
                      "Module 1 Instance 1 Pool-group buffer 90 percent threshold is exceeded! Please see "
                      "http://cisco.com/go/n9k-tahusd-buffer for more information")
        self.line(day_start + 15 * 3600, "usec755sf0161", "PLATFORM-2-PS_FAIL", "Power supply 2 failed or shut down (Serial number LIT2345ABCD)")
        self.line(day_start + 15 * 3600 + 900, "usec755sf0161", "PLATFORM-2-PS_OK", "Power supply 2 ok (Serial number LIT2345ABCD)")


def _day_name(ts: float) -> str:
    return from_wall(ts).strftime("%Y%m%d")


def generate(directory: str, history_days: int = 2, per_day: int = 24000, seed: int = 7) -> dict:
    """(Re)create the simulated CISCO directory relative to the current time."""
    d = Path(directory)
    d.mkdir(parents=True, exist_ok=True)
    for f in d.glob("log*"):
        f.unlink()
    now = now_wall()
    today0 = now - (now % 86400)
    start = today0 - history_days * 86400
    g = Gen(seed)
    g.background(start, now, per_day)
    g.scenarios(now, start)
    for i in range(1, history_days + 1):
        g.history_scenarios(today0 - i * 86400)
    g.out = [o for o in g.out if start <= o[0] <= now]
    g.out.sort(key=lambda o: o[0])
    by_day: dict[str, list[str]] = {}
    for rx, line in g.out:
        by_day.setdefault(_day_name(rx), []).append(line)
    today = _day_name(now)
    counts = {}
    for day, lines in by_day.items():
        if day == today:
            (d / "log").write_text("\n".join(lines) + "\n", encoding="utf-8")
            counts["log"] = len(lines)
        else:
            with gzip.open(d / f"log{day}.gz", "wt", encoding="utf-8") as f:
                f.write("\n".join(lines) + "\n")
            counts[f"log{day}.gz"] = len(lines)
    if not (d / "log").exists():
        (d / "log").write_text("", encoding="utf-8")
    (d / "README_SIMULATED.txt").write_text(
        "All files in this directory are SIMULATED Cisco syslog data generated by NetSignal demo mode.\n",
        encoding="utf-8")
    return counts


class LiveWriter(threading.Thread):
    """Appends simulated lines to the live `log` file and rotates it at midnight."""

    def __init__(self, directory: str, rate: float = 2.0, seed: int = 11):
        super().__init__(daemon=True, name="sim-live")
        self.dir = Path(directory)
        self.rate = max(0.1, rate)
        self.g = Gen(seed)
        self.stop_ev = threading.Event()
        self.day = _day_name(now_wall())
        self.next_poe = now_wall() + 60
        self.next_incident = now_wall() + 90
        self.pending: list[tuple[float, str]] = []

    def run(self):
        while not self.stop_ev.is_set():
            now = now_wall()
            if _day_name(now) != self.day:
                self.rotate()
            g = self.g
            g.out = []
            n = max(1, int(self.rate * random.uniform(0.6, 1.4)))
            for _ in range(n):
                g.one_background(now - random.uniform(0, 0.9))
            if now >= self.next_poe:  # the PoE boot loop keeps going
                g.line(now, "mmex340as0201", "ILPOWER-5-DETECT", "Interface Gi4/0/41: Power Device detected: Cisco PD")
                g.line(now + 0.2, "mmex340as0201", "ILPOWER-3-CONTROLLER_PORT_ERR",
                       "Controller port error, Interface Gi4/0/41: Power Controller reports power Tstart error detected")
                g.line(now + 0.3, "mmex340as0201", "ILPOWER-5-IEEE_DISCONNECT", "Interface Gi4/0/41: PD removed")
                self.next_poe = now + random.uniform(240, 480)
            if now >= self.next_incident:
                self.incident(now)
                self.next_incident = now + random.uniform(120, 300)
            self.pending.extend(g.out)
            self.pending.sort(key=lambda o: o[0])
            due = [o for o in self.pending if o[0] <= now + 1.0]
            self.pending = [o for o in self.pending if o[0] > now + 1.0]
            lines = [l for _, l in due]
            if lines:
                with open(self.dir / "log", "a", encoding="utf-8") as f:
                    f.write("\n".join(lines) + "\n")
            self.stop_ev.wait(1.0)

    def incident(self, now: float):
        g, r = self.g, random
        k = r.random()
        if k < 0.35:  # edge port bounce several times
            h = r.choice(ACCESS)
            p = g.edge_port(h)
            g.link(now, h, p, "down")
            g.link(now + 0.8, h, p, "up")
        elif k < 0.55:  # uplink bounce on unyc787as0705 (keeps the flap story alive)
            g.link(now, "unyc787as0705", "TenGigabitEthernet1/1/1", "down")
            g.link(now + 0.8, "unyc787as0705", "TenGigabitEthernet1/1/1", "up")
        elif k < 0.75:
            g.auth_fail(now, "cmon200as1101", "DOT1X", "Gi2/0/37", "845c.315d.dfcf", "No Response from Client")
            g.auth_fail(now + 0.02, "cmon200as1101", "MAB", "Gi2/0/37", "845c.315d.dfcf", "Cred Fail")
        elif k < 0.9:
            g.line(now, "bsan249sf0209", "TAHUSD-SLOT1-4-BUFFER_THRESHOLD_EXCEEDED",
                   "Module 1 Instance 1 Pool-group buffer 90 percent threshold is exceeded! Please see "
                   "http://cisco.com/go/n9k-tahusd-buffer for more information")
        else:
            g.line(now, "unwk165dl0209", "ETHPORT-3-IF_SFP_WARNING", "Interface Ethernet1/49, Low Rx Power Warning")

    def rotate(self):
        """Mimic logrotate: move `log` to logYYYYMMDD.gz and start a new empty file."""
        src = self.dir / "log"
        tmp = self.dir / f"log.rotating"
        if src.exists():
            os.replace(src, tmp)
            src.write_text("", encoding="utf-8")
            with open(tmp, "rb") as fi, gzip.open(self.dir / f"log{self.day}.gz", "wb") as fo:
                fo.write(fi.read())
            tmp.unlink()
        self.day = _day_name(now_wall())


if __name__ == "__main__":  # pragma: no cover
    import sys
    print(generate(sys.argv[1] if len(sys.argv) > 1 else "sample_data/CISCO"))
