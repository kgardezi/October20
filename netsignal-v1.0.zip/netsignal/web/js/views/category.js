// Category investigation: findings, playbook, category-specific intelligence, evidence explorer.
import { esc, icon, api, n, fmtShort, shortIf, loading, emptyState, sevBadge } from '../util.js';
import { state, go } from '../state.js';
import { rangeSeg, bindRange, findingList, bindFindings, cmdLine } from '../components.js';
import { explorer } from './investigate.js';
import { hbars } from '../charts.js';

export async function render(main, { arg }) {
  main.innerHTML = `<div class="page">${loading()}</div>`;
  const d = await api(`/api/category/${encodeURIComponent(arg)}?range=${state.range}`);
  const c = d.category, now = state.now();
  const ex = d.extra || {};
  let extraHtml = '';
  if (ex.auth) {
    const a = ex.auth;
    extraHtml += `<div class="card c6"><div class="hd"><h3>802.1X / MAB outcome analysis</h3></div><div class="bd">
      <div class="statgrid"><div class="stat"><div class="l">Failure messages</div><div class="v num">${n(a.fail_events)}</div></div>
      <div class="stat"><div class="l">Resolved by fallback</div><div class="v num" style="color:var(--good-text)">${n(a.resolved_by_fallback)}</div></div>
      <div class="stat"><div class="l">Unresolved</div><div class="v num">${n(a.unresolved)}</div></div></div>
      <p class="note">A DOT1X failure followed by a successful MAB (or 802.1X) authentication for the same MAC within 120 s is the normal flow for devices without a supplicant (printers, phones, cameras) and is not counted as a problem.</p>
      ${ex.reasons?.length ? hbars(ex.reasons.map(r => ({ label: r.reason || '(none)', value: r.n })), { color: 'var(--s-warning)' }) : ''}</div></div>`;
  }
  if (ex.neighbors) {
    extraHtml += `<div class="card c6"><div class="hd"><h3>Routing adjacencies seen</h3></div><div class="bd scroll" style="max-height:320px">
      ${ex.neighbors.length ? `<table class="tbl"><thead><tr><th>Device</th><th>Proto</th><th>Neighbor</th><th class="r">Downs</th><th class="r">Ups</th><th>Last</th></tr></thead><tbody>
      ${ex.neighbors.map(r => `<tr class="click" data-href="#/investigate?host=${esc(r.host)}&neighbor=${esc(r.neighbor)}"><td>${esc(r.host)}</td><td>${esc(r.protocol)}</td><td class="mono">${esc(r.neighbor)}</td>
        <td class="r num">${r.downs ? `<b style="color:var(--s-critical)">${r.downs}</b>` : 0}</td><td class="r num">${r.ups}</td><td class="muted">${esc(fmtShort(r.last, now))}</td></tr>`).join('')}</tbody></table>` : '<div class="muted">No adjacency changes logged.</div>'}</div></div>`;
  }
  if (ex.poe_budget) {
    extraHtml += `<div class="card c6"><div class="hd"><h3>Lowest available PoE budget</h3><span class="muted" style="font-size:12px">from SET_AVAILABLE_ILPOWER updates</span></div><div class="bd">
      ${ex.poe_budget.length ? `<table class="tbl"><thead><tr><th>Device</th><th>Member</th><th class="r">Min W</th><th class="r">Max W</th><th class="r">Updates</th></tr></thead><tbody>
      ${ex.poe_budget.map(r => `<tr><td>${esc(r.host)}</td><td>${esc(r.sw)}</td><td class="r num">${(r.lo ?? 0).toFixed(1)}</td><td class="r num">${(r.hi ?? 0).toFixed(1)}</td><td class="r num">${n(r.n)}</td></tr>`).join('')}</tbody></table>` : '<div class="muted">No budget updates.</div>'}</div></div>`;
  }

  main.innerHTML = `<div class="page">
    <div class="crumb"><a href="#/">Command Center</a> / ${esc(c.name)}</div>
    <div class="ph"><div style="display:flex;gap:12px;align-items:center"><div class="cat" style="padding:0;box-shadow:none;border:0;background:none"><div class="ic" style="width:42px;height:42px">${icon(c.icon, 'lg')}</div></div>
      <div><h1>${esc(c.name)}</h1><div class="sub">${esc(c.description)}</div></div></div><div class="grow"></div>${rangeSeg()}</div>
    <div class="grid">
      <div class="card c8"><div class="hd"><h3>Findings in this category</h3><span class="grow"></span><span class="muted">${d.findings.length}</span></div>
        <div class="bd" style="padding:6px 0 4px" id="fl">${findingList(d.findings, now, 'No findings in this category for the selected window')}</div></div>
      <div class="card c4 playbook"><div class="hd"><h3>${icon('terminal', 'sm')} Troubleshooting playbook</h3></div><div class="bd">
        <ol>${(c.playbook || []).map(s => `<li>${esc(s)}</li>`).join('')}</ol></div></div>
      ${extraHtml}
      <div class="card c6"><div class="hd"><h3>Event codes</h3></div><div class="bd scroll" style="max-height:340px">
        ${d.codes.length ? `<table class="tbl"><thead><tr><th>Code</th><th>Rating</th><th class="r">Messages</th><th class="r">Devices</th><th>Last</th></tr></thead><tbody>
        ${d.codes.map(r => `<tr class="click" data-href="#/investigate?category=${esc(c.id)}&code=${esc(r.code)}&signal=${esc(r.signal)}"><td><span class="code">${esc(r.code)}</span></td><td>${sevBadge(r.signal)}</td>
          <td class="r num">${n(r.n)}</td><td class="r num">${n(r.d)}</td><td class="muted">${esc(fmtShort(r.last, now))}</td></tr>`).join('')}</tbody></table>` : emptyState('No messages')}</div></div>
      <div class="card c6"><div class="hd"><h3>Most active interfaces</h3><span class="muted" style="font-size:12px">non-routine messages</span></div><div class="bd scroll" style="max-height:340px">
        ${d.top_interfaces.length ? `<table class="tbl"><thead><tr><th>Device</th><th>Interface</th><th class="r">Msgs</th><th class="r">Downs</th><th>Last</th></tr></thead><tbody>
        ${d.top_interfaces.map(r => `<tr class="click" data-href="#/interface?host=${esc(r.host)}&iface=${encodeURIComponent(r.interface)}"><td>${esc(r.host)}</td><td class="mono">${esc(shortIf(r.interface))}</td>
          <td class="r num">${n(r.n)}</td><td class="r num">${n(r.downs)}</td><td class="muted">${esc(fmtShort(r.last, now))}</td></tr>`).join('')}</tbody></table>` : emptyState('No interface-level activity')}</div></div>
    </div>
    <div class="section-title">Evidence <span class="line"></span></div>
    <div id="exp"></div></div>`;
  bindRange(main, () => go(location.hash));
  bindFindings(main.querySelector('#fl'));
  main.querySelectorAll('[data-href]').forEach(r => r.addEventListener('click', () => go(r.dataset.href)));
  return explorer(main.querySelector('#exp'), { category: c.id }, { fixed: ['category'], title: `${c.name} - message volume` });
}
