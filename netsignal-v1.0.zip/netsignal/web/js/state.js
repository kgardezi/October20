// Global client state + navigation.
const ls = {
  get(k, d) { try { return localStorage.getItem(k) ?? d; } catch (e) { return d; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch (e) { /* storage blocked */ } },
};

export const state = {
  range: ls.get('ns.range', '24h'),
  hideRoutine: ls.get('ns.hideRoutine', '1') === '1',
  meta: null,
  status: null,
  lastSearch: null,
  serverOffset: 0,           // server wall-clock minus browser clock
  listeners: new Set(),      // live event listeners
  setRange(r) { this.range = r; ls.set('ns.range', r); },
  setHideRoutine(v) { this.hideRoutine = v; ls.set('ns.hideRoutine', v ? '1' : '0'); },
  now() { return Date.now() / 1000 + this.serverOffset; },
};

export function go(hash) {
  if (location.hash === hash) window.dispatchEvent(new HashChangeEvent('hashchange'));
  else location.hash = hash;
}

export function parseHash() {
  const h = location.hash.replace(/^#/, '') || '/';
  const [path, query = ''] = h.split('?');
  const parts = path.split('/').filter(Boolean);
  const params = Object.fromEntries(new URLSearchParams(query));
  return { route: parts[0] || 'overview', arg: parts[1] ? decodeURIComponent(parts.slice(1).join('/')) : null, params };
}
