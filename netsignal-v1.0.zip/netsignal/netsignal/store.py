"""SQLite event store (WAL mode, FTS5 full-text index, uid-based de-duplication)."""
from __future__ import annotations

import json
import sqlite3
import threading
from pathlib import Path

COLUMNS = [
    "uid", "ts", "rx_ts", "dev_ts", "skew", "clock_flag", "host", "fqdn", "site", "role", "platform",
    "vendor", "facility", "severity", "mnemonic", "code", "slot", "message", "interface", "iface_class",
    "state", "neighbor", "mac", "ip", "vlan", "user", "reason", "protocol", "kind", "category", "signal",
    "rule", "repeat", "attrs", "source", "raw",
]

SCHEMA = f"""
PRAGMA journal_mode=WAL;
CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY,
    uid TEXT NOT NULL UNIQUE,
    ts REAL, rx_ts REAL, dev_ts REAL, skew REAL, clock_flag TEXT,
    host TEXT, fqdn TEXT, site TEXT, role TEXT, platform TEXT, vendor TEXT,
    facility TEXT, severity INTEGER, mnemonic TEXT, code TEXT, slot TEXT, message TEXT,
    interface TEXT, iface_class TEXT, state TEXT, neighbor TEXT, mac TEXT, ip TEXT, vlan INTEGER,
    user TEXT, reason TEXT, protocol TEXT,
    kind TEXT, category TEXT, signal TEXT, rule TEXT, repeat INTEGER DEFAULT 1,
    attrs TEXT, source TEXT, raw TEXT
);
CREATE INDEX IF NOT EXISTS ix_ev_ts ON events(ts);
CREATE INDEX IF NOT EXISTS ix_ev_host_ts ON events(host, ts);
CREATE INDEX IF NOT EXISTS ix_ev_cat_ts ON events(category, ts);
CREATE INDEX IF NOT EXISTS ix_ev_kind_ts ON events(kind, ts);
CREATE INDEX IF NOT EXISTS ix_ev_code ON events(code, ts);
CREATE INDEX IF NOT EXISTS ix_ev_mac ON events(mac);
CREATE INDEX IF NOT EXISTS ix_ev_iface ON events(interface, host);
CREATE INDEX IF NOT EXISTS ix_ev_site_ts ON events(site, ts);
CREATE VIRTUAL TABLE IF NOT EXISTS events_fts USING fts5(
    host, message, content='events', content_rowid='id',
    tokenize="unicode61 tokenchars '._/:-'"
);
CREATE TRIGGER IF NOT EXISTS events_ai AFTER INSERT ON events BEGIN
    INSERT INTO events_fts(rowid, host, message) VALUES (new.id, new.fqdn, new.message);
END;
CREATE TRIGGER IF NOT EXISTS events_ad AFTER DELETE ON events BEGIN
    INSERT INTO events_fts(events_fts, rowid, host, message) VALUES ('delete', old.id, old.fqdn, old.message);
END;
CREATE TABLE IF NOT EXISTS files (
    name TEXT PRIMARY KEY, day TEXT, size INTEGER, mtime REAL, status TEXT,
    lines INTEGER DEFAULT 0, inserted INTEGER DEFAULT 0, loaded_at REAL, error TEXT
);
CREATE TABLE IF NOT EXISTS kv (k TEXT PRIMARY KEY, v TEXT);
"""

SIGNAL_ORDER = ["routine", "info", "warning", "major", "critical"]


class Store:
    def __init__(self, path: str):
        self.path = path
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        self._wlock = threading.Lock()
        self._w = self._connect()
        self._w.executescript(SCHEMA)
        self._local = threading.local()
        self.inserted_total = 0
        self.duplicates_total = 0

    def _connect(self) -> sqlite3.Connection:
        c = sqlite3.connect(self.path, timeout=30, check_same_thread=False)
        c.row_factory = sqlite3.Row
        c.execute("PRAGMA synchronous=NORMAL")
        c.execute("PRAGMA temp_store=MEMORY")
        c.execute("PRAGMA cache_size=-65536")
        return c

    @property
    def r(self) -> sqlite3.Connection:
        c = getattr(self._local, "conn", None)
        if c is None:
            c = self._connect()
            self._local.conn = c
        return c

    # ------------------------------------------------------------------ write
    def insert_events(self, events: list[dict], source: str) -> list[dict]:
        """Insert parsed+classified events. Returns those actually inserted (new)."""
        if not events:
            return []
        sql = (f"INSERT OR IGNORE INTO events ({','.join(COLUMNS)}) "
               f"VALUES ({','.join('?' * len(COLUMNS))}) RETURNING id")
        new = []
        with self._wlock:
            cur = self._w.cursor()
            cur.execute("BEGIN")
            try:
                for ev in events:
                    ev["source"] = source
                    row = cur.execute(sql, [ev.get(c) for c in COLUMNS]).fetchone()
                    if row is not None:
                        ev["id"] = row[0]
                        new.append(ev)
                cur.execute("COMMIT")
            except Exception:
                cur.execute("ROLLBACK")
                raise
        self.inserted_total += len(new)
        self.duplicates_total += len(events) - len(new)
        return new

    def purge_before(self, ts: float) -> int:
        with self._wlock:
            cur = self._w.execute("DELETE FROM events WHERE ts < ?", (ts,))
            self._w.commit()
            return cur.rowcount

    def kv_get(self, k: str, default=None):
        row = self.r.execute("SELECT v FROM kv WHERE k=?", (k,)).fetchone()
        return json.loads(row[0]) if row else default

    def kv_set(self, k: str, v) -> None:
        with self._wlock:
            self._w.execute("INSERT OR REPLACE INTO kv(k,v) VALUES(?,?)", (k, json.dumps(v)))
            self._w.commit()

    def file_set(self, name: str, **fields) -> None:
        cols = ["name"] + list(fields)
        with self._wlock:
            self._w.execute(
                f"INSERT INTO files ({','.join(cols)}) VALUES ({','.join('?' * len(cols))}) "
                f"ON CONFLICT(name) DO UPDATE SET " + ",".join(f"{k}=excluded.{k}" for k in fields),
                [name] + list(fields.values()))
            self._w.commit()

    def files(self) -> dict:
        return {r["name"]: dict(r) for r in self.r.execute("SELECT * FROM files")}

    # ------------------------------------------------------------------ read
    def q(self, sql: str, params=()) -> list[dict]:
        return [dict(r) for r in self.r.execute(sql, params)]

    def one(self, sql: str, params=()):
        row = self.r.execute(sql, params).fetchone()
        return dict(row) if row else None


# ---------------------------------------------------------------------- filters
def _as_list(v):
    if v is None or v == "":
        return []
    if isinstance(v, (list, tuple, set)):
        return [x for x in v if x not in (None, "")]
    return [x.strip() for x in str(v).split(",") if x.strip()]


def fts_query(text: str) -> str:
    toks = [t for t in text.replace('"', " ").split() if t]
    return " ".join(f'"{t.lower()}"*' for t in toks)


def build_where(f: dict) -> tuple[str, list]:
    """Translate a filter dict into SQL WHERE clause on table alias e."""
    w, p = ["1=1"], []
    if f.get("t0") is not None:
        w.append("e.ts >= ?"); p.append(float(f["t0"]))
    if f.get("t1") is not None:
        w.append("e.ts <= ?"); p.append(float(f["t1"]))
    for key, col in (("host", "host"), ("site", "site"), ("category", "category"), ("kind", "kind"),
                     ("platform", "platform"), ("role", "role"), ("iface_class", "iface_class"),
                     ("protocol", "protocol"), ("state", "state"), ("signal", "signal")):
        vals = _as_list(f.get(key))
        if vals:
            w.append(f"e.{col} IN ({','.join('?' * len(vals))})"); p.extend(vals)
    codes = _as_list(f.get("code"))
    if codes:
        w.append("(" + " OR ".join("e.code LIKE ?" for _ in codes) + ")")
        p.extend([c.replace("*", "%") if "*" in c else c for c in codes])
    if f.get("iface"):
        ifs = _as_list(f["iface"])
        w.append("(" + " OR ".join("(e.interface = ? OR e.attrs LIKE ?)" for _ in ifs) + ")")
        for i in ifs:
            p.extend([i, f'%"{i}"%'])
    if f.get("mac"):
        w.append("e.mac = ?"); p.append(f["mac"])
    if f.get("ip"):
        w.append("(e.ip = ? OR e.neighbor = ? OR e.id IN (SELECT rowid FROM events_fts WHERE events_fts MATCH ?))")
        p.extend([f["ip"], f["ip"], f'"{f["ip"]}"'])
    if f.get("neighbor"):
        w.append("e.neighbor = ?"); p.append(f["neighbor"])
    if f.get("user"):
        w.append("e.user = ?"); p.append(f["user"])
    if f.get("vlan"):
        w.append("e.vlan = ?"); p.append(int(f["vlan"]))
    if f.get("sev_max") not in (None, ""):
        w.append("e.severity <= ?"); p.append(int(f["sev_max"]))
    if f.get("signal_min"):
        idx = SIGNAL_ORDER.index(f["signal_min"]) if f["signal_min"] in SIGNAL_ORDER else 0
        allowed = SIGNAL_ORDER[idx:]
        w.append(f"e.signal IN ({','.join('?' * len(allowed))})"); p.extend(allowed)
    ids = _as_list(f.get("ids"))
    if ids:
        w.append(f"e.id IN ({','.join('?' * len(ids))})"); p.extend(int(i) for i in ids)
    if f.get("q"):
        fq = fts_query(f["q"])
        if fq:
            w.append("e.id IN (SELECT rowid FROM events_fts WHERE events_fts MATCH ?)"); p.append(fq)
    return " AND ".join(w), p
