const {test} = require('node:test');
const assert = require('node:assert/strict');
const I = require('../js/importer-engine.js');
// NX-OS / ASR parser fixes first released in 3.6.1 and restored in 3.8.0. Synthetic documentation-range data.
const CL = 'EDEM001CL0101', TL = 'EDEM001TL0101';
const nx = `${CL}# show running-config
hostname ${CL}
interface Ethernet1/1
  description UPLINK: ${TL} Gi0/0/1
  no switchport
  ip address 198.51.100.1/31
  ip router ospf 1 area 0.0.0.0
  no shutdown
interface Ethernet1/2
  description UPLINK: ${TL} Gi0/0/2
  no switchport
  ip address 198.51.100.3/31
  ip router ospf 1 area 0.0.0.0
  shutdown
interface Ethernet1/3.100
  ip address 198.51.100.9/31
  ip router ospf 1 area 0.0.0.0
interface loopback0
  ip address 192.0.2.11/32
router ospf 1
  router-id 192.0.2.11
  vrf CORP
    router-id 192.0.2.111
    passive-interface default
${CL}# show interface description
-------------------------------------------------------------------------------
Port          Type   Speed   Description
-------------------------------------------------------------------------------
Eth1/1        eth    10G     UPLINK: ${TL} Gi0/0/1
Eth1/2        eth    10G     UPLINK: ${TL} Gi0/0/2
Eth1/3        eth    10G     --
${CL}# show interface status
--------------------------------------------------------------------------------
Port          Name               Status    Vlan      Duplex  Speed   Type
--------------------------------------------------------------------------------
Eth1/1        UPLINK: ${TL}  connected routed    full    10G     10Gbase-SR
Eth1/2        UPLINK: ${TL}  disabled  routed    auto    auto    10Gbase-SR
Eth1/3        --                 notconnec routed    auto    auto    10Gbase-SR
${CL}# show lldp neighbors detail
Capability codes:
  (R) Router, (B) Bridge
Chassis id: 00aa.bbcc.dd01
Port id: Gi0/0/1
Local Port id: Eth1/1
Port Description: UPLINK
System Name: ${TL}.example.net
Management Address: 192.0.2.1

Total entries displayed: 1
${CL}# show ip ospf neighbors detail vrf all
 Neighbor 192.0.2.1, interface address 198.51.100.0
    Process ID 1 VRF default, in area 0.0.0.0 via interface Ethernet1/1
    State is FULL, 5 state changes, last change 3w2d
 Neighbor 192.0.2.99, interface address 198.51.100.8
    Process ID 1 VRF default, in area 0.0.0.0 via interface Ethernet1/3.100
    State is FULL, 5 state changes, last change 3w2d
${CL}# exit`;
const asr = `${TL}#show running-config
hostname ${TL}
interface Loopback0
 ip address 192.0.2.1 255.255.255.255
interface GigabitEthernet0/0/1
 description UPLINK: ${CL} Eth1/1
 ip address 198.51.100.0 255.255.255.254
 ip ospf 1 area 0
interface GigabitEthernet0/0/2
 description UPLINK: ${CL} Eth1/2
 ip address 198.51.100.2 255.255.255.254
 ip ospf 1 area 0
router ospf 1
 router-id 192.0.2.1
${TL}#show interfaces description
Interface                      Status         Protocol Description
Gi0/0/1                        up             up       UPLINK: ${CL} Eth1/1
Gi0/0/2                        down           down     UPLINK: ${CL} Eth1/2
${TL}#show ip ospf neighbor
Neighbor ID     Pri   State           Dead Time   Address         Interface
192.0.2.11        0   FULL/  -        00:00:35    198.51.100.1    GigabitEthernet0/0/1
${TL}#exit`;
const pn = I.parseDevice(CL + '.txt', nx), pa = I.parseDevice(TL + '.txt', asr);

test('NX-OS LLDP detail blocks start at Chassis id and use Local Port id', () => {
  assert.equal(pn.lldp.length, 1);
});
test('NX-OS show interface description Port/Type/Speed section is read, -- means no description', () => {
  assert.ok(pn.desc.size >= 3);
  const e3 = [...pn.desc.values()].find(d => /1\/3$/.test(d.name));
  assert.equal(e3.desc, '');
});
test('NX-OS truncated status states (notconnec, disabled) are read', () => {
  assert.ok(pn.status.size >= 3);
  const st = [...pn.status.values()].map(v => v.status);
  assert.ok(st.includes('up') && st.includes('admin down') && st.includes('down'));
});
test('NX-OS router ospf vrf blocks keep their own router-id and passive default', () => {
  const procs = pn.run.ospf.map(p => [p.pid, p.vrf, p.rid, p.passiveDefault]);
  assert.deepEqual(procs.find(p => p[1] === ''), ['1', '', '192.0.2.11', false]);
  assert.deepEqual(procs.find(p => p[1] === 'CORP'), ['1', 'CORP', '192.0.2.111', true]);
  assert.equal(pn.run.ifs.get('eth1/1').ospf.passive, false);
});
test('OSPF neighbor detail output is read on NX-OS', () => {
  assert.equal(pn.ospfNbr.length, 2);
  assert.ok(pn.ospfNbr.every(n => n.state === 'FULL'));
});
test('NX-OS cable is found by LLDP and OSPF neighbours hidden by the suffix filter are reported', () => {
  const R = I.analyze([pn, pa], {inventory: new Map()});
  assert.ok(R.phys.some(L => [L.a.dev, L.b.dev].sort().join() === [CL, TL].sort().join()));
  assert.ok(R.problems.some(p => /subinterfaces other than/.test(p.msg)));
});
test('a command that names ports but yields no rows is reported', () => {
  const bad = I.parseDevice(CL + '.txt', `${CL}# show cdp neighbors detail\nweird format Eth1/1 something\n${CL}# exit`);
  const R = I.analyze([bad], {inventory: new Map()});
  assert.ok(R.problems.some(p => /names ports, but no rows/.test(p.msg)) || bad.cdp.length > 0);
});
