// Finding detail: why it was raised, correlations, next steps, evidence timeline + original lines.
import { esc, icon, api, n, fmtTs, fmtShort, shortIf, sevBadge, loading, emptyState, dur, copyText } from '../util.js';
import { state, go } from '../state.js';
import { eventTable, bindEventTable, openEvent, cmdLine, typeLabel } from '../components.js';
import { swimlanes } from '../charts.js';

export async function render(main, { arg }) {
  main.innerHTML = `<div class="page">${loading()}</div>`;
  let d;
  try { d = await api(`/api/finding/${arg}?range=${state.range}`); } catch (e) {
    main.innerHTML = `<div class="page"><div class="card">${emptyState('This finding is not present in the selected time range (' + state.range + '). It may have aged out - try a wider range.', 'clock')}</div></div>`;
    return;
  }
  const f = d.finding, now = state.now();
  const m = f.metrics || {};
  const metricRows = Object.entries(m).filter(([k, v]) => v !== null && v !== undefined && v !== '' && !(Array.isArray(v) && !v.length) && typeof v !== 'object' || (Array.isArray(v) && v.length && typeof v[0] !== 'object'))
    .map(([k, v]) => [k.replace(/_/g, ' '), Array.isArray(v) ? v.join(', ') : v]);
  let special = '';
  if (m.ports) special = `<table class="tbl"><thead><tr><th>Interface</th><th class="r">Down→up cycles</th></tr></thead><tbody>${m.ports.map(p => `<tr class="click" data-href="#/interface?host=${esc(f.host)}&iface=${encodeURIComponent(p.interface)}"><td class="mono">${esc(shortIf(p.interface))}</td><td class="r num">${p.cycles}</td></tr>`).join('')}</tbody></table>`;
  if (m.paths) special = `<table class="tbl"><thead><tr><th>Device: from → to</th><th class="r">Moves</th></tr></thead><tbody>${Object.entries(m.paths).map(([k, v]) => `<tr><td class="mono">${esc(k)}</td><td class="r num">${v}</td></tr>`).join('')}</tbody></table>`;
  if (m.probable_far_end) special += `<div class="ctx" style="margin-top:10px">${icon('link')}<div><b>Probable far end:</b> <a href="#/interface?host=${esc(m.probable_far_end.host)}&iface=${encodeURIComponent(m.probable_far_end.interface)}">${esc(m.probable_far_end.host)} ${esc(shortIf(m.probable_far_end.interface))}</a><div class="muted">${esc(m.probable_far_end.note)}</div></div></div>`;
  if (m.examples) special += `<div class="dsec" style="margin-top:10px"><h4>Example messages</h4>${m.examples.map(x => `<div class="mono" style="padding:3px 0">${esc(x)}</div>`).join('')}</div>`;

  const ctxIcon = { change: 'git', correlation: 'layers', coincident: 'layers', related: 'link', recurring: 'repeat' };
  const ctxTitle = { change: 'What changed', correlation: 'Correlation', coincident: 'Coincident event', related: 'Related', recurring: 'History' };
  const evs = d.events;

  main.innerHTML = `<div class="page">
    <div class="crumb"><a href="#/findings">Findings</a> / ${esc(typeLabel(f.type))}</div>
    <div class="ph"><div style="min-width:0"><div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">${sevBadge(f.severity)}${f.status === 'recovered' ? '<span class="sev good">recovered</span>' : ''}<span class="chip">${esc(typeLabel(f.type))}</span>${d.category ? `<a class="chip" href="#/category/${esc(d.category.id)}">${esc(d.category.name)}</a>` : ''}</div>
      <h1 style="margin-top:8px">${esc(f.title)}</h1><div class="sub">${esc(f.summary)}</div></div></div>

    <div class="grid">
      <div class="c8" style="display:flex;flex-direction:column;gap:16px">
        <div class="card"><div class="hd"><h3>Evidence timeline</h3><span class="grow"></span><span class="muted">${n(evs.length)} original messages · ${esc(fmtTs(f.first))} → ${esc(fmtTs(f.last))} (${esc(dur(f.last - f.first))})</span></div>
          <div class="bd"><div class="chart" id="lanes"></div><div class="note">Red = down, green = up, other colours = message rating. Click a dot for details.</div></div></div>
        ${f.context?.length ? `<div class="card"><div class="hd"><h3>Context & correlation</h3></div><div class="bd">
          ${f.context.map(c => `<div class="ctx ${esc(c.type)}" ${c.event_id ? `data-eid="${c.event_id}" style="cursor:pointer"` : ''}>${icon(ctxIcon[c.type] || 'info')}<div><b>${esc(ctxTitle[c.type] || c.type)}:</b> ${esc(c.text)}</div></div>`).join('')}
          <div class="note">Correlations are based on timing and naming only. They point you to where to look - they do not prove cause.</div></div></div>` : ''}
        <div class="card"><div class="hd"><h3>Original syslog evidence</h3><span class="grow"></span>
          <a class="btn sm" href="#/investigate?ids=${evs.slice(0, 300).map(e => e.id).join(',')}">Open in Investigate</a></div>
          <div class="bd" style="padding:0" id="evt">${eventTable([...evs].reverse(), { now, maxh: 520 })}</div></div>
      </div>
      <div class="c4" style="display:flex;flex-direction:column;gap:16px">
        <div class="card"><div class="hd"><h3>${icon('info', 'sm')} Why this was flagged</h3></div><div class="bd"><div class="why">${esc(f.why)}</div></div></div>
        ${f.next_steps?.length ? `<div class="card"><div class="hd"><h3>${icon('terminal', 'sm')} Next steps</h3></div><div class="bd"><div class="cmds">${f.next_steps.map(cmdLine).join('')}</div></div></div>` : ''}
        <div class="card"><div class="hd"><h3>Details</h3></div><div class="bd">
          <div class="kv">${f.host ? `<div class="k">Device</div><div class="v"><a href="#/device/${esc(f.host)}">${esc(f.host)}</a></div>` : ''}
          ${f.site ? `<div class="k">Site</div><div class="v"><a href="#/investigate?site=${esc(f.site)}">${esc(f.site)}</a></div>` : ''}
          ${f.interface ? `<div class="k">Interface</div><div class="v"><a href="#/interface?host=${esc(f.host)}&iface=${encodeURIComponent(f.interface)}">${esc(f.interface)}</a></div>` : ''}
          <div class="k">First seen</div><div class="v">${esc(fmtTs(f.first))}</div><div class="k">Last seen</div><div class="v">${esc(fmtTs(f.last))}</div>
          ${metricRows.map(([k, v]) => `<div class="k">${esc(k)}</div><div class="v">${esc(v)}</div>`).join('')}</div>
          ${special}</div></div>
      </div>
    </div></div>`;

  const draw = () => evs.length && swimlanes(main.querySelector('#lanes'), evs, { now, onClick: e => openEvent(e.id) });
  draw();
  bindEventTable(main.querySelector('#evt'));
  main.querySelectorAll('[data-eid]').forEach(el => el.addEventListener('click', () => openEvent(+el.dataset.eid)));
  main.querySelectorAll('[data-href]').forEach(el => el.addEventListener('click', () => go(el.dataset.href)));
  main.querySelectorAll('.cmd .copy').forEach(c => c.onclick = () => copyText(c.dataset.t));
  window.addEventListener('resize', draw);
  return () => window.removeEventListener('resize', draw);
}
