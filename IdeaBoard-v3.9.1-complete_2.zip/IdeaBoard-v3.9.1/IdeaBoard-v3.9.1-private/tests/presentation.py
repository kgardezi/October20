"""Presentation checks: outlines, anchors, graph paper, laser lifetimes and generated lanes."""
import io,json,os,pathlib,shutil,zipfile
import xml.etree.ElementTree as ET
from playwright.sync_api import sync_playwright,expect
ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=pathlib.Path(os.environ.get('IDEABOARD_TEST_OUTPUT','/workspace/ideaboard-setup/results-3.7'));OUT.mkdir(parents=True,exist_ok=True)
with sync_playwright() as p:
 b=p.chromium.launch(executable_path=shutil.which('chromium'),args=['--no-sandbox','--disable-dev-shm-usage'])
 page=b.new_page(viewport={'width':1500,'height':1100},accept_downloads=True);errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(os.environ.get('IDEABOARD_URL','http://127.0.0.1:8000/'));page.wait_for_function("window.ideaBoard&&document.querySelector('#canvas').style.visibility!== 'hidden'");page.evaluate('document.fonts.ready')
 # Every built-in shape offers more than four handles; round and diamond points follow their outline.
 assert page.evaluate("['rect','ellipse','diamond','cloud','note'].every(type=>portsOf({type,x:0,y:0,w:200,h:100}).length>=12)")
 assert page.evaluate("portsOf({type:'ellipse',x:0,y:0,w:200,h:100}).every(p=>Math.abs(((p.anchor.x-.5)*2)**2+((p.anchor.y-.5)*2)**2-1)<1e-8)")
 assert page.evaluate("portsOf({type:'diamond',x:0,y:0,w:200,h:100}).every(p=>Math.abs(Math.abs(p.anchor.x-.5)+Math.abs(p.anchor.y-.5)-.5)<1e-8)")
 assert page.evaluate("(()=>{const s={type:'rect',x:20,y:30,w:400,h:200};const p=portsOf(s)[0];return JSON.stringify(anchorPoint(s,{anchor:p.anchor}))===JSON.stringify({x:p.x,y:p.y})})()")
 print('PASS: built-in anchors, outline positions and resize attachment geometry',flush=True)
 page.evaluate("prefs.theme='light';applyTheme();")
 expect(page.locator('#gridbg')).to_have_attribute('fill','url(#graphPaper)')
 page.locator('#menuBtn').click();page.locator('#gridStyle').select_option('dots');expect(page.locator('#gridbg')).to_have_attribute('fill','url(#dots)')
 page.locator('#gridStyle').select_option('graph');page.locator('#menuBtn').click();page.reload();page.wait_for_function("window.ideaBoard&&document.querySelector('#canvas').style.visibility!== 'hidden'")
 expect(page.locator('#gridbg')).to_have_attribute('fill','url(#graphPaper)')
 print('PASS: graph-paper/dot switching and saved preference',flush=True)
 page.evaluate("""()=>{board.shapes=[{id:'dl1',type:'device',kind:'switch',view:'rack',x:0,y:0,w:290,h:64,font:'draw',text:'EDEM001DL0208',role:'DL',color:'orange',fill:'solid',size:'m'},{id:'dl2',type:'device',kind:'switch',view:'rack',x:400,y:0,w:290,h:64,font:'draw',text:'EDEM002DL0108',role:'DL',color:'orange',fill:'solid',size:'m'}];pages[curPage].shapes=board.shapes;sel.clear();zoomFit();render();}""")
 page.evaluate('document.fonts.ready');page.wait_for_timeout(100)
 svg=page.evaluate('exportSvgString(false).svg');xml=ET.fromstring(svg)
 assert len(xml.findall(".//{*}g[@data-outlined-font='IdeaDraw']"))==4
 assert not xml.findall('.//{*}text')
 assert 'EDEM001DL0208' in svg and 'EDEM002DL0108' in svg
 (OUT/'hand-drawn-devices.svg').write_text(svg)
 # Compare on-screen glyphs with their outlined equivalents in the same browser.
 comparison=page.evaluate("""()=>{const library=window.opentype;window.opentype=null;const original=exportSvgString(false).svg;window.opentype=library;return {original,outlined:exportSvgString(false).svg};}""")
 view=b.new_page(viewport={'width':1000,'height':350});view.set_content('<style>body{margin:0}</style>'+comparison['original']);view.evaluate('document.fonts.ready');view.locator('svg').screenshot(path=str(OUT/'font-original.png'))
 view.set_content('<style>body{margin:0}</style>'+comparison['outlined']);view.locator('svg').screenshot(path=str(OUT/'font-outlined.png'));view.close()
 from PIL import Image,ImageChops,ImageStat
 original=Image.open(OUT/'font-original.png').convert('RGB');outlined=Image.open(OUT/'font-outlined.png').convert('RGB')
 assert original.size==outlined.size
 difference=sum(ImageStat.Stat(ImageChops.difference(original,outlined)).mean)/3
 assert difference<3,('font outline mismatch',difference)
 page.locator('#menuBtn').click()
 with page.expect_download() as png:page.locator('[data-menu="png"]').click()
 png.value.save_as(OUT/'hand-drawn-devices.png');im=Image.open(OUT/'hand-drawn-devices.png');assert im.width>100 and im.height>100
 print('PASS: exported hand-drawn glyph outlines match canvas typography; PNG download',flush=True)
 # A real newly-added non-midpoint handle can start a connector and survive moves.
 page.evaluate("board.shapes.push({id:'shape1',type:'rect',x:0,y:180,w:200,h:100,color:'blue',fill:'none',dash:'draw',size:'m',fontSize:'m',text:''},{id:'shape2',type:'diamond',x:400,y:180,w:200,h:100,color:'blue',fill:'none',dash:'draw',size:'m',fontSize:'m',text:''});sel=new Set(['shape1']);render();")
 page.evaluate("setTool('select');zoomFit(board.shapes,true);");page.wait_for_timeout(100)
 start=page.evaluate("(()=>{const p=portsOf(byId('shape1')).find(p=>p.anchor.y===1&&p.anchor.x!==.5);return {x:p.x*cam.z+cam.x,y:p.y*cam.z+cam.y}})()")
 end=page.evaluate("(()=>{const p=portsOf(byId('shape2'))[0];return {x:p.x*cam.z+cam.x,y:p.y*cam.z+cam.y}})()")
 page.mouse.move(**start);page.mouse.down();page.mouse.move(**end,steps=8);page.mouse.up()
 assert page.evaluate("board.shapes.some(s=>s.type==='connector'&&s.start.id==='shape1'&&s.end.id==='shape2'&&s.start.anchor&&s.start.anchor.x!==.5)")
 print('PASS: dragging a new shape anchor creates an attached connector',flush=True)
 # Visio graph paper is a native exportable background, and built-in handles are native connection rows.
 page.locator('#menuBtn').click();page.locator('[data-menu="visio"]').click();page.locator('#visioScope').select_option('current');page.locator('#visioGrid').select_option('print');page.locator('#visioBg').select_option('light')
 with page.expect_download() as d:page.locator('#visioDownload').click()
 payload=pathlib.Path(d.value.path()).read_bytes();(OUT/'graph-paper.vsdx').write_bytes(payload)
 with zipfile.ZipFile(io.BytesIO(payload)) as z:
  docs=[ET.fromstring(z.read(n)) for n in z.namelist() if n.startswith('visio/pages/page') and n.endswith('.xml')]
  assert any(root.findall(".//{*}Shape[@NameU='GraphPaperMinor']") for root in docs)
  assert any(root.findall(".//{*}Shape[@NameU='GraphPaperMajor']") for root in docs)
  assert any(len(sec.findall('{*}Row'))>=12 for root in docs for sec in root.findall(".//{*}Section[@N='Connection']"))
 restored=page.evaluate('async a=>await IdeaVisio.parse(new Uint8Array(a))',list(payload));assert len(restored['pages'])==1
 assert not any('GraphPaper' in s.get('text','') for s in restored['pages'][0]['shapes'])
 page.locator('#visioClose').click()
 print('PASS: native Visio graph paper, extra connection points and background-free reimport',flush=True)
 page.locator('#canvas').focus();page.keyboard.press('k');expect(page.locator('#laserLifetime')).to_have_value('7000')
 page.mouse.move(700,350);page.mouse.down();page.mouse.move(800,400,steps=10);page.mouse.up()
 page.wait_for_timeout(5200);assert page.evaluate('ideaBoard.lasers.length')>0
 page.wait_for_timeout(2700);assert page.evaluate('ideaBoard.lasers.length')==0
 page.locator('#laserLifetime').select_option('0');page.mouse.move(700,350);page.mouse.down();page.mouse.move(820,400,steps=5);page.mouse.up();page.wait_for_timeout(800)
 assert page.evaluate('ideaBoard.lasers.length')>0
 assert 'laser' not in page.evaluate('exportSvgString(false).svg')
 page.locator('#clearLaser').click();assert page.evaluate('ideaBoard.lasers.length')==0
 page.locator('[data-set="laserMode"][data-v="spot"]').click();page.mouse.move(700,350);expect(page.locator('#laser circle')).to_have_count(2);expect(page.locator('#laser path')).to_have_count(0)
 page.locator('[data-set="laserColor"][data-v="cyan"]').click();page.mouse.move(710,350);expect(page.locator('#laser')).to_have_attribute('fill','#23d8ff')
 page.reload();page.wait_for_function("window.ideaBoard&&document.querySelector('#canvas').style.visibility!== 'hidden'");page.locator('#canvas').focus();page.keyboard.press('k');expect(page.locator('#laserLifetime')).to_have_value('0');expect(page.locator('[data-set="laserMode"][data-v="spot"]')).to_have_class('active')
 print('PASS: seven-second trail lifetime, persistent marks, clear, spot/color and preference persistence',flush=True)
 page.locator('#canvas').focus();page.keyboard.press('v');page.locator('#menuBtn').click();page.locator('[data-menu="cfgimport"]').click();page.locator('#collectionGuide summary').click()
 expect(page.locator('#collect-physical')).to_have_value(__import__('re').compile('show interfaces\\n'))
 page.locator('#niPlatform').select_option('nexus');expect(page.locator('#collect-physical')).to_have_value(__import__('re').compile('show interface status'));expect(page.locator('#collect-ospf')).to_have_value(__import__('re').compile('vrf all'))
 page.locator('#niPlatform').select_option('catalyst');expect(page.locator('#collect-physical')).to_have_value(__import__('re').compile('show etherchannel summary'))
 assert not errors,errors
 print('PASS: platform collection guide and no browser JavaScript errors',flush=True)
 b.close()
