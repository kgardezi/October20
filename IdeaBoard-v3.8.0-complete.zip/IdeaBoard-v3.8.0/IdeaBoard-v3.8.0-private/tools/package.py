"""Package private/public folder and offline HTML editions using only Python stdlib."""
import hashlib
import ast
import pathlib
import re
import shutil
import sys
import zipfile

ROOT=pathlib.Path(__file__).resolve().parents[1]
OUT=pathlib.Path(sys.argv[1]).resolve() if len(sys.argv)>1 else ROOT.parent/'releases'
VERSION='3.8.0'


def inline(folder):
    html=(folder/'index.html').read_text()
    html=html.replace('<link rel="stylesheet" href="css/app.css">','<style>\n'+(folder/'css/app.css').read_text()+'\n</style>')
    for name in ['visio-export','opentype.min','export-fonts','app','importer-engine','importer-ui']:
        js=(folder/f'js/{name}.js').read_text()
        js=re.sub(r'</script',r'<\\/script',js,flags=re.I)
        html=html.replace(f'<script src="js/{name}.js"></script>','<script>\n'+js+'\n</script>')
    license=(folder/'FONT-LICENSE.txt').read_text()
    html=html.replace('</head>','<!-- Embedded font license\n'+license+'\n-->\n</head>')
    assert not re.search(r'<script[^>]+src=',html)
    assert 'href="css/' not in html
    return html


def main():
    OUT.mkdir(parents=True,exist_ok=True)
    release=OUT/f'IdeaBoard-v{VERSION}'
    if release.exists():
        # Only this generated output is replaced; the source and original 3.4 are untouched.
        if release==ROOT or ROOT.is_relative_to(release):raise RuntimeError('Unsafe output directory')
        shutil.rmtree(release)
    release.mkdir()
    defaults=re.search(r"const DEFAULT_SITES = ('[^\n]*');",(ROOT/'js/importer-engine.js').read_text())
    private_names=[line.split('=',1)[1].strip() for line in ast.literal_eval(defaults[1]).splitlines() if '=' in line]
    for edition in ['private','public']:
        folder=release/f'IdeaBoard-v{VERSION}-{edition}'
        shutil.copytree(ROOT,folder,ignore=shutil.ignore_patterns('__pycache__','*.pyc','.git','team-server'))
        if edition=='public':
            engine=folder/'js/importer-engine.js'
            source=engine.read_text()
            source,n=re.subn(r"const DEFAULT_SITES = '[^\n]*';","const DEFAULT_SITES = '';",source)
            assert n==1
            engine.write_text(source)
            for name in ['app','importer-ui']:
                p=folder/f'js/{name}.js';source=p.read_text().replace('ideaboard:','ideaboard-public:')
                if name=='app':source=re.sub(r'async function detectServer\(\)\{.*?\n\}', 'async function detectServer(){ return false; }',source,count=1,flags=re.S)
                p.write_text(source)
            readme=folder/'README.md'
            readme.write_text(readme.read_text()+'\nPublic edition: organization defaults are empty, browser storage is isolated, and legacy team-server detection is disabled. Imported data is not anonymized automatically.\n')
            ui=folder/'js/importer-ui.js'
            ui.write_text(ui.read_text().replace('Turn device outputs into an editable, multi-page network diagram.', 'Public edition: no organization defaults. Imported data is not automatically anonymized.'))
            for p in folder.rglob('*'):
                if p.suffix in ['.html','.js','.json','.md','.txt']:
                    text=p.read_text()
                    for forbidden in private_names:
                        assert forbidden not in text,(p,forbidden)
        target=release/f'IdeaBoard-v{VERSION}-{edition}.html'
        target.write_text(inline(folder))
    # Team server: the private single-file app served by a zero-dependency Node.js server (Docker or systemd).
    server=release/f'IdeaBoard-v{VERSION}-team-server'
    shutil.copytree(ROOT/'team-server',server,ignore=shutil.ignore_patterns('__pycache__','data'))
    shutil.copy(release/f'IdeaBoard-v{VERSION}-private.html',server/'index.html')
    for name in ['FONT-LICENSE.txt','OPENTYPE-LICENSE.txt']:shutil.copy(ROOT/name,server/name)
    (server/'install.sh').chmod(0o755)
    (release/'START-HERE.txt').write_text('IdeaBoard 3.8.0\n\nOpen either standalone HTML in Chrome or Edge, or open index.html inside the matching folder.\nFor shared team boards on a Linux server, see the team-server folder (README.md there: Docker or systemd).\nPrivate retains organization site defaults; public removes them and isolates browser storage.\nPublic does not anonymize imported data. Samples are synthetic documentation-range data.\nRead Upgrade-guide.md, README.md and Feature-coverage.md for behavior, controls, validation, and limitations.\n')
    checks=[]
    for p in sorted(release.rglob('*')):
        if p.is_file():checks.append(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(release).as_posix())
    (release/'SHA256SUMS.txt').write_text('\n'.join(checks)+'\n')
    archive=OUT/f'IdeaBoard-v{VERSION}-complete.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(release.rglob('*')):
            if p.is_file():z.write(p,p.relative_to(OUT))
    print(f'Packaged {archive} ({archive.stat().st_size} bytes)')


if __name__=='__main__':main()
