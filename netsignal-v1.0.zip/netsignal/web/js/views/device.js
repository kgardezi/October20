// Device troubleshooting view.
import { esc, icon, api, n, fmtTs, fmtShort, shortIf, sevBadge, loading, healthColor, emptyState, ago } from '../util.js';
import { state, go } from '../state.js';
import { rangeSeg, bindRange, findingList, bindFindings } from '../components.js';
import { timeline, legend } from '../charts.js';
import { explorer } from './investigate.js';

export async function render(main, { arg }) {
  main.innerHTML = `<div class="page">${loading()}</div>`;
  const d = await api(`/api/device/${encodeURIComponent(arg)}?range=${state.range}`);
  const i = d.info, h = d.health, now = state.now();
  const sig = d.categories.reduce((a, c) => a + (c.sig || 0), 0);
  const skew = d.clock?.a;
  const ifRows = d.interfaces.map(r => {
    const st = r.last_state;
    const stc = st === 'down' ? 'critical' : st === 'up' ? 'good' : 'info';
    return `<tr class="click" data-href="#/interface?host=${esc(i.host)}&iface=${encodeURIComponent(r.interface)}">
      <td class="mono">${esc(shortIf(r.interface))}</td><td class="muted">${esc(r.cls || '')}</td>
      <td>${st ? `<span class="sev ${stc}">${esc(st)}</span>` : '<span class="muted">—</span>'}</td>
      <td class="r num">${r.downs ? `<b>${r.downs}</b>` : 0}</td><td class="r num">${n(r.n)}</td><td class="muted nowrap">${esc(ago(r.last, now))}</td></tr>`;
  }).join('');

  main.innerHTML = `<div class="page">
    <div class="crumb"><a href="#/devices">Devices</a> / ${esc(i.host)}</div>
    <div class="ph"><div class="devhead">
        <div class="ring" style="--p:${h.score};--c:${healthColor(h.score)}" title="Health score (100 = no findings)"><div>${h.score}</div></div>
        <div><h1>${esc(i.host)}</h1><div class="sub">${esc(i.fqdn || '')}</div>
          <div style="display:flex;gap:8px;margin-top:6px;flex-wrap:wrap">
            ${i.site ? `<a class="chip" href="#/investigate?site=${esc(i.site)}">${icon('target', 'sm')} site ${esc(i.site)}</a>` : ''}
            ${i.role_name ? `<span class="chip" title="Inferred from hostname - configurable">${esc(i.role_name)}</span>` : ''}
            <span class="chip" title="Inferred from message format">${esc(i.platform || 'platform unknown')}</span>
            <span class="chip">${icon('clock', 'sm')} last message ${esc(ago(i.last, now))}</span>
            ${skew != null && Math.abs(skew) > 5 ? `<span class="sev warning">clock offset ${skew.toFixed(0)} s</span>` : ''}</div></div></div>
      <div class="grow"></div>${rangeSeg()}</div>

    <div class="grid">
      <div class="c3 card kpi"><div class="l">Messages (window)</div><div class="v num">${n(d.histogram ? Object.values(d.histogram.series).flat().reduce((a, b) => a + b, 0) : 0)}</div><div class="s">${n(i.n)} indexed in total</div></div>
      <div class="c3 card kpi"><div class="l">Warning or higher</div><div class="v num">${n(sig)}</div><div class="s">${d.categories.filter(c => c.sig).map(c => c.category).join(', ') || 'none'}</div></div>
      <div class="c3 card kpi"><div class="l">Findings</div><div class="v num">${d.findings.length}</div><div class="s">${h.worst ? 'worst: ' + h.worst : 'nothing noteworthy'}</div></div>
      <div class="c3 card kpi"><div class="l">Interfaces with events</div><div class="v num">${d.interfaces.length}</div><div class="s">${d.interfaces.filter(r => r.last_state === 'down').length} currently down (per logs)</div></div>

      <div class="card c7"><div class="hd"><h3>Findings on this device</h3></div><div class="bd" style="padding:6px 0" id="fl">${findingList(d.findings, now, 'No findings - this device looks healthy in this window')}</div></div>
      <div class="card c5"><div class="hd"><h3>Interfaces</h3><span class="muted" style="font-size:12px">state = last logged state</span></div>
        <div class="bd scroll" style="max-height:360px;padding-top:4px">${ifRows ? `<table class="tbl"><thead><tr><th>Interface</th><th>Class</th><th>State</th><th class="r">Downs</th><th class="r">Msgs</th><th>Last</th></tr></thead><tbody>${ifRows}</tbody></table>` : emptyState('No interface events')}</div></div>

      <div class="card c8"><div class="hd"><h3>Activity</h3><span class="grow"></span>${legend(['critical', 'major', 'warning', 'info', 'routine'])}</div><div class="bd"><div class="chart" id="hist"></div></div></div>
      <div class="c4" style="display:flex;flex-direction:column;gap:16px">
        <div class="card"><div class="hd"><h3>Top event codes</h3></div><div class="bd scroll" style="max-height:220px">
          ${d.codes.map(c => `<div style="display:flex;gap:8px;align-items:center;padding:3px 0;cursor:pointer" data-href="#/investigate?host=${esc(i.host)}&code=${esc(c.code)}">
            <span class="sigdot ${esc(c.signal)}"></span><span class="code" style="flex:1;overflow:hidden;text-overflow:ellipsis">${esc(c.code)}</span><b class="num">${n(c.n)}</b></div>`).join('')}</div></div>
        ${d.neighbors.length ? `<div class="card"><div class="hd"><h3>Routing neighbors</h3></div><div class="bd">${d.neighbors.map(r => `<div style="display:flex;gap:8px;padding:3px 0"><span class="chip">${esc(r.protocol)}</span><span class="mono" style="flex:1">${esc(r.neighbor)}</span><span class="sev ${r.state === 'down' ? 'critical' : r.state === 'up' ? 'good' : 'info'}">${esc(r.state || '?')}</span></div>`).join('')}</div></div>` : ''}
        ${d.site_peers.length ? `<div class="card"><div class="hd"><h3>Other devices at ${esc(i.site)}</h3></div><div class="bd">${d.site_peers.map(r => `<a href="#/device/${esc(r.host)}" style="display:flex;gap:8px;padding:2px 0;color:inherit"><span style="flex:1">${esc(r.host)}</span><span class="muted num">${n(r.sig)} warn+</span></a>`).join('')}</div></div>` : ''}
      </div>
    </div>
    <div class="section-title">All messages from ${esc(i.host)} <span class="line"></span></div>
    <div id="exp"></div></div>`;

  bindRange(main, () => go(location.hash));
  bindFindings(main.querySelector('#fl'));
  main.querySelectorAll('[data-href]').forEach(r => r.addEventListener('click', () => go(r.dataset.href)));
  const draw = () => timeline(main.querySelector('#hist'), d.histogram, {
    signals: ['critical', 'major', 'warning', 'info', 'routine'], height: 160, now,
    onSelect: (a, b) => go(`#/investigate?host=${i.host}&t0=${Math.floor(a)}&t1=${Math.ceil(b)}`),
  });
  draw();
  window.addEventListener('resize', draw);
  const stop = explorer(main.querySelector('#exp'), { host: i.host }, { fixed: ['host'], title: 'Message volume' });
  return () => { window.removeEventListener('resize', draw); stop && stop(); };
}
