
/* Idea Board — Visio (.vsdx) export and import (IdeaVisio). */
/* Parts saved by Microsoft Visio 2016 (from the BSD-licensed 'vsdx' Python package template),
   reused so exported files carry Visio's own style sheets and Dynamic connector master. */
const VISIO_TEMPLATE = {"document": "<VisioDocument xmlns='http://schemas.microsoft.com/office/visio/2012/main' xmlns:r='http://schemas.openxmlformats.org/officeDocument/2006/relationships' xml:space='preserve'><DocumentSettings TopPage='0' DefaultTextStyle='3' DefaultLineStyle='3' DefaultFillStyle='3' DefaultGuideStyle='4'><GlueSettings>9</GlueSettings><SnapSettings>65847</SnapSettings><SnapExtensions>34</SnapExtensions><SnapAngles/><DynamicGridEnabled>1</DynamicGridEnabled><ProtectStyles>0</ProtectStyles><ProtectShapes>0</ProtectShapes><ProtectMasters>0</ProtectMasters><ProtectBkgnds>0</ProtectBkgnds></DocumentSettings><Colors><ColorEntry IX='24' RGB='#7F7F7F'/><ColorEntry IX='25' RGB='#FFFFFF'/></Colors><FaceNames><FaceName NameU='Calibri' UnicodeRanges='-469750017 -1073732485 9 0' CharSets='536871423 0' Panose='2 15 5 2 2 2 4 3 2 4' Flags='325'/></FaceNames><StyleSheets><StyleSheet ID='0' NameU='No Style' IsCustomNameU='1' Name='No Style' IsCustomName='1'><Cell N='EnableLineProps' V='1'/><Cell N='EnableFillProps' V='1'/><Cell N='EnableTextProps' V='1'/><Cell N='HideForApply' V='0'/><Cell N='LineWeight' V='0.01041666666666667'/><Cell N='LineColor' V='0'/><Cell N='LinePattern' V='1'/><Cell N='Rounding' V='0'/><Cell N='EndArrowSize' V='2'/><Cell N='BeginArrow' V='0'/><Cell N='EndArrow' V='0'/><Cell N='LineCap' V='0'/><Cell N='BeginArrowSize' V='2'/><Cell N='LineColorTrans' V='0'/><Cell N='CompoundType' V='0'/><Cell N='FillForegnd' V='1'/><Cell N='FillBkgnd' V='0'/><Cell N='FillPattern' V='1'/><Cell N='ShdwForegnd' V='0'/><Cell N='ShdwPattern' V='0'/><Cell N='FillForegndTrans' V='0'/><Cell N='FillBkgndTrans' V='0'/><Cell N='ShdwForegndTrans' V='0'/><Cell N='ShapeShdwType' V='0'/><Cell N='ShapeShdwOffsetX' V='0'/><Cell N='ShapeShdwOffsetY' V='0'/><Cell N='ShapeShdwObliqueAngle' V='0'/><Cell N='ShapeShdwScaleFactor' V='1'/><Cell N='ShapeShdwBlur' V='0'/><Cell N='ShapeShdwShow' V='0'/><Cell N='LeftMargin' V='0'/><Cell N='RightMargin' V='0'/><Cell N='TopMargin' V='0'/><Cell N='BottomMargin' V='0'/><Cell N='VerticalAlign' V='1'/><Cell N='TextBkgnd' V='0'/><Cell N='DefaultTabStop' V='0.5905511811023622'/><Cell N='TextDirection' V='0'/><Cell N='TextBkgndTrans' V='0'/><Cell N='LockWidth' V='0'/><Cell N='LockHeight' V='0'/><Cell N='LockMoveX' V='0'/><Cell N='LockMoveY' V='0'/><Cell N='LockAspect' V='0'/><Cell N='LockDelete' V='0'/><Cell N='LockBegin' V='0'/><Cell N='LockEnd' V='0'/><Cell N='LockRotate' V='0'/><Cell N='LockCrop' V='0'/><Cell N='LockVtxEdit' V='0'/><Cell N='LockTextEdit' V='0'/><Cell N='LockFormat' V='0'/><Cell N='LockGroup' V='0'/><Cell N='LockCalcWH' V='0'/><Cell N='LockSelect' V='0'/><Cell N='LockCustProp' V='0'/><Cell N='LockFromGroupFormat' V='0'/><Cell N='LockThemeColors' V='0'/><Cell N='LockThemeEffects' V='0'/><Cell N='LockThemeConnectors' V='0'/><Cell N='LockThemeFonts' V='0'/><Cell N='LockThemeIndex' V='0'/><Cell N='LockReplace' V='0'/><Cell N='LockVariation' V='0'/><Cell N='NoObjHandles' V='0'/><Cell N='NonPrinting' V='0'/><Cell N='NoCtlHandles' V='0'/><Cell N='NoAlignBox' V='0'/><Cell N='UpdateAlignBox' V='0'/><Cell N='HideText' V='0'/><Cell N='DynFeedback' V='0'/><Cell N='GlueType' V='0'/><Cell N='WalkPreference' V='0'/><Cell N='BegTrigger' V='0' F='No Formula'/><Cell N='EndTrigger' V='0' F='No Formula'/><Cell N='ObjType' V='0'/><Cell N='Comment' V=''/><Cell N='IsDropSource' V='0'/><Cell N='NoLiveDynamics' V='0'/><Cell N='LocalizeMerge' V='0'/><Cell N='NoProofing' V='0'/><Cell N='Calendar' V='0'/><Cell N='LangID' V='en-GB'/><Cell N='ShapeKeywords' V=''/><Cell N='DropOnPageScale' V='1'/><Cell N='TheData' V='0' F='No Formula'/><Cell N='TheText' V='0' F='No Formula'/><Cell N='EventDblClick' V='0' F='No Formula'/><Cell N='EventXFMod' V='0' F='No Formula'/><Cell N='EventDrop' V='0' F='No Formula'/><Cell N='EventMultiDrop' V='0' F='No Formula'/><Cell N='HelpTopic' V=''/><Cell N='Copyright' V=''/><Cell N='LayerMember' V=''/><Cell N='XRulerDensity' V='32'/><Cell N='YRulerDensity' V='32'/><Cell N='XRulerOrigin' V='0'/><Cell N='YRulerOrigin' V='0'/><Cell N='XGridDensity' V='8'/><Cell N='YGridDensity' V='8'/><Cell N='XGridSpacing' V='0'/><Cell N='YGridSpacing' V='0'/><Cell N='XGridOrigin' V='0'/><Cell N='YGridOrigin' V='0'/><Cell N='Gamma' V='1'/><Cell N='Contrast' V='0.5'/><Cell N='Brightness' V='0.5'/><Cell N='Sharpen' V='0'/><Cell N='Blur' V='0'/><Cell N='Denoise' V='0'/><Cell N='Transparency' V='0'/><Cell N='SelectMode' V='1'/><Cell N='DisplayMode' V='2'/><Cell N='IsDropTarget' V='0'/><Cell N='IsSnapTarget' V='1'/><Cell N='IsTextEditTarget' V='1'/><Cell N='DontMoveChildren' V='0'/><Cell N='ShapePermeableX' V='0'/><Cell N='ShapePermeableY' V='0'/><Cell N='ShapePermeablePlace' V='0'/><Cell N='Relationships' V='0'/><Cell N='ShapeFixedCode' V='0'/><Cell N='ShapePlowCode' V='0'/><Cell N='ShapeRouteStyle' V='0'/><Cell N='ShapePlaceStyle' V='0'/><Cell N='ConFixedCode' V='0'/><Cell N='ConLineJumpCode' V='0'/><Cell N='ConLineJumpStyle' V='0'/><Cell N='ConLineJumpDirX' V='0'/><Cell N='ConLineJumpDirY' V='0'/><Cell N='ShapePlaceFlip' V='0'/><Cell N='ConLineRouteExt' V='0'/><Cell N='ShapeSplit' V='0'/><Cell N='ShapeSplittable' V='0'/><Cell N='DisplayLevel' V='0'/><Cell N='ResizePage' V='0'/><Cell N='EnableGrid' V='0'/><Cell N='DynamicsOff' V='0'/><Cell N='CtrlAsInput' V='0'/><Cell N='AvoidPageBreaks' V='0'/><Cell N='PlaceStyle' V='0'/><Cell N='RouteStyle' V='0'/><Cell N='PlaceDepth' V='0'/><Cell N='PlowCode' V='0'/><Cell N='LineJumpCode' V='1'/><Cell N='LineJumpStyle' V='0'/><Cell N='PageLineJumpDirX' V='0'/><Cell N='PageLineJumpDirY' V='0'/><Cell N='LineToNodeX' V='0.09842519685039369'/><Cell N='LineToNodeY' V='0.09842519685039369'/><Cell N='BlockSizeX' V='0.1968503937007874'/><Cell N='BlockSizeY' V='0.1968503937007874'/><Cell N='AvenueSizeX' V='0.2952755905511811'/><Cell N='AvenueSizeY' V='0.2952755905511811'/><Cell N='LineToLineX' V='0.09842519685039369'/><Cell N='LineToLineY' V='0.09842519685039369'/><Cell N='LineJumpFactorX' V='0.66666666666667'/><Cell N='LineJumpFactorY' V='0.66666666666667'/><Cell N='LineAdjustFrom' V='0'/><Cell N='LineAdjustTo' V='0'/><Cell N='PlaceFlip' V='0'/><Cell N='LineRouteExt' V='0'/><Cell N='PageShapeSplit' V='0'/><Cell N='PageLeftMargin' V='0.25'/><Cell N='PageRightMargin' V='0.25'/><Cell N='PageTopMargin' V='0.25'/><Cell N='PageBottomMargin' V='0.25'/><Cell N='ScaleX' V='1'/><Cell N='ScaleY' V='1'/><Cell N='PagesX' V='1'/><Cell N='PagesY' V='1'/><Cell N='CenterX' V='0'/><Cell N='CenterY' V='0'/><Cell N='OnPage' V='0'/><Cell N='PrintGrid' V='0'/><Cell N='PrintPageOrientation' V='1'/><Cell N='PaperKind' V='9'/><Cell N='PaperSource' V='7'/><Cell N='QuickStyleLineColor' V='100'/><Cell N='QuickStyleFillColor' V='100'/><Cell N='QuickStyleShadowColor' V='100'/><Cell N='QuickStyleFontColor' V='100'/><Cell N='QuickStyleLineMatrix' V='100'/><Cell N='QuickStyleFillMatrix' V='100'/><Cell N='QuickStyleEffectsMatrix' V='100'/><Cell N='QuickStyleFontMatrix' V='100'/><Cell N='QuickStyleType' V='0'/><Cell N='QuickStyleVariation' V='0'/><Cell N='LineGradientDir' V='0'/><Cell N='LineGradientAngle' V='1.5707963267949'/><Cell N='FillGradientDir' V='0'/><Cell N='FillGradientAngle' V='1.5707963267949'/><Cell N='LineGradientEnabled' V='0'/><Cell N='FillGradientEnabled' V='0'/><Cell N='RotateGradientWithShape' V='1'/><Cell N='UseGroupGradient' V='0'/><Cell N='BevelTopType' V='0'/><Cell N='BevelTopWidth' V='0'/><Cell N='BevelTopHeight' V='0'/><Cell N='BevelBottomType' V='0'/><Cell N='BevelBottomWidth' V='0'/><Cell N='BevelBottomHeight' V='0'/><Cell N='BevelDepthColor' V='1'/><Cell N='BevelDepthSize' V='0'/><Cell N='BevelContourColor' V='0'/><Cell N='BevelContourSize' V='0'/><Cell N='BevelMaterialType' V='0'/><Cell N='BevelLightingType' V='0'/><Cell N='BevelLightingAngle' V='0'/><Cell N='RotationXAngle' V='0'/><Cell N='RotationYAngle' V='0'/><Cell N='RotationZAngle' V='0'/><Cell N='RotationType' V='0'/><Cell N='Perspective' V='0'/><Cell N='DistanceFromGround' V='0'/><Cell N='KeepTextFlat' V='0'/><Cell N='ReflectionTrans' V='0'/><Cell N='ReflectionSize' V='0'/><Cell N='ReflectionDist' V='0'/><Cell N='ReflectionBlur' V='0'/><Cell N='GlowColor' V='1'/><Cell N='GlowColorTrans' V='0'/><Cell N='GlowSize' V='0'/><Cell N='SoftEdgesSize' V='0'/><Cell N='SketchSeed' V='0'/><Cell N='SketchEnabled' V='0'/><Cell N='SketchAmount' V='5'/><Cell N='SketchLineWeight' V='0.04166666666666666' U='PT'/><Cell N='SketchLineChange' V='0.14'/><Cell N='SketchFillChange' V='0.1'/><Cell N='ColorSchemeIndex' V='0'/><Cell N='EffectSchemeIndex' V='0'/><Cell N='ConnectorSchemeIndex' V='0'/><Cell N='FontSchemeIndex' V='0'/><Cell N='ThemeIndex' V='0'/><Cell N='VariationColorIndex' V='0'/><Cell N='VariationStyleIndex' V='0'/><Cell N='EmbellishmentIndex' V='0'/><Cell N='ReplaceLockShapeData' V='0'/><Cell N='ReplaceLockText' V='0'/><Cell N='ReplaceLockFormat' V='0'/><Cell N='ReplaceCopyCells' V='0' U='BOOL' F='No Formula'/><Cell N='PageWidth' V='0' F='No Formula'/><Cell N='PageHeight' V='0' F='No Formula'/><Cell N='ShdwOffsetX' V='0' F='No Formula'/><Cell N='ShdwOffsetY' V='0' F='No Formula'/><Cell N='PageScale' V='0' U='MM' F='No Formula'/><Cell N='DrawingScale' V='0' U='MM' F='No Formula'/><Cell N='DrawingSizeType' V='0' F='No Formula'/><Cell N='DrawingScaleType' V='0' F='No Formula'/><Cell N='InhibitSnap' V='0' F='No Formula'/><Cell N='PageLockReplace' V='0' U='BOOL' F='No Formula'/><Cell N='PageLockDuplicate' V='0' U='BOOL' F='No Formula'/><Cell N='UIVisibility' V='0' F='No Formula'/><Cell N='ShdwType' V='0' F='No Formula'/><Cell N='ShdwObliqueAngle' V='0' F='No Formula'/><Cell N='ShdwScaleFactor' V='0' F='No Formula'/><Cell N='DrawingResizeType' V='0' F='No Formula'/><Section N='Character'><Row IX='0'><Cell N='Font' V='Calibri'/><Cell N='Color' V='0'/><Cell N='Style' V='0'/><Cell N='Case' V='0'/><Cell N='Pos' V='0'/><Cell N='FontScale' V='1'/><Cell N='Size' V='0.1666666666666667'/><Cell N='DblUnderline' V='0'/><Cell N='Overline' V='0'/><Cell N='Strikethru' V='0'/><Cell N='DoubleStrikethrough' V='0'/><Cell N='Letterspace' V='0'/><Cell N='ColorTrans' V='0'/><Cell N='AsianFont' V='0'/><Cell N='ComplexScriptFont' V='0'/><Cell N='ComplexScriptSize' V='-1'/><Cell N='LangID' V='en-GB'/></Row></Section><Section N='Paragraph'><Row IX='0'><Cell N='IndFirst' V='0'/><Cell N='IndLeft' V='0'/><Cell N='IndRight' V='0'/><Cell N='SpLine' V='-1.2'/><Cell N='SpBefore' V='0'/><Cell N='SpAfter' V='0'/><Cell N='HorzAlign' V='1'/><Cell N='Bullet' V='0'/><Cell N='BulletStr' V=''/><Cell N='BulletFont' V='0'/><Cell N='BulletFontSize' V='-1'/><Cell N='TextPosAfterBullet' V='0'/><Cell N='Flags' V='0'/></Row></Section><Section N='Tabs'><Row IX='0'/></Section><Section N='LineGradient'><Row IX='0'><Cell N='GradientStopColor' V='1'/><Cell N='GradientStopColorTrans' V='0'/><Cell N='GradientStopPosition' V='0'/></Row></Section><Section N='FillGradient'><Row IX='0'><Cell N='GradientStopColor' V='1'/><Cell N='GradientStopColorTrans' V='0'/><Cell N='GradientStopPosition' V='0'/></Row></Section></StyleSheet><StyleSheet ID='1' NameU='Text Only' IsCustomNameU='1' Name='Text Only' IsCustomName='1' LineStyle='3' FillStyle='3' TextStyle='3'><Cell N='EnableLineProps' V='1'/><Cell N='EnableFillProps' V='1'/><Cell N='EnableTextProps' V='1'/><Cell N='HideForApply' V='0'/><Cell N='LineWeight' V='Themed' F='Inh'/><Cell N='LineColor' V='Themed' F='Inh'/><Cell N='LinePattern' V='Themed' F='Inh'/><Cell N='Rounding' V='Themed' F='Inh'/><Cell N='EndArrowSize' V='2' F='Inh'/><Cell N='BeginArrow' V='0' F='Inh'/><Cell N='EndArrow' V='0' F='Inh'/><Cell N='LineCap' V='Themed' F='Inh'/><Cell N='BeginArrowSize' V='2' F='Inh'/><Cell N='LineColorTrans' V='Themed' F='Inh'/><Cell N='CompoundType' V='Themed' F='Inh'/><Cell N='FillForegnd' V='Themed' F='Inh'/><Cell N='FillBkgnd' V='Themed' F='Inh'/><Cell N='FillPattern' V='Themed' F='Inh'/><Cell N='ShdwForegnd' V='Themed' F='Inh'/><Cell N='ShdwPattern' V='Themed' F='Inh'/><Cell N='FillForegndTrans' V='Themed' F='Inh'/><Cell N='FillBkgndTrans' V='Themed' F='Inh'/><Cell N='ShdwForegndTrans' V='Themed' F='Inh'/><Cell N='ShapeShdwType' V='Themed' F='Inh'/><Cell N='ShapeShdwOffsetX' V='Themed' F='Inh'/><Cell N='ShapeShdwOffsetY' V='Themed' F='Inh'/><Cell N='ShapeShdwObliqueAngle' V='Themed' F='Inh'/><Cell N='ShapeShdwScaleFactor' V='Themed' F='Inh'/><Cell N='ShapeShdwBlur' V='Themed' F='Inh'/><Cell N='ShapeShdwShow' V='0' F='Inh'/><Cell N='LeftMargin' V='0'/><Cell N='RightMargin' V='0'/><Cell N='TopMargin' V='0'/><Cell N='BottomMargin' V='0'/><Cell N='VerticalAlign' V='0'/><Cell N='TextBkgnd' V='0'/><Cell N='DefaultTabStop' V='0.5905511811023622' F='Inh'/><Cell N='TextDirection' V='0' F='Inh'/><Cell N='TextBkgndTrans' V='0' F='Inh'/><Cell N='LineGradientDir' V='Themed' F='Inh'/><Cell N='LineGradientAngle' V='Themed' F='Inh'/><Cell N='FillGradientDir' V='Themed' F='Inh'/><Cell N='FillGradientAngle' V='Themed' F='Inh'/><Cell N='LineGradientEnabled' V='Themed' F='Inh'/><Cell N='FillGradientEnabled' V='Themed' F='Inh'/><Cell N='RotateGradientWithShape' V='Themed' F='Inh'/><Cell N='UseGroupGradient' V='Themed' F='Inh'/><Section N='Paragraph'><Row IX='0'><Cell N='IndFirst' V='0' F='Inh'/><Cell N='IndLeft' V='0' F='Inh'/><Cell N='IndRight' V='0' F='Inh'/><Cell N='SpLine' V='-1.2' F='Inh'/><Cell N='SpBefore' V='0' F='Inh'/><Cell N='SpAfter' V='0' F='Inh'/><Cell N='HorzAlign' V='0'/><Cell N='Bullet' V='0' F='Inh'/><Cell N='BulletStr' V='' F='Inh'/><Cell N='BulletFont' V='0' F='Inh'/><Cell N='BulletFontSize' V='-1' F='Inh'/><Cell N='TextPosAfterBullet' V='0' F='Inh'/><Cell N='Flags' V='0' F='Inh'/></Row></Section></StyleSheet><StyleSheet ID='2' NameU='None' IsCustomNameU='1' Name='None' IsCustomName='1' LineStyle='3' FillStyle='3' TextStyle='3'><Cell N='EnableLineProps' V='1'/><Cell N='EnableFillProps' V='1'/><Cell N='EnableTextProps' V='1'/><Cell N='HideForApply' V='0'/><Cell N='LineWeight' V='Themed' F='Inh'/><Cell N='LineColor' V='Themed' F='Inh'/><Cell N='LinePattern' V='0'/><Cell N='Rounding' V='Themed' F='Inh'/><Cell N='EndArrowSize' V='2' F='Inh'/><Cell N='BeginArrow' V='0' F='Inh'/><Cell N='EndArrow' V='0' F='Inh'/><Cell N='LineCap' V='Themed' F='Inh'/><Cell N='BeginArrowSize' V='2' F='Inh'/><Cell N='LineColorTrans' V='Themed' F='Inh'/><Cell N='CompoundType' V='Themed' F='Inh'/><Cell N='FillForegnd' V='Themed' F='Inh'/><Cell N='FillBkgnd' V='Themed' F='Inh'/><Cell N='FillPattern' V='0'/><Cell N='ShdwForegnd' V='Themed' F='Inh'/><Cell N='ShdwPattern' V='Themed' F='Inh'/><Cell N='FillForegndTrans' V='Themed' F='Inh'/><Cell N='FillBkgndTrans' V='Themed' F='Inh'/><Cell N='ShdwForegndTrans' V='Themed' F='Inh'/><Cell N='ShapeShdwType' V='Themed' F='Inh'/><Cell N='ShapeShdwOffsetX' V='Themed' F='Inh'/><Cell N='ShapeShdwOffsetY' V='Themed' F='Inh'/><Cell N='ShapeShdwObliqueAngle' V='Themed' F='Inh'/><Cell N='ShapeShdwScaleFactor' V='Themed' F='Inh'/><Cell N='ShapeShdwBlur' V='Themed' F='Inh'/><Cell N='ShapeShdwShow' V='0' F='Inh'/><Cell N='LineGradientDir' V='Themed' F='Inh'/><Cell N='LineGradientAngle' V='Themed' F='Inh'/><Cell N='FillGradientDir' V='Themed' F='Inh'/><Cell N='FillGradientAngle' V='Themed' F='Inh'/><Cell N='LineGradientEnabled' V='0'/><Cell N='FillGradientEnabled' V='0'/><Cell N='RotateGradientWithShape' V='Themed' F='Inh'/><Cell N='UseGroupGradient' V='Themed' F='Inh'/><Cell N='QuickStyleLineColor' V='100' F='Inh'/><Cell N='QuickStyleFillColor' V='100' F='Inh'/><Cell N='QuickStyleShadowColor' V='100' F='Inh'/><Cell N='QuickStyleFontColor' V='100' F='Inh'/><Cell N='QuickStyleLineMatrix' V='100' F='Inh'/><Cell N='QuickStyleFillMatrix' V='100' F='Inh'/><Cell N='QuickStyleEffectsMatrix' V='0' F='GUARD(0)'/><Cell N='QuickStyleFontMatrix' V='100' F='Inh'/><Cell N='QuickStyleType' V='0' F='Inh'/><Cell N='QuickStyleVariation' V='2'/></StyleSheet><StyleSheet ID='3' NameU='Normal' IsCustomNameU='1' Name='Normal' IsCustomName='1' LineStyle='6' FillStyle='6' TextStyle='6'><Cell N='EnableLineProps' V='1'/><Cell N='EnableFillProps' V='1'/><Cell N='EnableTextProps' V='1'/><Cell N='HideForApply' V='0'/><Cell N='LeftMargin' V='0.05555555555555555' U='PT'/><Cell N='RightMargin' V='0.05555555555555555' U='PT'/><Cell N='TopMargin' V='0.05555555555555555' U='PT'/><Cell N='BottomMargin' V='0.05555555555555555' U='PT'/><Cell N='VerticalAlign' V='1' F='Inh'/><Cell N='TextBkgnd' V='0' F='Inh'/><Cell N='DefaultTabStop' V='0.5905511811023622' F='Inh'/><Cell N='TextDirection' V='0' F='Inh'/><Cell N='TextBkgndTrans' V='0' F='Inh'/></StyleSheet><StyleSheet ID='4' NameU='Guide' IsCustomNameU='1' Name='Guide' IsCustomName='1' LineStyle='3' FillStyle='3' TextStyle='3'><Cell N='EnableLineProps' V='1'/><Cell N='EnableFillProps' V='1'/><Cell N='EnableTextProps' V='1'/><Cell N='HideForApply' V='0'/><Cell N='LineWeight' V='0' U='PT'/><Cell N='LineColor' V='#7f7f7f'/><Cell N='LinePattern' V='23'/><Cell N='Rounding' V='Themed' F='Inh'/><Cell N='EndArrowSize' V='2' F='Inh'/><Cell N='BeginArrow' V='0' F='Inh'/><Cell N='EndArrow' V='0' F='Inh'/><Cell N='LineCap' V='Themed' F='Inh'/><Cell N='BeginArrowSize' V='2' F='Inh'/><Cell N='LineColorTrans' V='Themed' F='Inh'/><Cell N='CompoundType' V='Themed' F='Inh'/><Cell N='FillForegnd' V='Themed' F='Inh'/><Cell N='FillBkgnd' V='Themed' F='Inh'/><Cell N='FillPattern' V='0'/><Cell N='ShdwForegnd' V='Themed' F='Inh'/><Cell N='ShdwPattern' V='Themed' F='Inh'/><Cell N='FillForegndTrans' V='Themed' F='Inh'/><Cell N='FillBkgndTrans' V='Themed' F='Inh'/><Cell N='ShdwForegndTrans' V='Themed' F='Inh'/><Cell N='ShapeShdwType' V='Themed' F='Inh'/><Cell N='ShapeShdwOffsetX' V='Themed' F='Inh'/><Cell N='ShapeShdwOffsetY' V='Themed' F='Inh'/><Cell N='ShapeShdwObliqueAngle' V='Themed' F='Inh'/><Cell N='ShapeShdwScaleFactor' V='Themed' F='Inh'/><Cell N='ShapeShdwBlur' V='Themed' F='Inh'/><Cell N='ShapeShdwShow' V='0' F='Inh'/><Cell N='LineGradientDir' V='Themed' F='Inh'/><Cell N='LineGradientAngle' V='Themed' F='Inh'/><Cell N='FillGradientDir' V='Themed' F='Inh'/><Cell N='FillGradientAngle' V='Themed' F='Inh'/><Cell N='LineGradientEnabled' V='0'/><Cell N='FillGradientEnabled' V='0'/><Cell N='RotateGradientWithShape' V='Themed' F='Inh'/><Cell N='UseGroupGradient' V='Themed' F='Inh'/><Cell N='LeftMargin' V='0.05555555555555555' U='PT' F='Inh'/><Cell N='RightMargin' V='0.05555555555555555' U='PT' F='Inh'/><Cell N='TopMargin' V='0'/><Cell N='BottomMargin' V='0'/><Cell N='VerticalAlign' V='2'/><Cell N='TextBkgnd' V='0' F='Inh'/><Cell N='DefaultTabStop' V='0.5905511811023622' F='Inh'/><Cell N='TextDirection' V='0' F='Inh'/><Cell N='TextBkgndTrans' V='0' F='Inh'/><Cell N='NoObjHandles' V='0' F='Inh'/><Cell N='NonPrinting' V='1'/><Cell N='NoCtlHandles' V='0' F='Inh'/><Cell N='NoAlignBox' V='0' F='Inh'/><Cell N='UpdateAlignBox' V='0' F='Inh'/><Cell N='HideText' V='0' F='Inh'/><Cell N='DynFeedback' V='0' F='Inh'/><Cell N='GlueType' V='0' F='Inh'/><Cell N='WalkPreference' V='0' F='Inh'/><Cell N='BegTrigger' V='0' F='No Formula'/><Cell N='EndTrigger' V='0' F='No Formula'/><Cell N='ObjType' V='0' F='Inh'/><Cell N='Comment' V='' F='Inh'/><Cell N='IsDropSource' V='0' F='Inh'/><Cell N='NoLiveDynamics' V='0' F='Inh'/><Cell N='LocalizeMerge' V='0' F='Inh'/><Cell N='NoProofing' V='0' F='Inh'/><Cell N='Calendar' V='0' F='Inh'/><Cell N='LangID' V='en-GB' F='Inh'/><Cell N='ShapeKeywords' V='' F='Inh'/><Cell N='DropOnPageScale' V='1' F='Inh'/><Cell N='ShapePermeableX' V='1'/><Cell N='ShapePermeableY' V='1'/><Cell N='ShapePermeablePlace' V='1'/><Cell N='Relationships' V='0' F='Inh'/><Cell N='ShapeFixedCode' V='0' F='Inh'/><Cell N='ShapePlowCode' V='0' F='Inh'/><Cell N='ShapeRouteStyle' V='0' F='Inh'/><Cell N='ShapePlaceStyle' V='0' F='Inh'/><Cell N='ConFixedCode' V='0' F='Inh'/><Cell N='ConLineJumpCode' V='0' F='Inh'/><Cell N='ConLineJumpStyle' V='0' F='Inh'/><Cell N='ConLineJumpDirX' V='0' F='Inh'/><Cell N='ConLineJumpDirY' V='0' F='Inh'/><Cell N='ShapePlaceFlip' V='0' F='Inh'/><Cell N='ConLineRouteExt' V='0' F='Inh'/><Cell N='ShapeSplit' V='0' F='Inh'/><Cell N='ShapeSplittable' V='0' F='Inh'/><Cell N='DisplayLevel' V='0' F='Inh'/><Section N='Character'><Row IX='0'><Cell N='Font' V='Themed' F='Inh'/><Cell N='Color' V='4'/><Cell N='Style' V='Themed' F='Inh'/><Cell N='Case' V='0' F='Inh'/><Cell N='Pos' V='0' F='Inh'/><Cell N='FontScale' V='1' F='Inh'/><Cell N='Size' V='0.125'/><Cell N='DblUnderline' V='0' F='Inh'/><Cell N='Overline' V='0' F='Inh'/><Cell N='Strikethru' V='0' F='Inh'/><Cell N='DoubleStrikethrough' V='0' F='Inh'/><Cell N='Letterspace' V='0' F='Inh'/><Cell N='ColorTrans' V='0' F='Inh'/><Cell N='AsianFont' V='Themed' F='Inh'/><Cell N='ComplexScriptFont' V='Themed' F='Inh'/><Cell N='ComplexScriptSize' V='-1' F='Inh'/><Cell N='LangID' V='en-GB' F='Inh'/></Row></Section></StyleSheet><StyleSheet ID='6' NameU='Theme' IsCustomNameU='1' Name='Theme' IsCustomName='1' LineStyle='0' FillStyle='0' TextStyle='0'><Cell N='EnableLineProps' V='1'/><Cell N='EnableFillProps' V='1'/><Cell N='EnableTextProps' V='1'/><Cell N='HideForApply' V='0'/><Cell N='LineWeight' V='Themed' F='THEMEVAL()'/><Cell N='LineColor' V='Themed' F='THEMEVAL()'/><Cell N='LinePattern' V='Themed' F='THEMEVAL()'/><Cell N='Rounding' V='Themed' F='THEMEVAL()'/><Cell N='EndArrowSize' V='2' F='Inh'/><Cell N='BeginArrow' V='0' F='Inh'/><Cell N='EndArrow' V='0' F='Inh'/><Cell N='LineCap' V='Themed' F='THEMEVAL()'/><Cell N='BeginArrowSize' V='2' F='Inh'/><Cell N='LineColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='CompoundType' V='Themed' F='THEMEVAL()'/><Cell N='FillForegnd' V='Themed' F='THEMEVAL()'/><Cell N='FillBkgnd' V='Themed' F='THEMEVAL()'/><Cell N='FillPattern' V='Themed' F='THEMEVAL()'/><Cell N='ShdwForegnd' V='Themed' F='THEMEVAL()'/><Cell N='ShdwPattern' V='Themed' F='THEMEVAL()'/><Cell N='FillForegndTrans' V='Themed' F='THEMEVAL()'/><Cell N='FillBkgndTrans' V='Themed' F='THEMEVAL()'/><Cell N='ShdwForegndTrans' V='Themed' F='THEMEVAL()'/><Cell N='ShapeShdwType' V='Themed' F='THEMEVAL()'/><Cell N='ShapeShdwOffsetX' V='Themed' F='THEMEVAL()'/><Cell N='ShapeShdwOffsetY' V='Themed' F='THEMEVAL()'/><Cell N='ShapeShdwObliqueAngle' V='Themed' F='THEMEVAL()'/><Cell N='ShapeShdwScaleFactor' V='Themed' F='THEMEVAL()'/><Cell N='ShapeShdwBlur' V='Themed' F='THEMEVAL()'/><Cell N='ShapeShdwShow' V='0' F='Inh'/><Cell N='LineGradientDir' V='Themed' F='THEMEVAL()'/><Cell N='LineGradientAngle' V='Themed' F='THEMEVAL()'/><Cell N='FillGradientDir' V='Themed' F='THEMEVAL()'/><Cell N='FillGradientAngle' V='Themed' F='THEMEVAL()'/><Cell N='LineGradientEnabled' V='Themed' F='THEMEVAL()'/><Cell N='FillGradientEnabled' V='Themed' F='THEMEVAL()'/><Cell N='RotateGradientWithShape' V='Themed' F='THEMEVAL()'/><Cell N='UseGroupGradient' V='Themed' F='THEMEVAL()'/><Cell N='BevelTopType' V='Themed' F='THEMEVAL()'/><Cell N='BevelTopWidth' V='Themed' F='THEMEVAL()'/><Cell N='BevelTopHeight' V='Themed' F='THEMEVAL()'/><Cell N='BevelBottomType' V='0' F='Inh'/><Cell N='BevelBottomWidth' V='0' F='Inh'/><Cell N='BevelBottomHeight' V='0' F='Inh'/><Cell N='BevelDepthColor' V='1' F='Inh'/><Cell N='BevelDepthSize' V='0' F='Inh'/><Cell N='BevelContourColor' V='Themed' F='THEMEVAL()'/><Cell N='BevelContourSize' V='Themed' F='THEMEVAL()'/><Cell N='BevelMaterialType' V='Themed' F='THEMEVAL()'/><Cell N='BevelLightingType' V='Themed' F='THEMEVAL()'/><Cell N='BevelLightingAngle' V='Themed' F='THEMEVAL()'/><Cell N='ReflectionTrans' V='Themed' F='THEMEVAL()'/><Cell N='ReflectionSize' V='Themed' F='THEMEVAL()'/><Cell N='ReflectionDist' V='Themed' F='THEMEVAL()'/><Cell N='ReflectionBlur' V='Themed' F='THEMEVAL()'/><Cell N='GlowColor' V='Themed' F='THEMEVAL()'/><Cell N='GlowColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GlowSize' V='Themed' F='THEMEVAL()'/><Cell N='SoftEdgesSize' V='Themed' F='THEMEVAL()'/><Cell N='SketchSeed' V='0' F='Inh'/><Cell N='SketchEnabled' V='Themed' F='THEMEVAL()'/><Cell N='SketchAmount' V='Themed' F='THEMEVAL()'/><Cell N='SketchLineWeight' V='Themed' F='THEMEVAL()'/><Cell N='SketchLineChange' V='Themed' F='THEMEVAL()'/><Cell N='SketchFillChange' V='Themed' F='THEMEVAL()'/><Cell N='QuickStyleLineColor' V='100'/><Cell N='QuickStyleFillColor' V='100'/><Cell N='QuickStyleShadowColor' V='100'/><Cell N='QuickStyleFontColor' V='100'/><Cell N='QuickStyleLineMatrix' V='100'/><Cell N='QuickStyleFillMatrix' V='100'/><Cell N='QuickStyleEffectsMatrix' V='100'/><Cell N='QuickStyleFontMatrix' V='100'/><Cell N='QuickStyleType' V='0' F='Inh'/><Cell N='QuickStyleVariation' V='0' F='Inh'/><Cell N='ColorSchemeIndex' V='65534'/><Cell N='EffectSchemeIndex' V='65534'/><Cell N='ConnectorSchemeIndex' V='65534'/><Cell N='FontSchemeIndex' V='65534'/><Cell N='ThemeIndex' V='65534'/><Cell N='VariationColorIndex' V='65534'/><Cell N='VariationStyleIndex' V='65534'/><Cell N='EmbellishmentIndex' V='65534'/><Section N='Character'><Row IX='0'><Cell N='Font' V='Themed' F='THEMEVAL()'/><Cell N='Color' V='Themed' F='THEMEVAL()'/><Cell N='Style' V='Themed' F='THEMEVAL()'/><Cell N='Case' V='0' F='Inh'/><Cell N='Pos' V='0' F='Inh'/><Cell N='FontScale' V='1' F='Inh'/><Cell N='Size' V='0.1666666666666667' F='Inh'/><Cell N='DblUnderline' V='0' F='Inh'/><Cell N='Overline' V='0' F='Inh'/><Cell N='Strikethru' V='0' F='Inh'/><Cell N='DoubleStrikethrough' V='0' F='Inh'/><Cell N='Letterspace' V='0' F='Inh'/><Cell N='ColorTrans' V='0' F='Inh'/><Cell N='AsianFont' V='Themed' F='THEMEVAL()'/><Cell N='ComplexScriptFont' V='Themed' F='THEMEVAL()'/><Cell N='ComplexScriptSize' V='-1' F='Inh'/><Cell N='LangID' V='en-GB' F='Inh'/></Row></Section><Section N='FillGradient'><Row IX='0'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='1'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='2'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='3'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='4'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='5'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='6'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='7'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='8'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='9'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row></Section><Section N='LineGradient'><Row IX='0'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='1'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='2'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='3'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='4'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='5'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='6'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='7'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='8'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row><Row IX='9'><Cell N='GradientStopColor' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopColorTrans' V='Themed' F='THEMEVAL()'/><Cell N='GradientStopPosition' V='Themed' F='THEMEVAL()'/></Row></Section></StyleSheet><StyleSheet ID='7' NameU='Connector' IsCustomNameU='1' Name='Connector' IsCustomName='1' LineStyle='3' FillStyle='3' TextStyle='3'><Cell N='EnableLineProps' V='1'/><Cell N='EnableFillProps' V='1'/><Cell N='EnableTextProps' V='1'/><Cell N='HideForApply' V='0'/><Cell N='LeftMargin' V='0.05555555555555555' U='PT' F='Inh'/><Cell N='RightMargin' V='0.05555555555555555' U='PT' F='Inh'/><Cell N='TopMargin' V='0.05555555555555555' U='PT' F='Inh'/><Cell N='BottomMargin' V='0.05555555555555555' U='PT' F='Inh'/><Cell N='VerticalAlign' V='1' F='Inh'/><Cell N='TextBkgnd' V='#ffffff' F='THEMEGUARD(THEMEVAL(\"BackgroundColor\")+1)'/><Cell N='DefaultTabStop' V='0.5905511811023622' F='Inh'/><Cell N='TextDirection' V='0' F='Inh'/><Cell N='TextBkgndTrans' V='0' F='Inh'/><Cell N='QuickStyleLineColor' V='100'/><Cell N='QuickStyleFillColor' V='100'/><Cell N='QuickStyleShadowColor' V='100'/><Cell N='QuickStyleFontColor' V='100'/><Cell N='QuickStyleLineMatrix' V='1'/><Cell N='QuickStyleFillMatrix' V='1'/><Cell N='QuickStyleEffectsMatrix' V='1'/><Cell N='QuickStyleFontMatrix' V='1'/><Cell N='QuickStyleType' V='0'/><Cell N='QuickStyleVariation' V='0'/><Cell N='LineWeight' V='Themed' F='Inh'/><Cell N='LineColor' V='Themed' F='Inh'/><Cell N='LinePattern' V='Themed' F='Inh'/><Cell N='Rounding' V='Themed' F='Inh'/><Cell N='EndArrowSize' V='Themed' F='THEMEVAL()'/><Cell N='BeginArrow' V='Themed' F='THEMEVAL()'/><Cell N='EndArrow' V='Themed' F='THEMEVAL()'/><Cell N='LineCap' V='Themed' F='Inh'/><Cell N='BeginArrowSize' V='Themed' F='THEMEVAL()'/><Cell N='LineColorTrans' V='Themed' F='Inh'/><Cell N='CompoundType' V='Themed' F='Inh'/><Cell N='NoObjHandles' V='0' F='Inh'/><Cell N='NonPrinting' V='0' F='Inh'/><Cell N='NoCtlHandles' V='0' F='Inh'/><Cell N='NoAlignBox' V='0' F='Inh'/><Cell N='UpdateAlignBox' V='0' F='Inh'/><Cell N='HideText' V='0' F='Inh'/><Cell N='DynFeedback' V='0' F='Inh'/><Cell N='GlueType' V='0' F='Inh'/><Cell N='WalkPreference' V='0' F='Inh'/><Cell N='BegTrigger' V='0' F='No Formula'/><Cell N='EndTrigger' V='0' F='No Formula'/><Cell N='ObjType' V='0' F='Inh'/><Cell N='Comment' V='' F='Inh'/><Cell N='IsDropSource' V='0' F='Inh'/><Cell N='NoLiveDynamics' V='0' F='Inh'/><Cell N='LocalizeMerge' V='0' F='Inh'/><Cell N='NoProofing' V='0' F='Inh'/><Cell N='Calendar' V='0' F='Inh'/><Cell N='LangID' V='en-GB' F='Inh'/><Cell N='ShapeKeywords' V='' F='Inh'/><Cell N='DropOnPageScale' V='1' F='Inh'/><Section N='Character'><Row IX='0'><Cell N='Font' V='Themed' F='Inh'/><Cell N='Color' V='Themed' F='Inh'/><Cell N='Style' V='Themed' F='Inh'/><Cell N='Case' V='0' F='Inh'/><Cell N='Pos' V='0' F='Inh'/><Cell N='FontScale' V='1' F='Inh'/><Cell N='Size' V='0.1111111111111111'/><Cell N='DblUnderline' V='0' F='Inh'/><Cell N='Overline' V='0' F='Inh'/><Cell N='Strikethru' V='0' F='Inh'/><Cell N='DoubleStrikethrough' V='0' F='Inh'/><Cell N='Letterspace' V='0' F='Inh'/><Cell N='ColorTrans' V='0' F='Inh'/><Cell N='AsianFont' V='Themed' F='Inh'/><Cell N='ComplexScriptFont' V='Themed' F='Inh'/><Cell N='ComplexScriptSize' V='-1' F='Inh'/><Cell N='LangID' V='en-GB' F='Inh'/></Row></Section></StyleSheet></StyleSheets><DocumentSheet NameU='TheDoc' IsCustomNameU='1' Name='TheDoc' IsCustomName='1' LineStyle='0' FillStyle='0' TextStyle='0'><Cell N='OutputFormat' V='0'/><Cell N='LockPreview' V='0'/><Cell N='AddMarkup' V='0'/><Cell N='ViewMarkup' V='0'/><Cell N='DocLockReplace' V='0' U='BOOL'/><Cell N='NoCoauth' V='0' U='BOOL'/><Cell N='DocLockDuplicatePage' V='0' U='BOOL'/><Cell N='PreviewQuality' V='0'/><Cell N='PreviewScope' V='0'/><Cell N='DocLangID' V='en-GB'/><Section N='User'><Row N='msvNoAutoConnect'><Cell N='Value' V='1'/><Cell N='Prompt' V='' F='No Formula'/></Row></Section></DocumentSheet></VisioDocument>", "masters": "<Masters xmlns='http://schemas.microsoft.com/office/visio/2012/main' xmlns:r='http://schemas.openxmlformats.org/officeDocument/2006/relationships' xml:space='preserve'><Master ID='2' NameU='Dynamic connector' IsCustomNameU='1' Name='Dynamic connector' IsCustomName='1' Prompt='This connector automatically routes between the shapes it connects.' IconSize='1' AlignName='2' MatchByName='1' IconUpdate='0' UniqueID='{002A9508-0000-0000-8E40-00608CF305B2}' BaseID='{F7290A45-E3AD-11D2-AE4F-006008C9F5A9}' PatternFlags='0' Hidden='0' MasterType='0'><PageSheet LineStyle='0' FillStyle='0' TextStyle='0'><Cell N='PageWidth' V='3.937007874015748'/><Cell N='PageHeight' V='3.937007874015748'/><Cell N='ShdwOffsetX' V='0.1181102362204724'/><Cell N='ShdwOffsetY' V='-0.1181102362204724'/><Cell N='PageScale' V='0.03937007874015748' U='MM'/><Cell N='DrawingScale' V='0.03937007874015748' U='MM'/><Cell N='DrawingSizeType' V='4'/><Cell N='DrawingScaleType' V='0'/><Cell N='InhibitSnap' V='0'/><Cell N='PageLockReplace' V='0' U='BOOL'/><Cell N='PageLockDuplicate' V='0' U='BOOL'/><Cell N='UIVisibility' V='0'/><Cell N='ShdwType' V='0'/><Cell N='ShdwObliqueAngle' V='0'/><Cell N='ShdwScaleFactor' V='1'/><Cell N='DrawingResizeType' V='0'/><Section N='Layer'><Row IX='0'><Cell N='Name' V='Connector'/><Cell N='Color' V='255'/><Cell N='Status' V='0'/><Cell N='Visible' V='1'/><Cell N='Print' V='1'/><Cell N='Active' V='0'/><Cell N='Lock' V='0'/><Cell N='Snap' V='1'/><Cell N='Glue' V='1'/><Cell N='NameUniv' V='Connector'/><Cell N='ColorTrans' V='0'/></Row></Section></PageSheet><Icon>\nAAABAAEAICAQIwAAAADoAgAAFgAAACgAAAAgAAAAQAAAAAEABAAAAAAAgAIAAAAAAAAAAAAAAAAAA\nAAAAAAAAAAAAACAAACAAAAAgIAAgAAAAIAAgACAgAAAgICAAMDAwAAAAP8AAP8AAAD//wD/AAAA/w\nD/AP//AAD///8AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\nAAAAAAAeHh4eAAAAAAAAAAAAAAAAIAAAAcAAAAAAAAAAAAAADNzMzAIAAAAAAAAAAAAAAAAAAAwBw\nAAAAAAAAAAAAAw///wMAgAAAAAAAAAAAAHgP//8IeHh4eHh4eHAAAACAD/n/AwCAAAAAAACAAAAAc\nACZkAAAcAAAAAAAcAAAAIAACTAAAIAAAAAAAIAAAABwAAAAAABwAAAAAABwAAAAgAAAMAAAgAAAAA\nAAgAAAAHAAADMzM3MzMzMAAHAAAACAAAAAAAAAAAADAACAAAAAcAAAAAAAcAAAAwAAcAAAAIAAAAA\nAAIAAAAMAAIAAAABwAAAAAABwAAADAABwAAAAgAAAAAAAgAAAAwAAgAAAAHAAAAAAAHAAM5MzMHAA\nAACAAAAAAACAAAmZADCAAAAAcAAAAAAAcAD/n/AwcAAAAIeHh4eHh4eA///wh4AAAAAAAAAAAABwA\nP//8DAAAAAAAAAAAAAAgAAAAAAAAAAAAAAAAAAAAHAAAHAAAAAAAAAAAAAAAACAAACAAAAAAAAAAA\nAAAAAAeHh4cAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA\nAAAD/////////////////gH///79///4Df//8A3//+AN///AAAAf0A3/39Ad/9/eff/f3H3/3959/\n9/eAAPf3gAD39/989/f/fPf3/3z39/989/f/cBf3/2AX9/9gF/AAAAf//2Af//9gP///ff///33//\n/8B/////////////////w==</Icon><Rel r:id='rId1'/></Master></Masters>", "master1": "<MasterContents xmlns='http://schemas.microsoft.com/office/visio/2012/main' xmlns:r='http://schemas.openxmlformats.org/officeDocument/2006/relationships' xml:space='preserve'><Shapes><Shape ID='5' OriginalID='0' Type='Shape' LineStyle='7' FillStyle='7' TextStyle='7'><Cell N='PinX' V='1.771653543307087' F='GUARD((BeginX+EndX)/2)'/><Cell N='PinY' V='1.771653543307087' F='GUARD((BeginY+EndY)/2)'/><Cell N='Width' V='1.181102362204724' F='GUARD(EndX-BeginX)'/><Cell N='Height' V='-1.181102362204724' F='GUARD(EndY-BeginY)'/><Cell N='LocPinX' V='0.5905511811023622' F='GUARD(Width*0.5)'/><Cell N='LocPinY' V='-0.5905511811023622' F='GUARD(Height*0.5)'/><Cell N='Angle' V='0' F='GUARD(0DA)'/><Cell N='FlipX' V='0' F='GUARD(FALSE)'/><Cell N='FlipY' V='0' F='GUARD(FALSE)'/><Cell N='ResizeMode' V='0'/><Cell N='BeginX' V='1.181102362204724'/><Cell N='BeginY' V='2.362204724409449'/><Cell N='EndX' V='2.362204724409449'/><Cell N='EndY' V='1.181102362204724'/><Cell N='TxtPinX' V='0' F='SETATREF(Controls.TextPosition)'/><Cell N='TxtPinY' V='-1.181102362204724' F='SETATREF(Controls.TextPosition.Y)'/><Cell N='TxtWidth' V='0.5555555555555556' F='MAX(TEXTWIDTH(TheText),5*Char.Size)'/><Cell N='TxtHeight' V='0.2444444444444444' F='TEXTHEIGHT(TheText,TxtWidth)'/><Cell N='TxtLocPinX' V='0.2777777777777778' F='TxtWidth*0.5'/><Cell N='TxtLocPinY' V='0.1222222222222222' F='TxtHeight*0.5'/><Cell N='TxtAngle' V='0'/><Cell N='LockHeight' V='1'/><Cell N='LockCalcWH' V='1'/><Cell N='HelpTopic' V='Vis_SE.chm!#20000'/><Cell N='Copyright' V='Copyright 2001 Microsoft Corporation.  All rights reserved.'/><Cell N='NoAlignBox' V='1'/><Cell N='DynFeedback' V='2'/><Cell N='GlueType' V='2'/><Cell N='ObjType' V='2'/><Cell N='NoLiveDynamics' V='1'/><Cell N='ShapeSplittable' V='1'/><Cell N='LayerMember' V='0'/><Section N='Control'><Row N='TextPosition'><Cell N='X' V='0'/><Cell N='Y' V='-1.181102362204724'/><Cell N='XDyn' V='0' F='Controls.TextPosition'/><Cell N='YDyn' V='-1.181102362204724' F='Controls.TextPosition.Y'/><Cell N='XCon' V='5' F='IF(OR(STRSAME(SHAPETEXT(TheText),\"\"),HideText),5,0)'/><Cell N='YCon' V='0'/><Cell N='CanGlue' V='0'/><Cell N='Prompt' V='Reposition Text'/></Row></Section><Section N='Geometry' IX='0'><Cell N='NoFill' V='1'/><Cell N='NoLine' V='0'/><Cell N='NoShow' V='0'/><Cell N='NoSnap' V='0'/><Cell N='NoQuickDrag' V='0'/><Row T='MoveTo' IX='1'><Cell N='X' V='0'/><Cell N='Y' V='0'/></Row><Row T='LineTo' IX='2'><Cell N='X' V='0'/><Cell N='Y' V='-1.181102362204724'/></Row><Row T='LineTo' IX='3'><Cell N='X' V='1.181102362204724'/><Cell N='Y' V='-1.181102362204724'/></Row></Section></Shape></Shapes></MasterContents>"};

/* Idea Board ⇄ Microsoft Visio (.vsdx) — offline writer and reader.
   Writer: OPC package laid out the way Visio 2016–2021 saves files (cells before sections before text,
   Visio's own style sheets, the Dynamic connector master, docProps, windows part).
   Reader: unzips (stored + deflate), resolves masters/groups/glue and maps shapes back to Idea Board. */
(function(root){
'use strict';
const NS = 'http://schemas.microsoft.com/office/visio/2012/main';
const R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
const PKG = 'http://schemas.openxmlformats.org/package/2006/relationships';
const VREL = t => 'http://schemas.microsoft.com/visio/2010/relationships/' + t;
const enc = new TextEncoder();
const HEAD = "<?xml version='1.0' encoding='utf-8' ?>\n";
const esc = v => String(v ?? '').replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F\uFFFE\uFFFF]/g, '')
  .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;').replace(/'/g, '&apos;');
const num = v => { if (!Number.isFinite(v)) throw Error('A shape contains an invalid coordinate.'); const r = Math.round(v * 1e6) / 1e6; return String(Object.is(r, -0) ? 0 : r); };
const C = (n, v, f, u) => `<Cell N='${n}' V='${typeof v === 'number' ? num(v) : esc(v)}'${u ? ` U='${u}'` : ''}${f ? ` F='${esc(f)}'` : ''}/>`;
const hex = v => /^#[\da-f]{6}$/i.test(v || '') ? v.toLowerCase() : '#1d1d1f';
const PX = 1 / 96;                                   // Idea Board pixels → inches

/* ---------------- ZIP (store) ---------------- */
const CRC = Array.from({length: 256}, (_, n) => { for (let i = 0; i < 8; i++) n = (n & 1) ? 0xedb88320 ^ (n >>> 1) : n >>> 1; return n >>> 0; });
function crc32(b){ let c = 0xffffffff; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
// files: [[name, string|bytes]]; deflated: optional Map name → raw-deflate bytes (method 8), others are stored
function zip(files, deflated){
  const parts = [], central = []; let off = 0;
  const now = new Date(), dt = ((now.getFullYear() - 1980) << 9) | ((now.getMonth() + 1) << 5) | now.getDate(), tm = (now.getHours() << 11) | (now.getMinutes() << 5) | (now.getSeconds() >> 1);
  for (const [name, input] of files){
    const data = typeof input === 'string' ? enc.encode(input) : input, n = enc.encode(name), crc = crc32(data);
    const packed = deflated && deflated.get(name), body = packed || data, method = packed ? 8 : 0;
    const L = new DataView(new ArrayBuffer(30));
    L.setUint32(0, 0x04034b50, true); L.setUint16(4, 20, true); L.setUint16(6, 0, true); L.setUint16(8, method, true);
    L.setUint16(10, tm, true); L.setUint16(12, dt, true); L.setUint32(14, crc, true); L.setUint32(18, body.length, true); L.setUint32(22, data.length, true); L.setUint16(26, n.length, true);
    const Cd = new DataView(new ArrayBuffer(46));
    Cd.setUint32(0, 0x02014b50, true); Cd.setUint16(4, 20, true); Cd.setUint16(6, 20, true); Cd.setUint16(8, 0, true); Cd.setUint16(10, method, true);
    Cd.setUint16(12, tm, true); Cd.setUint16(14, dt, true); Cd.setUint32(16, crc, true); Cd.setUint32(20, body.length, true); Cd.setUint32(24, data.length, true); Cd.setUint16(28, n.length, true); Cd.setUint32(42, off, true);
    parts.push(new Uint8Array(L.buffer), n, body); central.push(new Uint8Array(Cd.buffer), n); off += 30 + n.length + body.length;
  }
  const cs = central.reduce((a, b) => a + b.length, 0), E = new DataView(new ArrayBuffer(22));
  E.setUint32(0, 0x06054b50, true); E.setUint16(8, files.length, true); E.setUint16(10, files.length, true); E.setUint32(12, cs, true); E.setUint32(16, off, true);
  const out = new Uint8Array(off + cs + 22); let p = 0;
  for (const b of [...parts, ...central, new Uint8Array(E.buffer)]){ out.set(b, p); p += b.length; }
  return out;
}
// Deflate the XML parts the way Visio saves them (pictures are already compressed and stay stored).
async function zipDeflated(files){
  if (typeof CompressionStream === 'undefined') return zip(files);
  const deflated = new Map();
  for (const [name, input] of files){
    if (typeof input !== 'string') continue;
    const cs = new CompressionStream('deflate-raw'), w = cs.writable.getWriter(); w.write(enc.encode(input)); w.close();
    deflated.set(name, new Uint8Array(await new Response(cs.readable).arrayBuffer()));
  }
  return zip(files, deflated);
}
async function buildAsync(board, template){ const r = build(board, template); r.bytes = await zipDeflated(r.files); return r; }
async function unzip(bytes){
  bytes = bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes);
  const V = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  let e = -1;
  for (let i = bytes.length - 22; i >= Math.max(0, bytes.length - 65557); i--) if (V.getUint32(i, true) === 0x06054b50){ e = i; break; }
  if (e < 0) throw Error('This is not a .vsdx file (no ZIP directory found). Old binary .vsd files must be saved as .vsdx in Visio first.');
  const count = V.getUint16(e + 10, true); let p = V.getUint32(e + 16, true);
  const files = new Map(), dec = new TextDecoder();
  for (let k = 0; k < count; k++){
    if (V.getUint32(p, true) !== 0x02014b50) throw Error('The .vsdx file is damaged (bad ZIP directory).');
    const method = V.getUint16(p + 10, true), csize = V.getUint32(p + 20, true), nlen = V.getUint16(p + 28, true), xlen = V.getUint16(p + 30, true), clen = V.getUint16(p + 32, true), lo = V.getUint32(p + 42, true);
    const name = dec.decode(bytes.subarray(p + 46, p + 46 + nlen)); p += 46 + nlen + xlen + clen;
    if (name.endsWith('/')) continue;
    const start = lo + 30 + V.getUint16(lo + 26, true) + V.getUint16(lo + 28, true), raw = bytes.subarray(start, start + csize);
    let data;
    if (method === 0) data = raw;
    else if (method === 8){
      if (typeof DecompressionStream === 'undefined') throw Error('This browser cannot unpack compressed files. Use a current Chrome, Edge or Firefox.');
      const ds = new DecompressionStream('deflate-raw'), w = ds.writable.getWriter(); w.write(raw); w.close();
      data = new Uint8Array(await new Response(ds.readable).arrayBuffer());
    } else throw Error('The .vsdx file uses an unsupported ZIP compression method.');
    files.set(name.replace(/^\//, ''), data);
  }
  return files;
}

/* ---------------- geometry helpers ---------------- */
// SVG path (absolute+relative M L H V C S Q T A Z) → list of subpaths of segments in source coordinates.
function svgSubpaths(d){
  const toks = String(d).match(/[a-zA-Z]|-?(?:\d*\.\d+|\d+\.?)(?:e[-+]?\d+)?/g) || [];
  const out = []; let i = 0, cmd = '', cur = {x: 0, y: 0}, start = {x: 0, y: 0}, sub = null, lastC = null, lastQ = null;
  const n = () => parseFloat(toks[i++]);
  const begin = p => { sub = {start: {...p}, segs: [], closed: false}; out.push(sub); };
  const line = p => { if (!sub) begin(cur); sub.segs.push({t: 'L', p}); cur = p; };
  const cubic = (c1, c2, p) => { if (!sub) begin(cur); sub.segs.push({t: 'C', c1, c2, p}); cur = p; };
  while (i < toks.length){
    if (/[a-zA-Z]/.test(toks[i])) cmd = toks[i++];
    const rel = cmd === cmd.toLowerCase(), o = rel ? {...cur} : {x: 0, y: 0};
    switch (cmd.toUpperCase()){
      case 'M': { const p = {x: o.x + n(), y: o.y + n()}; cur = p; start = p; begin(p); cmd = rel ? 'l' : 'L'; lastC = lastQ = null; break; }
      case 'L': { line({x: o.x + n(), y: o.y + n()}); lastC = lastQ = null; break; }
      case 'H': { line({x: o.x + n(), y: cur.y}); lastC = lastQ = null; break; }
      case 'V': { line({x: cur.x, y: o.y + n()}); lastC = lastQ = null; break; }
      case 'C': { const c1 = {x: o.x + n(), y: o.y + n()}, c2 = {x: o.x + n(), y: o.y + n()}, p = {x: o.x + n(), y: o.y + n()}; cubic(c1, c2, p); lastC = c2; lastQ = null; break; }
      case 'S': { const c1 = lastC ? {x: 2 * cur.x - lastC.x, y: 2 * cur.y - lastC.y} : {...cur}, c2 = {x: o.x + n(), y: o.y + n()}, p = {x: o.x + n(), y: o.y + n()}; cubic(c1, c2, p); lastC = c2; lastQ = null; break; }
      case 'Q': case 'T': {
        const q = cmd.toUpperCase() === 'Q' ? {x: o.x + n(), y: o.y + n()} : (lastQ ? {x: 2 * cur.x - lastQ.x, y: 2 * cur.y - lastQ.y} : {...cur});
        const p = {x: o.x + n(), y: o.y + n()}, s = cur;
        cubic({x: s.x + 2 / 3 * (q.x - s.x), y: s.y + 2 / 3 * (q.y - s.y)}, {x: p.x + 2 / 3 * (q.x - p.x), y: p.y + 2 / 3 * (q.y - p.y)}, p); lastQ = q; lastC = null; break;
      }
      case 'A': {
        const rx = n(), ry = n(), rot = n(), large = n(), sweep = n(), p = {x: o.x + n(), y: o.y + n()};
        for (const c of arcToCubics(cur, rx, ry, rot, large, sweep, p)) cubic(c.c1, c.c2, c.p);
        lastC = lastQ = null; break;
      }
      case 'Z': { if (sub){ sub.closed = true; if (Math.hypot(cur.x - sub.start.x, cur.y - sub.start.y) > 1e-6) sub.segs.push({t: 'L', p: {...sub.start}}); } cur = {...start}; sub = null; lastC = lastQ = null; break; }
      default: i++;
    }
  }
  return out.filter(s => s.segs.length);
}
function arcToCubics(p0, rx, ry, phi, fa, fs, p1){
  if (!rx || !ry) return [{c1: p0, c2: p1, p: p1}];
  rx = Math.abs(rx); ry = Math.abs(ry); phi = phi * Math.PI / 180;
  const cos = Math.cos(phi), sin = Math.sin(phi), dx = (p0.x - p1.x) / 2, dy = (p0.y - p1.y) / 2;
  const x1 = cos * dx + sin * dy, y1 = -sin * dx + cos * dy;
  let lam = x1 * x1 / (rx * rx) + y1 * y1 / (ry * ry); if (lam > 1){ rx *= Math.sqrt(lam); ry *= Math.sqrt(lam); }
  const sign = fa === fs ? -1 : 1, num_ = rx * rx * ry * ry - rx * rx * y1 * y1 - ry * ry * x1 * x1, den = rx * rx * y1 * y1 + ry * ry * x1 * x1;
  const co = sign * Math.sqrt(Math.max(0, num_ / den)), cx1 = co * rx * y1 / ry, cy1 = -co * ry * x1 / rx;
  const cx = cos * cx1 - sin * cy1 + (p0.x + p1.x) / 2, cy = sin * cx1 + cos * cy1 + (p0.y + p1.y) / 2;
  const ang = (ux, uy, vx, vy) => { const a = Math.atan2(ux * vy - uy * vx, ux * vx + uy * vy); return a; };
  let t1 = ang(1, 0, (x1 - cx1) / rx, (y1 - cy1) / ry), dt = ang((x1 - cx1) / rx, (y1 - cy1) / ry, (-x1 - cx1) / rx, (-y1 - cy1) / ry);
  if (!fs && dt > 0) dt -= 2 * Math.PI; if (fs && dt < 0) dt += 2 * Math.PI;
  const segs = Math.max(1, Math.ceil(Math.abs(dt) / (Math.PI / 2))), d = dt / segs, k = 4 / 3 * Math.tan(d / 4), out = [];
  const pt = t => ({x: cx + rx * Math.cos(t) * cos - ry * Math.sin(t) * sin, y: cy + rx * Math.cos(t) * sin + ry * Math.sin(t) * cos});
  const dv = t => ({x: -rx * Math.sin(t) * cos - ry * Math.cos(t) * sin, y: -rx * Math.sin(t) * sin + ry * Math.cos(t) * cos});
  for (let s = 0; s < segs; s++){
    const a = t1 + s * d, b = a + d, pa = pt(a), pb = pt(b), da = dv(a), db = dv(b);
    out.push({c1: {x: pa.x + k * da.x, y: pa.y + k * da.y}, c2: {x: pb.x - k * db.x, y: pb.y - k * db.y}, p: s === segs - 1 ? p1 : pb});
  }
  return out;
}
// One Geometry section per subpath, as relative rows so the drawing scales with the shape in Visio.
// map(p) → {x, y} in the shape's local inches (y up); W/H are the shape's size in inches.
function geomSections(subpaths, map, W, H, ix0, opts = {}){
  const rx = v => W ? v / W : 0, ry = v => H ? v / H : 0;
  return subpaths.map((sp, k) => {
    const s = map(sp.start); let rows = `<Row T='RelMoveTo' IX='1'>${C('X', rx(s.x))}${C('Y', ry(s.y))}</Row>`, ix = 2;
    for (const g of sp.segs){
      const p = map(g.p);
      if (g.t === 'L') rows += `<Row T='RelLineTo' IX='${ix++}'>${C('X', rx(p.x))}${C('Y', ry(p.y))}</Row>`;
      else { const a = map(g.c1), b = map(g.c2); rows += `<Row T='RelCubBezTo' IX='${ix++}'>${C('X', rx(p.x))}${C('Y', ry(p.y))}${C('A', rx(a.x))}${C('B', ry(a.y))}${C('C', rx(b.x))}${C('D', ry(b.y))}</Row>`; }
    }
    const noFill = opts.noFill || !sp.closed ? 1 : 0;
    return `<Section N='Geometry' IX='${ix0 + k}'>${C('NoFill', noFill)}${C('NoLine', opts.noLine ? 1 : 0)}${C('NoShow', 0)}${C('NoSnap', 0)}${C('NoQuickDrag', 0)}${rows}</Section>`;
  }).join('');
}
const rectPath = (w, h) => [{start: {x: 0, y: 0}, closed: true, segs: [{t: 'L', p: {x: w, y: 0}}, {t: 'L', p: {x: w, y: h}}, {t: 'L', p: {x: 0, y: h}}, {t: 'L', p: {x: 0, y: 0}}]}];
const diamondPath = (w, h) => [{start: {x: w / 2, y: 0}, closed: true, segs: [{t: 'L', p: {x: w, y: h / 2}}, {t: 'L', p: {x: w / 2, y: h}}, {t: 'L', p: {x: 0, y: h / 2}}, {t: 'L', p: {x: w / 2, y: 0}}]}];
const ellipseSection = (ix, noFill, noLine) => `<Section N='Geometry' IX='${ix}'>${C('NoFill', noFill ? 1 : 0)}${C('NoLine', noLine ? 1 : 0)}${C('NoShow', 0)}${C('NoSnap', 0)}${C('NoQuickDrag', 0)}<Row T='Ellipse' IX='1'>${C('X', 0, 'Width*0.5')}${C('Y', 0, 'Height*0.5')}${C('A', 0, 'Width*1')}${C('B', 0, 'Height*0.5')}${C('C', 0, 'Width*0.5')}${C('D', 0, 'Height*1')}</Row></Section>`;
function fixEllipse(xml, w, h){                       // fill in the V values of the formula-driven ellipse row
  return xml.replace("N='X' V='0' F='Width*0.5'", `N='X' V='${num(w / 2)}' F='Width*0.5'`).replace("N='Y' V='0' F='Height*0.5'", `N='Y' V='${num(h / 2)}' F='Height*0.5'`)
    .replace("N='A' V='0' F='Width*1'", `N='A' V='${num(w)}' F='Width*1'`).replace("N='B' V='0' F='Height*0.5'", `N='B' V='${num(h / 2)}' F='Height*0.5'`)
    .replace("N='C' V='0' F='Width*0.5'", `N='C' V='${num(w / 2)}' F='Width*0.5'`).replace("N='D' V='0' F='Height*1'", `N='D' V='${num(h)}' F='Height*1'`);
}
function midpoint(pts){
  let L = 0; for (let i = 1; i < pts.length; i++) L += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
  let d = L / 2;
  for (let i = 1; i < pts.length; i++){ const a = pts[i - 1], b = pts[i], l = Math.hypot(b.x - a.x, b.y - a.y); if (d <= l || i === pts.length - 1){ const t = l ? Math.min(1, d / l) : 0; return {x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t}; } d -= l; }
  return pts[0];
}
function simplify(pts, tol){                          // Ramer–Douglas–Peucker
  if (pts.length < 3) return pts;
  const keep = new Uint8Array(pts.length); keep[0] = keep[pts.length - 1] = 1;
  const st = [[0, pts.length - 1]];
  while (st.length){
    const [a, b] = st.pop(); let m = -1, md = tol;
    const A = pts[a], B = pts[b], L = Math.hypot(B.x - A.x, B.y - A.y) || 1e-9;
    for (let i = a + 1; i < b; i++){ const d = Math.abs((B.x - A.x) * (A.y - pts[i].y) - (A.x - pts[i].x) * (B.y - A.y)) / L; if (d > md){ md = d; m = i; } }
    if (m > 0){ keep[m] = 1; st.push([a, m], [m, b]); }
  }
  return pts.filter((_, i) => keep[i]);
}

/* ---------------- package parts ---------------- */
function rels(rows){ return HEAD + `<Relationships xmlns='${PKG}'>` + rows.map(([id, type, target]) => `<Relationship Id='${id}' Type='${type}' Target='${esc(target)}'/>`).join('') + '</Relationships>'; }
function pagePart(inner){ return HEAD + `<PageContents xmlns='${NS}' xmlns:r='${R}' xml:space='preserve'>${inner}</PageContents>`; }
const charSection = (rows, font) => `<Section N='Character'>${rows.map((r, i) => `<Row IX='${i}'>${font ? C('Font', font) : ''}${C('Color', hex(r.color))}${C('Style', r.bold ? 1 : 0)}${C('Size', r.size / 72, null, 'PT')}</Row>`).join('')}</Section>`;
const paraSection = align => `<Section N='Paragraph'><Row IX='0'>${C('HorzAlign', align)}</Row></Section>`;
function propSection(rows){
  const list = rows.filter(r => r && r.value != null && r.value !== '');
  if (!list.length) return '';
  return `<Section N='Property'>${list.map(r => `<Row N='${r.name}'>${C('Value', String(r.value), null, 'STR')}${C('Prompt', '', 'No Formula')}${C('Label', r.label)}${C('Format', '', 'No Formula')}${C('SortKey', '', 'No Formula')}${C('Type', 0)}${C('Invisible', r.hidden ? 1 : 0)}${C('Verify', 0)}${C('DataLinked', 0)}${C('LangID', 'en-US')}${C('Calendar', 0)}</Row>`).join('')}</Section>`;
}
const userSection = rows => rows.length ? `<Section N='User'>${rows.map(([n, v]) => `<Row N='${n}'>${C('Value', v, null, 'STR')}${C('Prompt', '', 'No Formula')}</Row>`).join('')}</Section>` : '';
const ptSize = px => px * .75;                        // CSS px → points
const signed = v => (v < 0 ? '-' : '+') + num(Math.abs(v));   // "+0.12" / "-0.12" for appending to a formula

/* polyline helpers (page inches) */
function polyLength(P){ let L = 0; for (let i = 1; i < P.length; i++) L += Math.hypot(P[i].x - P[i - 1].x, P[i].y - P[i - 1].y); return L; }
function pointAt(P, t){                               // point at fraction t (0..1) of the path length
  const L = polyLength(P); let d = Math.max(0, Math.min(1, t)) * L;
  for (let i = 1; i < P.length; i++){ const a = P[i - 1], b = P[i], l = Math.hypot(b.x - a.x, b.y - a.y); if (d <= l || i === P.length - 1){ const k = l ? Math.min(1, d / l) : 0; return {x: a.x + (b.x - a.x) * k, y: a.y + (b.y - a.y) * k}; } d -= l; }
  return {...P[0]};
}
function project(P, q){                               // nearest point on the path: distance along it from the start
  let best = {d2: Infinity, along: 0}, run = 0;
  for (let i = 1; i < P.length; i++){
    const a = P[i - 1], b = P[i], dx = b.x - a.x, dy = b.y - a.y, l2 = dx * dx + dy * dy, l = Math.sqrt(l2);
    const k = l2 ? Math.max(0, Math.min(1, ((q.x - a.x) * dx + (q.y - a.y) * dy) / l2)) : 0, p = {x: a.x + dx * k, y: a.y + dy * k}, d2 = (q.x - p.x) ** 2 + (q.y - p.y) ** 2;
    if (d2 < best.d2) best = {d2, along: run + l * k};
    run += l;
  }
  return best.along;
}

/* Visio layers, in stacking/meaning order. Each page lists only the layers it uses. */
const LAYER_NAMES = {site: 'Sites', ink: 'Annotations', picture: 'Pictures', pipe: 'Pipes', link: 'Links', device: 'Devices', port: 'Port labels', note: 'Notes', shape: 'Shapes and text'};
function layerKey(s){
  if (s.role === 'portTag') return 'port';
  if (s.type === 'connector') return s.vname === 'Pipe' ? 'pipe' : 'link';
  return ({zone: 'site', draw: 'ink', image: 'picture', device: 'device', cloud: 'device', note: 'note'})[s.type] || 'shape';
}
// Shapes Visio's connector router should walk around (devices, clouds, boxes). Frames, labels, notes, text, ink and pictures are see-through.
const OBSTACLE = new Set(['device', 'cloud', 'rect', 'ellipse', 'diamond']);
const layoutCells = s => s.type === 'connector' ? '' : (OBSTACLE.has(s.type) && s.role !== 'portTag'
  ? C('ObjType', 1)
  : C('ShapePermeableX', 1, null, 'BOOL') + C('ShapePermeableY', 1, null, 'BOOL') + C('ShapePermeablePlace', 1, null, 'BOOL') + C('ObjType', 4));

/* ---------------- writer ---------------- */
/* board: {name, pages:[{name, shapes}], style:'visio'|'ideaboard', font, bg:'light'|'black'|'none', gradient, grid:'none'|'screen'|'print', dark}
   Shapes arrive in Idea Board pixels (y down); Visio uses inches with y up. */
function build(board, template){
  const T = template || (typeof VISIO_TEMPLATE !== 'undefined' ? VISIO_TEMPLATE : root.VISIO_TEMPLATE);
  if (!T) throw Error('The Visio template is missing.');
  if (!Array.isArray(board.pages) || !board.pages.length) throw Error('There are no pages to export.');
  if (board.pages.length > 200) throw Error('Export is limited to 200 pages.');
  const files = [], pageRows = [], pageRels = [], ct = [], warnings = new Set(); let img = 0;
  const margin = 48, native = board.style !== 'ideaboard', font = board.font || 'Calibri', follow = board.followLinks !== false, useContainers = board.containers !== false;
  const grid = board.grid === true ? 'print' : (board.grid || 'none');
  // native Visio style uses the line weights Visio diagrams normally have (about 2/3 of the canvas weights)
  const weightK = native ? 2 / 3 : 1;
  const TH = board.dark ? {ink: '#f1f3f5', sub: '#aeb4bd', paper: '#16181d', rack: '#23262d'} : {ink: '#1d1d1f', sub: '#5f6570', paper: '#ffffff', rack: '#eef0f3'};
  const chars = rows => charSection(rows, font);
  let maxPW = 2, maxPH = 2, firstView = null;
  board.pages.forEach((pg, pi) => {
    const shapes = pg.shapes || [];
    if (shapes.length > 10000) throw Error('A page has more than 10,000 objects.');
    const pts = shapes.flatMap(s => s.points && s.points.length ? s.points : [{x: s.x, y: s.y}, {x: s.x + s.w, y: s.y + s.h}]).concat(shapes.flatMap(s => s.labelBox ? [{x: s.labelBox.x, y: s.labelBox.y}, {x: s.labelBox.x + s.labelBox.w, y: s.labelBox.y + s.labelBox.h}] : []))
      .concat(shapes.flatMap(s => s.infoBox ? [{x: s.infoBox.x, y: s.infoBox.y}, {x: s.infoBox.x + s.infoBox.w, y: s.infoBox.y + s.infoBox.h}] : []));
    let minX = 0, minY = 0, maxX = 1056, maxY = 816;
    if (pts.length){ minX = Math.min(...pts.map(p => p.x)); minY = Math.min(...pts.map(p => p.y)); maxX = Math.max(...pts.map(p => p.x)); maxY = Math.max(...pts.map(p => p.y)); }
    const PW = Math.max(2, (maxX - minX + margin * 2) * PX), PH = Math.max(2, (maxY - minY + margin * 2) * PX);
    maxPW = Math.max(maxPW, PW); maxPH = Math.max(maxPH, PH);
    if (!pi) firstView = {PW, PH};
    const toPage = p => ({x: (p.x - minX + margin) * PX, y: (maxY - p.y + margin) * PX});
    const ids = new Map(); shapes.forEach((s, i) => ids.set(s.id, i + 1));
    if (ids.size !== shapes.length) throw Error('A page has duplicate object IDs.');
    // connector paths in page inches, for labels and port tags that follow them
    const pathOf = new Map(); for (const s of shapes) if (s.type === 'connector' && s.points && s.points.length > 1) pathOf.set(s.id, simplify(s.points.map(toPage), .004));
    // connection points requested by anchored connector ends
    const ports = new Map(), portOf = new Map();
    for (const s of shapes) if (s.type === 'connector') for (const key of ['start', 'end']){
      const ep = s[key]; if (!ep || !ep.id || !ids.has(ep.id) || !ep.anchor) continue;
      const list = ports.get(ep.id) || []; let k = list.findIndex(a => Math.abs(a.x - ep.anchor.x) < 1e-6 && Math.abs(a.y - ep.anchor.y) < 1e-6);
      if (k < 0){ list.push({x: ep.anchor.x, y: ep.anchor.y}); k = list.length - 1; }
      ports.set(ep.id, list); portOf.set(s.id + ':' + key, k);
    }
    // site frames become Visio containers: each shape belongs to the smallest frame that fully holds it
    const zones = useContainers ? shapes.filter(s => s.type === 'zone') : [], memberOf = new Map(), membersOf = new Map();
    const inside = (a, z) => a !== z && a.x >= z.x - 1 && a.y >= z.y - 1 && a.x + a.w <= z.x + z.w + 1 && a.y + a.h <= z.y + z.h + 1;
    for (const s of shapes){
      if (s.type === 'connector' || s.role === 'portTag') continue;
      let best = null; for (const z of zones) if (inside(s, z) && (!best || z.w * z.h < best.w * best.h) && !(s.type === 'zone' && s.w * s.h >= z.w * z.h)) best = z;
      if (best){ memberOf.set(s.id, ids.get(best.id)); const l = membersOf.get(best.id) || []; l.push(ids.get(s.id)); membersOf.set(best.id, l); }
    }
    const relationships = s => {
      const parts = [];
      if (membersOf.has(s.id)) parts.push(`DEPENDSON(1,${membersOf.get(s.id).map(i => `Sheet.${i}!SheetRef()`).join(',')})`);
      if (memberOf.has(s.id)) parts.push(`DEPENDSON(4,Sheet.${memberOf.get(s.id)}!SheetRef())`);
      return parts.length ? C('Relationships', 0, `SUM(${parts.join(',')})`) : '';
    };
    // layers used on this page
    const layerIx = new Map(); for (const k of Object.keys(LAYER_NAMES)) if (shapes.some(s => layerKey(s) === k)) layerIx.set(k, layerIx.size);
    const layerCell = s => layerIx.has(layerKey(s)) ? C('LayerMember', String(layerIx.get(layerKey(s)))) : '';
    const media = [], out = [], connects = []; let usesConnector = false, helperId = shapes.length + 100;
    for (const s of shapes){
      const id = ids.get(s.id), stroke = hex(s.color), lw = Math.max(.25, (s.lineWidth || 2) * .75 * weightK) / 72;
      const pattern = s.dash === 'dashed' ? 2 : s.dash === 'dotted' ? 3 : 1, nm = esc(String(s.vname || s.type).replace(/[^A-Za-z0-9 _-]/g, '').trim().slice(0, 40) || 'Shape') + '.' + id;
      if (s.type === 'connector'){
        usesConnector = true;
        const poly = s.points.map(toPage), a = poly[0], b = poly[poly.length - 1], W = b.x - a.x, H = b.y - a.y;
        let cells = C('PinX', (a.x + b.x) / 2, 'Inh') + C('PinY', (a.y + b.y) / 2, 'Inh') + C('Width', W, 'GUARD(EndX-BeginX)') + C('Height', H, 'GUARD(EndY-BeginY)') + C('LocPinX', W / 2, 'Inh') + C('LocPinY', H / 2, 'Inh');
        const glue = {};
        for (const [key, p, pre, part] of [['start', a, 'Begin', 9], ['end', b, 'End', 12]]){
          const ep = s[key], t = ep && ep.id ? ids.get(ep.id) : null; let f = null;
          if (t){
            const k = portOf.get(s.id + ':' + key);
            if (k != null){ f = `PAR(PNT(Sheet.${t}!Connections.X${k + 1},Sheet.${t}!Connections.Y${k + 1}))`; connects.push(`<Connect FromSheet='${id}' FromCell='${pre}X' FromPart='${part}' ToSheet='${t}' ToCell='Connections.X${k + 1}' ToPart='${100 + k}'/>`); }
            else { f = key === 'start' ? '_WALKGLUE(BegTrigger,EndTrigger,WalkPreference)' : '_WALKGLUE(EndTrigger,BegTrigger,WalkPreference)'; connects.push(`<Connect FromSheet='${id}' FromCell='${pre}X' FromPart='${part}' ToSheet='${t}' ToCell='PinX' ToPart='3'/>`); }
            glue[key] = t;
          }
          cells += C(pre + 'X', p.x, f) + C(pre + 'Y', p.y, f);
        }
        if (glue.start) cells += C('BegTrigger', 2, `_XFTRIGGER(Sheet.${glue.start}!EventXFMod)`);
        if (glue.end) cells += C('EndTrigger', 2, `_XFTRIGGER(Sheet.${glue.end}!EventXFMod)`);
        // Visio route styles: 1 right-angle, 2 straight; ConLineRouteExt 1 straight segments, 2 curved
        const route = s.route === 'straight' ? [2, 1] : s.route === 'curve' ? [1, 2] : [1, 1];
        cells += C('LineWeight', lw) + C('LineColor', stroke) + C('LinePattern', pattern) + C('BeginArrow', arrowCode(s.arrowStart)) + C('EndArrow', arrowCode(s.arrowEnd)) + C('BeginArrowSize', 2) + C('EndArrowSize', 2) +
          C('ShapeRouteStyle', route[0]) + C('ConLineRouteExt', route[1]) + C('ConLineJumpCode', 1) + layerCell(s);   // 1 = never draw line jumps (the canvas has none)
        let secs = '';
        if (s.text) secs += chars([{color: s.textColor || TH.ink, size: ptSize(s.fontSize || 13)}]) + paraSection(1);
        secs += propSection([{name: 'StartPort', label: 'A-end port', value: s.startLabel}, {name: 'EndPort', label: 'B-end port', value: s.endLabel}, {name: 'LinkType', label: 'Link type', value: s.linkName}, {name: 'IdeaBoard', label: 'Idea Board data', value: s.ib, hidden: true}]);
        // explicit path, relative to Begin (Width/Height may be 0 for axis-aligned lines)
        let rows = `<Row T='MoveTo' IX='1'>${C('X', 0)}${C('Y', 0)}</Row>`, ix = 2;
        const path = pathOf.get(s.id) || simplify(poly, .004);
        for (const p of path.slice(1)) rows += `<Row T='LineTo' IX='${ix++}'>${C('X', p.x - a.x)}${C('Y', p.y - a.y)}</Row>`;
        if (ix === 3) rows += `<Row T='LineTo' IX='3' Del='1'/>`;               // the master's path has a third row
        secs += `<Section N='Geometry' IX='0'>${C('NoFill', 1)}${C('NoLine', 0)}${C('NoShow', 0)}${C('NoSnap', 0)}${C('NoQuickDrag', 0)}${rows}</Section>`;
        // The label rides on the path: a fraction along it plus the offset it has on the board, so it follows when Visio reroutes.
        const want = s.labelCenter ? toPage(s.labelCenter) : midpoint(path), L = polyLength(path) || 1e-6;
        const tFrac = Math.max(0, Math.min(1, project(path, want) / L)), on = pointAt(path, tFrac), dx = want.x - on.x, dy = want.y - on.y;
        const tx = want.x - a.x, ty = want.y - a.y;
        cells += C('TxtPinX', tx, 'Inh') + C('TxtPinY', ty, 'Inh');
        if (s.text){
          const lines = String(s.text).split('\n'), fs = ptSize(s.fontSize || 13) / 72, tw = Math.max(...lines.map(l => l.length)) * fs * .56 + .12, th = lines.length * fs * 1.3 + .06;
          cells += C('TxtWidth', tw, 'Inh') + C('TxtHeight', th, 'Inh') + C('TxtLocPinX', tw / 2, 'Inh') + C('TxtLocPinY', th / 2, 'Inh') + C('TextBkgnd', TH.paper);
        }
        const tp = `POINTALONGPATH(Geometry1.Path,${num(tFrac)})`;
        secs = `<Section N='Control'><Row N='TextPosition'>${C('X', tx, follow ? `PNTX(${tp})${signed(dx)}` : null)}${C('Y', ty, follow ? `PNTY(${tp})${signed(dy)}` : null)}${C('XDyn', tx, 'Inh')}${C('YDyn', ty, 'Inh')}${C('XCon', s.text ? 0 : 5, 'Inh')}</Row></Section>` + secs;
        out.push(`<Shape ID='${id}' NameU='Dynamic connector.${id}' Name='Dynamic connector.${id}' Type='Shape' Master='2'>${cells}${secs}${s.text ? `<Text>${esc(s.text)}</Text>` : ''}</Shape>`);
        continue;
      }
      const W = Math.max(.01, s.w * PX), H = Math.max(.01, s.h * PX); let pin = toPage({x: s.x + s.w / 2, y: s.y + s.h / 2});
      let pinF = {}, tagIb = s.ib;
      // port tags ride on their link: same distance from the port along the path, same offset as on the board
      if (s.role === 'portTag' && s.bind && pathOf.has(s.bind.conn) && ids.has(s.bind.conn)){
        const cid = ids.get(s.bind.conn), P = pathOf.get(s.bind.conn), L = polyLength(P), ref = `Sheet.${cid}!Geometry1.Path`;
        tagIb = JSON.stringify({type: 'portLabel', tag: s.bind.end === 'end' ? 'end' : 'start', conn: String(cid), text: String(s.text || '')});
        if (follow && L > 1e-3){
          const along = project(P, pin), fromEnd = s.bind.end === 'end', D = Math.max(0, fromEnd ? L - along : along);
          const t = fromEnd ? Math.max(.55, 1 - D / L) : Math.min(.45, D / L), on = pointAt(P, t), ox = pin.x - on.x, oy = pin.y - on.y;
          const trav = fromEnd ? `MAX(0.55,1-${num(D)}/MAX(0.01,PATHLENGTH(${ref})))` : `MIN(0.45,${num(D)}/MAX(0.01,PATHLENGTH(${ref})))`;
          const P0 = `LOCTOPAR(POINTALONGPATH(${ref},${trav}),Sheet.${cid}!Width,Sheet.${cid}!Width)`;
          pinF = {x: `PNTX(${P0})${signed(ox)}`, y: `PNTY(${P0})${signed(oy)}`};
        }
      }
      let cells = C('PinX', pin.x, pinF.x) + C('PinY', pin.y, pinF.y) + C('Width', W) + C('Height', H) + C('LocPinX', W / 2, 'Width*0.5') + C('LocPinY', H / 2, 'Height*0.5') + C('Angle', 0) + C('FlipX', 0) + C('FlipY', 0) + C('ResizeMode', 0);
      let secs = '', text = s.text || '', type = 'Shape', foreign = '', children = '', textRows = null, align = 1, valign = 1, user = [];
      const fill = s.fillColor ? hex(s.fillColor) : null;
      const lineCells = (color, noLine, weight = lw) => C('LineWeight', weight) + C('LineColorTrans', 1 - (s.opacity ?? 1)) + C('LineColor', color) + C('LinePattern', noLine ? 0 : pattern) + C('LineCap', 1);
      const fillCells = f => f ? C('FillForegnd', f) + C('FillBkgnd', f) + C('FillPattern', 1) : C('FillPattern', 0);
      const local = p => ({x: (p.x - s.x) * PX, y: (s.y + s.h - p.y) * PX});
      if (s.type === 'device'){
        const k = Math.min(s.w, s.h), circle = s.shape === 'circle' && s.view !== 'rack';
        if (s.view === 'rack'){
          type = 'Group';
          const frame = stroke, band = Math.min(s.h * 1.1, s.w * .28), pos = ({left: 0, middle: .5, right: 1})[s.symbolPosition] ?? 0, slot = (s.w - band) * pos;
          const area = pos < .5 ? {x: slot + band, w: s.w - slot - band} : {x: 0, w: slot};
          const badgeW = s.role ? Math.min(60, area.w * .29) : 0, badgeH = Math.min(40, s.h - 16), gap = 10;
          const tx = area.x + gap, tw = Math.max(20, area.w - badgeW - gap * 3), hostSize = Math.min(17, Math.max(9, tw / Math.max(1, String(s.hostname || '').length * .6)));
          const gradient = board.gradient !== false;
          const stopColors = board.dark ? ['#454d5b', TH.rack] : ['#ffffff', fill || TH.rack];
          const childLayer = layerCell(s);
          function child(n, x, y, w, h, body, text, color, size, fillColor){
            const cid = ++helperId, Wc = w * PX, Hc = h * PX;
            let c = C('PinX', (x + w / 2) * PX, `Sheet.${id}!Width*${num((x + w / 2) / s.w)}`) + C('PinY', (s.h - y - h / 2) * PX, `Sheet.${id}!Height*${num((s.h - y - h / 2) / s.h)}`) + C('Width', Wc, `Sheet.${id}!Width*${num(w / s.w)}`) + C('Height', Hc, `Sheet.${id}!Height*${num(h / s.h)}`) +
              C('LocPinX', Wc / 2, 'Width*0.5') + C('LocPinY', Hc / 2, 'Height*0.5') + C('Angle', 0) + (body.includes("N='LinePattern'") ? '' : C('LinePattern', 0)) + (body.includes("N='FillPattern'") ? '' : C('FillPattern', fillColor ? 1 : 0)) + (fillColor ? C('FillForegnd', fillColor) : '') + C('ObjType', 4) + childLayer;
            if (text) c += C('VerticalAlign', 1) + C('LeftMargin', 2 * PX) + C('RightMargin', 2 * PX);
            return `<Shape ID='${cid}' NameU='${n}.${cid}' Name='${n}.${cid}' Type='Shape' LineStyle='3' FillStyle='3' TextStyle='3'>` + c + body + (text ? chars([{color: color || TH.ink, bold: true, size: ptSize(size || 14)}]) + paraSection(n === 'Hostname' ? 0 : 1) + '<Text>' + esc(text) + '</Text>' : '') + '</Shape>';
          }
          const bodyCells = C('LinePattern', 1) + C('LineColor', frame) + C('LineWeight', (native ? 3 : 6) * .75 / 72) + C('Rounding', 8 * PX) + C('FillPattern', 1) + C('FillForegnd', gradient ? stopColors[0] : stopColors[1]);
          const gradientCells = gradient ? C('FillGradientEnabled', 1) + C('FillGradientDir', 0) + C('FillGradientAngle', Math.PI / 2, null, 'DEG') + '<Section N="FillGradient">' + stopColors.map((c, i) => '<Row IX="' + i + '">' + C('GradientStopColor', c) + C('GradientStopColorTrans', 0) + C('GradientStopPosition', i) + '</Row>').join('') + '</Section>' : '';
          children += child('Chassis', 0, 0, s.w, s.h, bodyCells + gradientCells + geomSections(rectPath(W, H), p => p, W, H, 0), '');
          const ic = Math.min(band, s.h) * (s.symbolScale || .86), ox = slot + (band - ic) / 2, oy = (s.h - ic) / 2;
          if (s.icon) children += child('DeviceIcon', ox, oy, ic, ic, C('LinePattern', 1) + C('LineColor', board.dark ? TH.ink : frame) + C('LineWeight', 2.8 * .75 / 72) + geomSections(svgSubpaths(s.icon), p => ({x: p.x * ic / 48 * PX, y: (ic - p.y * ic / 48) * PX}), ic * PX, ic * PX, 0, {noFill: true}), '');
          children += child('Hostname', tx, 0, tw, s.h, '', s.hostname || '', TH.ink, hostSize);
          if (s.role) children += child('RoleBadge', area.x + area.w - badgeW - gap, (s.h - badgeH) / 2, badgeW, badgeH, C('Rounding', 7 * PX) + geomSections(rectPath(badgeW * PX, badgeH * PX), p => p, badgeW * PX, badgeH * PX, 0), s.role, '#ffffff', Math.min(24, badgeW * .48), s.roleColor || frame);
          cells += C('SelectMode', 1) + C('DisplayMode', 2);
          // the info lines under a rack unit are the group's own text, so they move and resize with it
          text = (s.infoLines || []).slice(0, 4).join('\n');
          if (text){
            const n = text.split('\n').length, th = n * 12 * PX + .06, tw = Math.max(W, 220 * PX);
            cells += C('TxtPinX', W / 2, 'Width*0.5') + C('TxtPinY', -th / 2 - 4 * PX, `-TxtHeight*0.5-${num(4 * PX)}`) + C('TxtWidth', tw, `MAX(Width,${num(220 * PX)})`) + C('TxtHeight', th) + C('TxtLocPinX', tw / 2, 'TxtWidth*0.5') + C('TxtLocPinY', th / 2, 'TxtHeight*0.5') + C('TxtAngle', 0);
            textRows = [{color: TH.sub, size: 8}];
          }
        } else {
          const solid = s.fillMode === 'solid';
          cells += lineCells(solid ? '#ffffff' : stroke, false, 2.4 * Math.max(s.w, s.h) / 64 * .75 / 72 * (native && !solid ? .75 : 1)) + fillCells(solid ? stroke : s.fillMode === 'semi' ? (fill || '#ffffff') : '#ffffff') + C('Rounding', circle ? 0 : k * .18 * PX);
          secs += circle ? fixEllipse(ellipseSection(0, 0, solid), W, H) : geomSections(rectPath(W, H), p => p, W, H, 0, {noLine: solid});
          const sc = (s.symbolScale || .86) / .86, iw = s.w * sc, ih = s.h * sc, ox = (s.w - iw) / 2, oy = (s.h - ih) / 2;
          if (s.icon) secs += geomSections(svgSubpaths(s.icon), p => ({x: (ox + p.x * iw / 48) * PX, y: (s.h - oy - p.y * ih / 48) * PX}), W, H, 1, {noFill: true});
          // label block hangs under the symbol, like Visio's network stencils
          const lines = [s.hostname, s.role ? 'Role: ' + s.role : '', ...(s.infoLines || [])].filter(Boolean);
          text = lines.join('\n'); valign = 0;
          const tw = Math.max(W * 2.6, 1.6), th = Math.max(.2, lines.length * .17);
          cells += C('TxtPinX', W / 2, 'Width*0.5') + C('TxtPinY', -0.04) + C('TxtWidth', tw) + C('TxtHeight', th) + C('TxtLocPinX', tw / 2, 'TxtWidth*0.5') + C('TxtLocPinY', th, 'TxtHeight') + C('TxtAngle', 0);
          if (lines.length) textRows = s.hostname ? [{color: TH.ink, bold: true, size: 10.5}, {color: TH.sub, size: 8}] : [{color: TH.sub, size: 8}];
        }
        // Shape Data names follow Visio's network shapes (Network Name, IP Address, Subnet Mask) so Visio reports and data graphics recognise them
        secs = propSection([{name: 'NetworkName', label: 'Hostname', value: s.hostname}, {name: 'DeviceType', label: 'Device type', value: s.kindName}, {name: 'Role', label: 'Role', value: s.role},
          {name: 'IPAddress', label: 'IP address', value: s.ip}, {name: 'SubnetMask', label: 'Subnet', value: s.subnet}, {name: 'VLAN', label: 'VLAN', value: s.vlan}, {name: 'Info', label: 'Info', value: s.info}, {name: 'Notes', label: 'Notes', value: s.notes},
          {name: 'IdeaBoard', label: 'Idea Board data', value: s.ib, hidden: true}]) + secs;
      } else if (s.type === 'image'){
        const m = /^data:image\/(png|jpe?g|gif|bmp);base64,([A-Za-z0-9+/=\s]+)$/.exec(s.src || '');
        if (!m){ warnings.add('A picture is missing or not PNG/JPEG/GIF/BMP, so it was left out.'); continue; }
        const bin = atob(m[2].replace(/\s/g, '')), bytes = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
        const ext = m[1] === 'jpeg' || m[1] === 'jpg' ? 'jpeg' : m[1], file = `image${++img}.${ext}`, rid = 'rId' + (media.length + 2);
        files.push(['visio/media/' + file, bytes]); media.push([rid, R + '/image', '../media/' + file]);
        type = 'Foreign'; text = '';
        cells += C('ImgOffsetX', 0, 'ImgWidth*0') + C('ImgOffsetY', 0, 'ImgHeight*0') + C('ImgWidth', W, 'Width*1') + C('ImgHeight', H, 'Height*1') + C('LineWeight', lw) + C('LinePattern', 0) + C('FillPattern', 0);
        foreign = `<ForeignData ForeignType='Bitmap' CompressionType='${({png: 'PNG', jpeg: 'JPEG', gif: 'GIF', bmp: 'None'})[ext]}'><Rel r:id='${rid}'/></ForeignData>`;
        secs = propSection([{name: 'IdeaBoard', label: 'Idea Board data', value: s.ib, hidden: true}]);
      } else if (s.role === 'portTag'){
        // canvas look: a rounded tag outlined in the link colour; Visio look: small text on a paper-coloured background
        if (native) cells += C('LinePattern', 0) + C('FillPattern', 0) + C('TextBkgnd', TH.paper);
        else { cells += lineCells(stroke, false, 1.2 * .75 / 72) + fillCells(fill || TH.paper) + C('Rounding', s.h / 2 * PX); secs += geomSections(rectPath(W, H), p => p, W, H, 0); }
        cells += C('LeftMargin', 2 * PX) + C('RightMargin', 2 * PX) + C('TopMargin', 0) + C('BottomMargin', 0);
        textRows = [{color: native ? TH.sub : (s.textColor || TH.ink), size: ptSize(s.fontSize || 12) * (native ? .85 : 1)}];
        secs = propSection([{name: 'IdeaBoard', label: 'Idea Board data', value: tagIb, hidden: true}]) + secs;
      } else {
        const noLine = s.type === 'text' || s.type === 'note';
        const zoneNative = s.type === 'zone' && native;
        cells += (zoneNative ? C('LineWeight', .75 / 72) + C('LineColorTrans', 0) + C('LineColor', stroke) + C('LinePattern', 1) + C('LineCap', 1) : lineCells(stroke, noLine)) + fillCells(s.type === 'text' ? null : fill);
        if (s.type === 'rect') cells += C('Rounding', Math.min(10, s.w / 4, s.h / 4) * PX);
        if (s.type === 'zone'){ cells += C('Rounding', (native ? 6 : 14) * PX); valign = 0; align = 0; cells += C('LeftMargin', 14 * PX) + C('TopMargin', 8 * PX); if (useContainers) user.push(['msvStructureType', 'Container']); }
        if (s.type === 'note') cells += C('Rounding', 6 * PX);
        if (s.type === 'text'){ align = s.align === 'center' ? 1 : 0; valign = s.align === 'center' ? 1 : 0; if (s.align === 'center' && !s.noBkgnd) cells += C('TextBkgnd', TH.paper); }
        if (s.type === 'ellipse') secs += fixEllipse(ellipseSection(0, !fill, noLine), W, H);
        else if (s.type === 'diamond') secs += geomSections(diamondPath(W, H), p => p, W, H, 0);
        else if (s.type === 'cloud' && s.cloud) secs += geomSections(s.cloud, local, W, H, 0);
        else if (s.type === 'draw' && s.points){
          const sp = simplify(s.points, .8).map(local);
          if (sp.length === 1) sp.push({x: sp[0].x + .001, y: sp[0].y});
          // smooth the stroke with Catmull-Rom → cubic Bézier segments, like the pencil on the board
          const segs = sp.slice(1).map((p, i) => {
            const p0 = sp[Math.max(0, i - 1)], p1 = sp[i], p3 = sp[Math.min(sp.length - 1, i + 2)];
            return sp.length < 3 ? {t: 'L', p} : {t: 'C', c1: {x: p1.x + (p.x - p0.x) / 6, y: p1.y + (p.y - p0.y) / 6}, c2: {x: p.x - (p3.x - p1.x) / 6, y: p.y - (p3.y - p1.y) / 6}, p};
          });
          secs += geomSections([{start: sp[0], closed: false, segs}], p => p, W, H, 0, {noFill: true});
          text = '';
        } else secs += geomSections(rectPath(W, H), p => p, W, H, 0, {noFill: s.type === 'text', noLine});
        if (text) textRows = [{color: s.textColor || TH.ink, bold: s.type === 'zone' || s.type === 'cloud' || !!s.bold, size: ptSize(s.fontSize || 18) * (s.type === 'zone' && native ? .8 : 1)}];
        secs = propSection([{name: 'IPAddress', label: 'IP address', value: s.ip}, {name: 'SubnetMask', label: 'Subnet', value: s.subnet}, {name: 'VLAN', label: 'VLAN', value: s.vlan}, {name: 'Notes', label: 'Notes', value: s.notes},
          {name: 'IdeaBoard', label: 'Idea Board data', value: s.ib, hidden: true}]) + secs;
      }
      cells += layoutCells(s) + layerCell(s) + relationships(s);
      // connection points: devices, clouds and boxes get their side points plus the anchored ends; frames, tags and text only the ones links really use
      if (s.type !== 'draw' && s.role !== 'portTag' && (s.type !== 'text' || ports.has(s.id))){
        const list = [...(ports.get(s.id) || [])];
        if (!['zone', 'text', 'note'].includes(s.type)) for (const q of [...(s.connectionPoints || []).map(p => [p.x, p.y]), [.5, 0], [1, .5], [.5, 1], [0, .5]]) if (!list.some(a => Math.abs(a.x - q[0]) < 1e-6 && Math.abs(a.y - q[1]) < 1e-6)) list.push({x: q[0], y: q[1]});
        if (list.length) secs = `<Section N='Connection'>${list.map((q, i) => `<Row IX='${i}'>${C('X', q.x * W, `Width*${num(q.x)}`)}${C('Y', (1 - q.y) * H, `Height*${num(1 - q.y)}`)}${C('DirX', 0)}${C('DirY', 0)}${C('Type', 0)}</Row>`).join('')}</Section>` + secs;
      }
      if (user.length) secs = userSection(user) + secs;
      if (text){
        cells += C('VerticalAlign', valign);
        const rows = textRows || [{color: TH.ink, size: 10}];
        secs = chars(rows) + paraSection(align) + secs;
        if (rows.length > 1){ const [first, ...rest] = text.split('\n'); text = `<cp IX='0'/>${esc(first)}${rest.length ? `\n<cp IX='1'/>${esc(rest.join('\n'))}` : ''}`; }
        else text = esc(text);
      }
      out.push(`<Shape ID='${id}' NameU='${nm}' Name='${nm}' Type='${type}' LineStyle='3' FillStyle='3' TextStyle='3'>${cells}${secs}${foreign}${text ? `<Text>${text}</Text>` : ''}${children ? '<Shapes>' + children + '</Shapes>' : ''}</Shape>`);
    }
    const n = pi + 1, name = String(pg.name || 'Page-' + n).replace(/[\r\n]+/g, ' ').slice(0, 31) || 'Page-' + n;
    const pr = [];
    if (usesConnector) pr.push(['rId1', VREL('master'), '../masters/master1.xml']);
    pr.push(...media);
    const layers = layerIx.size ? `<Section N='Layer'>${[...layerIx.keys()].map((k, i) => `<Row IX='${i}'>${C('Name', LAYER_NAMES[k])}${C('Color', 255)}${C('Status', 0)}${C('Visible', 1)}${C('Print', 1)}${C('Active', 0)}${C('Lock', 0)}${C('Snap', 1)}${C('Glue', 1)}${C('NameUniv', LAYER_NAMES[k])}${C('ColorTrans', 0)}</Row>`).join('')}</Section>` : '';
    // LineJumpCode 0: no hops where links cross (matches the canvas); the screen grid matches the canvas grid (20 px squares, heavier every 5)
    const gridCells = C('XGridDensity', 0) + C('YGridDensity', 0) + C('XGridSpacing', 20 * PX) + C('YGridSpacing', 20 * PX) + C('XGridOrigin', 0) + C('YGridOrigin', 0);
    pageRows.push(`<Page ID='${pi}' NameU='${esc(name)}' Name='${esc(name)}'><PageSheet LineStyle='0' FillStyle='0' TextStyle='0'>${C('PageWidth', PW)}${C('PageHeight', PH)}${C('ShdwOffsetX', .125)}${C('ShdwOffsetY', -.125)}${C('PageScale', 1, null, 'IN_F')}${C('DrawingScale', 1, null, 'IN_F')}${C('DrawingSizeType', 3)}${C('DrawingScaleType', 0)}${C('InhibitSnap', 0)}${C('UIVisibility', 0)}${C('ShdwType', 0)}${C('ShdwObliqueAngle', 0)}${C('ShdwScaleFactor', 1)}${C('DrawingResizeType', 1)}${C('PrintPageOrientation', PW > PH ? 2 : 1)}${C('LineJumpCode', 0)}${gridCells}${layers}</PageSheet><Rel r:id='rId${n}'/></Page>`);
    pageRels.push(['rId' + n, VREL('page'), `page${n}.xml`]);
    files.push([`visio/pages/page${n}.xml`, pagePart((out.length ? `<Shapes>${out.join('')}</Shapes>` : '') + (connects.length ? `<Connects>${connects.join('')}</Connects>` : ''))]);
    if (pr.length) files.push([`visio/pages/_rels/page${n}.xml.rels`, rels(pr)]);
    ct.push([`/visio/pages/page${n}.xml`, 'application/vnd.ms-visio.page+xml']);
  });
  const printGrid = grid === 'print';
  if (pageRows.length && ((board.bg && board.bg !== 'none') || printGrid)){
    const bgId = board.pages.length, n = bgId + 1, BW = maxPW, BH = maxPH, filled = board.bg && board.bg !== 'none';
    const stops = board.bg === 'black' ? [[board.gradient === false ? '#000000' : '#202530', 0], ['#000000', 1]] : [['#ffffff', 0], ['#dde5ef', 1]];
    let shape = `<Shape ID='1' NameU='Background.1' Name='Background' Type='Shape' LineStyle='3' FillStyle='3' TextStyle='3'>` +
      C('PinX', BW / 2) + C('PinY', BH / 2) + C('Width', BW) + C('Height', BH) + C('LocPinX', BW / 2, 'Width*0.5') + C('LocPinY', BH / 2, 'Height*0.5') + C('Angle', 0) +
      C('LinePattern', 0) + C('FillForegnd', stops[0][0]) + C('FillBkgnd', stops[1][0]) + C('FillPattern', filled ? 1 : 0) +
      C('FillGradientEnabled', filled && !printGrid && board.gradient !== false ? 1 : 0) + C('FillGradientDir', 0) + C('FillGradientAngle', Math.PI / 2, null, 'DEG') + C('RotateGradientWithShape', 0) + C('LockSelect', 1) +
      `<Section N='FillGradient'>${stops.map(([c, pos], i) => `<Row IX='${i}'>${C('GradientStopColor', c)}${C('GradientStopColorTrans', 0)}${C('GradientStopPosition', pos)}</Row>`).join('')}</Section>` +
      geomSections(rectPath(BW, BH), q => q, BW, BH, 0, {noLine: true, noFill: !filled}) + `</Shape>`;
    if (printGrid){
      const step = Math.max(20 * PX, Math.max(BW, BH) / 1800), minor = [], major = [];
      for (let i = 1; i * step < BW; i++){ const x = i * step; (i % 5 ? minor : major).push({start: {x, y: 0}, closed: false, segs: [{t: 'L', p: {x, y: BH}}]}); }
      for (let i = 1; i * step < BH; i++){ const y = i * step; (i % 5 ? minor : major).push({start: {x: 0, y}, closed: false, segs: [{t: 'L', p: {x: BW, y}}]}); }
      [minor, major].forEach((paths, i) => { shape += `<Shape ID='${i + 2}' NameU='GraphPaper${i ? 'Major' : 'Minor'}' Type='Shape'>` +
        C('PinX', BW / 2) + C('PinY', BH / 2) + C('Width', BW) + C('Height', BH) + C('LocPinX', BW / 2, 'Width*0.5') + C('LocPinY', BH / 2, 'Height*0.5') +
        C('LinePattern', 1) + C('LineColor', board.dark ? (i ? '#3d424a' : '#25282d') : (i ? '#c8ccd1' : '#e2e4e7')) + C('LineWeight', (i ? .7 : .5) * PX) + C('FillPattern', 0) + C('LockSelect', 1) + geomSections(paths, p => p, BW, BH, 0, {noFill: true}) + '</Shape>'; });
    }
    const first = pageRows[0];
    let bgRow = first.replace(/^<Page ID='0' NameU='[^']*' Name='[^']*'/, `<Page ID='${bgId}' NameU='Background' Name='Background' Background='1'`)
      .replace(/<Cell N='PageWidth' V='[^']*'/, `<Cell N='PageWidth' V='${num(BW)}'`).replace(/<Cell N='PageHeight' V='[^']*'/, `<Cell N='PageHeight' V='${num(BH)}'`).replace(/<Rel r:id='rId\d+'\/>/, `<Rel r:id='rId${n}'/>`).replace(/<Section N='Layer'>.*?<\/Section>/, '');
    for (let i = 0; i < pageRows.length; i++) pageRows[i] = pageRows[i].replace(/^<Page ID='(\d+)'/, `<Page ID='$1' BackPage='${bgId}'`);
    pageRows.push(bgRow);
    pageRels.push(['rId' + n, VREL('page'), `page${n}.xml`]);
    files.push([`visio/pages/page${n}.xml`, pagePart(`<Shapes>${shape}</Shapes>`)]);
    ct.push([`/visio/pages/page${n}.xml`, 'application/vnd.ms-visio.page+xml']);
  }
  const title = esc(board.name || 'Idea Board'), iso = new Date().toISOString().replace(/\.\d+Z$/, 'Z');
  files.unshift(['[Content_Types].xml', HEAD + `<Types xmlns='http://schemas.openxmlformats.org/package/2006/content-types'><Default Extension='rels' ContentType='application/vnd.openxmlformats-package.relationships+xml'/><Default Extension='xml' ContentType='application/xml'/><Default Extension='png' ContentType='image/png'/><Default Extension='jpeg' ContentType='image/jpeg'/><Default Extension='gif' ContentType='image/gif'/><Default Extension='bmp' ContentType='image/bmp'/>` +
    `<Override PartName='/visio/document.xml' ContentType='application/vnd.ms-visio.drawing.main+xml'/><Override PartName='/visio/masters/masters.xml' ContentType='application/vnd.ms-visio.masters+xml'/><Override PartName='/visio/masters/master1.xml' ContentType='application/vnd.ms-visio.master+xml'/><Override PartName='/visio/pages/pages.xml' ContentType='application/vnd.ms-visio.pages+xml'/>` +
    ct.map(([p, t]) => `<Override PartName='${p}' ContentType='${t}'/>`).join('') +
    `<Override PartName='/visio/windows.xml' ContentType='application/vnd.ms-visio.windows+xml'/><Override PartName='/docProps/core.xml' ContentType='application/vnd.openxmlformats-package.core-properties+xml'/><Override PartName='/docProps/app.xml' ContentType='application/vnd.openxmlformats-officedocument.extended-properties+xml'/></Types>`]);
  files.push(['_rels/.rels', rels([['rId1', VREL('document'), 'visio/document.xml'], ['rId2', 'http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties', 'docProps/core.xml'], ['rId3', 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties', 'docProps/app.xml']])]);
  files.push(['docProps/core.xml', HEAD + `<cp:coreProperties xmlns:cp='http://schemas.openxmlformats.org/package/2006/metadata/core-properties' xmlns:dc='http://purl.org/dc/elements/1.1/' xmlns:dcterms='http://purl.org/dc/terms/' xmlns:dcmitype='http://purl.org/dc/dcmitype/' xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'><dc:title>${title}</dc:title><dc:creator>Idea Board</dc:creator><dcterms:created xsi:type='dcterms:W3CDTF'>${iso}</dcterms:created><dcterms:modified xsi:type='dcterms:W3CDTF'>${iso}</dcterms:modified></cp:coreProperties>`]);
  const names = board.pages.map((p, i) => String(p.name || 'Page-' + (i + 1)).replace(/[\r\n]+/g, ' ').slice(0, 31) || 'Page-' + (i + 1));
  files.push(['docProps/app.xml', HEAD + `<Properties xmlns='http://schemas.openxmlformats.org/officeDocument/2006/extended-properties' xmlns:vt='http://schemas.openxmlformats.org/officeDocument/2006/docPropsVTypes'><Template></Template><Application>Microsoft Visio</Application><ScaleCrop>false</ScaleCrop><HeadingPairs><vt:vector size='4' baseType='variant'><vt:variant><vt:lpstr>Pages</vt:lpstr></vt:variant><vt:variant><vt:i4>${names.length}</vt:i4></vt:variant><vt:variant><vt:lpstr>Masters</vt:lpstr></vt:variant><vt:variant><vt:i4>1</vt:i4></vt:variant></vt:vector></HeadingPairs><TitlesOfParts><vt:vector size='${names.length + 1}' baseType='lpstr'>${names.map(n => `<vt:lpstr>${esc(n)}</vt:lpstr>`).join('')}<vt:lpstr>Dynamic connector</vt:lpstr></vt:vector></TitlesOfParts><Manager></Manager><Company></Company><LinksUpToDate>false</LinksUpToDate><SharedDoc>false</SharedDoc><HyperlinkBase></HyperlinkBase><HyperlinksChanged>false</HyperlinksChanged><AppVersion>16.0000</AppVersion></Properties>`]);
  files.push(['visio/document.xml', HEAD + T.document]);
  files.push(['visio/_rels/document.xml.rels', rels([['rId1', VREL('masters'), 'masters/masters.xml'], ['rId2', VREL('pages'), 'pages/pages.xml'], ['rId3', VREL('windows'), 'windows.xml']])]);
  files.push(['visio/masters/masters.xml', HEAD + T.masters]);
  files.push(['visio/masters/master1.xml', HEAD + T.master1]);
  files.push(['visio/masters/_rels/masters.xml.rels', rels([['rId1', VREL('master'), 'master1.xml']])]);
  files.push(['visio/pages/pages.xml', HEAD + `<Pages xmlns='${NS}' xmlns:r='${R}' xml:space='preserve'>${pageRows.join('')}</Pages>`]);
  files.push(['visio/pages/_rels/pages.xml.rels', rels(pageRels)]);
  // open on the first page, zoomed to show all of it
  const fit = firstView ? Math.max(.05, Math.min(1, Math.min(1500 / (firstView.PW * 96), 820 / (firstView.PH * 96)) * .95)) : 1;
  const view = firstView ? ` ViewScale='${num(fit)}' ViewCenterX='${num(firstView.PW / 2)}' ViewCenterY='${num(firstView.PH / 2)}'` : '';
  files.push(['visio/windows.xml', HEAD + `<Windows ClientWidth='1600' ClientHeight='900' xmlns='${NS}' xmlns:r='${R}' xml:space='preserve'><Window ID='0' WindowType='Drawing' WindowState='1073741824' WindowLeft='-8' WindowTop='-31' WindowWidth='1616' WindowHeight='939' ContainerType='Page' Page='0'${view}><ShowRulers>1</ShowRulers><ShowGrid>${grid === 'screen' ? 1 : 0}</ShowGrid><ShowPageBreaks>0</ShowPageBreaks><ShowGuides>1</ShowGuides><ShowConnectionPoints>1</ShowConnectionPoints><GlueSettings>9</GlueSettings><SnapSettings>65847</SnapSettings><SnapExtensions>34</SnapExtensions><SnapAngles/><DynamicGridEnabled>1</DynamicGridEnabled><TabSplitterPos>0.5</TabSplitterPos></Window></Windows>`]);
  return {bytes: zip(files), warnings: [...warnings], files};
}
// Visio arrowhead indices (Format Line ▸ Arrows): 1 open, 4 filled triangle, 10 filled dot, 22 diamond, 24 bar.
function arrowCode(k){ return ({arrow: 1, triangle: 4, dot: 10, diamond: 22, bar: 24})[k] || 0; }
function arrowKind(code){
  code = +code || 0; if (!code) return 'none';
  if ([1, 3, 9, 12, 27, 28, 43, 44, 45].includes(code)) return 'arrow';
  if ([10, 11, 20, 21, 29, 30].includes(code) || (code >= 31 && code <= 38) || code === 41 || code === 42) return 'dot';
  if (code === 22) return 'diamond';
  if ([23, 24, 25, 26].includes(code)) return 'bar';
  return 'triangle';
}

/* ---------------- reader ---------------- */
async function parse(input){
  const files = await unzip(input), dec = new TextDecoder();
  const text = p => { const b = files.get(p); return b ? dec.decode(b) : null; };
  const xmlDoc = p => { const t = text(p); if (t == null) return null; const d = new DOMParser().parseFromString(t, 'application/xml'); if (d.getElementsByTagName('parsererror').length) throw Error('Unreadable part in the Visio file: ' + p); return d; };
  const dir = p => p.includes('/') ? p.slice(0, p.lastIndexOf('/') + 1) : '';
  const resolve = (base, target) => { if (target.startsWith('/')) return target.slice(1); const parts = (dir(base) + target).split('/'), out = []; for (const s of parts){ if (s === '..') out.pop(); else if (s !== '.') out.push(s); } return out.join('/'); };
  const relsOf = part => { const d = xmlDoc(dir(part) + '_rels/' + part.slice(dir(part).length) + '.rels'), m = new Map(); if (d) for (const r of d.getElementsByTagName('Relationship')) m.set(r.getAttribute('Id'), {type: r.getAttribute('Type') || '', target: resolve(part, r.getAttribute('Target') || '')}); return m; };
  if (!files.has('[Content_Types].xml')) throw Error('This file is not a Visio drawing (.vsdx).');
  const rootRels = relsOf(''), docRel = [...(xmlDoc('_rels/.rels') ? relsOf('') : new Map()).values()].find(r => /\/document$/.test(r.type));
  const docPath = docRel ? docRel.target : 'visio/document.xml';
  if (!files.has(docPath)) throw Error('The Visio document part is missing.');
  const dRels = relsOf(docPath), find = t => [...dRels.values()].find(r => r.type.endsWith('/' + t));
  const kids = (el, tag) => el ? [...el.children].filter(c => c.localName === tag) : [];
  const kid = (el, tag) => kids(el, tag)[0] || null;
  // masters
  const masters = new Map();
  const mRel = find('masters');
  if (mRel){
    const md = xmlDoc(mRel.target), mr = relsOf(mRel.target);
    if (md) for (const m of kids(md.documentElement, 'Master')){
      const rel = kid(m, 'Rel'), rid = rel && (rel.getAttribute('r:id') || rel.getAttributeNS(R, 'id')), t = mr.get(rid);
      const cd = t ? xmlDoc(t.target) : null, byId = new Map(); let top = null;
      if (cd){ const walk = (el, depth) => { for (const s of kids(kid(el, 'Shapes'), 'Shape')){ byId.set(s.getAttribute('ID'), s); if (!depth && !top) top = s; walk(s, depth + 1); } }; walk(cd.documentElement, 0); }
      masters.set(m.getAttribute('ID'), {name: m.getAttribute('NameU') || m.getAttribute('Name') || '', top, byId});
    }
  }
  const pRel = find('pages');
  if (!pRel) throw Error('The Visio file has no pages.');
  const pd = xmlDoc(pRel.target), pr = relsOf(pRel.target), result = {pages: [], assets: {}, warnings: new Set()};
  let assetN = 0;
  for (const page of kids(pd.documentElement, 'Page')){
    if (page.getAttribute('Background') === '1') continue;
    const rel = kid(page, 'Rel'), rid = rel && (rel.getAttribute('r:id') || rel.getAttributeNS(R, 'id')), t = pr.get(rid);
    const ps = kid(page, 'PageSheet'), cellIn = (el, n) => { const c = kids(el, 'Cell').find(c => c.getAttribute('N') === n); return c ? c.getAttribute('V') : null; };
    const PH = parseFloat(cellIn(ps, 'PageHeight')) || 11;
    const doc = t ? xmlDoc(t.target) : null; if (!doc) continue;
    const prels = relsOf(t.target);
    result.pages.push(readPage(doc.documentElement, PH, prels));
    result.pages[result.pages.length - 1].name = page.getAttribute('Name') || page.getAttribute('NameU') || '';
  }
  return {pages: result.pages, assets: result.assets, warnings: [...result.warnings]};

  function readPage(pc, PH, prels){
    const shapes = [], byVisio = new Map(), parentOf = new Map(), out = [];
    // resolve master shape for an element
    const masterFor = (el, inherited) => {
      const mid = el.getAttribute('Master'), msid = el.getAttribute('MasterShape');
      if (mid && masters.has(mid)){ const m = masters.get(mid); return {m, ms: msid ? m.byId.get(msid) : m.top}; }
      if (inherited && msid) return {m: inherited, ms: inherited.byId.get(msid)};
      return {m: inherited || null, ms: null};
    };
    const cellEl = (el, n) => el ? kids(el, 'Cell').find(c => c.getAttribute('N') === n) : null;
    const make = (el, ms) => ({
      el, ms,
      raw(n){ const c = cellEl(el, n) || cellEl(ms, n); return c ? c.getAttribute('V') : null; },
      n(n, d = 0){ const v = parseFloat(this.raw(n)); return Number.isFinite(v) ? v : d; },
      has(n){ return !!(cellEl(el, n) || cellEl(ms, n)); },
      sections(name){ const own = kids(el, 'Section').filter(s => s.getAttribute('N') === name); return own.length ? own : kids(ms, 'Section').filter(s => s.getAttribute('N') === name); },
      text(){ const t = kid(el, 'Text') || kid(ms, 'Text'); return t ? t.textContent.replace(/\r/g, '').replace(/\u2028|\u2029/g, '\n').replace(/\n+$/, '') : ''; },
      prop(name){ for (const s of [...kids(el, 'Section'), ...kids(ms, 'Section')]) if (s.getAttribute('N') === 'Property') for (const r of kids(s, 'Row')) if (r.getAttribute('N') === name){ const c = cellEl(r, 'Value'); if (c) return c.getAttribute('V'); } return null; },
      user(name){ for (const s of [...kids(el, 'Section'), ...kids(ms, 'Section')]) if (s.getAttribute('N') === 'User') for (const r of kids(s, 'Row')) if (r.getAttribute('N') === name){ const c = cellEl(r, 'Value'); if (c) return c.getAttribute('V'); } return null; }
    });
    // affine helpers: [a,b,c,d,e,f] maps (x,y) → (a x + c y + e, b x + d y + f)
    const mul = (m, n) => [m[0] * n[0] + m[2] * n[1], m[1] * n[0] + m[3] * n[1], m[0] * n[2] + m[2] * n[3], m[1] * n[2] + m[3] * n[3], m[0] * n[4] + m[2] * n[5] + m[4], m[1] * n[4] + m[3] * n[5] + m[5]];
    const ap = (m, x, y) => ({x: m[0] * x + m[2] * y + m[4], y: m[1] * x + m[3] * y + m[5]});
    const localToParent = S => {
      const a = S.n('Angle'), c = Math.cos(a), s = Math.sin(a), fx = S.n('FlipX') ? -1 : 1, fy = S.n('FlipY') ? -1 : 1;
      return mul(mul([1, 0, 0, 1, S.n('PinX'), S.n('PinY')], [c, s, -s, c, 0, 0]), mul([fx, 0, 0, fy, 0, 0], [1, 0, 0, 1, -S.n('LocPinX'), -S.n('LocPinY')]));
    };
    const toPx = p => ({x: p.x * 96, y: (PH - p.y) * 96});
    const walk = (container, parentM, inheritedMaster, top) => {
      for (const el of kids(kid(container, 'Shapes'), 'Shape')){
        const {m, ms} = masterFor(el, inheritedMaster), S = make(el, ms), id = el.getAttribute('ID');
        S.master = m; S.vid = id; S.parentM = parentM; S.top = top || id;
        S.nameU = (el.getAttribute('NameU') || el.getAttribute('Name') || (m && m.name) || '').replace(/\.\d+$/, '');
        S.type = el.getAttribute('Type') || (ms && ms.getAttribute('Type')) || 'Shape';
        S.M = mul(parentM, localToParent(S));
        byVisio.set(id, S); shapes.push(S);
        if (S.type === 'Group') walk(el, S.M, m && ms ? m : inheritedMaster, top || id);
      }
    };
    walk(pc, [1, 0, 0, 1, 0, 0], null, null);
    const ibData = S => { const v = S.prop('IdeaBoard'); if (!v) return null; try { return JSON.parse(v); } catch (e) { return null; } };
    const color = v => { if (v == null) return null; v = String(v).trim(); if (/^#[\da-f]{6}$/i.test(v)) return v.toLowerCase(); if (/^\d+$/.test(v)) return ['#000000', '#ffffff', '#ff0000', '#00ff00', '#0000ff', '#ffff00', '#ff00ff', '#00ffff', '#800000', '#008000', '#000080', '#808000', '#800080', '#008080', '#c0c0c0', '#e6e6e6', '#cdcdcd', '#b3b3b3', '#9a9a9a', '#808080', '#666666', '#4d4d4d', '#333333', '#1a1a1a'][+v] || null; const m = /RGB\((\d+),\s*(\d+),\s*(\d+)\)/i.exec(v); return m ? '#' + [m[1], m[2], m[3]].map(x => (+x).toString(16).padStart(2, '0')).join('') : null; };
    const bbox = S => { const W = S.n('Width'), H = S.n('Height'), ps = [ap(S.M, 0, 0), ap(S.M, W, 0), ap(S.M, W, H), ap(S.M, 0, H)].map(toPx); const xs = ps.map(p => p.x), ys = ps.map(p => p.y); return {x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys)}; };
    const isOneD = S => S.has('BeginX') && S.has('EndX') && (S.n('ObjType') === 2 || /connector|line|arrow|link|cable|wire/i.test(S.nameU) || S.type !== 'Group');
    const geomInfo = S => {
      const secs = S.sections('Geometry').filter(g => { const c = cellEl(g, 'NoShow'); return !(c && c.getAttribute('V') === '1'); });
      let rows = [], noFillAll = true, noLineAll = true;
      for (const g of secs){ const nf = cellEl(g, 'NoFill'), nl = cellEl(g, 'NoLine'); if (!(nf && nf.getAttribute('V') === '1')) noFillAll = false; if (!(nl && nl.getAttribute('V') === '1')) noLineAll = false; rows.push(...kids(g, 'Row').filter(r => r.getAttribute('Del') !== '1').map(r => r.getAttribute('T'))); }
      return {count: secs.length, rows, noFillAll, noLineAll};
    };
    const DEVICE_WORDS = [[/firewall|\basa\b|fortigate|palo|checkpoint|check point/i, 'firewall'], [/load ?balanc|\bslb\b|f5|big-?ip/i, 'lb'], [/wireless lan controller|\bwlc\b/i, 'wlc'], [/access ?point|\bwap\b|wireless ap|\bap\b/i, 'ap'],
      [/layer ?3|l3 ?switch|multilayer|multi-layer|core switch|nexus/i, 'l3switch'], [/switch|catalyst/i, 'switch'], [/router|\basr\b|\bisr\b|gateway router/i, 'router'], [/voice gateway|\bvg\b|\bcube\b/i, 'vgw'], [/console server|terminal server|avocent|opengear/i, 'console'],
      [/\bise\b|\bnac\b|radius|aaa/i, 'ise'], [/ip ?phone|telephone|phone/i, 'phone'], [/server|host|vm\b|esx/i, 'server'], [/pc\b|workstation|laptop|desktop|computer|endpoint/i, 'pc'], [/modem|\bnte\b|\bcpe\b|ntu|demarc/i, 'nte']];
    const deviceKind = s => { for (const [re, k] of DEVICE_WORDS) if (re.test(s)) return k; return null; };
    const handled = new Set(), map = new Map();
    // decide what each top-level-ish shape becomes
    const visit = S => {
      if (handled.has(S.vid)) return;
      let data = ibData(S); if (data && data.type === 'draw' && !Array.isArray(data.pts)) data = null;
      const txt = S.type==='Group'&&data?.type==='device'?(shapes.find(o=>o.top===S.vid&&o.nameU==='Hostname')?.text()||S.text()):S.text(), b = bbox(S), stencil = (S.master ? S.master.name : '') + ' ' + S.nameU;
      const markChildren = () => { for (const o of shapes) if (o !== S && isDesc(o, S)) handled.add(o.vid); };
      if (isOneD(S) && !data?.type?.match(/^(rect|ellipse|diamond|cloud|zone|note|text|device|image|draw)$/)){
        out.push({kind: 'conn', S, data, txt}); handled.add(S.vid); return;
      }
      if (S.type === 'Foreign'){
        const fd = kid(S.el, 'ForeignData') || kid(S.ms, 'ForeignData'), rel = fd && kid(fd, 'Rel'), rid = rel && (rel.getAttribute('r:id') || rel.getAttributeNS(R, 'id')), t = rid && prels.get(rid);
        const bytes = t && files.get(t.target), ext = t ? t.target.split('.').pop().toLowerCase() : '';
        const mime = ({png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', bmp: 'image/bmp', svg: 'image/svg+xml'})[ext];
        if (bytes && mime){ const id = 'vsdx' + (++assetN) + Math.random().toString(36).slice(2, 6); let bin = ''; for (let i = 0; i < bytes.length; i += 8192) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192)); result.assets[id] = `data:${mime};base64,` + btoa(bin); out.push({kind: 'image', S, b, asset: id, data}); }
        else { result.warnings.add('Some pictures use formats a browser cannot show (EMF/WMF/OLE) and were replaced with placeholders.'); out.push({kind: 'shape', S, b, txt: txt || '[picture]', guess: 'rect'}); }
        handled.add(S.vid); return;
      }
      if (data && data.type){ out.push({kind: 'shape', S, data, txt, b}); handled.add(S.vid); markChildren(); return; }
      const dk = deviceKind(stencil);
      if (S.type === 'Group'){
        if (dk || /cloud/i.test(stencil)){ out.push({kind: 'shape', S, b, txt: txt || groupText(S), guess: dk ? 'device' : 'cloud', devKind: dk}); handled.add(S.vid); markChildren(); return; }
        if (S.user('msvStructureType') === 'Container' || /container/i.test(stencil)){ out.push({kind: 'shape', S, b, txt, guess: 'zone'}); handled.add(S.vid); return; }
        handled.add(S.vid);                                   // plain group: import its parts
        if (txt) out.push({kind: 'shape', S, b, txt, guess: 'text'});
        return;
      }
      const gi = geomInfo(S);
      let guess = 'rect';
      if (dk && !/text|label|callout/i.test(stencil)) guess = 'device';
      else if (/cloud/i.test(stencil)) guess = 'cloud';
      else if (S.user('msvStructureType') === 'Container' || /container/i.test(stencil)) guess = 'zone';
      else if (!gi.count || (gi.noFillAll && gi.noLineAll)) guess = txt ? 'text' : null;
      else if (gi.rows.length === 1 && gi.rows[0] === 'Ellipse') guess = 'ellipse';
      else if (gi.rows.filter(r => /LineTo/.test(r)).length === 4 && isDiamond(S)) guess = 'diamond';
      else if (gi.rows.length > 2 && gi.rows.every(r => /MoveTo|LineTo|PolylineTo|NURBSTo|SplineStart|SplineKnot|ArcTo|InfiniteLine/.test(r)) && gi.noFillAll && !txt) guess = 'draw';
      handled.add(S.vid);
      if (guess) out.push({kind: 'shape', S, b, txt, guess, devKind: dk});
    };
    // where Visio would draw the text: the text block (TxtPin/TxtLocPin/TxtWidth/TxtHeight) plus alignment
    const textBlock = S => {
      const W = S.n('Width'), H = S.n('Height'), tw = S.has('TxtWidth') ? S.n('TxtWidth') : W, th = S.has('TxtHeight') ? S.n('TxtHeight') : H;
      const px = S.has('TxtPinX') ? S.n('TxtPinX') : W / 2, py = S.has('TxtPinY') ? S.n('TxtPinY') : H / 2, lx = S.has('TxtLocPinX') ? S.n('TxtLocPinX') : tw / 2, ly = S.has('TxtLocPinY') ? S.n('TxtLocPinY') : th / 2;
      const x0 = px - lx, y0 = py - ly, ps = [ap(S.M, x0, y0), ap(S.M, x0 + tw, y0), ap(S.M, x0 + tw, y0 + th), ap(S.M, x0, y0 + th)].map(toPx);
      const xs = ps.map(p => p.x), ys = ps.map(p => p.y), para = S.sections('Paragraph')[0], row = para && kids(para, 'Row')[0], ha = row && cellEl(row, 'HorzAlign');
      return {x: Math.min(...xs), y: Math.min(...ys), w: Math.max(...xs) - Math.min(...xs), h: Math.max(...ys) - Math.min(...ys), h_: ha ? +ha.getAttribute('V') : 1, v_: S.has('VerticalAlign') ? S.n('VerticalAlign') : 1,
        m: {l: S.n('LeftMargin', 4 / 72) * 96, r: S.n('RightMargin', 4 / 72) * 96, t: S.n('TopMargin', 4 / 72) * 96, b: S.n('BottomMargin', 4 / 72) * 96}};
    };
    const isDesc = (o, S) => { let p = o; while (p){ const par = parentOf.get(p.vid); if (par === S.vid) return true; p = par ? byVisio.get(par) : null; } return false; };
    for (const S of shapes){ const el = S.el.parentElement && S.el.parentElement.parentElement; if (el && el.localName === 'Shape') parentOf.set(S.vid, el.getAttribute('ID')); }
    const groupText = S => shapes.filter(o => isDesc(o, S)).map(o => o.text()).filter(Boolean).join('\n');
    const isDiamond = S => { const g = S.sections('Geometry')[0]; if (!g) return false; const W = S.n('Width') || 1, H = S.n('Height') || 1; const pts = kids(g, 'Row').filter(r => /To$/.test(r.getAttribute('T'))).map(r => { let x = parseFloat(cellEl(r, 'X')?.getAttribute('V')), y = parseFloat(cellEl(r, 'Y')?.getAttribute('V')); if (/^Rel/.test(r.getAttribute('T'))){ x *= W; y *= H; } return {x: x / W, y: y / H}; }); return pts.some(p => Math.abs(p.x - .5) < .05 && Math.abs(p.y) < .05) && pts.some(p => Math.abs(p.x - 1) < .05 && Math.abs(p.y - .5) < .05); };
    for (const S of shapes) visit(S);
    // glue
    const glue = new Map();
    for (const c of kids(kid(pc, 'Connects'), 'Connect')){
      const from = c.getAttribute('FromSheet'), cellN = c.getAttribute('FromCell'), to = c.getAttribute('ToSheet'), toCell = c.getAttribute('ToCell') || '';
      if (!/^(BeginX|EndX)$/.test(cellN)) continue;
      glue.set(from + ':' + (cellN === 'BeginX' ? 'start' : 'end'), {to, toCell});
    }
    // port tags edited in Visio (their text differs from what was exported) win over the link's Shape Data
    const tagEdits = new Map();
    for (const S of shapes){ const d = ibData(S); if (d && d.type === 'portLabel' && d.tag && d.conn){ const t = S.text(); if (t !== (d.text || '')) tagEdits.set(d.conn + ':' + d.tag, t); } }
    // build Idea Board shapes
    const idFor = new Map(), result_ = [], conns = [];
    const ib = () => 'v' + Math.random().toString(36).slice(2, 10);
    for (const o of out){
      if (o.kind === 'conn'){ conns.push(o); continue; }
      const S = o.S, b = o.b, lc = color(S.raw('LineColor')), fp = S.n('FillPattern', 1), fc = fp ? color(S.raw('FillForegnd')) : null, lp = S.n('LinePattern', 1);
      const textHex = (() => { const ch = S.sections('Character')[0], r = ch && kids(ch, 'Row')[0], c = r && cellEl(r, 'Color'); return c ? color(c.getAttribute('V')) : null; })();
      const sizePt = (() => { const ch = S.sections('Character')[0], r = ch && kids(ch, 'Row')[0], c = r && cellEl(r, 'Size'); return c ? parseFloat(c.getAttribute('V')) * 72 : 12; })();
      const base = {id: ib(), x: b.x, y: b.y, w: Math.max(4, b.w), h: Math.max(4, b.h), text: o.txt || '', lineHex: lc, fillHex: fc, dash: lp === 0 ? 'none' : lp >= 2 ? (lp === 3 || lp >= 9 ? 'dotted' : 'dashed') : 'solid', fontPt: sizePt, noLine: lp === 0, lineIn: S.n('LineWeight', .01), textHex, textBox: textBlock(S)};
      let s;
      if (o.kind === 'image') s = o.data && o.data.type === 'image' ? {...o.data, id: ib(), x: b.x, y: b.y, w: b.w, h: b.h, asset: o.asset, __exact: true} : {...base, type: 'image', asset: o.asset};
      else if (o.data){
        s = {...o.data, id: ib(), x: b.x, y: b.y, w: b.w, h: b.h};
        if (s.type === 'device'){ const [host] = (o.txt || '').split('\n'); if (o.txt != null && s.view !== 'rack') s.text = host || ''; else if (s.view === 'rack' && o.txt) s.text = o.txt.split(/\s{3,}/)[0]; s.role = S.prop('Role') ?? s.role; s.info = S.prop('Info') ?? s.info; }
        else if (s.type !== 'draw') s.text = o.txt;
        s.__exact = true;
      } else {
        s = {...base, type: o.guess};
        if (o.guess === 'device'){ s.kind = o.devKind || 'switch'; const lines = (o.txt || '').split('\n').filter(Boolean); s.text = S.prop('Hostname') || S.prop('NetworkName') || lines[0] || ''; s.info = lines.slice(1).join('\n'); s.role = S.prop('Role') || ''; }
        if (o.guess === 'draw'){
          const g = S.sections('Geometry')[0], W = S.n('Width') || 1, H = S.n('Height') || 1;
          s.points = kids(g, 'Row').filter(r => /To$/.test(r.getAttribute('T'))).map(r => { let x = parseFloat(cellEl(r, 'X')?.getAttribute('V')) || 0, y = parseFloat(cellEl(r, 'Y')?.getAttribute('V')) || 0; if (/^Rel/.test(r.getAttribute('T'))){ x *= W; y *= H; } return toPx(ap(S.M, x, y)); });
          if (s.points.length < 2) s.type = 'rect';
        }
      }
      idFor.set(S.vid, s.id); result_.push(s);
    }
    // map glue targets inside groups to their imported ancestor
    const targetId = vid => { let p = vid; while (p){ if (idFor.has(p)) return idFor.get(p); p = parentOf.get(p); } return null; };
    for (const o of conns){
      const S = o.S, d = o.data, pts = (() => {
        const W = S.n('Width'), H = S.n('Height'); const list = [];
        for (const g of S.sections('Geometry')) for (const r of kids(g, 'Row')){ if (r.getAttribute('Del') === '1' || !/To$/.test(r.getAttribute('T'))) continue; let x = parseFloat(cellEl(r, 'X')?.getAttribute('V')), y = parseFloat(cellEl(r, 'Y')?.getAttribute('V')); if (!Number.isFinite(x) || !Number.isFinite(y)) continue; if (/^Rel/.test(r.getAttribute('T'))){ x *= W; y *= H; } list.push(toPx(ap(S.M, x, y))); }
        return list;
      })();
      const pm = S.parentM, bp = toPx(ap(pm, S.n('BeginX'), S.n('BeginY'))), epnt = toPx(ap(pm, S.n('EndX'), S.n('EndY')));
      const ends = {};
      for (const [key, p] of [['start', bp], ['end', epnt]]){
        const g = glue.get(S.vid + ':' + key), tid = g && targetId(g.to);
        if (tid){
          const ep = {id: tid}, m = /^Connections\.X(\d+)$/.exec(g.toCell || ''), T = byVisio.get(g.to);
          if (m && T){ const sec = T.sections('Connection')[0], row = sec && kids(sec, 'Row')[+m[1] - 1]; if (row){ const W = T.n('Width') || 1, H = T.n('Height') || 1; const x = parseFloat(cellEl(row, 'X')?.getAttribute('V')), y = parseFloat(cellEl(row, 'Y')?.getAttribute('V')); if (Number.isFinite(x) && Number.isFinite(y) && T.vid === g.to && idFor.get(T.vid) === tid) ep.anchor = {x: Math.round(Math.max(0, Math.min(1, x / W)) * 1e4) / 1e4, y: Math.round(Math.max(0, Math.min(1, 1 - y / H)) * 1e4) / 1e4}; } }
          ends[key] = ep;
        } else ends[key] = {x: p.x, y: p.y};
      }
      const ba = S.n('BeginArrow'), ea = S.n('EndArrow'), lp = S.n('LinePattern', 1), rs = S.n('ShapeRouteStyle'), ext = S.n('ConLineRouteExt');
      let route = 'straight';
      if (ext === 2) route = 'curve';
      else if (pts.length > 2 && rs !== 16 && rs !== 2) route = 'elbow';
      const c = {id: ib(), type: 'connector', start: ends.start, end: ends.end, route, text: o.txt || '', lineHex: color(S.raw('LineColor')), dash: lp >= 2 ? (lp === 3 || lp >= 9 ? 'dotted' : 'dashed') : 'solid',
        arrowStart: arrowKind(ba), arrowEnd: arrowKind(ea), lineIn: S.n('LineWeight', .01), startLabel: tagEdits.get(S.vid + ':start') ?? (S.prop('StartPort') || ''), endLabel: tagEdits.get(S.vid + ':end') ?? (S.prop('EndPort') || '')};
      if (d){ Object.assign(c, d, {id: c.id, start: c.start, end: c.end, text: c.text, startLabel: c.startLabel, endLabel: c.endLabel}); c.__exact = true; }
      result_.push(c);
    }
    return {shapes: result_};
  }
}

const api = {build, buildAsync, parse, zip, zipDeflated, unzip, crc32, svgSubpaths, arrowCode, arrowKind};
if (typeof module === 'object' && module.exports) module.exports = api; else root.IdeaVisio = api;
})(typeof window !== 'undefined' ? window : globalThis);

