"""Cisco IOS / IOS-XE / NX-OS syslog line parser.

Handles the formats observed on the central syslog server, e.g.

IOS-XE (Catalyst 9k):
  Oct 19 15:44:47 unyc787as0705.us.net.intra Oct 19 2026 15:44:46.647 EDST: %LINEPROTO-5-UPDOWN: Line protocol ...
NX-OS (Nexus 9k/3k):
  Oct 19 15:50:32 usec755sf0160.us.net.intra 2026 Oct 19 15:50:32.921215 EDST: %L2FM-4-L2FM_MAC_MOVE2: Mac ...
Classic IOS with sequence numbers / unsynchronised clock markers:
  Oct 19 15:44:47 host 123456: *Oct 19 15:44:46.647: %SYS-5-CONFIG_I: ...
ISO-8601 server timestamps (rsyslog RFC5424 template) are also accepted.
"""
from __future__ import annotations

import hashlib
import re
from datetime import datetime

from ..timeutil import MONTHS, to_wall

VENDOR = "cisco"

RX_RE = re.compile(
    r"^(?P<mon>[A-Z][a-z]{2})\s+(?P<day>\d{1,2})\s+(?P<time>\d{2}:\d{2}:\d{2})\s+(?P<host>\S+)\s+(?P<rest>.*)$")
RX_ISO_RE = re.compile(
    r"^(?P<iso>\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}:\d{2})(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?\s+(?P<host>\S+)\s+(?P<rest>.*)$")
CODE_RE = re.compile(
    r"%(?P<fac>[A-Z][A-Z0-9_]*(?:-[A-Z0-9_]+)*?)-(?P<sev>[0-7])-(?P<mnem>[A-Z][A-Z0-9_]*):?\s*")
NX_TS_RE = re.compile(
    r"(?P<y>\d{4})\s+(?P<mon>[A-Z][a-z]{2})\s+(?P<d>\d{1,2})\s+(?P<t>\d{2}:\d{2}:\d{2})(?:\.(?P<f>\d+))?(?:\s+(?P<tz>[A-Za-z]{2,6}))?")
IOS_TS_RE = re.compile(
    r"(?P<flag>[*.])?(?P<mon>[A-Z][a-z]{2})\s+(?P<d>\d{1,2})(?:\s+(?P<y>\d{4}))?\s+(?P<t>\d{2}:\d{2}:\d{2})(?:\.(?P<f>\d+))?(?:\s+(?P<tz>[A-Za-z]{2,6}))?")
REPEAT_RE = re.compile(r"\s*\(message repeated (\d+) times?\)\s*$")
LAST_REPEAT_RE = re.compile(r"last message repeated (\d+) times?", re.I)
SLOT_RE = re.compile(r"-(SLOT\d+|MOD\d+|SUP\d*|LC\d+)$")

NXOS_FACILITIES = {
    "ETHPORT", "L2FM", "TAHUSD", "VSHD", "ETH_PORT_CHANNEL", "VPC", "SYSMGR", "PFMA", "MODULE",
    "HSRP_ENGINE", "ETHPM", "IM", "VDC_MGR", "NVE", "BGP", "OSPF", "STP", "USER", "DAEMON", "KERN",
    "CALLHOME", "SATCTRL", "LLDP", "ACLLOG", "TAHUSD_SLOT1", "PLATFORM", "FEX",
}
_NX_ONLY = {"ETHPORT", "L2FM", "TAHUSD", "VSHD", "ETH_PORT_CHANNEL", "VPC", "SYSMGR", "PFMA",
            "HSRP_ENGINE", "ETHPM", "VDC_MGR", "NVE", "SATCTRL", "FEX"}


def _mk(y: int, mon: str, d: int, t: str, frac: str | None) -> float | None:
    try:
        hh, mm, ss = (int(x) for x in t.split(":"))
        us = int((frac or "0")[:6].ljust(6, "0"))
        return to_wall(datetime(y, MONTHS[mon], d, hh, mm, ss, us))
    except (KeyError, ValueError):
        return None


def uid_for(raw: str) -> str:
    return hashlib.sha1(raw.encode("utf-8", "replace")).hexdigest()[:20]


def parse_line(line: str, ref_dt: datetime) -> dict | None:
    """Parse one raw line. ref_dt = approximate date of the file (year inference)."""
    raw = line.rstrip("\r\n")
    if not raw.strip():
        return None
    ev: dict = {"raw": raw, "uid": uid_for(raw), "vendor": VENDOR, "repeat": 1}

    m = RX_RE.match(raw)
    if m:
        mon = m.group("mon")
        if mon not in MONTHS:
            return _unparsed(ev)
        y = ref_dt.year
        if MONTHS[mon] - ref_dt.month > 6:      # Dec lines read in January
            y -= 1
        elif ref_dt.month - MONTHS[mon] > 6:    # Jan lines with a December reference
            y += 1
        rx = _mk(y, mon, int(m.group("day")), m.group("time"), None)
    else:
        m = RX_ISO_RE.match(raw)
        if not m:
            return _unparsed(ev)
        try:
            rx = to_wall(datetime.fromisoformat(m.group("iso").replace(" ", "T")))
        except ValueError:
            return _unparsed(ev)
    if rx is None:
        return _unparsed(ev)

    fqdn = m.group("host").lower()
    rest = m.group("rest")
    ev.update(rx_ts=rx, ts=rx, fqdn=fqdn, host=fqdn.split(".")[0])

    cm = CODE_RE.search(rest)
    if not cm:
        rm = LAST_REPEAT_RE.search(rest)
        ev.update(message=rest.strip(), facility=None, severity=None, mnemonic=None, code=None,
                  platform=None, dev_ts=None, skew=None, clock_flag=None)
        if rm:
            ev["repeat"] = int(rm.group(1))
            ev["kind_hint"] = "repeat"
        return ev

    prefix = rest[:cm.start()]
    message = rest[cm.end():].strip()
    rp = REPEAT_RE.search(message)
    if rp:
        ev["repeat"] = max(1, int(rp.group(1)))  # as reported by the device
        message = message[:rp.start()].rstrip()

    fac = cm.group("fac")
    slot = None
    sm = SLOT_RE.search(fac)
    if sm:
        slot = sm.group(1)
        fac = fac[:sm.start()]
    sev = int(cm.group("sev"))
    mnem = cm.group("mnem")

    # ---- device timestamp ----
    dev = None
    clock_flag = None
    platform = None
    nm = NX_TS_RE.search(prefix)
    if nm:
        dev = _mk(int(nm.group("y")), nm.group("mon"), int(nm.group("d")), nm.group("t"), nm.group("f"))
        platform = "nx-os"
    else:
        im = IOS_TS_RE.search(prefix)
        if im:
            yy = int(im.group("y")) if im.group("y") else int(_year_of(rx))
            dev = _mk(yy, im.group("mon"), int(im.group("d")), im.group("t"), im.group("f"))
            clock_flag = {"*": "unsynced", ".": "sync-lost"}.get(im.group("flag") or "")
            platform = "ios"
    if fac in _NX_ONLY:
        platform = "nx-os"
    elif platform != "nx-os" and re.search(r"(?:^|\s)(?:Switch \d+ )?R0/0:|^\s*Switch \d+ R0/0", message):
        platform = "ios-xe"
    elif platform == "ios" and re.match(r"^[A-Z][a-z]{2} \d+ \d{4} ", prefix.strip()):
        platform = "ios-xe"

    ev.update(
        facility=fac, severity=sev, mnemonic=mnem, slot=slot,
        code=f"{fac}-{sev}-{mnem}", message=message, platform=platform,
        dev_ts=dev, skew=(round(dev - rx, 3) if dev is not None else None), clock_flag=clock_flag,
    )
    if dev is not None and abs(dev - rx) < 300:
        ev["ts"] = dev        # device time is more precise (ms) when the clock is sane
    return ev


def _year_of(ts: float) -> int:
    from ..timeutil import from_wall
    return from_wall(ts).year


def _unparsed(ev: dict) -> dict:
    ev.update(rx_ts=None, ts=None, host=None, fqdn=None, message=ev["raw"], code=None,
              facility=None, severity=None, mnemonic=None, platform=None, dev_ts=None,
              skew=None, clock_flag=None, unparsed=True)
    return ev
