# NetSignal: design notes

## 1. Research summary

What I looked at, and what it changed in the design:

* **Existing tools.** General-purpose log platforms (ELK/Kibana, Graylog, Splunk, Grafana Loki) are search and dashboard engines. They need you to write the network knowledge yourself: grok patterns, flap rules, correlation searches. Cisco-specific community efforts are narrow. One example is Cisco DevNet's *NX-OS Interface Flap Finder*, which polls switches and counts flaps over a threshold; its author points to a syslog platform for the long term. Splunk's Cisco Networks app ships event types such as MAC flapping keyed on `MACFLAP_NOTIF`/`HOSTFLAPPING`, but users report it struggling with mnemonic parsing.
  **Consequence:** the value isn't another search UI. It is **built-in network semantics** (what a mnemonic means, what is routine, what a flap is) delivered with zero infrastructure.
* **Commercial NetOps dashboards** (Statseeker, NetBrain, DX NetOps): the recurring good ideas are drill-down from summary to detail, device context next to its logs, message-count views to spot spikes, incident summaries with history, and a timeline linking symptom to incident.
  **Consequence:** panels → category → finding → evidence line, plus device and interface views, plus a per-incident evidence timeline.
* **Message formats.** NX-OS logs `OSPF-5-ADJCHANGE … went DOWN`, while IOS logs `OSPF-5-ADJCHG … from FULL to DOWN`. NX-OS puts the year first (`2026 Oct 19`), IOS-XE puts it after the day (`Oct 19 2026`). NX-OS `ETHPORT-5-IF_DOWN_*` carries the down reason in parentheses.
  **Consequence:** per-format extraction regexes and platform inference from the timestamp style.
* **Your screenshots.** These were the most important input. Over 85% of the stream is routine: DOT1X/MAB successes, PoE budget updates, access-port bounces, ISDN call logs. The `DOT1X FAIL (No Response from Client)` → `MAB SUCCESS` pair (about 30 ms apart) is the normal flow, not a failure. Gi4/0/41 on mmex340as0201 shows a PoE boot loop (`DETECT` → `CONTROLLER_PORT_ERR Tstart` → `IEEE_DISCONNECT`). MAC `0050.568d.51fb` (VMware OUI) moves across four Nexus switches within a second. `TAHUSD-SLOT1-…` shows that facility names can carry slot qualifiers, and NX-OS appends `(message repeated N times)`.

## 2. Key decisions

| Decision | Why |
|---|---|
| **Separate "Infrastructure Links" from "Access Port Activity"** (instead of one "Interface flaps" panel) | Access-port bounces are most of the volume and almost always benign. Mixing them with uplinks buries the signal. Edge vs uplink is decided by hostname role plus interface pattern, and is configurable. |
| **Merge OSPF + BGP into "Routing & Redundancy"** (with EIGRP, IS-IS, BFD, HSRP) | Correlated during incidents. Per-protocol filtering is one click (or `bgp down` in search). This frees a panel for Access Ports. |
| **"Port Errors & Protection"** instead of "CRC" | Syslog rarely carries CRC data. Err-disable, BPDU guard, storm control, UDLD, duplex mismatch and stack cables *are* in syslog. The UI says explicitly where counters are needed. |
| **NetSignal rating separate from Cisco severity** | Cisco severity 3 `LINK-3-UPDOWN` fires for every PC that sleeps. The rating takes port class and state into account. Cisco severity is preserved. |
| **Findings, not alerts** | Each finding has an explicit, documented condition (`why`), evidence ids, and timing-only correlation wording. |
| **SQLite + FTS5** | Zero install on a VDI; handles millions of lines/day with WAL. Retention keeps it bounded; older days are reachable by deep archive search. |
| **SFTP-only access** | Works with the most restrictive read-only account; no shell commands on the primary server. |
| **No-build vanilla JS UI** | Corporate VDIs often block CDNs and npm. SVG charts are hand-built and theme-aware. |

## 3. Things engineers need that log dashboards usually miss (all implemented)

1. **Noise accounting.** "91% of messages were routine" makes the filtering transparent and trustworthy.
2. **Expected-behaviour recognition.** 802.1X→MAB fallback, single vMotion moves, access-port bounces.
3. **Probable far end of a link.** Inferred from simultaneous down events on two devices.
4. **"What changed".** The config change preceding an incident, with user and source IP.
5. **Recurring problem detection.** "This interface also flapped on 2 earlier days."
6. **Clock drift detection.** A device 3 minutes behind makes cross-device correlation lie, so NetSignal tells you.
7. **Site-level correlation.** Hostname naming convention → site → "5 switches at bsao190 lost uplinks within 14 s", next to a PSU failure.
8. **Parser lab + unclassified list.** The rule set improves from your own data.
9. **Deep archive search.** Grep old `.gz` files read-only from the UI without importing them.
10. **CSV export of evidence.** Original lines included, for TAC cases and incident tickets.

## 4. Roadmap / next versions

* Juniper, ADVA and Metamako parsers (directories already separated on the server).
* Optional enrichment: CDP/LLDP neighbour table import to confirm far-end inference; device inventory (model/serial) import.
* Notifications (e-mail / Teams / Slack webhook) for new critical findings.
* Authentication for multi-user Option B (reverse-proxy SSO header support).
* Acknowledge/annotate findings and keep incident notes.
* Optional SNMP/gNMI counters to answer what syslog cannot (CRC rates, utilisation).

## Sources consulted

- Cisco DevNet Code Exchange: NX-OS Interface Flap Finder: https://developer.cisco.com/codeexchange/github/repo/ChristopherJHart/nxos_interface_flap_finder
- Splunk Answers: Cisco Networks app mnemonic parsing / MAC-flap event type: https://answers.splunk.com/answers/214580/cisco-networks-app-does-not-interpret-mnemonic-and.html
- Open-source log analysis tools overview: https://aimultiple.com/open-source-log-analysis-tools
- Statseeker dashboards: https://statseeker.com/?p=5177
- NetBrain incident dashboards: https://netbrain.com/product/dashboards-and-reports/
- Broadcom DX NetOps syslog integration: https://academy.broadcom.com/blog/network-operations/network-monitoring/dx-netops-syslog-integration
- Cisco Community NX-OS log examples (ETHPORT / OSPF ADJCHANGE): https://community.cisco.com/t5/switching/cisco-nexus-5548-ethernet-1-5-went-down-suddenly/m-p/4026296 , https://community.cisco.com/t5/other-data-center-subjects/problem-reset-nexus-5596/m-p/2118222
- VMware Smart Assurance OSPF syslog samples: https://docs.vmware.com/en/VMware-Smart-Assurance/10.1.0/npm-config-guide-101/GUID-302012B7-B806-4370-B99E-AF0E11B8A7F6.html
