# Coverage against the supplied specification (3.8.0)

| Area | 3.8.0 behavior / verification |
| --- | --- |
| Text, timestamp names, arbitrary suffixes, prompt and collector sessions | Implemented; parser and file-picker/ZIP browser checks |
| Folders, paste, CSV/jump-box inventory, separate config sections | Retained; folder and paste browser checks, inventory/config parser checks |
| Filename authority, duplicate-file merge, masking | Implemented with regression checks; no raw session persistence |
| IOS-XE and native NX-OS commands | Supported parsers; unfamiliar output is reported; real platform captures still needed |
| Host roles, descriptions, pseudowires and normalized ports | Retained and strengthened with configured-port canonicalization |
| LLDP/CDP/subnet/description priority | Strict source order; conflicting reciprocal weaker endpoints omitted |
| Management physical-link speeds | Observed rates from status/detailed output; uploaded endpoints only; one-ended/unknown/conflict/down states, provenance and individual member cables |
| Cable/member/circuit/pipe views and reports | Retained; individual cables, Po labels, circuit details and state styling |
| Four role rows and site/country/DC placement | Applied to network pages, with remote-peer boxes above per-site OSPF |
| Whole-network L1/L2 and L3, WAN and services | Implemented, including links between loaded remote/DC devices |
| OSPF aggregation, VRF and suffix filters | Implemented; seven eligible adjacencies become one pair line; counts exclude hidden sessions |
| OSPF overview and per-site pages | Implemented; site overview uses TL-row anchors and preserves actual endpoints in evidence |
| Router ID mapping and unresolved peers | Loopback/process, inventory, management, interface matching; manual mappings; one unresolved box per site |
| Cost source, mismatch labels, off switch | Observed cost precedes config; both/single-ended labels; warnings; label toggle |
| Selection evidence, exclusions and device-position preservation | Implemented; OSPF adjacencies can be excluded separately |
| Layered site arrangement | Aligned pairs, centered access stacks, unique anchors and cable lanes; synthetic 19-link example checked for device-body crossings |
| Hand-drawn export fonts | Embedded local font and outlined glyphs; browser pixel comparison and PNG download checked |
| Canvas / Visio graph paper | Selectable canvas grid and native Visio background geometry; export/reimport checks |
| Laser controls | Spot/Trail, 5/7/10 seconds, 7-second default, keep/clear, color/size and saved preferences checked |
| Platform command guide | Copyable ASR/Catalyst/Nexus lists and actionable missing-speed review notes |
| Drawing tools, labels, tubes/lanes/flow and exports | Retained; at least three anchors per side; fullscreen shortcut checked |
| Visio symbols, Shape Data, glued connectors, labels and tubes | Native package/XML and browser round trips checked |
| Visio gradient/black/transparent backgrounds | Implemented as background page when applicable; no page for None |
| Exact recovery of every possible Visio edit | Not claimed. Supported native geometry/text edits are checked; complex external features can be approximated or unsupported |
| Desktop Visio appearance and formula behaviour / stylus hardware / actual Get Out output | Not verified without those applications, hardware, or device captures |
| Visio look and behaviour (3.8.0) | Visio/Canvas looks, font choice, port names and labels bound to links by formulas, containers, layers, see-through frames/labels, no line jumps, Visio Shape Data names, compressed package; node formula/move/structure checks, LibreOffice rendering, browser export/re-import. Native Visio not available here |
| Visio port-name edits on import (3.8.0) | Tag text edited in Visio becomes the link's port label; browser check |
| PNG/SVG options (3.8.0) | Area, background, light colours, 1×–4× PNG with resolution tag, editable or outlined SVG, size limits, font trimming; tests/exports.py |
| Restored 3.6.1 NX-OS/ASR parsing (3.8.0) | tests/nxos.test.cjs (7 checks fail on 3.7.0, pass on 3.8.0) |
| Restored drawing extras (3.8.0) | Lines grid, grid-in-export toggle, laser glow/dot/colours/short trails; presentation checks plus manual screenshot |
| Team server (3.8.0) | Packaged for Docker/systemd; live two-browser edit test and CSP check against the packaged server |
| Private/public folder and single-file builds | Packaged; public has separate storage and no organization defaults or production samples |
| Offline, no installation/admin, local parsing | All four bundles checked with networking disabled and locally fulfilled assets; direct file:// opening blocked by managed Chromium policy |

The source package contains no monitoring, live device collector, or automatic anonymization of imported data. The optional team server stores boards, not device sessions. Grouped counts are a drawing aid, not a health guarantee for hidden VRFs. Keep a saved copy before regenerating diagrams with manual notes.
