# IdeaBoard 3.9.1

Open **index.html** in Chrome or Edge and keep `css/` and `js/` beside it. No installation, admin rights, account, or Internet connection is needed. The release ZIP also contains private and public single-file HTML builds.

See **Upgrade-guide.md** for what changed in 3.8.0 (native-feeling Visio export, PNG/SVG options, restored NX-OS parsing and drawing extras, team server) and **Version-history.md** for how this release compares with earlier builds.

## Import network data

Choose **Menu → Import network**. Choose files, choose a folder, upload a ZIP, or paste one device session. Review devices, descriptions, connections, and notes before generating diagrams. The Connections tab includes individual OSPF adjacency checkboxes.

- One text session per device; several files for the same device merge their configuration and observations.
- Any filename beginning with the standard hostname is accepted, including no extension, timestamps, and arbitrary suffixes. The filename supplies the device identity; prompts, hostname configuration, and collector headers are checks and fallbacks.
- Keep `HOSTNAME#show ...` command prompts or `Running command <command> on the <HOSTNAME>` collector headings. Interface and OSPF configuration sections can be collected separately.
- Direct inputs and ZIP archives have an 8 MB upload limit. Binary data is rejected. Nested ZIPs are not recursively opened.
- Optional inventory accepts CSV columns `Host Name, Device IP, Vendor, Model` and numbered jump-box connection listings. Include data centers and other countries to resolve remote peers.
- Optional site mappings use `DEM001 = Example campus`; a name containing `DC` identifies a data center. Country defaults to the hostname's first letter. Both country and DC overrides are available.

Hostnames follow `X` + three letters + three digits + role + two-digit floor + two-digit unit. Supported roles: TL, CL, DL, AG, ML, AS, SF, MX, ACS, VG. Site codes are the three letters and three digits.

Supported IOS-XE commands: running configuration (or interface / router OSPF sections), interface descriptions/status, IP interface brief, CDP/LLDP neighbors (brief/detail), EtherChannel summary, OSPF process/interface/neighbor outputs, xconnect, MPLS L2transport VC/detail, MPLS LDP neighbors, VLAN brief, and MAC address-table. NX-OS equivalents include port-channel summary and `show ospf ... vrf all`; prefix addresses, `vrf member`, and `ip router ospf` are recognized. Unsupported output is reported rather than treated as validated data.

## Physical link speeds — management page

After importing device files, choose the new **Physical link speeds** page, immediately after L1/L2. It contains physical connections whose two devices both have uploaded files. Port-channel members are individual plain lines; logical pseudowire/OSPF relationships and inventory-only endpoints are excluded. The existing L1/L2 page retains its detailed connection labels.

Rates come from the **Speed** column of IOS-XE/NX-OS `show interfaces status` (including `a-1000`, `100`, `10G`, etc.), or explicit duplex/speed lines in `show interfaces`. Abbreviated `sho interface status` is supported. These are operating port rates at the time the files were collected. Add CDP/LLDP neighbor output or interface descriptions to identify far-end devices and ports; interface status alone cannot identify physical connections.

- **Green, 1 Gb/s:** both ends report the same operating rate.
- **Blue, 1 Gb/s (one end):** only one end has a usable operating-rate observation.
- **Grey, Speed unknown:** no numeric operating rate; `auto`, interface names, media capabilities, configured `speed`, and `BW` are not converted into a measured rate.
- **Orange, Rates differ / Speed conflict / State conflict:** observations disagree; inspect both values and source files. No minimum or aggregate capacity is invented.
- **Grey, Down / Admin down:** the rate is not advertised as active capacity. Administratively shut links follow the existing import toggle.

The management page shows rate labels without port tags to reduce clutter. Selecting a connection shows its ports, commands, raw speed values, source filenames, connection evidence, and port-channel membership. Dashed connections are inferred from configuration/descriptions and need cable verification. Carrier handoff port rates can differ from the committed circuit service bandwidth; actual traffic utilization is a separate metric. Upload fresh command output and regenerate the diagrams to refresh the snapshot.

See Physical-link-speeds-guide.md for a short collection and reading guide.

## Diagram rules

Descriptions beginning with UPLINK, CIRCUIT, PWIRE or PW supply connection meaning; a keyword must end or be followed by a colon/space. Similar words such as `PW-MGMT` do not match. PW and PWIRE are aliases; an empty attachment marks a port without inventing a far end. Circuit labels include carrier, circuit ID, and bandwidth.

Cable evidence is chosen in this order: LLDP, CDP, /31 pairs, then descriptions. Weaker reciprocal observations cannot create an extra cable that conflicts with the selected endpoint. Stale descriptions are reported. CDP-through-pseudowire is kept logical while LLDP identifies the local TL cable. Abbreviated interface names are reconciled against configured ports, including Ten/Twe.

Port-channel members are drawn individually in L1/L2 and labeled with their Po. Speed uses the slower endpoint type. Labels distinguish trunk, access VLAN, and routed ports. Circuits are solid yellow when available; down/shut state uses grey, with shut connections optionally hidden. Pseudowire attachment cables use teal tubes. Non-standard named neighbors appear as other devices; carrier CPE, phones, APs, and MAC-only neighbors are noted without extra device boxes.

## Pages and layout

WAN, whole-network L1/L2, Physical link speeds, whole-network L3, Pseudowires, OSPF overview, OSPF per site, and Problems are separate pages. Empty views explicitly say no matching connections were found.

Sites sit side by side with aligned pairs and centered access stacks. Layer spacing grows with link density. Layers: **TL → CL/DL → AG/ML → AS/SF/VG/ACS/other**. Access/end devices stack vertically, with their cables in separate side lanes. Data centers, foreign countries, and circuit endpoints sit above. Same-country sites without input files sit at the sides. The optional focus-site filter retains that site's direct peers. Reimports can preserve device positions on matching pages; manual annotations are not merged into regenerated pages, so save a board copy first.

L3 retains routed subnets and names SVI/BDI OSPF relationships. A pseudowire uses the selected representative subinterface (default `.5`, configurable to `.100` or another suffix).

## OSPF views

The import window defaults to the **default/global VRF**. Choose another VRF or All VRFs to include it. Only the selected subinterface suffix is eligible; untagged routed interfaces are included and SVI/BDI neighbors are optional. Counts apply to the selected sessions, not hidden VRFs or suffixes.

- **Overview:** one line per site pair, anchored at the TL row; same-site device pairs remain separate. A site summary anchor is used if no TL is known. This is logical aggregation, not a claim that a core adjacency terminates on the TL.
- **Per site:** one line per router pair, with remote peers shown as small boxes above the local role rows.
- Parallel adjacencies show a count and VRF names. Select a line to read every included adjacency, router ID, interface, address, process, area, cost and state.
- Unknown IDs share one Unresolved peers box per origin site and are listed on Problems.
- Router IDs are matched against loopbacks and known OSPF process IDs, inventory IPs, CDP/LLDP management IPs, then neighbor interface addresses. Ambiguous matches are not selected automatically. Manual `192.0.2.32 = EDEM001TL0101` mappings take priority and are remembered in this browser.
- Costs come from OSPF interface output first, then configuration. Labels show `cost 10`, `cost 10 / 20`, or the known cost with its local port. Mismatches are reported. The cost toggle affects OSPF and L3 labels; selection evidence still contains the costs.

## Drawing and files

Rack/icon devices, movable port/link labels with leaders and reset, multi-lane tubes, alternating flow colors and animation, link presets, smart routing, boards/pages, undo, dark mode, library, and PNG/SVG/PDF export remain available. Devices have at least three anchors on each side.

P: pencil; B: highlighter; E: eraser (including Ink only); G: site frame; **Shift+F or F: fullscreen**; Esc: restore; V: selection; Ctrl+S: save board file. Browser storage stays on that computer/browser. Use saved board files to transfer work to another PC.

## Visio

Menu ▸ Export Visio (.vsdx). The file opens in Visio 2016, 2019, 2021 and Microsoft 365.

- **Look:** *Visio* (default) gives a white page, standard Visio line weights, port names as small text, thin site frames and your chosen font (Calibri, Segoe UI or Arial). *Canvas* keeps the board's colours, outlined port tags, dashed frames and optional Light/Black gradient backgrounds.
- **Behaviour in Visio:** links are dynamic connectors glued to the device ports. Port names and link labels ride on their link (ShapeSheet formulas), so they follow when a device moves and Visio reroutes. Site frames are Visio containers: moving a frame moves its devices. Frames, notes, labels, text, pictures and pencil marks are see-through to Visio's connector routing, so links only route around devices, clouds and boxes. No line jumps are added where links cross. Both behaviours can be switched off under *Visio behaviour* in the export window.
- **Layers:** Sites, Annotations, Pictures, Pipes, Links, Devices, Port labels, Notes, Shapes and text. Use View ▸ Layer Properties to hide or lock, for example, all port labels.
- **Shape Data:** devices carry Network Name (hostname), IP Address and Subnet Mask in Visio's own field names, plus Device type, Role, VLAN, Info and Notes; links carry A-end port, B-end port and Link type.
- **Grid:** *Visio grid* switches on Visio's own grid (on screen, not printed); *Graph paper* draws printed grid lines on the background page.
- Rack units are grouped (chassis, icon, hostname, role badge) and their info lines are the group's own text, so everything moves and resizes together. Files are compressed like Visio's own (about 90 KB for the 10-page example).

**Import Visio** restores IdeaBoard drawings from the hidden data and reads supported edits made in Visio: moved and resized shapes, edited text, re-glued links, and port names typed into the port tags. Shapes from Visio's network stencils (router, switch, firewall, server…) are imported as devices, taking the hostname from Network Name when present.

Checked here: package/XML structure, element order, formula values against stored values and simulated device moves (node tests), LibreOffice rendering, and browser export/re-import. Microsoft Visio itself was not available, so the formula-driven following, containers and layer behaviour still need a look in your installation; the two switches give the plain behaviour if anything misbehaves.

## PNG and SVG

Menu ▸ Export PNG / Export SVG use your last choices; Menu ▸ Image export options… changes them:

- Area: selection (when something is selected) or the whole page.
- Background: as on the canvas, white with light colours, or transparent. Colours: current theme or always light (for documents and slides from dark mode).
- PNG resolution 1×–4×. The PNG records its resolution, so Visio, Word and PowerPoint insert it at drawing size instead of twice as large. Very large pages are reduced automatically to stay within browser limits.
- SVG text: *Outlined* (identical everywhere; the embedded font is dropped when every word is outlined) or *Editable text* for Visio, PowerPoint and Inkscape (real text, no filters, line positions that do not depend on browser-only attributes).
- Include the canvas grid (also Menu ▸ Include grid in PNG / SVG / PDF).

## Editions and privacy

Private builds retain the supplied default site mappings. Public builds ship with no organization site mappings or production examples and use a separate browser-storage namespace. All included demonstration sessions use documentation IP ranges and an example carrier. The public edition does **not** automatically anonymize data you import or existing board files you share.

Device sessions are parsed inside the browser, with supported passwords, keys and communities masked before parsing. Source session files are not persisted in board saves or browser storage. Generated boards contain device names, addresses, labels and connection evidence. Site and peer mappings are remembered locally. Static/file mode sends no device logs to a server. The release also contains a team-server folder (Docker or systemd) for shared boards on a trusted LAN; see its README.

## Development validation

Node 18+ can run `node --test tests/*.test.cjs`; regenerate synthetic examples with `node tools/make-demo.cjs`. For browser development, serve this directory with `python -m http.server 8000 --bind 127.0.0.1`.

The browser suite requires Python Playwright and Chromium for testing only. Run `python tests/browser.py`; set `IDEABOARD_URL` for a different port or a file URL, `CHROMIUM_PATH` for a specific Chrome/Chromium binary, and `IDEABOARD_TEST_OUTPUT` for test artifacts. The regular application requires none of these test dependencies.

Regenerate the Visio examples (Example-Visio-look, Example-canvas-light-gradient, Example-canvas-black-gradient) with `python tools/export-examples.py` while the development server is running. `node --test tests/*.test.cjs` includes the Visio writer checks (tests/visio.test.cjs); `python tests/exports.py` checks PNG/SVG options. Package both editions and the team server with `python tools/package.py /path/to/output`; validate the outputs with `python tests/offline.py /path/to/output/IdeaBoard-v3.9.1`.

Packaged offline execution was checked with networking disabled and local assets fulfilled by the browser test runner. Direct `file://` opening is blocked by the managed Chromium policy on this cloud machine, so that exact launch path remains unverified here.

Run `python tests/presentation.py` against the development server to check graph paper, anchors, font fidelity, laser controls and platform guides. See Changes.md, Upgrade-guide.md and Feature-coverage.md. Embedded Shantell Sans uses the SIL Open Font License in FONT-LICENSE.txt.

Public edition: organization defaults are empty, browser storage is isolated, and legacy team-server detection is disabled. Imported data is not anonymized automatically.
