// Synthetic device sessions use only documentation addresses; no production input.
const fs=require('node:fs'),path=require('node:path');
const root=path.resolve(__dirname,'..'),I=require('../js/importer-engine.js'),V=require('../js/visio-export.js');
const sessions=new Map(),commands=new Map();
const add=(h,command,body)=>{const list=commands.get(h)||[];list.push([command,body]);commands.set(h,list);};
const h=(site,role,unit='01')=>'EDEM'+site+role+'01'+unit;
const core=[h('001','CL'),h('002','CL')],tls=[h('001','TL'),h('002','TL')];
for(let side=0;side<2;side++){
  const c=core[side],t=tls[side],far=core[1-side],ft=tls[1-side];
  let cfg=`hostname ${c}\ninterface Gi1/0/1\n description UPLINK: ${t} Gi0/0/1\n!\n`;
  for(let i=0;i<2;i++){
    cfg+=`interface Gi1/0/${i+1}.5\n${i?' vrf forwarding BLUE\n':''} ip address 192.0.2.${i*2+side} 255.255.255.254\n ip ospf ${i+1} area 0\n ip ospf cost 10\n!\nrouter ospf ${i+1}${i?' vrf BLUE':''}\n router-id 198.51.100.${side+1}\n!\n`;
    add(c,`show ip ospf ${i+1} neighbor${i?' vrf BLUE':''}`,`Neighbor ID Pri State Dead Time Address Interface\n198.51.100.${2-side} 1 FULL/DR 00:00:30 192.0.2.${i*2+1-side} Gi1/0/${i+1}.5`);
  }
  add(c,'show running-config',cfg);
  add(c,'show cdp neighbors detail',`Device ID: ${far}\nInterface: GigabitEthernet1/0/1, Port ID (outgoing port): GigabitEthernet1/0/1\nPlatform: cisco C9500`);
  add(c,'show lldp neighbors detail',`Local Intf: Gi1/0/1\nPort id: Gi0/0/1\nSystem Name: ${t}\nManagement Address: 198.51.100.${side+11}`);
  add(t,'show running-config',`hostname ${t}\ninterface Loopback0\n ip address 198.51.100.${side+11} 255.255.255.255\n!\ninterface Gi0/0/1\n description PW: ${c} Gi1/0/1 via ${ft} Gi0/0/1 to ${far} Gi1/0/1\n xconnect 198.51.100.${12-side} 100 encapsulation mpls\n!\ninterface Te0/0/2\n description CIRCUIT: Example carrier Cir ID DEMO-100 10G to ${ft} Te0/0/2\n ip address 203.0.113.${side} 255.255.255.254\n!`);
  add(t,'show cdp neighbors detail',`Device ID: ${ft}\nInterface: TenGigabitEthernet0/0/2, Port ID (outgoing port): TenGigabitEthernet0/0/2\nPlatform: cisco ASR920`);
  add(t,'show xconnect all',`UP pri ac Gi0/0/1(Eth VLAN) UP mpls 198.51.100.${12-side}:100 UP`);
  add(t,'show mpls ldp neighbor',`Peer LDP Ident: 198.51.100.${12-side}:0`);
}
for(const [i,role]of ['CL','DL','AG','ML','AS','SF','VG','ACS'].entries()){
  const name=h('001',role,role==='CL'?'02':'01'),port='Gi1/0/'+(i+10);
  add(name,'show running-config',`hostname ${name}\ninterface Gi1/0/1\n description UPLINK: ${core[0]} ${port}\n switchport mode trunk\n!`);
  add(name,'show cdp neighbors detail',`Device ID: ${core[0]}\nInterface: GigabitEthernet1/0/1, Port ID (outgoing port): ${port}\nPlatform: cisco C9500`);
}
add('UDEM900DL0101','show running-config','hostname UDEM900DL0101\ninterface Loopback0\n ip address 198.51.100.90 255.255.255.255\n!');
// Explicit synthetic observations: these rates are test inputs, not runtime inference.
for(const [host,blocks] of commands){
  if(host.includes('SF'))continue; // Demonstrate a missing operating rate.
  const cfg=I.parseRun(blocks.filter(([cmd])=>cmd==='show running-config').map(([,body])=>body).join('\n'));
  const ports=[...cfg.ifs.values()].filter(i=>/^(Gi|Te|Twe|Hu|Fo|Fa|Eth)\d/i.test(i.name)&&!i.name.includes('.'));
  if(ports.length)add(host,'show interfaces status','Port Name Status Vlan Duplex Speed Type\n'+ports.map(i=>`${i.name} example uplink connected trunk a-full ${host.includes('AS0101')?'a-100':/^Te/.test(i.name)?'10000':'a-1000'} copper`).join('\n'));
}
for(const[host,blocks]of commands)sessions.set(host+'.20261015.120000',blocks.map(([cmd,body])=>'-'.repeat(70)+'\nRunning command '+cmd+' on the '+host+'\n'+body+'\n').join('\n'));
const samples=path.join(root,'samples');fs.mkdirSync(samples,{recursive:true});
const zip=V.zip([...sessions].map(([name,text])=>['device-outputs/'+name,text]));fs.writeFileSync(path.join(samples,'Synthetic-device-outputs.zip'),zip);
const parsed=[...sessions].map(([name,text])=>I.parseDevice(name,text));
const sites=I.parseSites('DEM001 = Example campus\nDEM002 = Example branch\nDEM900 = Example DC');
const R=I.analyze(parsed,{sites});
const board=I.buildBoard(R,{title:'Synthetic network',sites,vrf:'',dataCenterSites:['DEM900']});
fs.writeFileSync(path.join(root,'Whole-network-demo.ideaboard.json'),JSON.stringify(board,null,2));
console.log(`Synthetic demo: ${parsed.length} devices, ${board.pages.length} pages, ${R.phys.length} cables.`);
