# Lantern — a local-first learning library

Lantern replaces the NoteForge Learning Hub page. It is one self-contained HTML file: no build step, no server, no account, no API key. Everything you save stays in your browser (IndexedDB) until you export it.

## Files

| File | What it is |
|---|---|
| `lantern.html` | **The app.** Includes the 1,362 links from the original NoteForge page as an opt-in seed. Open it in a browser. |
| `lantern-empty.html` | Same app without the embedded NoteForge dataset, for a fresh library. |
| `src/` | Readable source: `style.css`, `core.js` (storage, model, import/export), `ui.js` (screens), `index.html` (shell), `noteforge-seed.json` (the extracted dataset). |
| `build.py` | Assembles `src/` into the two HTML files (`python3 build.py`). |
| `tests/e2e.test.js` | Playwright end-to-end checks (`node tests/e2e.test.js`). `tests/original-noteforge.html` is the original app, kept for import tests. |

## Launch

1. Save `lantern.html` somewhere permanent (for example `Documents/Lantern/lantern.html`). The browser ties your data to the file's location, so do not keep moving it.
2. Double-click it, or drag it into Chrome, Edge, Firefox or Safari. Bookmark the tab.
3. Optional: serve it over HTTP for a stable origin (`python3 -m http.server 8000` in that folder, then open `http://localhost:8000/lantern.html`). This is recommended if you use several browsers' private modes, which may restrict IndexedDB on `file://` pages.

Lantern makes **no network requests** unless you turn on YouTube thumbnails or the optional title fetcher in *Settings & data → Previews & privacy*. Playing a video inside the app loads that platform's embedded player on demand.

## Migrate your NoteForge data

NoteForge kept data in two places, and both must be brought across:

* **The 1,362 links were hard-coded inside the NoteForge HTML file**, not in browser storage. Lantern already contains them. On first launch choose *Load the 1,362 links embedded from NoteForge*. You can also import the original `.html` file itself from *Settings & data*; the dataset is extracted from it.
* **Your tracker entries, extra imported links, hidden links and preferences lived in `localStorage`** of whichever browser and location you used NoteForge from. A new HTML file, another browser, another computer or a different folder **cannot read that storage**. You must export it from the old app:
  1. Open your original NoteForge page in the same browser you used before.
  2. Sidebar → *Backup & data settings* → **Back Up Everything**. This downloads `noteforge-backup-YYYY-MM-DD.json` containing `entries`, `extraVideos`, `hiddenVideos` and `preferences`.
  3. In Lantern go to *Settings & data* → **Restore / import a file** and choose that JSON (or drop it anywhere on the page).
  4. Read the preview. It shows how many items are new, how many already exist, how many are malformed and skipped. Tracker entries that point at a link already in the library are **merged into that link** (status, title, notes, picture), not duplicated. Links you had hidden are archived, not deleted.
  5. Click Import. A safety snapshot is taken first and an Undo button appears afterwards.

If the old browser profile is gone, the tracker entries are gone with it; only the embedded 1,362 links can be recovered. Lantern tells you this instead of guessing.

### What is preserved from each NoteForge record

| NoteForge field | Lantern field |
|---|---|
| video `u` (URL) | `url`, plus a canonical `key` for duplicate detection |
| video `n` (WhatsApp caption) | `title` |
| video `g` (auto-detected topics) | `tags` (also kept in `legacy.autoTopics`) |
| video `d`, `t` (date, time) | `savedAt`, `legacy.time` |
| video `p`, `c` (platform, times shared) | `legacy.platform`, `legacy.timesShared` |
| entry `task`, `notes`, `link`, `date` | `title`, `notes`, `url`, `savedAt` |
| entry `status` Not started / In progress / Completed / Blocked | `status` To learn / Learning / Done / Blocked |
| entry `picture` (base64) | `image` |
| hidden video | `archived: true` |

## Everyday use

* **Save** (button or `n`): paste a link, title, tags, status. Duplicates are flagged while you type, including the same YouTube/TikTok/X post with different tracking parameters.
* **Library**: card or list view, filters by status, tag, collection, platform, year, "has notes", sort options, bulk selection (checkbox, `x`, or Shift/Ctrl-click) with status, tag, collection, favorite, archive and delete actions, all undoable.
* **Resource panel**: edit title, link, description, Markdown notes with preview, tags, collection, priority, status, saved and review dates. *Copy as text* gives a plain-text version for pasting anywhere.
* **Search** understands words plus `tag:ai`, `status:learning`, `in:collection-name`, `is:fav`, `is:untagged`, `has:notes`, `site:youtube`, `year:2024`, and `-word` to exclude.
* **Review queue**: items whose review date has arrived, learning items untouched for two weeks, and a random sample of old never-opened saves.
* **Backups**: *Settings & data → Download backup* (JSON). Snapshots are taken automatically before imports, restores and permanent deletes. Exports: CSV, Markdown, Netscape bookmarks HTML.
* Press `?` for all keyboard shortcuts.

## Tests

```
node tests/e2e.test.js
```

Needs Node 18+ with `playwright` and a Chromium build (`npx playwright install chromium`). The suite serves the built file on `localhost:8731`, blocks every external request, and checks import/preservation, persistence across reloads, NoteForge backup merging, duplicate and malformed-file handling, backup→wipe→restore round trip, search operators, bulk undo, trash, keyboard navigation and focus trapping, phone layout, and offline rendering.
