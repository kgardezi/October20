"""Read-only file access backends.

Both backends expose the same tiny interface, and only ever OPEN FILES FOR READING:

    connect() / close()
    listdir(directory) -> [(name, size, mtime)]
    stat(path)         -> (size, mtime)
    read_range(path, offset, length) -> bytes
    open_read(path)    -> binary file-like object (for streaming .gz archives)

SFTPAccess never executes remote commands - it uses the SFTP subsystem only, so
the account on the syslog server can be restricted to read-only SFTP
(e.g. `ForceCommand internal-sftp -R` in sshd_config, chrooted to /log).
"""
from __future__ import annotations

import os
import posixpath
import stat as statmod
from pathlib import Path


class LocalAccess:
    kind = "local"

    def __init__(self, directory: str):
        self.directory = directory

    def connect(self):
        if not os.path.isdir(self.directory):
            raise FileNotFoundError(f"directory not found: {self.directory}")

    def close(self):
        pass

    def join(self, name: str) -> str:
        return str(Path(self.directory) / name)

    def listdir(self, directory: str | None = None):
        d = directory or self.directory
        out = []
        for e in os.scandir(d):
            if e.is_file():
                st = e.stat()
                out.append((e.name, st.st_size, st.st_mtime))
        return out

    def stat(self, path: str):
        st = os.stat(path)
        return st.st_size, st.st_mtime

    def read_range(self, path: str, offset: int, length: int) -> bytes:
        with open(path, "rb") as f:
            f.seek(offset)
            return f.read(length)

    def open_read(self, path: str):
        return open(path, "rb")

    def describe(self) -> str:
        return f"local:{self.directory}"


class SFTPAccess:
    kind = "ssh"

    def __init__(self, cfg: dict):
        self.cfg = cfg
        self.directory = cfg["directory"]
        self.client = None
        self.sftp = None

    def connect(self):
        import paramiko  # imported lazily so demo/local modes work without it

        c = self.cfg
        client = paramiko.SSHClient()
        kh = os.path.expanduser(c.get("known_hosts") or "~/.ssh/known_hosts")
        if os.path.exists(kh):
            client.load_host_keys(kh)
        client.load_system_host_keys() if os.name != "nt" else None
        # Never trust unknown host keys silently.
        client.set_missing_host_key_policy(paramiko.RejectPolicy())
        password = os.environ.get(c.get("password_env") or "", None)
        passphrase = os.environ.get(c.get("key_passphrase_env") or "", None)
        key_file = os.path.expanduser(c["key_file"]) if c.get("key_file") else None
        if key_file and not os.path.exists(key_file):
            key_file = None
        client.connect(
            hostname=c["host"], port=int(c.get("port", 22)), username=c["username"],
            key_filename=key_file, password=password, passphrase=passphrase,
            timeout=float(c.get("connect_timeout", 15)), banner_timeout=30, auth_timeout=30,
            allow_agent=True, look_for_keys=key_file is None and password is None,
        )
        tr = client.get_transport()
        tr.set_keepalive(int(c.get("keepalive", 30)))
        self.client = client
        self.sftp = client.open_sftp()
        self.sftp.get_channel().settimeout(60)

    def close(self):
        for o in (self.sftp, self.client):
            try:
                o and o.close()
            except Exception:
                pass
        self.sftp = self.client = None

    def join(self, name: str) -> str:
        return posixpath.join(self.directory, name)

    def listdir(self, directory: str | None = None):
        out = []
        for a in self.sftp.listdir_attr(directory or self.directory):
            if a.st_mode is not None and statmod.S_ISREG(a.st_mode):
                out.append((a.filename, a.st_size, a.st_mtime))
        return out

    def stat(self, path: str):
        a = self.sftp.stat(path)
        return a.st_size, a.st_mtime

    def read_range(self, path: str, offset: int, length: int) -> bytes:
        with self.sftp.open(path, "rb") as f:
            f.seek(offset)
            if length > 32768:
                f.prefetch(min(length, max(0, self.stat(path)[0] - offset)))
            return f.read(length)

    def open_read(self, path: str):
        f = self.sftp.open(path, "rb")
        f.prefetch()
        return f

    def describe(self) -> str:
        c = self.cfg
        return f"sftp://{c['username']}@{c['host']}:{c.get('port', 22)}{self.directory}"


def make_access(cfg: dict):
    src = cfg["source"]
    mode = src.get("mode", "demo")
    if mode == "ssh":
        return SFTPAccess(src["ssh"])
    if mode == "local":
        return LocalAccess(src["local"]["directory"])
    return LocalAccess(src["demo"]["directory"])
