"""HTTP API + static web UI."""
from __future__ import annotations

import asyncio
import csv
import io
import json
import os
import threading
import time
from collections import defaultdict
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles

from . import __version__
from .classifier import Classifier, SEV_NAMES
from .config import ROOT
from .ingest.manager import IngestManager, Pipeline
from .intel.findings import Intel, health, SEV_RANK, dur
from .intel.search import interpret, suggestions
from .netmodel import mac_vendor, short_interface
from .store import Store, build_where
from .timeutil import window, fmt, now_wall

WEB = ROOT / "web"
SIG = ["routine", "info", "warning", "major", "critical"]
SIGNIFICANT = ("warning", "major", "critical")


class App:
    def __init__(self, cfg: dict, store: Store, classifier: Classifier, pipeline: Pipeline,
                 ingest: IngestManager, simulated: bool):
        self.cfg, self.store, self.cls, self.pipe, self.ingest = cfg, store, classifier, pipeline, ingest
        self.simulated = simulated
        self.intel = Intel(store, classifier, cfg)
        self._cache: dict = {}
        self._cache_lock = threading.Lock()

    def cached(self, key, ttl, fn):
        now = time.time()
        with self._cache_lock:
            hit = self._cache.get(key)
            if hit and now - hit[0] < ttl:
                return hit[1]
        val = fn()
        with self._cache_lock:
            self._cache[key] = (now, val)
            if len(self._cache) > 200:
                self._cache.clear()
        return val

    def hosts(self) -> set[str]:
        return self.cached("hosts", 30, lambda: {r["host"] for r in self.store.q(
            "SELECT DISTINCT host FROM events WHERE host IS NOT NULL")})

    def sites(self) -> set[str]:
        return self.cached("sites", 30, lambda: {r["site"] for r in self.store.q(
            "SELECT DISTINCT site FROM events WHERE site IS NOT NULL")})


def ev_out(r: dict) -> dict:
    d = dict(r)
    if isinstance(d.get("attrs"), str):
        try:
            d["attrs"] = json.loads(d["attrs"])
        except ValueError:
            d["attrs"] = {}
    d["attrs"] = d.get("attrs") or {}
    return d


def filters_from(req: Request) -> dict:
    qp = dict(req.query_params)
    t0, t1 = window(qp.get("range"), float(qp["t0"]) if qp.get("t0") else None,
                    float(qp["t1"]) if qp.get("t1") else None)
    f = {k: v for k, v in qp.items() if k not in ("range", "limit", "offset", "facets", "hist", "order", "t0", "t1")}
    f["t0"], f["t1"] = t0, t1
    return f


def histogram(store: Store, where: str, params: list, t0: float, t1: float, buckets: int = 60) -> dict:
    step = max(60.0, (t1 - t0) / buckets)
    rows = store.q(f"SELECT CAST((e.ts - ?) / ? AS INT) b, e.signal s, COUNT(*) n FROM events e WHERE {where} "
                   f"GROUP BY b, s", [t0, step] + params)
    nb = int((t1 - t0) // step) + 1
    series = {s: [0] * nb for s in SIG}
    for r in rows:
        if 0 <= r["b"] < nb and r["s"] in series:
            series[r["s"]][r["b"]] += r["n"]
    return {"t0": t0, "step": step, "n": nb, "series": series}


def build(app_state: App) -> FastAPI:
    S = app_state
    api = FastAPI(title="NetSignal", version=__version__)

    # ------------------------------------------------------------------ meta
    @api.get("/api/meta")
    def meta():
        return {"version": __version__, "simulated": S.simulated, "mode": S.cfg["source"]["mode"],
                "categories": S.cls.category_list(), "now": now_wall(), "config": S.cfg.get("_config_file"),
                "target": S.ingest.status.get("target")}

    @api.get("/api/status")
    def status():
        st = dict(S.ingest.status)
        db = S.store.one("SELECT COUNT(*) n, MIN(ts) a, MAX(ts) b FROM events")
        st.update(db_events=db["n"], db_first=db["a"], db_last=db["b"], inserted=S.store.inserted_total,
                  duplicates=S.store.duplicates_total, parsed=S.pipe.parsed, unparsed=S.pipe.unparsed,
                  jobs=S.ingest.job_status, now=now_wall(), simulated=S.simulated,
                  db_size=os.path.getsize(S.store.path) if os.path.exists(S.store.path) else 0)
        # message rate from the index (receive time) - unaffected by catch-up reads
        recent = S.store.one("SELECT COUNT(*) n FROM events WHERE rx_ts > ?", (now_wall() - 60,))["n"]
        st["live"] = dict(st["live"], rate=round(recent / 60.0, 2))
        return st

    # ------------------------------------------------------------------ overview
    @api.get("/api/overview")
    def overview(range: str = "24h"):
        maxid = S.store.one("SELECT MAX(id) m FROM events")["m"] or 0
        return S.cached(("ov", range, maxid // 50), 6, lambda: _overview(range))

    def _overview(range_):
        t0, t1 = window(range_)
        span = t1 - t0
        st = S.store
        cats = S.cls.category_list()
        agg = st.q("SELECT category, signal, COUNT(*) n, COUNT(DISTINCT host) d FROM events "
                   "WHERE ts BETWEEN ? AND ? GROUP BY category, signal", (t0, t1))
        prev = {r["category"]: r["n"] for r in st.q(
            "SELECT category, COUNT(*) n FROM events WHERE ts BETWEEN ? AND ? AND signal IN ('warning','major','critical') "
            "GROUP BY category", (t0 - span, t0))}
        devs = {r["category"]: r["d"] for r in st.q(
            "SELECT category, COUNT(DISTINCT host) d FROM events WHERE ts BETWEEN ? AND ? "
            "AND signal IN ('warning','major','critical') GROUP BY category", (t0, t1))}
        nb = 24
        step = span / nb
        spark = defaultdict(lambda: [0] * nb)
        for r in st.q("SELECT category, CAST((ts-?)/? AS INT) b, COUNT(*) n FROM events WHERE ts BETWEEN ? AND ? "
                      "AND signal IN ('warning','major','critical') GROUP BY 1,2", (t0, step, t0, t1)):
            if 0 <= r["b"] < nb:
                spark[r["category"]][r["b"]] += r["n"]
        topdev = defaultdict(list)
        for r in st.q("SELECT category, host, COUNT(*) n FROM events WHERE ts BETWEEN ? AND ? "
                      "AND signal IN ('warning','major','critical') GROUP BY 1,2 ORDER BY n DESC", (t0, t1)):
            if len(topdev[r["category"]]) < 3:
                topdev[r["category"]].append({"host": r["host"], "n": r["n"]})
        latest = {r["category"]: r for r in st.q(
            "SELECT * FROM (SELECT id, ts, host, code, message, category, signal, ROW_NUMBER() OVER "
            "(PARTITION BY category ORDER BY ts DESC) rn FROM events WHERE ts BETWEEN ? AND ? "
            "AND signal IN ('warning','major','critical')) WHERE rn = 1", (t0, t1))}

        findings = S.intel.findings(t0, t1)
        fcount = defaultdict(lambda: defaultdict(int))
        for f in findings:
            fcount[f["category"]][f["severity"]] += 1

        by = defaultdict(lambda: defaultdict(int))
        for r in agg:
            by[r["category"]][r["signal"]] += r["n"]
        cards = []
        for c in cats:
            cid = c["id"]
            sigs = by.get(cid, {})
            total = sum(sigs.values())
            significant = sum(sigs.get(s, 0) for s in SIGNIFICANT)
            cf = fcount.get(cid, {})
            worst = max(cf, key=lambda s: SEV_RANK[s]) if cf else None
            cards.append({
                "id": cid, "name": c["name"], "icon": c.get("icon"), "description": c.get("description"),
                "total": total, "significant": significant, "routine": sigs.get("routine", 0),
                "by_signal": {s: sigs.get(s, 0) for s in SIG}, "devices": devs.get(cid, 0),
                "prev_significant": prev.get(cid, 0), "spark": spark.get(cid, [0] * nb),
                "top_devices": topdev.get(cid, []), "latest": latest.get(cid),
                "findings": dict(cf), "findings_total": sum(cf.values()), "worst": worst,
            })
        total = sum(sum(v.values()) for v in by.values())
        routine = sum(v.get("routine", 0) for v in by.values())
        sig_total = sum(sum(v.get(s, 0) for s in SIGNIFICANT) for v in by.values())
        active = [f for f in findings if f["status"] == "active" and SEV_RANK[f["severity"]] >= SEV_RANK["warning"]]
        sevc = defaultdict(int)
        for f in findings:
            sevc[f["severity"]] += 1
        hl = health(findings)
        ndev = st.one("SELECT COUNT(DISTINCT host) n FROM events WHERE ts BETWEEN ? AND ?", (t0, t1))["n"]
        timeline = histogram(st, "e.ts BETWEEN ? AND ?", [t0, t1], t0, t1, 72)
        # heatmap: top devices by significant events
        hm_hosts = [r["host"] for r in st.q(
            "SELECT host, COUNT(*) n FROM events WHERE ts BETWEEN ? AND ? AND signal IN ('warning','major','critical') "
            "GROUP BY host ORDER BY n DESC LIMIT 18", (t0, t1))]
        hm_n = 36
        hm_step = span / hm_n
        matrix = {h: [0] * hm_n for h in hm_hosts}
        if hm_hosts:
            for r in st.q(f"SELECT host, CAST((ts-?)/? AS INT) b, COUNT(*) n FROM events WHERE ts BETWEEN ? AND ? "
                          f"AND signal IN ('warning','major','critical') AND host IN ({','.join('?' * len(hm_hosts))}) "
                          f"GROUP BY 1,2", [t0, hm_step, t0, t1] + hm_hosts):
                if 0 <= r["b"] < hm_n:
                    matrix[r["host"]][r["b"]] += r["n"]
        changes = st.q("SELECT id, ts, host, user, ip, message, code FROM events WHERE ts BETWEEN ? AND ? "
                       "AND kind='config_change' ORDER BY ts DESC LIMIT 8", (t0, t1))
        auth = getattr(S.intel, "auth_stats", {})
        return {
            "window": {"t0": t0, "t1": t1, "range": range_},
            "kpis": {"messages": total, "routine": routine, "significant": sig_total, "devices": ndev,
                     "findings": len(findings), "active_findings": len(active), "by_severity": dict(sevc),
                     "noise_pct": round(100 * routine / total, 1) if total else 0,
                     "devices_with_findings": len(hl)},
            "summary": _summary(findings, total, routine, auth),
            "cards": cards,
            "findings": [_fslim(f) for f in findings[:12]],
            "timeline": timeline,
            "heatmap": {"hosts": hm_hosts, "t0": t0, "step": hm_step, "matrix": [matrix[h] for h in hm_hosts],
                        "health": {h: hl.get(h, {}).get("score", 100) for h in hm_hosts}},
            "changes": changes, "auth": auth,
            "health": sorted(({"host": h, **v} for h, v in hl.items()), key=lambda x: x["score"])[:10],
        }

    def _summary(findings, total, routine, auth):
        crit = [f for f in findings if f["severity"] == "critical" and f["status"] == "active"]
        maj = [f for f in findings if f["severity"] == "major" and f["status"] == "active"]
        lines = []
        if crit or maj:
            lines.append(f"{len(crit)} critical and {len(maj)} major issue(s) need attention.")
        else:
            lines.append("No critical or major issues detected in this window.")
        for f in (crit + maj)[:4]:
            lines.append(f"• {f['title']}.")
        if total:
            lines.append(f"{routine:,} of {total:,} messages ({100 * routine / total:.0f}%) were routine "
                         f"(successful authentications, access-port bounces, PoE budget updates, call logs) and are "
                         f"hidden from alert counts.")
        if auth.get("fail_events"):
            lines.append(f"{auth['resolved_by_fallback']:,} of {auth['fail_events']:,} authentication failures were "
                         f"followed by a successful authentication of the same endpoint (expected 802.1X -> MAB fallback).")
        return lines

    def _fslim(f):
        d = {k: v for k, v in f.items() if k != "evidence"}
        d["evidence_count"] = len(f["evidence"])
        return d

    # ------------------------------------------------------------------ findings
    @api.get("/api/findings")
    def findings(range: str = "24h", type: str = "", severity: str = "", host: str = "", category: str = "",
                 min_cycles: int = 0, protocol: str = "", status: str = ""):
        t0, t1 = window(range)
        fs = S.intel.findings(t0, t1)
        types = set(filter(None, type.split(",")))
        out = []
        for f in fs:
            if types and f["type"] not in types:
                continue
            if severity and SEV_RANK[f["severity"]] < SEV_RANK.get(severity, 0):
                continue
            if host and f["host"] != host and host not in (f["metrics"].get("devices") or []) \
                    and host not in (f["metrics"].get("switches") or []):
                continue
            if category and f["category"] != category:
                continue
            if status and f["status"] != status:
                continue
            if protocol and f["metrics"].get("protocol") != protocol:
                continue
            if min_cycles:
                c = f["metrics"].get("down_up_cycles")
                if c is None and f["type"] == "edge_flap":
                    ports = [p for p in f["metrics"].get("ports", []) if p["cycles"] >= min_cycles]
                    if not ports:
                        continue
                elif c is not None and c < min_cycles:
                    continue
            out.append(_fslim(f))
        return {"window": {"t0": t0, "t1": t1}, "findings": out, "health": health(fs)}

    @api.get("/api/finding/{fid}")
    def finding(fid: str, range: str = "24h"):
        t0, t1 = window(range)
        for f in S.intel.findings(t0, t1):
            if f["id"] == fid:
                ids = f["evidence"]
                evs = [ev_out(r) for r in S.store.q(
                    f"SELECT * FROM events WHERE id IN ({','.join('?' * len(ids)) or 'NULL'}) ORDER BY ts", ids)]
                ctx_ids = [c["event_id"] for c in f["context"] if c.get("event_id")]
                return {"finding": f, "events": evs, "category": S.cls.cat_by_id.get(f["category"]),
                        "context_events": [ev_out(r) for r in S.store.q(
                            f"SELECT * FROM events WHERE id IN ({','.join('?' * len(ctx_ids)) or 'NULL'})", ctx_ids)]}
        raise HTTPException(404, "finding not found in this time range")

    # ------------------------------------------------------------------ events
    @api.get("/api/events")
    def events(request: Request, limit: int = 200, offset: int = 0, facets: int = 0, hist: int = 0,
               order: str = "desc"):
        f = filters_from(request)
        where, params = build_where(f)
        st = S.store
        limit = max(1, min(limit, 2000))
        rows = st.q(f"SELECT * FROM events e WHERE {where} ORDER BY e.ts {'ASC' if order == 'asc' else 'DESC'}, e.id "
                    f"LIMIT ? OFFSET ?", params + [limit, offset])
        total = st.one(f"SELECT COUNT(*) n FROM events e WHERE {where}", params)["n"]
        out = {"total": total, "events": [ev_out(r) for r in rows], "window": {"t0": f["t0"], "t1": f["t1"]}}
        if facets:
            fc = {}
            for col in ("host", "code", "interface", "category", "signal", "site", "kind"):
                fc[col] = st.q(f"SELECT e.{col} v, COUNT(*) n FROM events e WHERE {where} AND e.{col} IS NOT NULL "
                               f"GROUP BY e.{col} ORDER BY n DESC LIMIT 12", params)
            out["facets"] = fc
        if hist:
            out["histogram"] = histogram(st, where, params, f["t0"], f["t1"], 72)
        return out

    @api.get("/api/export")
    def export(request: Request):
        f = filters_from(request)
        where, params = build_where(f)
        rows = S.store.q(f"SELECT ts, host, site, code, severity, signal, category, interface, message, raw "
                         f"FROM events e WHERE {where} ORDER BY e.ts LIMIT 100000", params)
        buf = io.StringIO()
        w = csv.writer(buf)
        w.writerow(["time", "host", "site", "code", "cisco_severity", "netsignal_signal", "category", "interface",
                    "message", "raw"])
        for r in rows:
            w.writerow([fmt(r["ts"], True), r["host"], r["site"], r["code"], r["severity"], r["signal"], r["category"],
                        r["interface"], r["message"], r["raw"]])
        return StreamingResponse(iter([buf.getvalue()]), media_type="text/csv",
                                 headers={"Content-Disposition": "attachment; filename=netsignal-events.csv"})

    @api.get("/api/event/{eid}")
    def event(eid: int):
        st = S.store
        r = st.one("SELECT * FROM events WHERE id=?", (eid,))
        if not r:
            raise HTTPException(404)
        e = ev_out(r)
        exp = S.cls.explain(r)
        around = [ev_out(x) for x in st.q(
            "SELECT * FROM events WHERE host=? AND ts BETWEEN ? AND ? AND id != ? ORDER BY ts LIMIT 60",
            (r["host"], r["ts"] - 120, r["ts"] + 120, eid))]
        iface_hist = []
        if r["interface"]:
            iface_hist = [ev_out(x) for x in st.q(
                "SELECT * FROM events WHERE host=? AND interface=? ORDER BY ts DESC LIMIT 40", (r["host"], r["interface"]))]
        site_rel = []
        if r["site"]:
            site_rel = [ev_out(x) for x in st.q(
                "SELECT * FROM events WHERE site=? AND host != ? AND ts BETWEEN ? AND ? AND signal IN "
                "('warning','major','critical') ORDER BY ts LIMIT 30", (r["site"], r["host"], r["ts"] - 60, r["ts"] + 60))]
        mac_hist = []
        if r["mac"]:
            mac_hist = [ev_out(x) for x in st.q("SELECT * FROM events WHERE mac=? ORDER BY ts DESC LIMIT 40", (r["mac"],))]
        return {"event": e, "explain": exp, "severity_name": SEV_NAMES.get(r["severity"]),
                "vendor": mac_vendor(r["mac"]), "around": around, "interface_history": iface_hist,
                "site_related": site_rel, "mac_history": mac_hist,
                "category": S.cls.cat_by_id.get(r["category"])}

    # ------------------------------------------------------------------ category
    @api.get("/api/category/{cid}")
    def category(cid: str, range: str = "24h"):
        c = S.cls.cat_by_id.get(cid)
        if not c:
            raise HTTPException(404)
        t0, t1 = window(range)
        fs = [_fslim(f) for f in S.intel.findings(t0, t1) if f["category"] == cid]
        st = S.store
        codes = st.q("SELECT code, signal, COUNT(*) n, COUNT(DISTINCT host) d, MAX(ts) last FROM events "
                     "WHERE category=? AND ts BETWEEN ? AND ? GROUP BY code, signal ORDER BY n DESC LIMIT 25",
                     (cid, t0, t1))
        top_ifaces = st.q("SELECT host, interface, COUNT(*) n, SUM(state='down') downs, MAX(ts) last FROM events "
                          "WHERE category=? AND ts BETWEEN ? AND ? AND interface IS NOT NULL AND signal != 'routine' "
                          "GROUP BY host, interface ORDER BY n DESC LIMIT 12", (cid, t0, t1))
        extra = {}
        if cid == "auth":
            S.intel.findings(t0, t1)
            extra["auth"] = getattr(S.intel, "auth_stats", {})
            extra["reasons"] = st.q("SELECT reason, COUNT(*) n FROM events WHERE category='auth' AND kind='auth_fail' "
                                    "AND ts BETWEEN ? AND ? GROUP BY reason ORDER BY n DESC", (t0, t1))
        if cid == "power":
            extra["poe_budget"] = st.q(
                "SELECT host, json_extract(attrs,'$.switch') sw, MIN(CAST(json_extract(attrs,'$.budget') AS REAL)) lo, "
                "MAX(CAST(json_extract(attrs,'$.budget') AS REAL)) hi, COUNT(*) n FROM events WHERE kind='poe_budget' "
                "AND ts BETWEEN ? AND ? GROUP BY host, sw ORDER BY lo ASC LIMIT 10", (t0, t1))
        if cid == "routing":
            extra["neighbors"] = st.q(
                "SELECT host, protocol, neighbor, SUM(state='down') downs, SUM(state='up') ups, MAX(ts) last FROM events "
                "WHERE kind='routing_adj' AND ts BETWEEN ? AND ? GROUP BY host, protocol, neighbor ORDER BY downs DESC",
                (t0, t1))
        return {"category": c, "window": {"t0": t0, "t1": t1}, "findings": fs, "codes": codes,
                "top_interfaces": top_ifaces, "extra": extra}

    # ------------------------------------------------------------------ devices
    @api.get("/api/devices")
    def devices(range: str = "24h"):
        t0, t1 = window(range)
        rows = S.store.q(
            "SELECT host, MIN(fqdn) fqdn, MIN(site) site, MIN(role) role, MAX(platform) platform, COUNT(*) n, "
            "SUM(signal IN ('warning','major','critical')) sig, SUM(signal='routine') routine, MAX(ts) last, "
            "MIN(ts) first FROM events WHERE ts BETWEEN ? AND ? GROUP BY host", (t0, t1))
        hl = health(S.intel.findings(t0, t1))
        roles = S.cfg["hostnames"].get("roles", {})
        for r in rows:
            r.update(hl.get(r["host"], {"score": 100, "findings": 0, "worst": None}))
            r["role_name"] = roles.get(r["role"])
        rows.sort(key=lambda r: (r["score"], -r["sig"]))
        return {"devices": rows, "window": {"t0": t0, "t1": t1}}

    @api.get("/api/device/{host}")
    def device(host: str, range: str = "24h"):
        t0, t1 = window(range)
        st = S.store
        info = st.one("SELECT host, MIN(fqdn) fqdn, MIN(site) site, MIN(role) role, MAX(platform) platform, "
                      "COUNT(*) n, MIN(ts) first, MAX(ts) last FROM events WHERE host=?", (host,))
        if not info or not info["n"]:
            raise HTTPException(404, "unknown device")
        info["role_name"] = S.cfg["hostnames"].get("roles", {}).get(info["role"])
        fs = S.intel.findings(t0, t1)
        mine = [_fslim(f) for f in fs if f["host"] == host or host in (f["metrics"].get("devices") or [])
                or host in (f["metrics"].get("switches") or [])]
        hl = health(fs).get(host, {"score": 100, "findings": 0, "worst": None})
        ifaces = st.q(
            "SELECT interface, MIN(iface_class) cls, SUM(state='down' AND kind IN ('link_state','errdisable')) downs, "
            "SUM(state='up' AND kind='link_state') ups, COUNT(*) n, MAX(ts) last, "
            "(SELECT state FROM events x WHERE x.host=e.host AND x.interface=e.interface AND x.state IS NOT NULL "
            " AND x.kind IN ('link_state','proto_state','errdisable') ORDER BY x.ts DESC LIMIT 1) last_state "
            "FROM events e WHERE host=? AND ts BETWEEN ? AND ? AND interface IS NOT NULL GROUP BY interface "
            "ORDER BY downs DESC, n DESC LIMIT 60", (host, t0, t1))
        codes = st.q("SELECT code, category, signal, COUNT(*) n, MAX(ts) last FROM events WHERE host=? AND ts BETWEEN ? AND ? "
                     "GROUP BY code ORDER BY n DESC LIMIT 20", (host, t0, t1))
        cats = st.q("SELECT category, COUNT(*) n, SUM(signal IN ('warning','major','critical')) sig FROM events "
                    "WHERE host=? AND ts BETWEEN ? AND ? GROUP BY category ORDER BY sig DESC, n DESC", (host, t0, t1))
        skew = st.one("SELECT AVG(skew) a, COUNT(*) n FROM events WHERE host=? AND skew IS NOT NULL AND ts > ?",
                      (host, t1 - 3600))
        nbrs = st.q("SELECT protocol, neighbor, MAX(ts) last, (SELECT state FROM events x WHERE x.host=e.host AND "
                    "x.neighbor=e.neighbor AND x.kind='routing_adj' ORDER BY ts DESC LIMIT 1) state FROM events e "
                    "WHERE host=? AND kind='routing_adj' GROUP BY protocol, neighbor", (host,))
        peers = st.q("SELECT host, COUNT(*) n, SUM(signal IN ('warning','major','critical')) sig FROM events "
                     "WHERE site=? AND host != ? AND ts BETWEEN ? AND ? GROUP BY host ORDER BY sig DESC LIMIT 12",
                     (info["site"], host, t0, t1)) if info["site"] else []
        return {"info": info, "health": hl, "findings": mine, "interfaces": ifaces, "codes": codes,
                "categories": cats, "clock": skew, "neighbors": nbrs, "site_peers": peers,
                "histogram": histogram(st, "e.host = ? AND e.ts BETWEEN ? AND ?", [host, t0, t1], t0, t1, 72),
                "window": {"t0": t0, "t1": t1}}

    @api.get("/api/interface")
    def interface(host: str, iface: str, range: str = "7d"):
        t0, t1 = window(range)
        rows = [ev_out(r) for r in S.store.q(
            "SELECT * FROM events WHERE host=? AND (interface=? OR attrs LIKE ?) AND ts BETWEEN ? AND ? ORDER BY ts",
            (host, iface, f'%"{iface}"%', t0, t1))]
        segs, cur, start = [], None, t0
        for r in rows:
            if r["kind"] in ("link_state", "errdisable") and r["state"] in ("up", "down", "admin_down"):
                if cur is not None and r["state"] != cur:
                    segs.append({"state": cur, "t0": start, "t1": r["ts"]})
                    start = r["ts"]
                elif cur is None:
                    segs.append({"state": "unknown", "t0": t0, "t1": r["ts"]})
                    start = r["ts"]
                cur = r["state"]
        segs.append({"state": cur or "unknown", "t0": start, "t1": t1})
        downs = sum(1 for r in rows if r["kind"] == "link_state" and r["state"] == "down")
        return {"host": host, "interface": iface, "short": short_interface(iface), "events": rows[-500:],
                "segments": segs, "downs": downs, "window": {"t0": t0, "t1": t1},
                "class": next((r["iface_class"] for r in rows if r.get("iface_class")), None)}

    # ------------------------------------------------------------------ search
    @api.get("/api/search")
    def search(q: str = ""):
        return interpret(q, S.hosts(), S.sites())

    @api.get("/api/suggest")
    def suggest(q: str = ""):
        return {"items": suggestions(q, S.store)}

    # ------------------------------------------------------------------ live stream (SSE)
    @api.get("/api/stream")
    async def stream(request: Request):
        loop = asyncio.get_running_loop()
        q: asyncio.Queue = asyncio.Queue(maxsize=300)
        S.pipe.subscribe(loop, q)

        async def gen():
            try:
                yield "retry: 3000\n\n"
                while True:
                    if await request.is_disconnected():
                        break
                    try:
                        batch = await asyncio.wait_for(q.get(), timeout=15)
                        yield f"data: {json.dumps(batch, default=str)}\n\n"
                    except asyncio.TimeoutError:
                        yield ": keepalive\n\n"
            finally:
                S.pipe.unsubscribe(loop, q)

        return StreamingResponse(gen(), media_type="text/event-stream",
                                 headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})

    # ------------------------------------------------------------------ archives
    @api.get("/api/archives")
    def archives():
        from .ingest.access import make_access
        files, err = [], None
        try:
            acc = make_access(S.cfg)
            acc.connect()
            try:
                files = S.ingest.list_files(acc)
            finally:
                acc.close()
        except Exception as e:
            err = f"{type(e).__name__}: {e}"
        db = S.store.files()
        for f in files:
            f["db"] = db.get(f["name"])
            f["job"] = S.ingest.job_status.get(f["name"])
        return {"files": files, "error": err, "retention_days": S.cfg["database"]["retention_days"]}

    @api.post("/api/archives/{name}/load")
    def load_archive(name: str):
        try:
            S.ingest.queue_archive(name)
        except ValueError as e:
            raise HTTPException(400, str(e))
        return {"queued": name}

    @api.get("/api/archives/search")
    def deep_search(files: str, q: str, limit: int = 300):
        if not q.strip():
            raise HTTPException(400, "query required")
        names = [x for x in files.split(",") if x]
        res = S.ingest.deep_search(names, q, limit=min(limit, 2000))
        res["events"] = [{k: v for k, v in ev_out(e).items()} for e in res["events"]]
        return res

    # ------------------------------------------------------------------ rules
    @api.get("/api/rules")
    def rules():
        unclassified = S.store.q("SELECT code, COUNT(*) n, MAX(message) example FROM events WHERE category='other' "
                                 "AND code IS NOT NULL GROUP BY code ORDER BY n DESC LIMIT 50")
        usage = {r["rule"]: r["n"] for r in S.store.q("SELECT rule, COUNT(*) n FROM events GROUP BY rule")}
        rs = S.cls.rules_summary()
        for r in rs:
            r["hits"] = usage.get(r["id"], 0)
        return {"categories": S.cls.category_list(), "rules": rs, "unclassified": unclassified,
                "intel": S.cfg.get("intel", {}), "hostnames": S.cfg.get("hostnames", {}),
                "interfaces": S.cfg.get("interfaces", {})}

    @api.post("/api/rules/reload")
    def rules_reload():
        S.cls.reload()
        S.intel._cache.clear()
        return {"ok": True, "rules": len(S.cls.rules), "note": "New rules apply to newly ingested lines."}

    @api.post("/api/parse-test")
    async def parse_test(request: Request):
        body = await request.json()
        from .timeutil import now_dt
        out = []
        for line in (body.get("text") or "").splitlines()[:50]:
            if not line.strip():
                continue
            ev = S.pipe.parser.parse_line(line, now_dt())
            if ev is None or ev.get("unparsed"):
                out.append({"line": line, "ok": False})
                continue
            ev = S.cls.classify(ev)
            out.append({"line": line, "ok": True, "event": ev_out(ev), "explain": S.cls.explain(ev)})
        return {"results": out}

    # ------------------------------------------------------------------ UI
    api.mount("/static", StaticFiles(directory=str(WEB)), name="static")

    @api.get("/")
    def index():
        return FileResponse(WEB / "index.html", headers={"Cache-Control": "no-cache"})

    return api
