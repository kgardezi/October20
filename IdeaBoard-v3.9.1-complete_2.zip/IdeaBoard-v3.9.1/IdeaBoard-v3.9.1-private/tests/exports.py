"""PNG / SVG export checks: resolution tag, transparency, scale, editable (Office/Visio) SVG and font trimming."""
import os, pathlib, shutil, struct, tempfile, zlib
import xml.etree.ElementTree as ET
from playwright.sync_api import sync_playwright

URL = os.environ.get('IDEABOARD_URL', 'http://127.0.0.1:8000/')
OUT = pathlib.Path(os.environ.get('IDEABOARD_TEST_OUTPUT', tempfile.gettempdir() + '/ideaboard-exports')); OUT.mkdir(parents=True, exist_ok=True)

def png_info(data):
    assert data[:8] == b'\x89PNG\r\n\x1a\n'
    i, chunks = 8, {}
    while i < len(data):
        n, kind = struct.unpack('>I4s', data[i:i + 8]); body = data[i + 8:i + 8 + n]; crc = struct.unpack('>I', data[i + 8 + n:i + 12 + n])[0]
        assert zlib.crc32(kind + body) & 0xffffffff == crc, kind
        chunks.setdefault(kind.decode(), []).append(body); i += 12 + n
    w, h, depth, colour = struct.unpack('>IIBB', chunks['IHDR'][0][:10])
    return w, h, colour, chunks

with sync_playwright() as p:
    b = p.chromium.launch(executable_path=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium'), args=['--no-sandbox'])
    page = b.new_page(viewport={'width': 1400, 'height': 900}, accept_downloads=True); errors = []; page.on('pageerror', lambda e: errors.append(str(e)))
    page.goto(URL); page.wait_for_function("window.ideaBoard&&document.querySelector('#canvas').style.visibility!=='hidden'")
    page.evaluate("sel.clear();render()")
    W, H = page.evaluate("(()=>{const r=exportSvgString(false);return [r.W,r.H]})()")

    def export(fmt, **o):
        page.locator('#menuBtn').click(); page.locator('[data-menu="imageopts"]').click()
        page.locator('#imgFormat').select_option(fmt)
        for k, v in o.items():
            el = page.locator('#img' + k)
            if isinstance(v, bool): el.set_checked(v)
            else: el.select_option(str(v))
        with page.expect_download() as d: page.locator('#imgDownload').click()
        return pathlib.Path(d.value.path()).read_bytes()

    data = export('png', Scale=3, Bg='transparent', Grid=False)
    w, h, colour, chunks = png_info(data)
    assert (w, h) == (W * 3, H * 3), (w, h, W, H)
    ppm = struct.unpack('>IIB', chunks['pHYs'][0]); assert ppm[0] == ppm[1] == round(288 / .0254) and ppm[2] == 1, ppm
    raw = zlib.decompress(b''.join(chunks['IDAT'])); assert colour == 6
    assert raw[1 + 3] == 0, 'top-left pixel is transparent'
    (OUT / 'transparent-3x.png').write_bytes(data)
    print('PASS: PNG at 3x with 288 dpi resolution tag and a transparent background', flush=True)

    data = export('png', Scale=1, Bg='white', Grid=False)
    w, h, colour, chunks = png_info(data); assert (w, h) == (W, H)
    assert struct.unpack('>I', chunks['pHYs'][0][:4])[0] == round(96 / .0254)
    print('PASS: PNG at 1x is tagged 96 dpi (drawing size in Office and Visio)', flush=True)

    svg = export('svg', Text='editable', Bg='canvas', Grid=False).decode()
    root = ET.fromstring(svg)
    assert root.findall('.//{*}text'), 'editable text kept'
    assert 'dominant-baseline' not in svg and 'filter="url(' not in svg
    assert any(t.get('dy') for t in root.iter() if t.tag.endswith('tspan') or t.tag.endswith('text'))
    (OUT / 'editable.svg').write_text(svg)
    print('PASS: editable SVG keeps real text without filters or dominant-baseline', flush=True)

    page.evaluate("for(const s of board.shapes) s.font='draw'; render()")
    svg = export('svg', Text='outlined').decode()
    assert '<text' not in svg and '@font-face' not in svg, 'all words outlined, font not embedded'
    print('PASS: outlined SVG drops the embedded font when every word is outlined (%d KB)' % (len(svg) // 1024), flush=True)

    page.evaluate("document.documentElement.dataset.theme='dark';render()")
    svg = export('svg', Colors='light', Bg='canvas', Text='editable').decode()
    assert '#101113' not in svg and '#e6e6e6' not in svg, 'dark canvas colours replaced by light ones'
    assert page.evaluate("document.documentElement.dataset.theme") == 'dark', 'theme restored'
    print('PASS: light colours on export from dark mode; theme restored', flush=True)

    # Visio import of the exported PNG would size it from the resolution tag; the menu shortcut uses the remembered options
    page.locator('#menuBtn').click()
    with page.expect_download() as d: page.locator('[data-menu="png"]').click()
    assert png_info(pathlib.Path(d.value.path()).read_bytes())[3].get('pHYs')
    print('PASS: menu PNG uses remembered options', flush=True)

    # 3.9: light-background colours, PDF with white background, hand-drawn devices
    assert page.evaluate("document.documentElement.dataset.theme='light';render();col('yellow')") == '#b54708'
    assert page.evaluate("document.documentElement.dataset.theme='dark';render();col('yellow')") == '#ffe347'
    data = export('pdfall', Bg='white', Colors='light')
    assert data[:5] == b'%PDF-' and data.count(b'/Type /Page') >= 1
    print('PASS: burnt-orange WAN (no yellow) on light backgrounds, bright yellow on dark; PDF with white background', flush=True)
    page.evaluate("document.documentElement.dataset.theme='light';sel.clear();board.shapes.push(makeShape('device',900,900,{kind:'switch',view:'rack'}),makeShape('device',900,1000,{kind:'router',view:'rack'}));for(const d of board.shapes.filter(x=>x.view==='rack')){d.w=290;d.h=64;}render()")
    before = page.evaluate("exportSvgString(false,{text:'editable'}).svg")
    page.locator('#canvas').focus(); page.keyboard.press('Alt+h')
    assert page.evaluate("board.shapes.filter(s=>s.view==='rack').every(s=>s.outline==='hand')")
    assert page.evaluate("board.shapes.filter(s=>s.type==='device'&&s.view!=='rack').every(s=>s.outline!=='hand')"), 'icons stay clean'
    after = page.evaluate("exportSvgString(false,{text:'editable'}).svg")
    assert after.count('<path') > before.count('<path'), 'marker outlines drawn for devices'
    page.keyboard.press('Alt+h'); assert page.evaluate("board.shapes.filter(s=>s.view==='rack').every(s=>s.outline==='clean')")
    page.evaluate("sel=new Set([board.shapes.find(s=>s.view==='rack').id]);panelKey='';render()")
    page.locator('[data-set="outline"][data-v="hand"]').click()
    assert page.evaluate("board.shapes.filter(s=>s.type==='device'&&s.outline==='hand').length") == 1
    print('PASS: Alt H sketches rack units only (icons stay clean); one unit via its style panel; exports include it', flush=True)

    assert not errors, errors
    print('PASS: no browser JavaScript errors', flush=True)
    b.close()
