# Using IdeaBoard 3.8.0

Keep a saved copy of important boards before switching versions (Menu ▸ Save to file), then open them in 3.8.0 with Menu ▸ Open file. Browser storage is shared with 3.7.0 in the private edition.

## Exporting to Visio

1. Menu ▸ Export Visio (.vsdx). Choose All pages or Current page.
2. **Look:** keep *Visio* for a drawing that matches other Visio diagrams (white page, standard line weights, small port text, thin frames). Choose *Canvas* to keep IdeaBoard's colours, outlined port tags, dashed frames and the Light/Black gradient backgrounds.
3. **Font:** Calibri is Visio's default; Segoe UI and Arial are available.
4. **Grid:** *Visio grid* shows Visio's own grid on screen only; *Graph paper* prints grid lines with the drawing; *No grid*.
5. Download and open in Visio.

In Visio:

- Drag a device: its links stay glued, Visio reroutes them, and the port names and link labels travel with the links.
- Drag a site frame: the devices inside move with it (it is a Visio container).
- View ▸ Layer Properties: hide or lock Port labels, Pipes, Sites, Annotations and so on.
- Right-click a device ▸ Data ▸ Shape Data: Network Name, IP Address, Subnet Mask, Device type, Role, VLAN, Info, Notes. Links carry A-end port, B-end port and Link type.
- Dragging a port name or label by hand detaches it from the formula (normal Visio behaviour); it then stays where you put it.

If your Visio reports a problem with labels or frames, open *Visio behaviour* in the export window and untick *Port names and link labels follow their links* and/or *Site frames are Visio containers*. Please note the exact Visio message.

Back in IdeaBoard, Menu ▸ Import Visio reads the moved devices, edited text, re-glued links and any port names you retyped in the tags.

## PNG and SVG for documents and slides

Menu ▸ Image export options… sets the area, background (canvas, white, transparent), colours (current or always light), PNG resolution and SVG text mode. Export PNG / Export SVG then reuse those choices.

- PNG pastes into Visio, Word and PowerPoint at drawing size at any resolution.
- Choose SVG with *Editable text* to insert into Visio or PowerPoint and convert it to shapes with editable labels. *Outlined* SVG looks identical everywhere but its words are vector shapes.

## Restored features

- Nexus/ASR parsing from 3.6.1 (see Changes.md). Re-import device files to benefit, especially where Nexus speeds showed as unknown.
- Menu ▸ Grid style ▸ Lines, and Menu ▸ Include grid in PNG / SVG / PDF.
- Laser panel: seven colours, glow, 1–10 second trails or Keep until cleared, and a bright dot at the pointer while drawing.
- Team server: see the IdeaBoard-v3.8.0-team-server folder and its README (Docker or `sudo ./install.sh`).

# Using the 3.7.0 improvements (still current)

## Apply the automatic layout

1. Save a copy of the current board.
2. Open Menu > Import network and add the original device logs.
3. Review connections and select the desired site/VRF filters.
4. Turn OFF **Keep device positions from matching current-board pages** to apply the new layout. Leaving it on intentionally retains your previous device positions.
5. Generate diagrams. TL and CL/DL pairs align across the site; AS and other end devices stack in the center below. Multiple AG/ML devices retain their intermediate layer. Access cables use separate side lanes; other links use straight, elbow or obstacle-aware routes.
6. Check dense labels and unusual topologies. The algorithm avoids device bodies where it can, but does not guarantee that all labels or crossings disappear. Manual annotations are not merged on regeneration.

Open Layered-layout-demo.ideaboard.json for the six-access-switch example, or import samples/Layered-layout-outputs.zip. Both contain synthetic documentation-range data only.

## More connection points

Select a built-in shape and drag from any + handle to another shape. Boxes have at least three handles per side; larger boxes offer more. Round and diamond shapes project the handles onto their outline. Devices also distribute generated connections across their edges. Anchors stay attached when shapes move or resize. Existing four-point drawings still open normally.

## Fonts and exports

SVG, PNG and raster PDF retain hand-drawn appearance using vector glyph outlines from the bundled font. This does not depend on the recipient installing the handwritten font. Outlined SVG words remain accessible through titles but are paths, not editable text. Edit text in the saved IdeaBoard file or the editable Visio export instead. Other font choices remain SVG text and rely on the recipient's installed fonts. Unsupported non-Latin glyphs retain their text fallback.

The application remains fully local and static. Font outline assets and the OpenType parser are bundled; no online font service or runtime installation is used. See FONT-LICENSE.txt and OPENTYPE-LICENSE.txt.

## Graph paper and Visio

Menu > Grid style switches between **Graph paper** and **Dots**. Show grid toggles either off. The canvas follows light/dark mode. The visible grid also appears in SVG/PNG/PDF.

For Visio, the export window's Grid choice replaces the old checkbox (see 3.8.0 above).

## Laser

Select K or the Laser tool. Choose Spot (a pointing dot) or Trail (temporary drawing). Choose red, green or cyan and a size. Trail lifetime starts after release: 5, 7 or 10 seconds; the default is 7. Keep until cleared retains marks until Clear laser marks or Escape. Marks do not become board shapes and are not saved/exported. Set options before entering clean fullscreen; K can select the laser while presenting.

## Missing speeds and collection guide

The import window's Collection guide has ASR 920, Catalyst and Nexus lists with copy buttons for physical, OSPF and pseudowire groups. The application does not execute them or access devices.

ASR 920: collect show interfaces with explicit duplex/speed observations. Nexus 9K: collect show interface status and detailed show interface output. Preserve command headings and Ethernet breakout identifiers. Plain show interfaces description has no operating-speed column. BW and carrier description bandwidth are not operating port rates. Unknown-speed review notes now recommend the relevant additional outputs.

The Physical link speeds page reports observed rates. Legacy L1/L2 labels may describe nominal interface capability. Port rate, provider circuit capacity and traffic utilization are distinct values. This release does not monitor live flows, compute ECMP utilization or infer pseudowire bandwidth allocation.
