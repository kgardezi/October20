// Live tail: an intelligent `tail -f log`.
import { esc, icon, api, qs, fmtTime, n } from '../util.js';
import { state } from '../state.js';
import { openEvent } from '../components.js';

const MAX = 1500;

export async function render(main) {
  let paused = false, raw = false, hide = state.hideRoutine, filter = '', minSig = '', lines = [], received = 0, shown = 0, queued = [];
  main.innerHTML = `<div class="page">
    <div class="ph"><div><h1>Live tail</h1><div class="sub">The same stream as <span class="mono">tail -f log</span> - parsed, colour-rated and clickable. Routine lines can be dimmed or hidden.</div></div><div class="grow"></div></div>
    <div class="card" style="margin-bottom:12px"><div class="filterbar">
      <button class="btn sm" id="pause">${icon('pause', 'sm')} Pause</button>
      <input class="inp" id="flt" placeholder="Filter: host, code, interface, text…" style="width:300px;padding:5px 9px">
      <select class="inp" id="sig" style="width:auto;padding:5px 9px"><option value="">All ratings</option><option value="warning">Warning +</option><option value="major">Major +</option></select>
      <label class="toggle ${hide ? 'on' : ''}" id="tgHide"><span class="sw"></span>Hide routine</label>
      <label class="toggle ${raw ? 'on' : ''}" id="tgRaw"><span class="sw"></span>Raw lines</label>
      <button class="btn sm" id="clear">Clear</button>
      <span style="flex:1"></span><span class="muted num" id="cnt"></span></div></div>
    <div class="term" id="term"></div></div>`;
  const term = main.querySelector('#term');

  const RANK = { routine: 0, info: 1, warning: 2, major: 3, critical: 4 };
  const visible = e => (!hide || e.signal !== 'routine') && (!minSig || RANK[e.signal] >= RANK[minSig]) &&
    (!filter || (e.raw || '').toLowerCase().includes(filter));

  const color = msg => esc(msg)
    .replace(/\b((?:TenGigabitEthernet|GigabitEthernet|Ethernet|Port-channel|Te|Gi|Eth|Po)\d+(?:\/\d+)*)\b/g, '<span class="t-if">$1</span>')
    .replace(/\b([0-9a-f]{4}\.[0-9a-f]{4}\.[0-9a-f]{4})\b/g, '<span class="t-mac">$1</span>')
    .replace(/(changed state to down|is down|to DOWN| Down\b|PD removed)/g, '<span class="t-down">$1</span>')
    .replace(/(changed state to up|is up|to FULL| Up\b)/g, '<span class="t-up">$1</span>');

  const lineHtml = (e, isNew) => raw
    ? `<div class="ln ${esc(e.signal)} ${isNew ? 'new' : ''}" data-id="${e.id}"><span class="rawline">${esc(e.raw)}</span></div>`
    : `<div class="ln ${esc(e.signal)} ${isNew ? 'new' : ''}" data-id="${e.id}"><span class="ts">${esc(fmtTime(e.ts, true))}</span><span class="h">${esc(e.host)}</span>
       <span class="c">%${esc(e.code || '')}</span><span>${color(e.message || '')}</span></div>`;

  function redraw() {
    const vis = lines.filter(visible).slice(-600);
    shown = vis.length;
    term.innerHTML = vis.map(e => lineHtml(e, false)).join('') || `<div style="padding:20px;color:#8a93a3">Waiting for messages…</div>`;
    term.scrollTop = term.scrollHeight;
    count();
  }
  function count() { main.querySelector('#cnt').textContent = `${n(received)} received · ${n(shown)} shown${paused ? ` · ${queued.length} queued` : ''}`; }

  function add(batch) {
    received += batch.length;
    if (paused) { queued.push(...batch); count(); return; }
    lines.push(...batch);
    if (lines.length > MAX) lines = lines.slice(-MAX);
    const atBottom = term.scrollHeight - term.scrollTop - term.clientHeight < 60;
    const vis = batch.filter(visible);
    if (vis.length) {
      if (term.firstElementChild && !term.firstElementChild.dataset.id) term.innerHTML = '';
      term.insertAdjacentHTML('beforeend', vis.map(e => lineHtml(e, true)).join(''));
      while (term.children.length > 600) term.firstElementChild.remove();
      if (atBottom) term.scrollTop = term.scrollHeight;
    }
    shown = term.children.length;
    count();
  }

  // seed with the most recent messages
  try {
    const r = await api('/api/events?' + qs({ range: '1h', limit: 300 }));
    lines = r.events.reverse();
  } catch (e) { /* ignore */ }
  redraw();

  main.querySelector('#pause').onclick = ev => {
    paused = !paused;
    ev.currentTarget.innerHTML = paused ? `${icon('play', 'sm')} Resume` : `${icon('pause', 'sm')} Pause`;
    if (!paused && queued.length) { const q = queued; queued = []; received -= q.length; add(q); }
    count();
  };
  main.querySelector('#flt').oninput = ev => { filter = ev.target.value.toLowerCase(); redraw(); };
  main.querySelector('#sig').onchange = ev => { minSig = ev.target.value; redraw(); };
  main.querySelector('#tgHide').onclick = ev => { hide = !hide; ev.currentTarget.classList.toggle('on', hide); redraw(); };
  main.querySelector('#tgRaw').onclick = ev => { raw = !raw; ev.currentTarget.classList.toggle('on', raw); redraw(); };
  main.querySelector('#clear').onclick = () => { lines = []; redraw(); };
  term.addEventListener('click', ev => { const l = ev.target.closest('.ln'); if (l?.dataset.id) openEvent(+l.dataset.id); });
  state.listeners.add(add);
  return () => state.listeners.delete(add);
}
