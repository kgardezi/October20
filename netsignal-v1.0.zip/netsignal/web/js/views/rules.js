// Rules & parser lab: categories, rule coverage, unclassified messages, live parser tester.
import { esc, icon, api, n, sevBadge, loading } from '../util.js';

const SAMPLE = `Oct 19 15:44:47 unyc787as0705.us.net.intra Oct 19 2026 15:44:46.647 EDST: %LINEPROTO-5-UPDOWN: Line protocol on Interface GigabitEthernet1/0/16, changed state to down
Oct 19 15:50:32 usec755sf0160.us.net.intra 2026 Oct 19 15:50:32.921215 EDST: %L2FM-4-L2FM_MAC_MOVE2: Mac 0050.568d.51fb in vlan 507 has moved from Po2 to Eth1/38
Oct 19 15:48:27 bsan249sf0209.br.net.intra 2026 Oct 19 15:48:27.058550 EDST: %TAHUSD-SLOT1-4-BUFFER_THRESHOLD_EXCEEDED: Module 1 Instance 1 Pool-group buffer 90 percent threshold is exceeded! (message repeated 3 times)`;

export async function render(main) {
  main.innerHTML = `<div class="page">${loading()}</div>`;
  const d = await api('/api/rules');
  const byCat = {};
  d.rules.forEach(r => { (byCat[r.category] = byCat[r.category] || []).push(r); });
  main.innerHTML = `<div class="page">
    <div class="ph"><div><h1>Rules & parser lab</h1><div class="sub">Classification is driven by <span class="mono">netsignal/rules/cisco_rules.yaml</span> and <span class="mono">categories.yaml</span>. Edit them, then reload - no code changes needed.</div></div>
      <div class="grow"></div><button class="btn" id="reload">${icon('refresh', 'sm')} Reload rules</button></div>
    <div class="grid">
      <div class="card c7"><div class="hd"><h3>${icon('terminal', 'sm')} Parser lab</h3><span class="muted" style="font-size:12px">paste raw lines from <span class="mono">tail -f log</span></span></div><div class="bd">
        <textarea class="inp" id="pt">${esc(SAMPLE)}</textarea>
        <div style="margin-top:8px"><button class="btn primary" id="parse">Parse & classify</button></div>
        <div id="pres" style="margin-top:12px"></div></div></div>
      <div class="card c5"><div class="hd"><h3>Unclassified message codes</h3><span class="muted" style="font-size:12px">candidates for new rules</span></div><div class="bd scroll" style="max-height:440px">
        ${d.unclassified.length ? `<table class="tbl"><thead><tr><th>Code</th><th class="r">Count</th></tr></thead><tbody>${d.unclassified.map(u => `<tr title="${esc(u.example)}"><td><span class="code">${esc(u.code)}</span><div class="muted mono" style="font-size:11px;margin-top:3px">${esc(u.example.slice(0, 110))}</div></td><td class="r num">${n(u.n)}</td></tr>`).join('')}</tbody></table>` : '<div class="muted">Every indexed message matched a rule.</div>'}</div></div>
      <div class="card c12"><div class="hd"><h3>Categories & rules</h3><span class="grow"></span><span class="muted">${d.rules.length} rules · first match wins</span></div><div class="bd">
        ${d.categories.map(c => `<div class="section-title" style="margin-top:14px">${icon(c.icon, 'sm')} ${esc(c.name)} <span class="line"></span><span style="text-transform:none;letter-spacing:0">${(byCat[c.id] || []).length} rules</span></div>
          ${(byCat[c.id] || []).length ? `<table class="tbl"><thead><tr><th>Rule</th><th>Code pattern</th><th>Type</th><th>Default rating</th><th>Overrides</th><th class="r">Hits</th></tr></thead><tbody>
          ${(byCat[c.id] || []).map(r => `<tr><td class="mono">${esc(r.id)}</td><td class="mono" style="font-size:11.5px">${esc(r.code || '')}</td><td>${esc(r.kind)}</td><td>${sevBadge(r.signal)}</td>
            <td class="muted" style="font-size:12px">${Object.entries(r.signal_by_state || {}).map(([k, v]) => `${esc(k)}→${esc(v)}`).join(', ')}${r.edge_signal ? ` · access ports→${esc(r.edge_signal)}` : ''}</td><td class="r num">${n(r.hits)}</td></tr>`).join('')}</tbody></table>` : '<div class="muted">Fallback for unmatched messages.</div>'}`).join('')}
      </div></div>
      <div class="card c6"><div class="hd"><h3>Intelligence thresholds</h3><span class="muted" style="font-size:12px">config.yaml → intel</span></div><div class="bd"><div class="kv">
        ${Object.entries(d.intel).map(([k, v]) => `<div class="k mono">${esc(k)}</div><div class="v num">${esc(v)}</div>`).join('')}</div></div></div>
      <div class="card c6"><div class="hd"><h3>Hostname convention</h3><span class="muted" style="font-size:12px">config.yaml → hostnames (inferred - please verify)</span></div><div class="bd">
        <div class="mono" style="font-size:12px;margin-bottom:8px">${esc(d.hostnames.pattern)}</div><div class="kv">
        ${Object.entries(d.hostnames.roles || {}).map(([k, v]) => `<div class="k mono">${esc(k)}</div><div class="v">${esc(v)}${(d.hostnames.access_roles || []).includes(k) ? ' <span class="chip">access ports = edge</span>' : ''}</div>`).join('')}</div></div></div>
    </div></div>`;

  main.querySelector('#reload').onclick = async () => { await api('/api/rules/reload', { method: 'POST' }); render(main); };
  main.querySelector('#parse').onclick = async () => {
    const r = await api('/api/parse-test', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: main.querySelector('#pt').value }) });
    main.querySelector('#pres').innerHTML = r.results.map(x => x.ok ? `<div class="ctx" style="display:block">
      <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">${sevBadge(x.event.signal)}<span class="code">${esc(x.event.code || 'no code')}</span>
        <span class="chip">${esc(x.event.category)}</span><span class="chip">${esc(x.event.kind)}</span><span class="chip">rule: ${esc(x.explain.rule || 'none')}</span>
        <span class="chip">${esc(x.event.platform || '?')}</span><span class="chip">${esc(x.event.host)} · site ${esc(x.event.site || '?')}</span>
        ${x.event.interface ? `<span class="chip">${esc(x.event.interface)} (${esc(x.event.iface_class)})</span>` : ''}${x.event.state ? `<span class="chip">state ${esc(x.event.state)}</span>` : ''}
        ${x.event.mac ? `<span class="chip">${esc(x.event.mac)}</span>` : ''}${x.event.repeat > 1 ? `<span class="chip">×${x.event.repeat}</span>` : ''}</div>
      <div style="margin-top:6px">${esc(x.explain.text)}</div></div>` : `<div class="ctx change">${icon('alert')}<div>Could not parse: <span class="mono">${esc(x.line)}</span></div></div>`).join('');
  };
}
