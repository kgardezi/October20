const {test}=require('node:test');
const assert=require('node:assert/strict');
const I=require('../js/importer-engine.js');

const A='EDEM001CL0101',B='EDEM001CL0102';
const table=(port,speed,state='connected')=>`Port      Name                  Status       Vlan       Duplex  Speed Type\n${port} To the other core ${state} trunk a-full ${speed} 10GBase-SR`;
function device(host,peer,speed,{state='connected',extra='',cfg='',port='Gi1/0/1'}={}){
 const config=`interface ${port}\n description UPLINK: ${peer} ${port}\n ${cfg}\n!`;
 return I.parseDevice(host,`${host}#show running-config\n${config}\n${host}#show cdp neighbors detail\nDevice ID: ${peer}\nInterface: ${port}, Port ID (outgoing port): ${port}\n${speed==null?'':`${host}#sho interface status\n${table(port,speed,state)}\n`}${extra}`);
}
const build=(left,right,opts={})=>{const R=I.analyze([left,right]);return {R,board:I.buildBoard(R,opts)};};
const speedPage=board=>board.pages.find(p=>p.name==='Physical link speeds');
const links=board=>speedPage(board).shapes.filter(s=>s.type==='connector');
const detail=(port,rate,state='up',bw='10000000')=>`${port} is ${state}, line protocol is ${state}\n  Hardware is Ethernet, BW ${bw} Kbit/sec\n  Full-duplex, ${rate}, media type is 10GBase-SR\n`;

test('operational rate units normalize without guessing auto or media capabilities',()=>{
 for(const [raw,mbps]of [['a-1000',1000],['100',100],['2.5G',2500],['a-10G',10000],['100G',100000],['1000 Mb/s',1000],['10Gb/s',10000],['1000Mbps',1000],['1Tb/s',1000000],['64000Kb/s',64]])
  assert.equal(I.speedMbps(raw),mbps,raw);
 for(const raw of ['auto','--','unknown','10GBase-SR','a-auto','0','BW 10000000 Kbit/sec'])assert.equal(I.speedMbps(raw),null,raw);
 assert.equal(I.speedLabel(2500),'2.5 Gb/s');assert.equal(I.speedLabel(100),'100 Mb/s');
});

test('IOS status parses names with spaces, short commands, actual Speed column',()=>{
 const p=device(A,B,'a-100');assert.ok(p.cmds.has('status'));
 assert.equal(p.status.get('gi1/0/1').speed,'a-100');
 assert.equal(p.status.get('gi1/0/1').status,'up');
 assert.equal(p.prompt,A);
});

test('NX-OS status variants preserve observed speed and inactive state',()=>{
 const rows=I.parseStatus('Port Name Status Vlan Duplex Speed Type\nEth1/1 To Campus connected routed full 10G 10Gbase-SR\nEth1/2 sfpAbsent 1 auto auto --\nEth1/3 err-disabled trunk full 100G QSFP\n');
 assert.equal(rows.get('eth1/1').speed,'10G');assert.equal(rows.get('eth1/1').status,'up');
 assert.equal(rows.get('eth1/2').speed,'auto');assert.equal(rows.get('eth1/3').status,'down');
 assert.equal(I.parseStatus('Port Status Vlan Duplex Speed Type\nGi1/1 connected trunk a-full a-1000 copper').get('gi1/1').speed,'a-1000');
});

test('IOS and NX-OS detailed interface output uses duplex/speed, not BW',()=>{
 const ios=I.parseDevice(A,`${A}#show interfaces Gi1/0/1\n${detail('Gi1/0/1','100Mb/s')}`);
 assert.equal(ios.interfaceDetails.get('gi1/0/1').speed,'100Mb/s');
 const nx=I.parseDevice(B,`${B}#show interface Ethernet1/1\nEthernet1/1 is up\n  admin state is up, Dedicated Interface\n  Hardware: Ethernet, BW 10000000 Kbit\n  full-duplex, 10 Gb/s, media type is 10G\n`);
 assert.equal(nx.interfaceDetails.get('eth1/1').speed,'10 Gb/s');
 const noRate=I.parseInterfaceDetails('Gi1/1 is up, line protocol is up\n BW 10000000 Kbit/sec\n Speed: auto\n');
 assert.equal(noRate.get('gi1/1').speed,'');
});

test('OSPF detailed interface output is still parsed as OSPF, not Ethernet speed',()=>{
 const p=I.parseDevice(A,`${A}#show ip ospf interface\nGigabitEthernet1/0/1 is up, line protocol is up\n Internet Address 192.0.2.0/31, Area 0\n Process ID 1, Router ID 198.51.100.1, Network Type POINT_TO_POINT, Cost: 10\n`);
 assert.ok(p.cmds.has('ospfi'));assert.equal(p.interfaceDetails.size,0);assert.equal(p.ospfInterfaces[0].cost,10);
});

test('management label is the reported 100Mb rate even on nominal 10Gb ports',()=>{
 const {board}=build(device(A,B,'a-100',{port:'Te1/0/1'}),device(B,A,'100',{port:'Te1/0/1'}));
 const [c]=links(board);assert.equal(c.text,'100 Mb/s');assert.equal(c.operatingSpeed.mbps,100);
 assert.equal(c.operatingSpeed.status,'agreed');assert.equal(c.pipe,undefined);
 assert.match(c.foundBy,/show interfaces status: up; speed a-100/);
 assert.equal(c.startLabel,'');assert.equal(c.endLabel,'');
 assert.equal(c.operatingSpeed.a.port,'Te1/0/1');assert.equal(c.operatingSpeed.b.port,'Te1/0/1');
});

test('one-sided evidence is labelled; unknown/auto does not become port maximum',()=>{
 const one=build(device(A,B,'a-1000'),device(B,A,null)).board;
 assert.equal(links(one)[0].text,'1 Gb/s (one end)');assert.equal(links(one)[0].operatingSpeed.status,'one-sided');
 const unknown=build(device(A,B,'auto',{cfg:'speed 10000\n bandwidth 10000000'}),device(B,A,null)).board;
 assert.equal(links(unknown)[0].text,'Speed unknown');assert.equal(links(unknown)[0].operatingSpeed.mbps,null);
});

test('different endpoint rates are visible without inventing a bottleneck capacity',()=>{
 const {board}=build(device(A,B,'1000'),device(B,A,'10G'));
 const c=links(board)[0];assert.match(c.text,/Rates differ/);assert.match(c.text,/1 Gb\/s/);assert.match(c.text,/10 Gb\/s/);
 assert.equal(c.operatingSpeed.mbps,null);assert.equal(c.color,'orange');
 assert.ok(board.pages.find(p=>p.name==='Problems').shapes.some(s=>s.text.includes('Rates differ')));
});

test('conflicting source speeds at one endpoint retain both observations',()=>{
 const a=device(A,B,'a-1000',{extra:`${A}#show interfaces Gi1/0/1\n${detail('Gi1/0/1','10Gb/s')}`});
 const {board}=build(a,device(B,A,'1000'));
 const c=links(board)[0];assert.equal(c.text,'Speed conflict');assert.equal(c.operatingSpeed.mbps,null);
 assert.equal(c.operatingSpeed.a.observations.length,2);assert.match(c.foundBy,/10Gb\/s/);
});

test('down ports never advertise a historical or configured speed as active',()=>{
 const {board}=build(device(A,B,'1000',{state:'notconnect'}),device(B,A,'1000'));
 const c=links(board)[0];assert.equal(c.text,'Down');assert.equal(c.operatingSpeed.mbps,null);assert.equal(c.color,'grey');
 const shut=build(device(A,B,null,{cfg:'shutdown'}),device(B,A,null),{showShut:true}).board;
 assert.equal(links(shut)[0].text,'Admin down');assert.equal(links(shut)[0].operatingSpeed.mbps,null);
});

test('up/down source disagreement is flagged instead of choosing a rate',()=>{
 const a=device(A,B,'a-1000',{extra:`${A}#show interfaces Gi1/0/1\n${detail('Gi1/0/1','1000Mb/s','down')}`});
 const c=links(build(a,device(B,A,'1000')).board)[0];
 assert.equal(c.text,'State conflict');assert.equal(c.operatingSpeed.mbps,null);
});

test('separate status and detailed-output files merge and remain repeatable',()=>{
 const first=device(A,B,'a-1000');
 const second=I.parseDevice(A,`${A}#show interfaces Gi1/0/1\n${detail('Gi1/0/1','1000Mb/s')}`);
 const R=I.analyze([first,second,device(B,A,'1000')]);
 const c=links(I.buildBoard(R))[0];assert.equal(c.text,'1 Gb/s');assert.equal(c.operatingSpeed.a.observations.length,2);
 assert.equal(first.interfaceDetails.size,0,'analysis must not mutate input data');
 assert.equal(links(I.buildBoard(I.analyze([first,second,device(B,A,'1000')])))[0].text,'1 Gb/s');
});

test('only physical connections with both uploaded devices appear, regardless of logical links',()=>{
 const a=device(A,B,'1000'),b=device(B,A,'1000');
 const R=I.analyze([a,b]);
 R.devices.set('EXTERNAL',{name:'EXTERNAL',site:'DEM001',role:'TL',ifs:new Map(),data:null});
 R.phys.push({...R.phys[0],b:{dev:'EXTERNAL',if:'Gi1/0/2'}});
 R.phys.push({...R.phys[0],a:{dev:A,if:'Po10'},b:{dev:B,if:'Po10'}});
 const board=I.buildBoard(R);assert.equal(links(board).length,1);
 assert.ok(speedPage(board).shapes.filter(s=>s.type==='device').every(s=>[A,B].includes(s.text)));
});

test('parallel port-channel cables show their own operating rates, not a total or a Po-only line',()=>{
 const make=(h,peer)=>I.parseDevice(h,`${h}#show running-config\ninterface Gi1/0/1\n channel-group 10 mode active\n description UPLINK: ${peer} Gi1/0/1\n!\ninterface Te1/0/2\n channel-group 10 mode active\n description UPLINK: ${peer} Te1/0/2\n!\n${h}#show cdp neighbors detail\nDevice ID: ${peer}\nInterface: Gi1/0/1, Port ID (outgoing port): Gi1/0/1\nDevice ID: ${peer}\nInterface: Te1/0/2, Port ID (outgoing port): Te1/0/2\n${h}#show interfaces status\n${table('Gi1/0/1','a-1000')}\nTe1/0/2 second member connected trunk full 10G 10GBase-SR\n`);
 const cs=links(build(make(A,B),make(B,A)).board);assert.equal(cs.length,2);
 assert.deepEqual(cs.map(c=>c.text).sort(),['1 Gb/s','10 Gb/s']);
 assert.ok(cs.every(c=>c.foundBy.includes('Port-channel membership: Po10')));
});

test('status-only imports show uploaded nodes without inventing connections',()=>{
 const inputs=[A,B].map(h=>I.parseDevice(h,`${h}#show interfaces status\n${table('Gi1/0/1','1000')}`));
 const board=I.buildBoard(I.analyze(inputs));assert.equal(links(board).length,0);
 assert.equal(speedPage(board).shapes.filter(s=>s.type==='device').length,2);
});
