// Shared helpers: formatting, icons, DOM, API.

export const $ = (s, el = document) => el.querySelector(s);
export const $$ = (s, el = document) => [...el.querySelectorAll(s)];

export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// --------------------------------------------------------------- time
// Timestamps are "wall-clock epochs" (syslog server local time encoded as UTC) - always use UTC getters.
const pad = (n, w = 2) => String(n).padStart(w, '0');
export function fmtTs(ts, ms = false) {
  if (ts == null) return '';
  const d = new Date(ts * 1000);
  const s = `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
  return ms ? `${s}.${pad(d.getUTCMilliseconds(), 3)}` : s;
}
export function fmtTime(ts, ms = false) {
  if (ts == null) return '';
  const d = new Date(ts * 1000);
  const s = `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
  return ms ? `${s}.${pad(d.getUTCMilliseconds(), 3)}` : s;
}
const MON = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
export function fmtShort(ts, now) {
  const d = new Date(ts * 1000), n = new Date((now ?? ts) * 1000);
  const sameDay = d.getUTCDate() === n.getUTCDate() && d.getUTCMonth() === n.getUTCMonth();
  return sameDay ? fmtTime(ts) : `${MON[d.getUTCMonth()]} ${d.getUTCDate()} ${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
}
export function axisLabel(ts, span) {
  const d = new Date(ts * 1000);
  if (span > 3 * 86400) return `${MON[d.getUTCMonth()]} ${d.getUTCDate()}`;
  if (span > 86400) return `${MON[d.getUTCMonth()]} ${d.getUTCDate()} ${pad(d.getUTCHours())}:00`;
  return `${pad(d.getUTCHours())}:${pad(d.getUTCMinutes())}`;
}
export function ago(ts, now) {
  const s = Math.max(0, (now - ts));
  if (s < 60) return `${Math.round(s)}s ago`;
  if (s < 3600) return `${Math.round(s / 60)}m ago`;
  if (s < 86400) return `${(s / 3600).toFixed(1)}h ago`;
  return `${(s / 86400).toFixed(1)}d ago`;
}
export function dur(s) {
  s = Math.abs(s);
  if (s < 60) return `${s.toFixed(s < 10 ? 1 : 0)}s`;
  if (s < 3600) return `${Math.floor(s / 60)}m ${pad(Math.floor(s % 60))}s`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ${pad(Math.floor(s % 3600 / 60))}m`;
  return `${(s / 86400).toFixed(1)}d`;
}
export const n = v => (v ?? 0).toLocaleString('en-US');
export function compact(v) {
  v = v ?? 0;
  if (v >= 1e6) return (v / 1e6).toFixed(1) + 'M';
  if (v >= 1e4) return Math.round(v / 1e3) + 'k';
  if (v >= 1e3) return (v / 1e3).toFixed(1) + 'k';
  return String(v);
}
export function shortIf(i) {
  if (!i) return '';
  const m = [['TwentyFiveGigE', 'Twe'], ['TwoGigabitEthernet', 'Tw'], ['FiveGigabitEthernet', 'Fi'], ['TenGigabitEthernet', 'Te'],
    ['FortyGigabitEthernet', 'Fo'], ['HundredGigE', 'Hu'], ['GigabitEthernet', 'Gi'], ['FastEthernet', 'Fa'], ['Ethernet', 'Eth'],
    ['Port-channel', 'Po'], ['Serial', 'Se'], ['Vlan', 'Vl']];
  for (const [a, b] of m) if (i.startsWith(a)) return b + i.slice(a.length);
  return i;
}

// --------------------------------------------------------------- API
export async function api(path, opts = {}) {
  const r = await fetch(path, opts);
  if (!r.ok) {
    let msg = r.statusText;
    try { msg = (await r.json()).detail || msg; } catch (e) { /* not json */ }
    throw new Error(`${r.status} ${msg}`);
  }
  return r.json();
}
export function qs(obj) {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(obj)) if (v !== undefined && v !== null && v !== '') p.set(k, v);
  return p.toString();
}

// --------------------------------------------------------------- icons
const P = {
  route: '<circle cx="6" cy="19" r="2.5"/><circle cx="18" cy="5" r="2.5"/><path d="M8.5 19H16a3.5 3.5 0 0 0 0-7H8a3.5 3.5 0 0 1 0-7h7.5"/>',
  link: '<path d="M10 13a5 5 0 0 0 7.07 0l3-3a5 5 0 0 0-7.07-7.07l-1.5 1.5"/><path d="M14 11a5 5 0 0 0-7.07 0l-3 3a5 5 0 0 0 7.07 7.07l1.5-1.5"/>',
  plug: '<path d="M9 2v6M15 2v6M6 8h12v4a6 6 0 0 1-12 0V8zM12 18v4"/>',
  alert: '<path d="M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/><path d="M12 9v4M12 17h.01"/>',
  bolt: '<path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/>',
  chip: '<rect x="5" y="5" width="14" height="14" rx="2"/><rect x="9" y="9" width="6" height="6"/><path d="M9 1v4M15 1v4M9 19v4M15 19v4M1 9h4M1 15h4M19 9h4M19 15h4"/>',
  shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',
  network: '<rect x="9" y="2" width="6" height="6" rx="1"/><rect x="2" y="16" width="6" height="6" rx="1"/><rect x="16" y="16" width="6" height="6" rx="1"/><path d="M5 16v-3h14v3M12 8v5"/>',
  laser: '<circle cx="12" cy="12" r="3"/><path d="M12 2v4M12 18v4M4.9 4.9l2.8 2.8M16.3 16.3l2.8 2.8M2 12h4M18 12h4M4.9 19.1l2.8-2.8M16.3 7.7l2.8-2.8"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1A1.7 1.7 0 0 0 9 19.4a1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1A1.7 1.7 0 0 0 4.6 9a1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  help: '<circle cx="12" cy="12" r="10"/><path d="M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3M12 17h.01"/>',
  home: '<path d="M3 10.5 12 3l9 7.5V20a1 1 0 0 1-1 1h-5v-6h-6v6H4a1 1 0 0 1-1-1z"/>',
  target: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="6"/><circle cx="12" cy="12" r="2"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/>',
  server: '<rect x="2" y="3" width="20" height="8" rx="2"/><rect x="2" y="13" width="20" height="8" rx="2"/><path d="M6 7h.01M6 17h.01"/>',
  terminal: '<path d="m4 17 6-6-6-6M12 19h8"/>',
  archive: '<rect x="2" y="3" width="20" height="5" rx="1"/><path d="M4 8v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8M10 12h4"/>',
  sliders: '<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>',
  moon: '<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  copy: '<rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>',
  clock: '<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
  download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M7 10l5 5 5-5M12 15V3"/>',
  pause: '<rect x="6" y="4" width="4" height="16"/><rect x="14" y="4" width="4" height="16"/>',
  play: '<path d="m5 3 14 9-14 9V3z"/>',
  zap: '<path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/>',
  git: '<circle cx="18" cy="18" r="3"/><circle cx="6" cy="6" r="3"/><path d="M6 21V9a9 9 0 0 0 9 9"/>',
  repeat: '<path d="m17 1 4 4-4 4"/><path d="M3 11V9a4 4 0 0 1 4-4h14M7 23l-4-4 4-4"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/>',
  arrow: '<path d="M5 12h14M12 5l7 7-7 7"/>',
  info: '<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
  check: '<path d="M20 6 9 17l-5-5"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/>',
  layers: '<path d="m12 2 10 5-10 5L2 7l10-5z"/><path d="m2 17 10 5 10-5M2 12l10 5 10-5"/>',
  filter: '<path d="M22 3H2l8 9.5V19l4 2v-8.5L22 3z"/>',
  refresh: '<path d="M23 4v6h-6M1 20v-6h6"/><path d="M3.5 9a9 9 0 0 1 14.9-3.4L23 10M1 14l4.6 4.4A9 9 0 0 0 20.5 15"/>',
};
export function icon(name, cls = '') {
  return `<svg class="i ${cls}" viewBox="0 0 24 24" aria-hidden="true">${P[name] || P.help}</svg>`;
}

// --------------------------------------------------------------- small components
export const SEV_ORDER = ['info', 'low', 'warning', 'major', 'critical'];
export function sevBadge(sev, label) {
  return `<span class="sev ${esc(sev)}">${esc(label || sev)}</span>`;
}
export function sigDot(sig) { return `<span class="sigdot ${esc(sig)}" title="${esc(sig)}"></span>`; }
export function healthColor(score) {
  if (score >= 90) return 'var(--s-good)';
  if (score >= 70) return 'var(--s-warning)';
  if (score >= 45) return 'var(--s-major)';
  return 'var(--s-critical)';
}
export function copyText(t) {
  try { navigator.clipboard.writeText(t); } catch (e) {
    const ta = document.createElement('textarea'); ta.value = t; document.body.appendChild(ta); ta.select();
    document.execCommand('copy'); ta.remove();
  }
  toast({ title: 'Copied to clipboard', msg: t.slice(0, 120), sev: 'info' }, 1800);
}
export function toast({ title, msg, sev = 'major', onClick }, ms = 7000) {
  const box = document.getElementById('toasts');
  const el = document.createElement('div');
  el.className = `toast ${sev}`;
  el.innerHTML = `<div class="tt">${sev === 'info' ? '' : sevBadge(sev)} ${esc(title)}</div>${msg ? `<div class="tm">${esc(msg)}</div>` : ''}`;
  el.onclick = () => { onClick && onClick(); el.remove(); };
  box.appendChild(el);
  while (box.children.length > 4) box.firstChild.remove();
  setTimeout(() => el.remove(), ms);
}

// Highlight entities inside a syslog message and make them clickable (data-pivot).
const RE_ENT = /\b((?:TwentyFiveGigE|TwoGigabitEthernet|FiveGigabitEthernet|TenGigabitEthernet|FortyGigabitEthernet|HundredGigE|GigabitEthernet|FastEthernet|Ethernet|Port-channel|port-channel|Serial|Vlan|Twe|Tw|Te|Gi|Fo|Hu|Eth|Po|Se)\d+(?:\/\d+)*(?::\d+)?)\b|\b([0-9a-f]{4}\.[0-9a-f]{4}\.[0-9a-f]{4})\b|\b(\d{1,3}(?:\.\d{1,3}){3})\b|\b(changed state to (?:down|administratively down)|is down|went DOWN|to DOWN| Down\b|PD removed)|\b(changed state to up|is up|to FULL| Up\b|went FULL)/g;
export function hlMsg(msg, host) {
  return esc(msg).replace(RE_ENT, (m, ifc, mac, ip, dn, up) => {
    if (ifc) return `<span class="hl-if" data-pivot="iface" data-host="${esc(host || '')}" data-v="${esc(ifc)}">${ifc}</span>`;
    if (mac) return `<span class="hl-mac" data-pivot="mac" data-v="${mac}">${mac}</span>`;
    if (ip) return `<span class="hl-ip" data-pivot="ip" data-v="${ip}">${ip}</span>`;
    if (dn) return `<span class="hl-down">${dn}</span>`;
    if (up) return `<span class="hl-up">${up}</span>`;
    return m;
  });
}

export function loading(msg = 'Loading') {
  return `<div class="loading"><div class="spin"></div>${esc(msg)}…</div>`;
}
export function emptyState(msg, ic = 'check') {
  return `<div class="empty">${icon(ic)}<div>${esc(msg)}</div></div>`;
}
