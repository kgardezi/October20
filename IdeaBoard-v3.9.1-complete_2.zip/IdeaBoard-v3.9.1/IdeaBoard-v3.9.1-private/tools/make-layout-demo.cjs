// A dense synthetic site with two transport routers, two cores and six dual-homed access switches.
const fs=require('node:fs'),path=require('node:path'),I=require('../js/importer-engine.js'),V=require('../js/visio-export.js');
const root=path.resolve(__dirname,'..'),records=new Map(),tl=['EDEM010TL0101','EDEM010TL0102'],cl=['EDEM010CL0101','EDEM010CL0102'],access=Array.from({length:6},(_,i)=>'EDEM010AS01'+String(i+1).padStart(2,'0')),remote=['UDEM900TL0101','UDEM900TL0102'];
const rec=n=>{if(!records.has(n))records.set(n,{cfg:`hostname ${n}\n`,cdp:[],rates:[]});return records.get(n);};
function cable(a,pa,b,pb,{rate='1000',description='',po}={}){
 for(const [host,port,peer,far] of [[a,pa,b,pb],[b,pb,a,pa]]){
  const r=rec(host);r.cfg+=`interface ${port}\n description ${description||'UPLINK: '+peer+' '+far}\n${po?' channel-group '+po+' mode active\n':''} switchport mode trunk\n!\n`;
  r.cdp.push(`Device ID: ${peer}\nInterface: ${port}, Port ID (outgoing port): ${far}\n`);r.rates.push(`${port} synthetic connected trunk full ${rate} fiber`);
 }
}
for(let i=0;i<2;i++){
 cable(tl[i],'Gi0/0/8',cl[i],'Twe1/0/12');
 for(let j=0;j<6;j++)cable(cl[i],'Te1/0/'+(j+1),access[j],'Te1/0/'+(i+1),{rate:'10G'});
 cable(tl[i],'Te0/0/26',remote[i],'Te0/0/26',{rate:'10G',description:`CIRCUIT: Example carrier ID DEMO-${i+1} 2G to ${remote[i]} Te0/0/26`});
}
cable(tl[0],'Gi0/0/10',tl[1],'Gi0/0/10');
for(let i=0;i<2;i++)cable(cl[0],'Te1/0/'+(47+i),cl[1],'Te1/0/'+(47+i),{rate:'10G',po:1});
const sessions=[...records].map(([host,r])=>[host+'.synthetic.log',`${host}#show running-config\n${r.cfg}${host}#show cdp neighbors detail\n${r.cdp.join('\n-------------------------\n')}${host}#show interfaces status\nPort Name Status Vlan Duplex Speed Type\n${r.rates.join('\n')}\n`]);
const R=I.analyze(sessions.map(([name,text])=>I.parseDevice(name,text)),{sites:I.parseSites('DEM010 = Layered example campus\nDEM900 = Example DC')});
const board=I.buildBoard(R,{title:'Layered layout example',appearance:'sketch',dataCenterSites:['DEM900']});
fs.writeFileSync(path.join(root,'Layered-layout-demo.ideaboard.json'),JSON.stringify(board,null,2));
fs.writeFileSync(path.join(root,'samples','Layered-layout-outputs.zip'),V.zip(sessions));
console.log(`Layered example: ${records.size} devices, ${R.phys.length} cables, six centered access switches.`);
