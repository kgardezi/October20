# Idea Board 3.8.0 — team server

The same Idea Board app, served from one Linux server so your team can share boards.

| | Team server | Personal (the HTML file) |
|---|---|---|
| Boards stored | on the server | in each person's browser |
| Team boards, edited live together | yes | — |
| Private boards (listed only for their owner) | yes | yes |
| Live cursors, shared laser pointer, who's online | yes | — |
| Internet needed | no | no |

The app switches to team mode by itself when this server serves it. `index.html` in this folder is the private single-file build; nothing else needs to be copied.

## Docker

```bash
cd IdeaBoard-v3.8.0-team-server
docker compose up -d --build
# open http://<server-name-or-ip>:8080
```

Air-gapped server: build where Docker can pull `node:22-alpine`, then copy the image across.

```bash
docker compose build && docker save idea-board:latest | gzip > idea-board-image.tgz
# on the server:
gunzip -c idea-board-image.tgz | docker load && docker compose up -d
```

Stop with `docker compose down`; update by copying the new folder and running `docker compose up -d --build` again. Boards stay in the `ideaboard-data` volume.

## Without Docker (systemd)

Needs Node.js 18 or newer (`node --version`). No npm packages and no internet access.

```bash
sudo ./install.sh                 # install or update, http://<server>:8080
sudo ./install.sh --port 9090     # another port
sudo ./install.sh --uninstall     # remove the service; boards are kept
```

It installs to `/opt/idea-board`, keeps boards in `/var/lib/idea-board`, runs as an unprivileged `ideaboard` user, and opens the port in firewalld/ufw. Logs: `journalctl -u idea-board -f`. To try it without installing: `node server/server.js` (boards go to `server/data`).

HTTPS or a friendly URL: put it behind nginx with `nginx-reverse-proxy.conf`. The WebSocket upgrade headers in that file are required for live editing.

## Using it

- Everyone types their name once (remembered on their computer; the avatar at the top left changes it).
- Boards button: **+ Team board** (everyone can open and edit it live) or **+ Private board** (listed only for you). Owners can switch a board between team and private.
- Every change is sent item by item; if two people change the same item at the same moment, the last change wins. Undo only undoes your own changes.
- If the connection drops, the dot by your avatar turns red; keep working and your changes are sent when it reconnects.

## Backups

- `index.json`: the board list (owner, team/private, last edit).
- `boards/<id>.json`: one file per board. Deleted boards are renamed `…deleted-<time>.json`, so they can be recovered.

```bash
docker compose cp idea-board:/data ./ideaboard-backup-$(date +%F)     # Docker
sudo tar czf ideaboard-$(date +%F).tgz -C /var/lib idea-board          # systemd
```

## Security

Meant for a trusted internal network: there are no passwords, and people are identified by the name they type. Private boards are hidden from other people's lists, but anyone who types the same name, or knows a board's ID, could open one. Only the owner can delete a board or change its sharing. Device sessions imported into the app are parsed in each person's browser; generated boards (device names, addresses, labels) are stored on the server like any other board.
