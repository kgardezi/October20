const {test} = require('node:test');
const assert = require('node:assert/strict');
const I = require('../js/importer-engine.js');

const A='EDEM001CL0101', B='EDEM002CL0101', T='EDEM001TL0101';
const cfg = (host, body, extras='') => I.parseDevice(host,`${host}#show running-config\n${body}\n${extras}`);
const page = (board,name) => board.pages.find(p=>p.name===name);
const connectors = p => p.shapes.filter(s=>s.type==='connector');
function routedPair({vrfs=['default'],observed=false,reverse=true,suffix='5'}={}){
  return [A,B].map((host,side)=>{
    let text='', neighbors=[],brief=[];
    vrfs.forEach((vrf,i)=>{
      const intf=`Gi1/0/${i+1}.${suffix}`, ip=`192.0.2.${i*2+side}`, peer=`192.0.2.${i*2+1-side}`;
      text+=`interface ${intf}\n${vrf==='default'?'':` vrf forwarding ${vrf}\n`} ip address ${ip} 255.255.255.254\n ip ospf ${i+1} area 0\n ip ospf cost ${observed?99:side?20:10}\n!\n`;
      text+=`router ospf ${i+1}${vrf==='default'?'':` vrf ${vrf}`}\n router-id 198.51.100.${side+1}\n!\n`;
      if(side===0||reverse)neighbors.push(`${host}#show ip ospf ${i+1} neighbor${vrf==='default'?'':` vrf ${vrf}`}\n198.51.100.${2-side} 1 FULL/DR 00:00:30 ${peer} ${intf}\n`);
      if(observed)brief.push(`${host}#show ip ospf ${i+1} interface brief${vrf==='default'?'':` vrf ${vrf}`}\nInterface PID Area IP Address/Mask Cost State Nbrs F/C\n${intf} ${i+1} 0 ${ip}/31 ${side?20:10} P2P 1/1\n`);
    });
    return cfg(host,text,neighbors.join('')+brief.join(''));
  });
}

test('filename identity takes precedence and accepts arbitrary suffixes',()=>{
  for(const suffix of ['', '.20261015.120000','_20261015','-20261015','20261015','.anything','.csv']){
    const parsed=I.parseDevice(A+suffix,`${B}#show running-config\nhostname ${B}\ninterface Gi1/0/1\n description PW:\n`);
    assert.equal(parsed.name,A,suffix);
    assert.equal(parsed.prompt,B);
    assert.ok(I.analyze([parsed]).problems.some(p=>p.msg.includes('config of')));
  }
});

test('collector sessions, multiple config sections and masking',()=>{
  const raw=`Running command show running-config | section interface on the ${A}\n${'-'.repeat(70)}\ninterface Gi1/0/1\n description PW:\n ip address 192.0.2.0 255.255.255.254\n ip ospf 1 area 0\n!\nRunning command show running-config | section router ospf on the ${A}\nrouter ospf 1\n router-id 198.51.100.1\n!\n password 7 never-store-this\nsnmp-server community never-store-community RO\n`;
  const parsed=I.parseDevice(A,raw);
  assert.equal(parsed.name,A);assert.equal(parsed.run.ospf.length,1);
  assert.ok(parsed.run.ifs.get('gi1/0/1').ospf.enabled);
  assert.ok(parsed.secretsRemoved>=2);
  const board=I.buildBoard(I.analyze([parsed]));
  assert.ok(!JSON.stringify(board).includes('never-store'));
});

test('duplicate files merge config sections, observations and explicit shutdown changes',()=>{
  const first=cfg(A,'interface Gi1/0/1\n ip address 192.0.2.0 255.255.255.254\n shutdown\n!');
  const second=cfg(A,'interface Gi1/0/1\n description UPLINK: '+T+' Gi1/0/1\n no shutdown\n!\nrouter ospf 1\n network 192.0.2.0 0.0.0.1 area 0\n!');
  I.mergeDevices(first,second);
  const intf=first.run.ifs.get('gi1/0/1');
  assert.equal(intf.ips.length,1);assert.equal(intf.shut,false);assert.ok(intf.desc);assert.ok(intf.ospf.enabled);
  const r=I.analyze([first,second]);assert.ok(!r.problems.some(p=>p.msg.startsWith('Two files')));
});

test('NX-OS OSPF commands and per-VRF output retain cost and VRF',()=>{
  const p=cfg(A,'interface Ethernet1/1\n vrf member BLUE\n ip address 192.0.2.0/31\n ip router ospf 1 area 0\n!',
    `${A}#show ospf neighbors vrf all\nOSPF Process ID 1 VRF BLUE\n198.51.100.2 FULL/DR 00:00:30 192.0.2.1 Eth1/1\n${A}#show ospf interface brief vrf all\nOSPF Process ID 1 VRF BLUE\nInterface ID Area Cost State Neighbors Status\nEth1/1 1 0.0.0.0 10 P2P 1 up\n`);
  assert.equal(p.ospfNbr.length,1);assert.equal(p.ospfNbr[0].vrf,'BLUE');
  assert.equal(p.ospfInterfaces[0].cost,10);assert.equal(p.run.ifs.get('eth1/1').vrf,'BLUE');
  assert.equal(I.ospfRecords(I.analyze([p]),{vrf:'BLUE'}).records[0].localCost,10);
});

test('LLDP wins over CDP, subnet and stale descriptions',()=>{
  const C='EDEM001CL0102',D='EDEM001CL0103';
  const a=cfg(A,`interface Gi1/0/1\n description UPLINK: ${D} Gi1/0/1\n ip address 192.0.2.0 255.255.255.254\n!`,
    `${A}#show cdp neighbors detail\nDevice ID: ${C}\nInterface: GigabitEthernet1/0/1, Port ID (outgoing port): GigabitEthernet1/0/1\n${A}#show lldp neighbors detail\nLocal Intf: Gi1/0/1\nPort id: Gi1/0/1\nSystem Name: ${T}\n`);
  const r=I.analyze([a,cfg(C,'interface Gi1/0/1\n ip address 192.0.2.1 255.255.255.254\n!')]);
  assert.ok(r.phys.some(l=>l.a.dev===A&&l.b.dev===T&&l.srcs.has('lldp')));
  assert.equal(r.phys.filter(l=>[l.a.dev,l.b.dev].includes(A)).length,1,'weaker reciprocal /31 must not produce a phantom cable');
  assert.ok(r.problems.some(p=>p.msg.includes('description looks out of date')));
});

test('PW/PWIRE, empty attachment and Ten/Twe interface identity remain supported',()=>{
  for(const label of ['PW:','PWIRE:']){assert.equal(I.parseDesc(label).kind,'pwire');assert.ok(I.parseDesc(label).empty);}
  assert.equal(I.parseDesc('PW-MGMT').kind,'other');
  const p=I.parseDevice(A,`${A}#show cdp neighbors\nDevice ID Local Intrfce Holdtme Capability Platform Port ID\n${T} Ten 1/0/4 120 R S C9500 Twe1/0/4\n`);
  assert.ok(p.cmds.has('cdp'));
  const a=cfg(A,'interface TwentyFiveGigE1/0/4\n description UPLINK: '+T+' Twe1/0/4\n!',
    `${A}#show cdp neighbors\nDevice ID Local Intrfce Holdtme Capability Platform Port ID\n${T} Ten 1/0/4 120 R S C9500 Twe1/0/4\n`);
  const r=I.analyze([a,cfg(T,'interface TwentyFiveGigE1/0/4\n description UPLINK: '+A+' Twe1/0/4\n!')]);
  assert.equal(r.phys.length,1);assert.equal(r.phys[0].a.if,'Twe1/0/4');assert.equal(r.phys[0].speed,'25G');
});

test('global table is the default; all VRFs aggregate seven adjacencies without double counting',()=>{
  const vrfs=['default','RED','BLUE','GREEN','GOLD','WHITE','BLACK'];
  const r=I.analyze(routedPair({vrfs}));
  assert.equal(I.ospfRecords(r).records.length,1);
  assert.equal(I.ospfRecords(r,{vrf:''}).records.length,7);
  const board=I.buildBoard(r,{vrf:''});
  const c=connectors(page(board,'OSPF · DEM001'));
  assert.equal(c.length,1);assert.equal(c[0].adjacencies.length,7);assert.match(c[0].text,/OSPF ×7/);
  assert.match(c[0].foundBy,/VRF: RED/);
  assert.equal(connectors(page(board,'OSPF overview')).length,1);
});

test('OSPF labels use observed costs ahead of config; costs can be hidden',()=>{
  const r=I.analyze(routedPair({observed:true}));
  const result=I.ospfRecords(r);assert.equal(result.records[0].cost,'cost 10 / 20');
  assert.ok(result.problems.some(p=>p.msg.includes('cost 10 / 20')));
  const shown=I.buildBoard(r),hidden=I.buildBoard(r,{showCosts:false});
  assert.ok(connectors(page(shown,'L3')).some(c=>c.text.includes('cost 10 / 20')));
  for(const p of hidden.pages.filter(p=>p.name.startsWith('OSPF')||p.name==='L3'))
    for(const c of connectors(p))assert.ok(!c.text.includes('cost '));
  assert.match(connectors(page(hidden,'OSPF overview'))[0].foundBy,/cost 10 \/ 20/);
});

test('only known cost is labelled with its local port',()=>{
  const parsed=routedPair({reverse:false});
  for(const i of parsed[1].run.ifs.values())i.ospf.cost=null;
  const rec=I.ospfRecords(I.analyze(parsed)).records[0];assert.match(rec.cost,/cost 10 \(Gi1\/0\/1.5\)/);
});

test('router IDs resolve from inventory, manual mappings, and unknowns group per site',()=>{
  const p=I.parseDevice(A,`${A}#show ip ospf neighbor\n198.51.100.2 1 FULL/DR 00:00:30 192.0.2.1 Gi1/0/1\n198.51.100.3 1 FULL/DR 00:00:30 192.0.2.3 Gi1/0/2\n`);
  const inventory=new Map([[B,{name:B,ip:'198.51.100.2',vendor:'',model:''}]]);
  const r=I.analyze([p],{inventory});
  assert.equal(I.ospfRecords(r).records[0].peer,B);
  assert.ok(r.problems.some(p=>p.msg.includes('Unknown peer 198.51.100.3')));
  const noInv=I.buildBoard(I.analyze([p]));
  const boxes=page(noInv,'OSPF · DEM001').shapes.filter(s=>s.text.startsWith('Unresolved peers'));
  assert.equal(boxes.length,1);assert.match(boxes[0].info,/198.51.100.2/);assert.match(boxes[0].info,/198.51.100.3/);
  const routerMap=I.parseRouterMap('198.51.100.3 = EDEM003TL0101');
  const mapped=I.analyze([p],{inventory,routerMap});
  assert.ok(I.ospfRecords(mapped,{routerMap}).records.every(r=>r.peer));
  assert.throws(()=>I.parseRouterMap('999.1.1.1 = TEST'));
  assert.throws(()=>I.parseRouterMap('198.51.100.2 = A\n198.51.100.2 = B'));
});

test('nonbaseline subinterfaces are hidden; custom suffix selects them',()=>{
  const parsed=routedPair({suffix:'100'});
  const r=I.analyze(parsed);assert.equal(I.ospfRecords(r).records.length,0);
  assert.equal(I.ospfRecords(r,{baseline:'100'}).records.length,1);
});

test('four role rows, foreign/DC top band, and no-file same-country sides',()=>{
  const roles=['TL','CL','DL','AG','ML','AS','SF','VG','ACS'];
  const inputs=roles.map(role=>cfg('EDEM001'+role+'0101','interface Gi1/0/1\n description PW:\n!'));
  inputs.push(cfg('UDEM900TL0101','interface Gi1/0/1\n description PW:\n!'));
  const missing='EDEM003TL0101',inventory=new Map([[missing,{name:missing,ip:'198.51.100.30',vendor:'',model:''}]]);
  const r=I.analyze(inputs,{inventory});
  // Connect a missing peer so it is represented at the side.
  r.phys.push({a:{dev:T,if:'Gi1/0/2'},b:{dev:missing,if:'Gi1/0/1'},srcs:new Set(['desc']),extras:[],state:'unknown'});
  const p=page(I.buildBoard(r),'L1/L2'),devs=p.shapes.filter(s=>s.type==='device');
  const y=role=>devs.find(s=>s.text==='EDEM001'+role+'0101').y;
  assert.ok(y('TL')<y('CL')&&y('CL')<y('AG')&&y('AG')<y('AS'));
  assert.equal(y('CL'),y('DL'));assert.equal(y('AG'),y('ML'));assert.notEqual(y('AS'),y('ACS'));const access=devs.filter(s=>['AS','SF','VG','ACS'].includes(s.role));assert.equal(new Set(access.map(s=>s.x)).size,1);assert.equal(new Set(access.map(s=>s.y)).size,access.length);
  assert.ok(devs.find(s=>s.text==='UDEM900TL0101').y<y('TL'));
  assert.ok(devs.find(s=>s.text===missing).x<0);
  for(const c of connectors(p)){const ids=new Set(p.shapes.map(s=>s.id));assert.ok(ids.has(c.start.id)&&ids.has(c.end.id));}
});

test('whole-network L3 retains foreign-to-foreign links and per-site peers sit above',()=>{
  const parsed=routedPair().map(p=>{p.name=p.name.replace(/^E/,'U');return p;});
  const home=cfg(T,'interface Gi1/0/1\n description PW:\n!');
  const r=I.analyze([home,...parsed]);
  const board=I.buildBoard(r);
  assert.ok(connectors(page(board,'L3')).length);
  const site=page(board,'OSPF · DEM001');
  // A site page exists for each loaded site and every coordinate is finite.
  assert.ok(site);for(const p of board.pages)for(const s of p.shapes)assert.ok(Number.isFinite(s.x)&&Number.isFinite(s.y));
});

test('CDP through a PW stays logical; LLDP cable to the TL is a teal pipe',()=>{
  const remoteTL='EDEM002TL0101';
  const a=cfg(A,`interface Gi1/0/1\n description UPLINK: ${T} Gi0/0/1\n!`,
    `${A}#show cdp neighbors detail\nDevice ID: ${B}\nInterface: GigabitEthernet1/0/1, Port ID (outgoing port): GigabitEthernet1/0/1\n${A}#show lldp neighbors detail\nLocal Intf: Gi1/0/1\nPort id: Gi0/0/1\nSystem Name: ${T}\n`);
  const tl=cfg(T,`interface Gi0/0/1\n description PW: ${A} Gi1/0/1 via ${remoteTL} Gi0/0/1 to ${B} Gi1/0/1\n xconnect 198.51.100.12 100 encapsulation mpls\n!`);
  const inventory=new Map([[remoteTL,{name:remoteTL,ip:'198.51.100.12',vendor:'',model:''}]]);
  const r=I.analyze([a,tl,cfg(B,'interface Gi1/0/1\n description PW:\n!')],{inventory});
  assert.ok(r.phys.some(l=>[l.a.dev,l.b.dev].includes(A)&&[l.a.dev,l.b.dev].includes(T)&&l.pw));
  assert.ok(!r.phys.some(l=>[l.a.dev,l.b.dev].includes(A)&&[l.a.dev,l.b.dev].includes(B)));
  assert.ok(connectors(page(I.buildBoard(r),'L1/L2')).some(c=>c.pipe==='on'&&c.pipeColor==='teal'));
});

test('a selected OSPF adjacency can be excluded without hiding its review checkbox',()=>{
  const r=I.analyze(routedPair());const record=r.ospfReview.records[0];
  assert.equal(I.ospfRecords(r,{excluded:['ospf:'+record.key]}).records.length,0);
  assert.equal(connectors(page(I.buildBoard(r,{excluded:['ospf:'+record.key]}),'OSPF overview')).length,0);
  const again=I.analyze(routedPair(),{excluded:['ospf:'+record.key]});assert.equal(again.ospfReview.records.length,1);
});

test('carrier circuits include ID and bandwidth; down and shut styling takes precedence',()=>{
  const parsed=cfg(T,'interface Te0/0/1\n description CIRCUIT: Example carrier Cir ID DEMO-100 10G\n!',
    `${T}#show interfaces description\nInterface Status Protocol Description\nTe0/0/1 down down CIRCUIT: Example carrier Cir ID DEMO-100 10G\n`);
  const r=I.analyze([parsed]);const c=connectors(page(I.buildBoard(r),'L1/L2'))[0];
  assert.match(c.text,/DEMO-100/);assert.match(c.text,/10G/);assert.equal(c.color,'grey');assert.equal(c.pipe,undefined);
  parsed.run.ifs.get('te0/0/1').shut=true;
  assert.equal(connectors(page(I.buildBoard(I.analyze([parsed])),'L1/L2')).length,0);
  assert.equal(connectors(page(I.buildBoard(I.analyze([parsed]),{showShut:true}),'L1/L2'))[0].color,'grey');
});

test('inventory and jump-box listing parse, and ambiguous router IDs remain unresolved',()=>{
  assert.equal(I.parseInventory('Host Name,Device IP,Vendor,Model\n'+T+',198.51.100.12,Cisco,ASR920').get(T).model,'ASR920');
  assert.equal(I.parseInventory('1 - '+T+' (198.51.100.12)').get(T).ip,'198.51.100.12');
  const p=I.parseDevice(A,`${A}#show ip ospf neighbor\n198.51.100.12 1 FULL/DR 00:00:30 192.0.2.1 Gi1/0/1\n`);
  const r=I.analyze([p,cfg(T,'interface Loopback0\n ip address 198.51.100.12 255.255.255.255\n!'),cfg('EDEM002TL0101','interface Loopback0\n ip address 198.51.100.12 255.255.255.255\n!')]);
  assert.equal(I.ospfRecords(r).records[0].peer,null);
});

test('saved device positions survive reimport of matching pages',()=>{
  const r=I.analyze(routedPair());const first=I.buildBoard(r);
  const device=page(first,'L3').shapes.find(s=>s.type==='device');device.x=1234;device.y=456;
  const second=I.buildBoard(r,{previousPages:first.pages});
  const moved=page(second,'L3').shapes.find(s=>s.networkKey===device.networkKey);
  assert.equal(moved.x,1234);assert.equal(moved.y,456);
});
