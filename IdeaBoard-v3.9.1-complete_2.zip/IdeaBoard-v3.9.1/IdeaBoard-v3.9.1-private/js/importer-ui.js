
/* Guided import UI. Raw sessions are parsed locally and are not saved in the board. */
(function(){
'use strict';
const I=window.IdeaImport;if(!I)return;
const h=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const say=m=>{if(typeof toast==='function')toast(m);};
const SITES_KEY='ideaboard:import:sites:v1',lsGet=k=>{try{return localStorage.getItem(k);}catch(e){return null;}},lsSet=(k,v)=>{try{localStorage.setItem(k,v);}catch(e){}};
async function copy(text,what){try{await navigator.clipboard.writeText(text);say(what+' copied');}catch(e){const t=document.createElement('textarea');t.value=text;document.body.appendChild(t);t.select();try{document.execCommand('copy');say(what+' copied');}catch(_){}t.remove();}}
function download(name,text){const url=URL.createObjectURL(new Blob([text],{type:'text/plain'})),l=document.createElement('a');l.href=url;l.download=name;l.click();setTimeout(()=>URL.revokeObjectURL(url),500);}
const css=document.createElement('style');css.textContent=`
#cfgImport{width:min(1100px,96vw);max-height:92vh;padding:0;border:1px solid var(--border);border-radius:16px;background:var(--panel);color:var(--text)}
#cfgImport[open]{display:flex;flex-direction:column}#cfgImport::backdrop{background:#10203970}
#cfgImport header{padding:20px 24px 12px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between}#cfgImport h2{font-size:20px;margin:0 0 4px}#cfgImport p{line-height:1.5}#cfgImport .ni-muted{font-size:12px;color:var(--muted)}
#cfgImport .ni-steps{display:flex;gap:12px;padding:12px 24px;background:var(--hover);font-size:12px;flex-wrap:wrap}#cfgImport .ni-steps b{color:var(--accent)}
#cfgImport .ni-body{overflow:auto;padding:20px 24px;flex:1}#cfgImport .ni-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}#cfgImport .ni-card{border:1px solid var(--border);border-radius:12px;padding:16px}#cfgImport h3{margin:0 0 10px;font-size:14px}#cfgImport label{display:block;font-weight:600;font-size:12px;margin:12px 0 5px}#cfgImport .field{width:100%;margin:0}#cfgImport textarea{resize:vertical;min-height:90px;font:12px Consolas,monospace}#cfgImport button{cursor:pointer}#cfgImport .ni-btn{padding:8px 13px;background:var(--panel);border:1px solid var(--grid);border-radius:8px;color:var(--text);font:500 12px var(--font)}#cfgImport .ni-btn:hover{background:var(--hover)}#cfgImport .ni-primary{background:var(--accent);color:white;border-color:var(--accent)}#cfgImport button:disabled{opacity:.45;cursor:default}#cfgImport .ni-actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:12px}
#cfgImport .ni-drop{border:1px dashed var(--grid);padding:16px;border-radius:10px;background:var(--hover)}#cfgImport .ni-drop.over{border-color:var(--accent);background:var(--accent-soft)}#cfgImport .ni-foot{border-top:1px solid var(--border);padding:14px 24px;display:flex;justify-content:space-between;gap:12px;align-items:center}#cfgImport .ni-tabs{display:flex;gap:6px;margin:18px 0 10px;flex-wrap:wrap}#cfgImport .ni-tabs button.on{background:var(--accent-soft);color:var(--accent)}#cfgImport table{width:100%;border-collapse:collapse;font-size:12px}#cfgImport td,#cfgImport th{padding:9px 8px;border-bottom:1px solid var(--border);text-align:left;vertical-align:top}#cfgImport th{position:sticky;top:0;background:var(--panel)}#cfgImport .ni-scroll{max-height:30vh;overflow:auto;border:1px solid var(--border);border-radius:10px}#cfgImport .ni-chip{display:inline-block;margin:2px;padding:3px 6px;background:var(--hover);border-radius:5px;font-size:11px}#cfgImport .ni-stats{display:flex;gap:20px;flex-wrap:wrap;padding:14px;background:var(--accent-soft);border-radius:10px;margin-top:18px}#cfgImport .ni-stat b{font-size:22px;display:block}#cfgImport .ni-error{color:var(--danger);white-space:pre-wrap}#cfgImport .ni-check{display:flex;gap:7px;align-items:center;font-weight:400}#cfgImport details{margin-top:14px}#cfgImport summary{cursor:pointer;font-size:12px}#cfgImport code{font-size:11px}#cfgImport .ni-name{width:170px;padding:5px;border:1px solid var(--grid);border-radius:5px;background:var(--panel);color:var(--text)}
@media(max-width:720px){#cfgImport .ni-grid{grid-template-columns:1fr}#cfgImport .ni-body{padding:14px}#cfgImport header{padding:14px}.ni-foot{flex-wrap:wrap}}
`;document.head.appendChild(css);
const dlg=document.createElement('dialog');dlg.id='cfgImport';dlg.setAttribute('aria-labelledby','cfgImportTitle');document.body.appendChild(dlg);
let state=null;
const COLLECTION={
  asr:{name:'ASR 920 (IOS-XE)',physical:['show running-config | section interface','show interfaces description','show interfaces','show ip interface brief','show cdp neighbors detail','show lldp neighbors detail'],ospf:['show running-config | section router ospf','show ip ospf','show ip ospf interface','show ip ospf neighbor'],services:['show xconnect all','show mpls l2transport vc detail','show mpls ldp neighbor'],note:'Use detailed show interfaces for duplex and operating speed. show interfaces status may be unsupported. Add show etherchannel summary if bundles are configured and supported.'},
  catalyst:{name:'Catalyst (IOS-XE)',physical:['show running-config | section interface','show interfaces description','show interfaces status','show ip interface brief','show cdp neighbors detail','show lldp neighbors detail','show etherchannel summary'],ospf:['show running-config | section router ospf','show ip ospf','show ip ospf interface','show ip ospf neighbor'],services:['show xconnect all','show mpls l2transport vc detail'],note:'If the Speed column is missing or nonnumeric, add show interfaces. MPLS/pseudowire commands apply only on supported platforms with these services configured.'},
  nexus:{name:'Nexus 9000 / 3000 (NX-OS)',physical:['show running-config','show interface description','show interface status','show interface','show ip interface brief vrf all','show cdp neighbors detail','show lldp neighbors detail','show port-channel summary'],ospf:['show ospf vrf all','show ospf interface vrf all','show ospf neighbors vrf all'],services:[],note:'Keep interface status Speed values and detailed duplex/speed lines, including Ethernet breakout port names. Retain per-VRF headings. Commands vary by NX-OS release; unsupported output is reported, not treated as a successful collection.'}
};
function collectionGuide(s){
 const key=s.guidePlatform||'asr',c=COLLECTION[key]||COLLECTION.asr;
 return `<details id="collectionGuide"><summary>Collection guide — copy platform commands</summary><label for="niPlatform">Device platform</label><select id="niPlatform" class="field">${Object.entries(COLLECTION).map(([k,v])=>`<option value="${k}" ${key===k?'selected':''}>${h(v.name)}</option>`).join('')}</select><p id="collectionNote" class="ni-muted">${h(c.note)}</p><p>Run these commands yourself or with your approved collector. IdeaBoard reads the saved outputs locally; it does not log into devices.</p>${[['physical','Physical links, operating speeds and L1/L2'],['ospf','OSPF / L3 — where configured'],['services','Pseudowires / MPLS — where configured']].map(([k,label])=>`<label for="collect-${k}">${label}</label><textarea class="field" id="collect-${k}" readonly rows="${Math.max(2,c[k].length)}">${h(c[k].join('\n'))}</textarea><button type="button" class="ni-btn" data-act="copycommands" data-group="${k}">Copy commands</button>`).join('')}<p>One session per device, including command headings and hostname prompts. Numeric operating rates are required for the speed page; configured BW, interface names and media type are not substituted. OSPF costs describe routing, not circuit bandwidth. CIRCUIT, UPLINK, PW and PWIRE descriptions supply connection context.</p></details>`;
}
const PEERS_KEY='ideaboard:import:peers:v1';
const fresh=()=>({parsed:[],result:null,title:'Imported network',sites:lsGet(SITES_KEY)||I.DEFAULT_SITES,baseline:'5',appearance:'clean',countryText:'',dcText:'',site:'',vrf:'default',showCosts:true,routerText:lsGet(PEERS_KEY)||'',showShut:false,preserve:true,paste:'',host:'',tab:'devices',busy:false,error:'',skipped:[],excluded:[],inventory:new Map()});
function keep(){if(!state)return;for(const [id,k]of [['niTitle','title'],['niSites','sites'],['niBaseline','baseline'],['niAppearance','appearance'],['niCountries','countryText'],['niDC','dcText'],['niSite','site'],['niVrf','vrf'],['niPaste','paste'],['niHost','host'],['niPeers','routerText'],['niPlatform','guidePlatform']]){const el=dlg.querySelector('#'+id);if(el)state[k]=el.value;}for(const [id,k]of [['niShut','showShut'],['niPreserve','preserve'],['niSvis','includeSvis'],['niPipes','pipes'],['niCosts','showCosts']]){const el=dlg.querySelector('#'+id);if(el)state[k]=el.checked;}}
function analyze(){
 if(!state)return;
 try{
  state.routerMap=I.parseRouterMap(state.routerText);state.error='';
  state.result=state.parsed.length?I.analyze(state.parsed,{...state,sites:I.parseSites(state.sites),inventory:state.inventory,baseline:/^\d+$/.test(state.baseline)?state.baseline:'5'}):null;
 }catch(error){state.result=null;state.error=error.message;}

 if(state.result&&state.title==='Imported network'){const c=new Map();for(const p of state.parsed){const x=I.parseHost(p.name);if(x)c.set(x.country,(c.get(x.country)||0)+1);}const top=[...c].sort((a,b)=>b[1]-a[1])[0];if(top)state.title=({MEX:'Mexico'}[top[0]]||top[0])+' network';}
 render();
}
function render(){
 if(!state)return;const s=state,R=s.result,devs=R?[...R.devices.values()]:[],sites=[...new Set(devs.map(d=>d.site).filter(Boolean))].sort(),vrfs=[...new Set(['default',...devs.flatMap(d=>[...d.ifs.values()].map(i=>i.vrf||'default')),...devs.flatMap(d=>(d.data?.ospfNbr||[]).map(n=>n.vrf||'default'))])].sort();
 let review='';
 if(R){
  const types=new Map();for(const d of devs)for(const i of d.ifs.values())if(i.pdesc){const t=i.pdesc.kind;types.set(t,(types.get(t)||0)+1);}
  review=`<div class="ni-stats"><div class="ni-stat"><b>${s.parsed.length}</b>device inputs</div><div class="ni-stat"><b>${R.phys.length}</b>physical connections</div><div class="ni-stat"><b>${R.links.length}</b>logical connections</div><div class="ni-stat"><b>${R.problems.length}</b>review notes</div></div>
  <div class="ni-tabs" role="tablist">${[['devices','Devices'],['ports','Descriptions & ports'],['links','Connections'],['problems','Review notes']].map(([k,t])=>`<button class="ni-btn ${s.tab===k?'on':''}" data-tab="${k}" role="tab" aria-selected="${s.tab===k}">${t}</button>`).join('')}</div><div class="ni-scroll">`;
  if(s.tab==='devices')review+=`<table><tr><th>Device name (editable)</th><th>Source</th><th>Role / site</th><th>Recognized outputs</th><th></th></tr>${s.parsed.map((p,i)=>`<tr><td><input class="ni-name" data-name="${i}" aria-label="Device name for ${h(p.file)}" value="${h(p.name)}"></td><td>${h(p.file)}</td><td>${h((I.parseHost(p.name)||{}).role||'Unassigned')}<br>${h((I.parseHost(p.name)||{}).site||'Unknown site')}</td><td>${[...p.cmds].map(c=>`<span class="ni-chip" title="${h(I.CMD_NAMES[c]||c)}">${h(c)}</span>`).join('')}</td><td><button class="ni-btn" data-remove="${i}">Remove</button></td></tr>`).join('')}</table>`;
  else if(s.tab==='ports')review+=`<table><tr><th>Device / port</th><th>Description</th><th>Read as</th><th>Details</th></tr>${devs.filter(d=>d.data).flatMap(d=>[...d.ifs.values()].filter(i=>i.desc||i.chan).map(i=>`<tr><td>${h(d.name)}<br>${h(i.name)}</td><td>${h(i.desc)}</td><td>${h(i.pdesc?.kind==='other'?'Ignored':i.pdesc?.kind||'Unclassified')}</td><td>${h([i.pdesc?.speed,i.chan,i.vrf&&'VRF '+i.vrf,i.pdesc?.empty&&'No far end supplied'].filter(Boolean).join(' · '))}</td></tr>`)).join('')}</table>`;
  else if(s.tab==='links')review+=`<p class="ni-muted" style="padding:0 10px">Uncheck a connection to omit that exact endpoint pair. Physical members and logical bundles are reviewed separately.</p><table><tr><th>Draw</th><th>View</th><th>A end</th><th>B end</th><th>Evidence</th></tr>${[...R.phys.map(l=>[l,'Physical']),...R.links.map(l=>[l,l.kind]),...(R.ospfReview?.records||[]).map(r=>[{...r,a:r.a,b:r.peer?r.b:{...r.b,dev:'Unknown peer '+r.rid},_reviewKey:'ospf:'+r.key,srcs:new Set(['ospf']),confidence:r.state},'OSPF adjacency'])].map(([l,t])=>`<tr><td><input type="checkbox" data-link="${h((l._reviewKey||I.linkKey(l)))}" aria-label="Include ${h(l.a.dev+' '+l.a.if+' to '+(l.b.dev||'unknown'))}" ${s.excluded.includes((l._reviewKey||I.linkKey(l)))?'':'checked'}></td><td>${h(t)}</td><td>${h(l.a.dev)}<br>${h(l.a.if)}</td><td>${h(l.b.dev||'Unresolved far end')}<br>${h(l.b.if)}</td><td>${h([...l.srcs].join(', '))}<br>${h(l.confidence)}</td></tr>`).join('')}</table>`;
  else review+=R.problems.length?`<table><tr><th>Device</th><th>Note</th></tr>${R.problems.map(p=>`<tr><td>${h(p.dev)}</td><td>${h(p.msg)}</td></tr>`).join('')}</table>`:'<p style="padding:10px">No review notes.</p>';
  review+='</div>';
 }
 dlg.innerHTML=`<header><div><h2 id="cfgImportTitle">Import network</h2><div class="ni-muted">Turn device outputs into an editable, multi-page network diagram.</div></div><button class="ibtn" data-act="close" aria-label="Close import">✕</button></header>
 <div class="ni-steps"><b>1 · Add outputs</b><span>2 · Review devices & connections</span><span>3 · Draw the board</span></div>
 <div class="ni-body"><div class="ni-grid"><section class="ni-card"><h3>Add device outputs</h3><div class="ni-drop" id="niDrop"><b>Drop text logs or a ZIP here</b><p class="ni-muted">One device per log (any name, with or without .txt). Keep the command lines or the \"Running command … on the …\" headers with the outputs.</p><div class="ni-actions"><button class="ni-btn" data-act="files" ${s.busy?'disabled':''}>Choose files</button><button class="ni-btn" data-act="folder" ${s.busy?'disabled':''}>Choose folder</button></div></div>
 <label for="niHost">Device name for pasted output</label><input id="niHost" class="field" value="${h(s.host)}" placeholder="Optional if the hostname is in the prompt">
 <label for="niPaste">Paste a device session</label><textarea id="niPaste" class="field" rows="5" placeholder="Paste command names and their outputs here">${h(s.paste)}</textarea><div class="ni-actions"><button class="ni-btn" data-act="paste" ${s.busy?'disabled':''}>Add pasted device</button><button class="ni-btn" data-act="inventory">Optional inventory CSV</button></div>
 </section><section class="ni-card"><h3>Diagram settings</h3><label for="niTitle">Board name</label><input id="niTitle" class="field" value="${h(s.title)}">
 <label for="niAppearance">Diagram appearance</label><select id="niAppearance" class="field"><option value="clean" ${s.appearance==='clean'?'selected':''}>Clean</option><option value="sketch" ${s.appearance==='sketch'?'selected':''}>Hand-drawn</option></select><div class="ni-grid"><div><label for="niSite">Focus site / country</label><select id="niSite" class="field"><option value="">All loaded sites</option>${sites.map(x=>`<option value="${h(x)}" ${s.site===x?'selected':''}>${h(R.sites.get(x)||x)}</option>`).join('')}</select></div><div><label for="niBaseline">Representative OSPF suffix</label><input id="niBaseline" class="field" inputmode="numeric" value="${h(s.baseline)}" placeholder="5"></div></div>
 <label for="niVrf">VRF in Layer 3 and OSPF views</label><select id="niVrf" class="field"><option value="" ${s.vrf===''?'selected':''}>All VRFs (grouped, with counts)</option>${vrfs.map(x=>`<option value="${h(x)}" ${s.vrf===x?'selected':''}>${h(x)}</option>`).join('')}</select>
 <label class="ni-check"><input id="niCosts" type="checkbox" ${s.showCosts!==false?'checked':''}>Show OSPF costs on OSPF and L3 pages</label><label class="ni-check"><input id="niShut" type="checkbox" ${s.showShut?'checked':''}>Include administratively shut connections</label><label class="ni-check"><input id="niPreserve" type="checkbox" ${s.preserve?'checked':''}>Keep device positions from matching current-board pages (turn off to apply the new layout)</label><label class="ni-check"><input id="niSvis" type="checkbox" ${s.includeSvis?'checked':''}>Also include SVI / BDI OSPF neighbors</label><label class="ni-check"><input id="niPipes" type="checkbox" ${s.pipes!==false?'checked':''}>Draw pseudowires as pipes (circuits stay plain yellow)</label>
 <p class="ni-muted">Physical link speeds: an extra management page between uploaded devices, using observed operating rates. Whole-network L1/L2 and L3 pages; an optional site filter keeps that site and its direct peers. Individual port-channel cables. Rows: TL, CL/DL, AG/ML, then AS/SF/VG/ACS/other. Sites sit side by side. Data centers and other countries sit above. Separate WAN, L3, Pseudowires, OSPF overview, OSPF per-site, and Problems pages. OSPF defaults to the global table; counts include only selected sessions. Country grouping defaults to the first hostname letter; override it below when needed.</p>
 <details><summary>OSPF peer mappings (remembered in this browser)</summary><label for="niPeers">One router ID per line: IP = HOSTNAME</label><textarea id="niPeers" class="field" rows="4" placeholder="192.0.2.32 = EDEM001TL0101">${h(s.routerText)}</textarea><p class="ni-muted">Explicit mappings take priority. Otherwise: loopback/process router IDs, inventory IPs, neighbor management IPs, then neighbor interface addresses. Unknown IDs appear together per site and in review notes.</p></details><details><summary>Country and data-center overrides</summary><label for="niCountries">One site per line: SITE = COUNTRY</label><textarea id="niCountries" class="field" rows="3">${h(s.countryText)}</textarea><label for="niDC">Data-center site codes (comma separated)</label><input id="niDC" class="field" value="${h(s.dcText)}" placeholder="SEC800, NWK165"></details><details><summary>Site names (a name containing "DC" puts that site on top as a data centre)</summary><textarea id="niSites" class="field" rows="4" aria-label="Site code to name mappings">${h(s.sites)}</textarea></details></section></div>
 ${collectionGuide(s)}
 ${s.busy?'<p role="status">Reading device outputs…</p>':''}${s.error?`<p class="ni-error" role="alert">${h(s.error)}</p>`:''}${s.skipped.length?`<p class="ni-muted">Skipped: ${s.skipped.map(h).join(', ')}</p>`:''}${review}</div>
 <footer class="ni-foot"><span class="ni-muted">Device outputs are read locally. Generated boards contain diagram data and labels.</span><div class="ni-actions" style="margin:0">${R?'<button class="ni-btn" data-act="debug" title="Hostnames and IPs are replaced; review the summary before sharing">Copy debug summary</button><button class="ni-btn" data-act="report">Save review notes (.txt)</button>':''}<button class="ni-btn" data-act="close">Cancel</button><button class="ni-btn ni-primary" data-act="draw" ${R&&s.parsed.length&&!s.busy?'':'disabled'}>Generate diagrams</button></div></footer>`;
 const drop=dlg.querySelector('#niDrop');drop.addEventListener('dragover',e=>{e.preventDefault();drop.classList.add('over');});drop.addEventListener('dragleave',()=>drop.classList.remove('over'));drop.addEventListener('drop',e=>{e.preventDefault();keep();addFiles([...e.dataTransfer.files]);});
}
function store(name,text,override){
 if(/\u0000/.test(text.slice(0,2000)))throw Error(name+': not a text file.');
 const p=I.parseDevice(name,text);if(override)p.name=override.toUpperCase();
 if(!p.cmds.size)throw Error(name+': no supported command output recognized. Keep the command lines and hostname prompt, or include an interface configuration.');
 // Preserve related outputs when importing separate files for the same device.
 const old=state.parsed.find(x=>x.name===p.name);
 if(old)I.mergeDevices(old,p);else state.parsed.push(p);
}
async function addFiles(files){
 const s=state;if(!s)return;s.busy=true;s.error='';render();
 try{for(const f of files){if(state!==s)return;const deviceNamed=!!I.parseHost(I.parseDevice(f.name,'').fileHost);if(f.size>8e6){s.skipped.push(f.name+' (larger than 8 MB)');continue;}
  if(/\.zip$/i.test(f.name)){
   try{const entries=await IdeaVisio.unzip(new Uint8Array(await f.arrayBuffer()));for(const [n,bytes]of entries){const name=n.split('/').at(-1),device=!!I.parseHost(I.parseDevice(name,'').fileHost);if(/(^|\/)\.|__MACOSX|\/$/.test(n)||(!device&&/\.(zip|png|jpe?g|gif|pdf|xlsx?|docx?|csv|exe|dll)$/i.test(n)))continue;try{store(name,new TextDecoder().decode(bytes));}catch(e){s.skipped.push(e.message);}}}catch(e){try{if(!deviceNamed)throw e;store(f.name,await f.text());}catch(error){s.skipped.push(f.name+': '+error.message);}}
  }else if(!deviceNamed&&(/\.csv$/i.test(f.name)||/inventory/i.test(f.name))){s.inventory=I.parseInventory(await f.text());s.skipped=s.skipped.filter(x=>!x.startsWith(f.name));}
  else if(!deviceNamed&&/\.(png|jpe?g|gif|pdf|xlsx?|docx?|exe|dll|vsdx)$/i.test(f.name))s.skipped.push(f.name+' (use a text log or ZIP)');
  else{try{store(f.name,await f.text());}catch(e){s.skipped.push(e.message);}}   // any text file: .txt/.log or no extension (e.g. HOSTNAME.20261014.155657)
 }}catch(e){s.error=e.message;}finally{if(state===s){s.busy=false;analyze();}}
}
function pick(folder=false,inventory=false){return new Promise(resolve=>{const f=document.createElement('input');f.type='file';f.multiple=!inventory;if(inventory)f.accept='.csv,.txt';if(folder)f.webkitdirectory=true;f.addEventListener('change',()=>resolve([...f.files]));f.addEventListener('cancel',()=>resolve([]));f.click();});}
dlg.addEventListener('click',async e=>{
 const b=e.target.closest('[data-act],[data-tab],[data-remove]');if(!b||!state)return;keep();
 if(b.dataset.tab){state.tab=b.dataset.tab;render();return;}
 if(b.dataset.remove!=null){state.parsed.splice(+b.dataset.remove,1);analyze();return;}
 const action=b.dataset.act;
 if(action==='copycommands'){const t=dlg.querySelector('#collect-'+b.dataset.group);if(t?.value)await copy(t.value,'Collection commands');return;}
 if(action==='close'){dlg.close();return;}
 if(action==='debug'&&state.result){await copy(I.debugSummary(state.result),'Debug summary (no hostnames or IPs)');return;}
 if(action==='report'&&state.result){download((state.title||'import')+' - review notes.txt',state.result.problems.map(p=>`[${p.sev==='warn'?'CHECK':'info'}] ${p.dev}: ${p.msg}`).join('\r\n')||'No review notes.');return;}
 if(action==='files'||action==='folder'){const s=state,files=await pick(action==='folder');if(state===s)await addFiles(files);return;}
 if(action==='inventory'){const s=state,[f]=await pick(false,true);if(f&&state===s){state.inventory=I.parseInventory(await f.text());analyze();}return;}
 if(action==='paste'){
  state.error='';const host=state.host.trim();if(host&&!/^[A-Za-z0-9][A-Za-z0-9_-]{0,62}$/.test(host)){state.error='Use a device name containing letters, numbers, underscores, or hyphens.';render();return;}
  if(!state.paste.trim()){state.error='Paste a device session first.';render();return;}
  try{const p=I.parseDevice((host||'pasted-device')+'.txt',state.paste);if(!host&&!p.prompt&&!p.cfgHost)throw Error('Enter the device name for output without a hostname prompt.');store((host||p.name)+'.txt',state.paste,host||null);state.paste='';state.host='';analyze();}catch(e){state.error=e.message;render();}return;
 }
 if(action==='draw'){
  if(!/^\d+$/.test(state.baseline)){state.error='Enter a numeric baseline suffix, such as 5 or 100.';render();return;}
  const current=typeof pages!=='undefined'?pages:[];
  const siteCountries=Object.fromEntries(state.countryText.split(/\n/).map(l=>/^\s*(\S+)\s*=\s*(.+?)\s*$/.exec(l)).filter(Boolean).map(m=>[m[1].toUpperCase(),m[2]]));
  const dataCenterSites=state.dcText.split(/[,\s]+/).filter(Boolean).map(x=>x.toUpperCase());
  let built;try{built=I.buildBoard(state.result,{...state,routerMap:I.parseRouterMap(state.routerText),siteCountries,dataCenterSites,previousPages:state.preserve?current:[]});}catch(error){state.error=error.message;render();return;}
  const f=new File([JSON.stringify(built)],(state.title||'Network')+'.ideaboard.json',{type:'application/json'});dlg.close();openFile(f);
 }
});
dlg.addEventListener('change',e=>{
 if(!state)return;keep();
 if(e.target.dataset.name!=null){const p=state.parsed[+e.target.dataset.name],n=e.target.value.trim().toUpperCase();if(!/^[A-Z0-9][A-Z0-9_-]{0,62}$/.test(n)||state.parsed.some(x=>x!==p&&x.name===n)){state.error='Use a unique device name with letters, numbers, underscores, or hyphens.';render();return;}p.name=n;state.error='';analyze();}
 else if(e.target.dataset.link!=null){const k=e.target.dataset.link;state.excluded=state.excluded.filter(x=>x!==k);if(!e.target.checked)state.excluded.push(k);render();}
 else if(e.target.id==='niPlatform'){const c=COLLECTION[state.guidePlatform];for(const k of ['physical','ospf','services']){const t=dlg.querySelector('#collect-'+k);t.value=c[k].join('\n');t.rows=Math.max(2,c[k].length);}dlg.querySelector('#collectionNote').textContent=c.note;}
 else if(e.target.id==='niSites'){lsSet(SITES_KEY,state.sites);analyze();}
 else if(e.target.id==='niPeers'){try{I.parseRouterMap(state.routerText);lsSet(PEERS_KEY,state.routerText);}catch(error){}analyze();}
 else if(['niVrf','niSvis','niCosts'].includes(e.target.id))analyze();
 else if(e.target.id==='niBaseline'&&/^\d+$/.test(state.baseline))analyze();
});
dlg.addEventListener('close',()=>state=null);
function open(){if(typeof closeMenu==='function')closeMenu();state=fresh();render();if(!dlg.open)dlg.showModal();}
const menu=document.getElementById('menu');if(menu){const b=document.createElement('button');b.dataset.menu='cfgimport';b.innerHTML='<span>Import network from device files…</span>';const after=menu.querySelector('[data-menu="visioimport"]');if(after)after.after(b);else menu.prepend(b);b.addEventListener('click',e=>{e.stopPropagation();open();});}
window.IdeaImportUI={open};
})();

