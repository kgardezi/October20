# NoteForge Learning Hub → Lantern: assessment, research and delivery notes

Date: 2026-10-19. Everything under "Verified" was read directly from the attached `7777521c-NoteForge_Learning_Hub.html` (890 lines, 268 KB) or observed in automated tests. "Assumptions" are labelled as such.

## 1. Assessment of the original app

### Verified from the code

**Purpose and shape.** A single HTML file with inline CSS (lines 8–297) and inline JS (lines 418–888). It has two separate data models: a *Saved Library* of video links and a *Learning Tracker* of entries. Line 420 is a 193 KB constant `BASE_VIDEOS` containing **1,362 links parsed from a WhatsApp chat export** (dates 2023‑09‑03 to 2026‑09‑20; 1,062 Facebook, 162 TikTok, 86 YouTube, 32 X, 17 other, 3 LinkedIn). 186 have a caption (`n`), 97 carry auto-detected topics (`g`), 18 were shared more than once (`c`).

**Storage.** Four `localStorage` keys: `fiveBlockEntriesV2` (tracker entries), `nfVideosExtraV1` (links added by WhatsApp import), `nfVideosHiddenV1` (hidden URLs), `nfPrefsV1` (view, theme, last backup). The 1,362 base links are **not** in storage at all; they live only inside the HTML. A backup (`version: 6`) contains `entries`, `extraVideos`, `hiddenVideos`, `preferences`, and therefore cannot restore the base library on its own.

**Record schemas.** Video: `{u,p,d,t,n,c,y,g}`. Entry: `{id,date,task,notes,link,status,picture,source?}` with `picture` as a base64 data URL up to 2 MB.

**Dependencies.** No bundled libraries. It references 31 Font Awesome icon classes and the fonts "DM Sans"/"Lora" but **never loads Font Awesome or any webfont**, so every icon renders as an empty box and the fonts fall back to system fonts. External services used on demand: `i.ytimg.com` thumbnails (always, for YouTube cards), TikTok oEmbed (automatically on scroll for every TikTok card), `youtube-nocookie.com`/TikTok/Facebook embed players, `api.microlink.io` and `image.thum.io` for bookmark previews (opt-in), and `cdnjs.cloudflare.com` for JSZip when a ZIP is imported.

**What works and was kept (re-implemented):** the WhatsApp parser logic (two header formats, caption extraction, Facebook boilerplate stripping), the YouTube/TikTok/Facebook embed player with "open original" fallback, ZIP support for WhatsApp exports, bookmark HTML import with folder selection and dates, undo toasts for hide/delete, keyboard focus trap in dialogs, `/` and Ctrl+K search focus, light/dark tokens, reduced-motion support, pagination at 60, sidebar counts.

**Problems found:**

| Area | Finding (verified) | Consequence |
|---|---|---|
| Data loss | `LS.set` fails silently when the 5 MB quota is exceeded: the in-memory array is already mutated, the UI shows the item saved, and it vanishes on reload. Pictures are base64 in the same quota, so two or three 2 MB images can exhaust it. | Real risk of silent loss. |
| Data loss | Restore replaces all entries after a `confirm()`; no copy of the current state is kept. Any single malformed record fails the whole file with the misleading message "not a NoteForge backup". | Unrecoverable mistakes. |
| Data loss | "Clear Tracker" has no undo, no snapshot. Hidden videos can never be un-hidden from the UI. | |
| Model | Two disconnected models. Tracker and library are linked only by *exact* URL string match, so the same YouTube video with a different `?si=` parameter is not recognised. Bookmarks import into the tracker, WhatsApp imports into the library. | Confusing; duplicates. |
| Editing | Library items cannot be edited at all (no title, no tags, no notes); only "Hide" or "+ Track". Topics are regex-only (`TOPICS` table) and not user-editable. | Core knowledge-management loop is missing. |
| Status | `cycleStatus` skips "Blocked"; status pills convey state by colour alone. | |
| Search | Dashboard search, library search and tracker search are three separate code paths with different fields; tags/collections are not searchable from the tracker. | |
| Export | Only the JSON backup. No CSV/Markdown/HTML. | Lock-in. |
| Privacy | TikTok oEmbed and YouTube thumbnail requests fire without consent; the bookmark importer also sends URLs to thum.io as a fallback even when microlink fails. | |
| Accessibility | Icons invisible (font never loaded). Tracker cards are `div`s with click handlers and no keyboard access (library cards were patched later with `tabIndex`). Icon buttons rely on `title` only. Whole card click opens an external tab, including clicks on text. | |
| Performance | Every keystroke re-renders the whole page via `innerHTML` (debounced 160 ms); acceptable at 1.4 k items but the per-card TikTok oEmbed fetch is wasteful. | Minor. |
| Dates | WhatsApp day/month ambiguity resolved by a fixed heuristic with no user override. | Possible wrong dates. |

### Assumptions (not verified)
* The WhatsApp export used day/month/year order (dates like `2023-09-03` are consistent with either). Lantern auto-detects and lets you override.
* The user's real tracker contents are unknown; only the embedded library was available, so NoteForge backup import was tested with a synthetic backup matching the code's exact schema.
* Nothing was tested in the original app's running state in a real browser beyond reading its code.

**Can the current structure support the improvements?** No. The two-model design, string-match linking, per-record localStorage writes, and the absence of a canonical URL key would each need replacing. A rebuild that *imports* NoteForge data losslessly is cheaper and safer than patching.

## 2. Research: what users of similar tools struggle with

Browsing was available. Findings, with documented capability vs. anecdote distinguished:

* **Services disappear; export matters.** Mozilla shut Pocket down on 8 July 2025 and later disabled data export entirely (documented: [Mozilla support: Pocket has shut down](https://support.mozilla.org/en-US/kb/future-of-pocket)). Lesson applied: local-first storage plus four export formats and automatic snapshots.
* **Duplicates and dead links are paid features elsewhere.** Raindrop.io documents a Duplicates filter that keeps originals and skips duplicate URLs on import, with a pre-import summary ([help.raindrop.io/duplicates](https://help.raindrop.io/duplicates), [import](https://help.raindrop.io/import.md)); its broken-link finder and daily backups are Pro-only ([broken-links](https://help.raindrop.io/broken-links.md)). Third-party plan listings ([freetier.co](https://freetier.co/directory/products/raindropio)) are promotional and were not relied on. Lesson applied: duplicate detection on canonical URLs with a preview showing new / existing / repeated / invalid counts, free.
* **"Saved and never returned to" is the dominant complaint.** Anecdotal forum posts ([Tildes thread](https://tildes.net/~tildes/13m/can_we_have_a_save_feature)) and a developer's own motivation for a Reddit saved-post manager ([tryunearth/api](https://github.com/tryunearth/api)) describe saving a lot and never revisiting; the proposed remedies were reminders, tags, filtering and search. Lesson applied: the Review queue (due dates, stalled learning, random rediscovery) and the dashboard "Up next" list.
* **Resurfacing works when it is small and regular.** Readwise's App Store listing documents daily resurfacing of highlights via spaced repetition ([App Store](https://apps.apple.com/us/app/-/id1476885528)); the "5–10 per day" figure comes from reviews, not official docs ([asianefficiency review](https://www.asianefficiency.com/productivity/readwise-reader-review/)). Lesson applied: the queue shows a bounded random sample with a Shuffle button, not the whole backlog.
* **Self-hosted bookmark managers converge on Netscape HTML import/export** (linkding, per [selfhostyourself.com](https://selfhostyourself.com/alternative-to/pocket); Karakeep/Hoarder per its [GitHub mirror](https://github.com/neuroradiology/hoarder)). These are directory pages, not official docs; one directory ([openalternative.co](https://openalternative.co/alternatives/karakeep)) had copy-pasted feature lists and was discounted. Lesson applied: Netscape HTML import and export are supported.
* **The Netscape bookmark format has no formal standard.** Microsoft's archived page is the closest to a spec ([learn.microsoft.com](https://learn.microsoft.com/en-us/previous-versions/windows/internet-explorer/ie-developer/platform-apis/aa753582(v=vs.85)?redirectedfrom=MSDN)); Chromium test fixtures show Firefox exports with `ADD_DATE` in Unix seconds and zero/empty edge cases ([chromium.googlesource.com](https://chromium.googlesource.com/chromium/src/+/913eaefa55beab765aa1d99da170db474d8c63ca/chrome/test/data/bookmark_html_reader/firefox2.html)). Lesson applied: the parser tolerates `ADD_DATE` of 0, milliseconds vs seconds, `DD` descriptions, `TAGS` attributes, nested folders and `javascript:` links.

## 3. Decision: rebuild, importing everything

Improving in place would mean rewriting the model, storage, search and card rendering anyway while keeping the iconless shell. Rebuilding allowed one unified **Resource** model (link or note, with title, description, Markdown notes, tags, collection, favorite, status, priority, review date, saved date, image, archive/trash flags, and a `legacy` block that preserves every original NoteForge field), IndexedDB storage with a localStorage fallback, and a canonical URL key for duplicate detection. For personal use this stays a single HTML file with zero dependencies. The original app's data is imported losslessly (seed, backup JSON, or the original HTML itself).

Terminology is fixed to: Resource, Library, Collection, Tag, Status (Saved → To learn → Learning → Done, plus Blocked), Priority, Review date, Archive, Trash, Backup, Snapshot.

## 4. Enhancement evaluation

| Enhancement | Status | Notes |
|---|---|---|
| Editable titles and descriptions | **Implemented** | Panel edits; autosaves on close, refuses invalid links instead of dropping edits. |
| Manual tags, collections, favorites | **Implemented** | Tag rename/merge/remove across the library; collections as the "goal/course" grouping. Folders from bookmarks are preserved as `folder` and searchable; a separate folder tree was judged unnecessary for one person. |
| Statuses, priorities, review dates | **Implemented** | Five statuses, four priorities, review date with +1w/+1m/+3m. "Goals" are expressed as collections plus priorities rather than a separate entity, to avoid clutter. |
| Markdown notes with plain-text copy | **Implemented** | Safe renderer (no raw HTML), Write/Preview toggle, "Copy as text". Notes are stored as the Markdown you typed, so copy/paste out is lossless. |
| Bulk edit / tag / move / archive / delete with undo | **Implemented** | Multi-select by checkbox, `x`, Shift/Ctrl-click; every bulk action has Undo (also Ctrl+Z). |
| Duplicate detection on equivalent URLs | **Implemented** | Canonical key strips `www/m/mobile`, tracking params (`utm_*`, `si`, `sfnsn`, `mibextid`, `fbclid`, `igshid`, …), trailing slashes; YouTube/TikTok/X/Instagram/Facebook by post id. Warns on save and in imports. |
| Import: browser bookmarks, WhatsApp, old backups | **Implemented** | Format auto-detected; preview before write; day/month override; ZIP handled without a dependency via `DecompressionStream`. |
| Export JSON, Markdown, CSV, bookmark HTML | **Implemented** | |
| Backup/restore with validation and recovery | **Implemented** | Per-record validation with skipped-record list; merge or replace; automatic snapshots (last 6) before imports, restores, trash emptying; snapshot restore and download; trash with 30-day retention. |
| Review queue | **Implemented** | Due, stalled, rediscover (random sample, configurable age). |
| Optional metadata previews with privacy controls | **Implemented (opt-in)** | Off by default. YouTube thumbnails (i.ytimg.com) and page-title fetching (microlink.io, **external free service**, rate-limited, fails gracefully) are separate switches with the destination named. |
| CSV import | **Recommended next** | Easy to add on the existing pipeline; not needed for migration. |
| Automatic broken-link checking | **Requires an external service / proxy** | Browsers cannot read cross-origin status codes reliably; a tiny local script or a service would be needed. Not simulated. |
| AI tagging, summaries, semantic search | **Not implemented; requires an external service or a local model** | For 1.4 k mostly-captionless Facebook/TikTok links there is little text to summarise; the cost and key management are not justified. If wanted later, it belongs as an optional "suggest tags" button calling a user-supplied endpoint. Nothing in the UI pretends to do this. |

## 5. Protecting existing information

* All 1,362 embedded links ship inside `lantern.html` and are loaded only after an explicit choice and a preview. Every original field maps to a Lantern field or to `legacy` (see README table).
* The old app's `localStorage` cannot be read by a different file, browser, folder or domain. The README gives the exact export steps in the old app (*Back Up Everything*) and the import steps in Lantern.
* NoteForge tracker entries that point at a library link are merged into that link (status, title, notes, picture), not duplicated. Hidden links become archived. Preferences are not applied automatically.
* Imports never overwrite: in "merge" mode existing fields are only filled when empty or appended (notes). "Replace" is explicit, snapshots first, and offers Undo.
* Malformed records are skipped individually and listed; invalid files abort with a message and no change.

## 6. Checks actually performed

Automated with Playwright/Chromium against the built file served on localhost, with **every external request blocked** (15/15 passing; `node tests/e2e.test.js`):

1. First run → preview shows 1,362 new → import; dates, times, platforms, share counts, captions and topics verified field-by-field against the seed.
2. Persistence after reload in IndexedDB; welcome not shown again.
3. NoteForge backup import: tracker entry merged into its library link (status Learning, title, notes), hidden link archived, bookmark-style entry with folder, link-less note kept, 3 malformed records listed and skipped, duplicate with a different `?si=` recognised, snapshot taken.
4. Malformed JSON: error dialog, no change.
5. WhatsApp `.txt` (day/month detected, in-file repeat and library duplicate counted, `utm_source` stripped) and Netscape bookmarks `.html` (nested folder, `TAGS`, `DD` description, `ADD_DATE` conversion, `javascript:` link rejected, `www` + trailing slash recognised as duplicate).
6. Quick save duplicate warning (YouTube id with different host and params), create, edit title/tags/status/priority, Markdown preview renders headings and task boxes, persisted across reload.
7. Search: words, `tag:`, `status:`, notes content, `site:`, `-status:`, `is:untagged`.
8. Bulk status change + Undo; delete → trash → restore; permanent delete persisted.
9. Backup → typed-confirmation wipe → restore (replace) → byte-identical resource set; CSV, Markdown, bookmarks HTML downloads non-empty with correct headers.
10. Importing the original NoteForge `.html` directly: dataset extracted, all 1,362 reported as already present.
11. Review queue snooze; rediscover sample present.
12. Keyboard: `/` focuses search, `?` opens help, Tab trapped inside dialog, Esc closes, `f`/Enter on cards, `g d` navigation.
13. 390×844 viewport: drawer nav, 1–2 column grid, full-width panel, no horizontal overflow on library and dashboard.
14. Offline with previews on: thumbnail requests attempted and blocked, fallback glyphs shown, no other external request at any point in the run, zero uncaught errors.

Manual: screenshots of welcome, import preview, dashboard, library (cards/list, light/dark), detail panel, review queue, settings, mobile dashboard/library/nav were inspected; three layout defects found that way were fixed (toast width on phones, dashboard overflow on phones, checkbox overlapping titles on compact cards).

### Known limitations
* Tested in Chromium only. Firefox and Safari should work (standard IndexedDB, `DecompressionStream`, `:has()`), but were not run. Safari private mode may fall back to localStorage, which Lantern reports in the sidebar.
* The base64 pictures from NoteForge entries are carried over; very large libraries of images will grow backups accordingly.
* The bookmark parser depends on the browser's HTML parser treating `<DL>` as nested inside `<DT>`; Chrome, Edge and Firefox exports tested synthetically, not a Safari export.
* Date detection for WhatsApp falls back to day/month when every date is ambiguous; the preview says which order was used and offers the alternative.
* No sync between devices by design; moving the file to another computer means exporting and importing a backup.

## 7. Prioritised future enhancements

1. CSV import (reusing the import pipeline) and a "paste a list of URLs" quick importer.
2. Saved searches / smart collections (store a query string as a sidebar entry).
3. Per-resource highlights/quotes list separate from notes, exportable to Markdown.
4. Optional link health check via a tiny local script that writes a JSON report Lantern can import.
5. Spaced-repetition style review intervals (auto-suggest the next review date from how you answered).
6. Optional "suggest tags" using a user-provided LLM endpoint, kept strictly behind a setting and a per-click button.
