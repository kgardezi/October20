
/* Idea Board — config importer engine (IdeaImport).
   Reads one session-log file per device (running config + show commands), finds the links between devices,
   checks them, and builds an Idea Board board. Everything runs in the browser; nothing is sent anywhere.
   MIT licence. */
(function(root){
'use strict';

const VERSION = '3.8';
/* ---------------- small helpers ---------------- */
const ROLE_RE = '(?:ACS|TL|DL|CL|AG|ML|AS|VG|SF|MX)';
const HOST_RE = new RegExp(`^([A-Z])([A-Z]{3})(\\d{3})(${ROLE_RE})(\\d{2})(\\d{2})$`);
const HOST_SCAN = new RegExp(`\\b[A-Z][A-Z]{3}\\d{3}${ROLE_RE}\\d{4}\\b`, 'gi');
const END_ROLES = new Set(['ACS', 'VG']);
const IPV4 = /\b(\d{1,3}(?:\.\d{1,3}){3})\b/;

function parseHost(h){
  h = String(h || '').toUpperCase();
  const m = HOST_RE.exec(h); if (!m) return null;
  return {name: h, letter: m[1], country: m[2], site: m[2] + m[3], siteNum: m[3], role: m[4], floor: m[5], unit: m[6]};
}
function cleanName(n){
  n = String(n || '').trim().replace(/^[,;]+|[,;]+$/g, '').replace(/\(.*?\)\s*$/, '');      // NX-OS "name(SERIAL)"
  if (!IPV4.test(n) || /[A-Za-z]/.test(n)) n = n.split('.')[0];  // strip domain
  return n.toUpperCase();
}
const ip2n = ip => { const p = String(ip).split('.').map(Number); return p.length === 4 && p.every(x => x >= 0 && x <= 255) ? ((p[0] << 24) >>> 0) + (p[1] << 16) + (p[2] << 8) + p[3] : null; };
const n2ip = n => [n >>> 24, (n >>> 16) & 255, (n >>> 8) & 255, n & 255].join('.');
function maskLen(m){
  if (/^\d+$/.test(m)) return +m;
  const n = ip2n(m); if (n == null) return null;
  let len = 0; for (let i = 31; i >= 0; i--){ if (n & (1 << i)) len++; else break; }
  return len;
}
const netOf = (ip, len) => { const n = ip2n(ip); if (n == null) return null; const mask = len === 0 ? 0 : (0xffffffff << (32 - len)) >>> 0; return (n & mask) >>> 0; };

/* interface names: long and short Cisco forms map to one key */
const IF_FULL = [['twentyfivegige', 'Twe'], ['twentyfivegigabitethernet', 'Twe'], ['hundredgige', 'Hu'], ['hundredgigabitethernet', 'Hu'],
  ['fortygigabitethernet', 'Fo'], ['fortygige', 'Fo'], ['tengigabitethernet', 'Te'], ['gigabitethernet', 'Gi'], ['fastethernet', 'Fa'],
  ['appgigabitethernet', 'Ap'], ['port-channel', 'Po'], ['loopback', 'Lo'], ['vlan', 'Vl'], ['tunnel', 'Tu'], ['bdi', 'BDI'],
  ['pseudowire', 'pw'], ['ethernet', 'Eth'], ['mgmt', 'mgmt'], ['twogigabitethernet', 'Tw']];
function ifShort(name){
  name = String(name || '').trim().replace(/\s+/g, '');
  if (/^(ge|xe|et|me|em|irb|ae)-?\d/i.test(name)) return name.toLowerCase();
  const m = /^([A-Za-z][A-Za-z-]*?)(\d.*)$/.exec(name); if (!m) return name;
  const p = m[1].toLowerCase();
  for (const [full, short] of IF_FULL) if (full === p || p === short.toLowerCase()) return short + m[2];
  for (const [full, short] of IF_FULL) if (p.length >= 2 && full.startsWith(p)) return short + m[2];
  return m[1] + m[2];
}
const ifKey = n => ifShort(n).toLowerCase();
/* the same port written two ways ("Ten 1/0/4" in a cut-off CDP table, "Twe1/0/4" in LLDP): same numbers, both Ethernet */
const PHYS_RE = /^(Gi|Te|Twe|Tw|Hu|Fo|Fa|Eth|Ap)\d/i;
const isPhys = n => PHYS_RE.test(ifShort(n)) && !/\./.test(n) || /^(ge|xe|et)-\d[^.]*$/i.test(n);
const samePort = (a, b) => { if (!a || !b) return false; if (ifKey(a) === ifKey(b)) return true; const x = ifShort(a), y = ifShort(b); return PHYS_RE.test(x) && PHYS_RE.test(y) && x.replace(/^[A-Za-z]+/, '') === y.replace(/^[A-Za-z]+/, ''); };
const PORT_SPEED = {Fa: '100M', Gi: '1G', Tw: '2.5G', Te: '10G', Twe: '25G', Fo: '40G', Hu: '100G'};
const spN = x => parseFloat(x) * (/G$/.test(x) ? 1000 : 1);
const portSpeed = n => { const m = /^([A-Za-z]+)\d/.exec(ifShort(n)); return m ? PORT_SPEED[m[1]] || '' : ''; };
const isIfToken = t => /^[A-Za-z]{1,4}\d+(\/\d+){1,3}(\.\d+)?$/.test(t) || /^(Gi|Te|Tw|Twe|Hu|Fo|Fa|Po|Eth|Ap|Gig|Ten|Twenty|Hundred|Forty|Fast|Port-channel|GigabitEthernet|TenGigabitEthernet|TwentyFiveGigE|HundredGigE|FortyGigabitEthernet|Ethernet|ge-|xe-|et-)[\w-]*\d+(\/\d+)*(\.\d+)?$/i.test(t);

/* ---------------- secrets ---------------- */
const SECRET_RULES = [
  /(\b(?:enable\s+)?secret\s+(?:\d+\s+)?)(\S+)/gi,
  /(\bpassword\s+(?:\d+\s+)?)(\S+)/gi,
  /(\bkey-string\s+(?:\d+\s+)?)(\S+)/gi,
  /(\bauthentication-key\s+(?:\d+\s+)?)(\S+)/gi,
  /(\bmessage-digest-key\s+\d+\s+md5\s+(?:\d+\s+)?)(\S+)/gi,
  /(\bpre-shared-key\b.*?\bkey\s+(?:\d+\s+)?)(\S+)/gi,
  /(\bserver-key\s+(?:\d+\s+)?)(\S+)/gi,
  /(^\s*key\s+(?:\d+\s+)?)(\S+)\s*$/gim,
  /(\btacacs-server\s+(?:host\s+\S+\s+)?key\s+(?:\d+\s+)?)(\S+)/gi,
  /(\bradius-server\s+(?:host\s+\S+.*?\s+)?key\s+(?:\d+\s+)?)(\S+)/gi,
  /(\bsnmp-server\s+community\s+)(\S+)/gi,
  /(\b(?:auth\s+(?:md5|sha\S*)|priv\s+(?:des\S*|3des|aes(?:\s+\d+)?))\s+)(\S+)/gi,
  /(\bneighbor\s+\S+\s+password\s+(?:\d+\s+)?)(\S+)/gi,
  /(\bwpa-psk\s+(?:ascii|hex)\s+(?:\d+\s+)?)(\S+)/gi,
];
function scrub(text){
  let n = 0;
  for (const re of SECRET_RULES) text = text.replace(re, (m, a, b) => { if (b === '<removed>') return m; n++; return a + '<removed>'; });
  return {text, removed: n};
}

/* ---------------- session log → command blocks ---------------- */
const CMDS = [
  ['run', /^sh\w*\s+run/i],
  ['cdp', /^sh\w*\s+cdp\s+nei\w*\s+det/i],
  ['lldp', /^sh\w*\s+lldp\s+nei\w*\s+det/i],
  ['cdpb', /^sh\w*\s+cdp\s+nei\w*\s*$/i],
  ['lldpb', /^sh\w*\s+lldp\s+nei\w*\s*$/i],
  ['l2vc', /^sh\w*\s+mpls\s+l2t\w*\s+vc/i],
  ['status', /^sh\w*\s+int\w*\s+stat/i],
  ['ospfi', /^sh\w*\s+(?:ip\s+)?ospf(?:\s+(?!vrf\b)\S+)?\s+int/i],
  ['ospfp', /^sh\w*\s+(?:ip\s+)?ospf(?:\s+(?!vrf\b|nei\w*\b|int\w*\b)\S+)?(?:\s+vrf\s+\S+)?\s*$/i],
  ['desc', /^sh\w*\s+int\w*\s+desc/i],
  ['brief', /^sh\w*\s+ip\s+int\w*\s+br/i],
  ['po', /^sh\w*\s+(?:eth\w*|port-channel)\s+sum/i],
  ['ospf', /^sh\w*\s+(?:ip\s+)?ospf(?:\s+(?!vrf\b)\S+)?\s+nei/i],
  ['xc', /^sh\w*\s+(xconn|l2vpn\s+atom\s+vc)/i],
  ['ldp', /^sh\w*\s+mpls\s+ldp\s+nei/i],
  ['nxbrief', /^sh\w*\s+int\w*\s+br\w*\s*$/i],
  ['interfaces', /^sh\w*\s+int\w*(?:\s+[A-Za-z-]+\d[\w/.:\-]*)?\s*$/i],
  ['vlan', /^sh\w*\s+vlan(\s+br\w*)?\s*$/i],
  ['mac', /^sh\w*\s+mac(\s+|-)addr/i],
];
// Outputs are recognised by their own headers first (a long command can show up as "$…" in the log), then by the command typed.
const SNIFF = [['run', /^(Building configuration|Current configuration\s*:)/m], ['cdp', /^Device ID:/m], ['lldp', /^\s*Local (?:Intf|Port id):/m],
  ['cdpb', /Device ID\s+Local Intrfce\s+Holdtme/], ['lldpb', /Device ID\s+Local Intf\s+Hold-time/], ['ospf', /Neighbor ID\s+Pri\s+State|^\s*Neighbor \d+\.\d+\.\d+\.\d+, interface address/m],
  ['desc', /^Interface\s+Status\s+Protocol\s+Description|^\s*Port\s+Type\s+Speed\s+Description|^\s*Interface\s+Description\s*$/m], ['brief', /IP-Address\s+OK\?\s+Method|IP Interface Status for VRF/], ['l2vc', /Local intf\s+Local circuit\s+Dest address/i],
  ['nxbrief', /^\s*Ethernet\s+VLAN\s+Type\s+Mode\s+Status\s+Reason/m],
  ['xc', /XC ST\s+Segment 1/], ['po', /Group\s+Port-channel\s+Protocol/], ['ldp', /Peer LDP Ident/], ['vlan', /^VLAN\s+Name\s+Status\s+Ports/m],
  ['mac', /Mac Address Table|Vlan\s+Mac Address\s+Type/i],
  ['status', /^\s*Port\s+(?:(?:Name|Description)\s+)?Status\s+Vlan\s+Duplex\s+Speed/im],
  ['interfaces', /^\s*(?:full|half|auto)[ -]duplex,\s*/im]];
const sniff = body => { const head = body.slice(0, 1500); const hit = SNIFF.find(([, re]) => re.test(head)); return hit ? hit[0] : null; };
const CMD_NAMES = {interfaces: 'show interfaces', status: 'show interfaces status', ospfi: 'show ip ospf interface', ospfp: 'show ip ospf', run: 'show running-config', cdp: 'show cdp neighbors detail', lldp: 'show lldp neighbors detail', desc: 'show interfaces description',
  brief: 'show ip interface brief', po: 'show etherchannel summary', ospf: 'show ip ospf neighbor', xc: 'show xconnect all', ldp: 'show mpls ldp neighbor', cdpb: 'show cdp neighbors', lldpb: 'show lldp neighbors', l2vc: 'show mpls l2transport vc',
  vlan: 'show vlan brief', mac: 'show mac address-table', nxbrief: 'show interface brief'};
function splitSession(text){
  text = String(text).replace(/\r/g, '').replace(/[^\n]\x08/g, '').replace(/\x08/g, '').replace(/ *--More-- *(\x08+ *)?/g, '').replace(/\x1b\[[0-9;]*[A-Za-z]/g, '');
  // collection-script logs: "Running command <cmd> on the <host>" between long dashed lines, no device prompt
  const RUN_HDR = /^\s*Running command\s+(.+?)\s+on the\s+(\S+)\s*$/i;
  if (text.split('\n').some(l => RUN_HDR.test(l))){
    const hosts = new Map(), blocks = [], unknown = []; let cur = null;
    for (const l of text.split('\n')){
      const m = RUN_HDR.exec(l);
      if (m){ if (cur) blocks.push(cur); hosts.set(m[2], (hosts.get(m[2]) || 0) + 1); const cmd = m[1].trim(), hit = CMDS.find(([, re]) => re.test(cmd)); cur = {cmd, kind: hit ? hit[0] : null, lines: []}; continue; }
      if (/^\s*-{60,}\s*$/.test(l)) continue;               // the script's own separator lines
      if (cur) cur.lines.push(l);
    }
    if (cur) blocks.push(cur);
    const prompt = [...hosts].sort((a, b) => b[1] - a[1])[0][0];
    const out = {prompt, blocks: [], invalid: [], unknown};
    for (const b of blocks){
      const body = b.lines.join('\n');
      b.kind = sniff(body) || b.kind;
      if (!b.kind){ if (/^sh/i.test(b.cmd) && body.trim()) unknown.push(b.cmd); continue; }
      if (/^\s*% ?(Invalid|Incomplete|Ambiguous|Unknown)/m.test(body) && b.lines.filter(l => l.trim()).length < 6){ out.invalid.push(b.cmd); continue; }
      out.blocks.push({kind: b.kind, cmd: b.cmd, text: body});
    }
    return out;
  }
  const lines = text.split('\n');
  const PROMPT = /^([A-Za-z0-9][A-Za-z0-9._-]{1,62})(?:\([\w-]+\))?[#>]\s*(.*)$/;
  const counts = new Map();
  for (const l of lines){ const m = PROMPT.exec(l.trim()); if (m && (/^(sh(?:o(?:w)?)?|ter|term|en|exit|end|wr|dir|conf)\b/i.test(m[2]) || !m[2])) counts.set(m[1], (counts.get(m[1]) || 0) + 1); }
  let prompt = null, best = 0; for (const [k, v] of counts) if (v > best){ best = v; prompt = k; }
  const blocks = [], unknown = [];
  if (prompt){
    let cur = null;
    for (const l of lines){
      const m = PROMPT.exec(l.trim());
      if (m && m[1].toLowerCase() === prompt.toLowerCase()){
        if (cur) blocks.push(cur);
        const cmd = (m[2] || '').trim(), hit = CMDS.find(([, re]) => re.test(cmd));
        cur = cmd ? {cmd, kind: hit ? hit[0] : null, lines: []} : null;
        continue;
      }
      if (cur) cur.lines.push(l);
    }
    if (cur) blocks.push(cur);
  }
  if (!prompt){
    let cur = null;
    for (const l of lines){
      const hit = CMDS.find(([, re]) => re.test(l.trim()));
      if (hit){ if(cur) blocks.push(cur); cur = {cmd:l.trim(),kind:hit[0],lines:[]}; }
      else if(cur) cur.lines.push(l);
    }
    if(cur) blocks.push(cur);
  }
  if (!blocks.some(b => b.kind === 'run') && /^hostname\s+\S+/m.test(text) && /^interface\s+\S+/m.test(text))
    blocks.push({cmd: 'show running-config', kind: 'run', lines: prompt ? text.split('\n') : lines, whole: true});
  const out = {prompt, blocks: [], invalid: [], unknown};
  for (const b of blocks){
    const body = b.lines.join('\n');
    b.kind = sniff(body) || b.kind;
    if (!b.kind){ if (/^\$|^sh/i.test(b.cmd) && body.trim()) unknown.push(b.cmd); continue; }
    if (/^\s*% ?(Invalid|Incomplete|Ambiguous|Unknown)/m.test(body) && b.lines.filter(l => l.trim()).length < 6){ out.invalid.push(b.cmd); continue; }
    out.blocks.push({kind: b.kind, cmd: b.cmd, text: body});
  }
  return out;
}

/* ---------------- running config ---------------- */
function newIf(name){ return {name: ifShort(name), long: name, ips: [], desc: '', shut: false, l2: false, mode: '', trunk: false, accessVlan: null, chan: null, chanMode: '', vrf: '', ospf: {cost: null, area: null, p2p: false, pid: null}, xc: [], svcs: [], mpls: false, bw: null, speed: null}; }
const newOspf = (pid, vrf) => ({pid, vrf, passiveDefault: false, passive: new Set(), nonPassive: new Set(), networks: [], rid: null});
function parseRun(text){
  const cfg = {hostname: null, ifs: new Map(), ospf: [], vrfs: new Set(), pws: new Map(), l2vpn: [], lines: 0};
  let ctx = null, svc = null, svcIndent = 0;
  const getIf = n => { const k = ifKey(n); if (!cfg.ifs.has(k)) cfg.ifs.set(k, newIf(n)); return cfg.ifs.get(k); };
  for (const raw of String(text).split('\n')){
    const line = raw.replace(/\s+$/, ''); if (!line.trim() || /^\s*!/.test(line)) continue;
    cfg.lines++;
    const ind = /^\s*/.exec(line)[0].length, t = line.trim(); let m;
    if (ind === 0){
      ctx = null; svc = null;
      if ((m = /^hostname\s+(\S+)/i.exec(t))) cfg.hostname = m[1];
      else if ((m = /^interface\s+(\S+)/i.exec(t))){
        if (/^pseudowire/i.test(m[1])){ const p = {name: m[1].toLowerCase(), peer: null, vcid: null}; cfg.pws.set(p.name, p); ctx = {type: 'pw', p}; }
        else ctx = {type: 'if', i: getIf(m[1])};
      }
      else if ((m = /^router\s+ospf\s+(\S+)/i.exec(t))){ const o = newOspf(m[1], (/\bvrf\s+(\S+)/i.exec(t)||[])[1]||''); cfg.ospf.push(o); ctx = {type: 'ospf', o, base: o, vrfInd: null}; }
      else if ((m = /^(?:vrf\s+definition|ip\s+vrf)\s+(\S+)/i.exec(t))) cfg.vrfs.add(m[1]);
      else if ((m = /^l2vpn\s+xconnect\s+context\s+(\S+)/i.exec(t))){ const x = {name: m[1], members: []}; cfg.l2vpn.push(x); ctx = {type: 'l2vpn', x}; }
      continue;
    }
    if (!ctx) continue;
    if (ctx.type === 'pw'){
      if ((m = /^neighbor\s+(\S+)\s+(\d+)/i.exec(t))){ ctx.p.peer = m[1]; ctx.p.vcid = m[2]; }
      continue;
    }
    if (ctx.type === 'l2vpn'){
      if ((m = /^member\s+(\S+)(?:\s+service-instance\s+(\d+))?/i.exec(t))) ctx.x.members.push({name: m[1], svc: m[2] || null});
      continue;
    }
    if (ctx.type === 'ospf'){
      // NX-OS nests per-VRF settings under the process: "router ospf 1" / "  vrf CORP" / "    passive-interface default"
      if (ctx.vrfInd != null && ind <= ctx.vrfInd){ ctx.o = ctx.base; ctx.vrfInd = null; }
      if ((m = /^vrf\s+(\S+)/i.exec(t))){
        let v = cfg.ospf.find(x => x.pid === ctx.base.pid && x.vrf === m[1]);
        if (!v){ v = newOspf(ctx.base.pid, m[1]); cfg.ospf.push(v); }
        ctx.o = v; ctx.vrfInd = ind; continue;
      }
      const o = ctx.o;
      if (/^passive-interface\s+default/i.test(t)) o.passiveDefault = true;
      else if ((m = /^no\s+passive-interface\s+(\S+)/i.exec(t))) o.nonPassive.add(ifKey(m[1]));
      else if ((m = /^passive-interface\s+(\S+)/i.exec(t))) o.passive.add(ifKey(m[1]));
      else if ((m = /^network\s+(\S+)\s+(\S+)\s+area\s+(\S+)/i.exec(t))) o.networks.push({ip: m[1], wild: m[2], area: m[3]});
      else if ((m = /^router-id\s+(\S+)/i.exec(t))) o.rid = m[1];
      continue;
    }
    const i = ctx.i;
    if (svc && ind <= svcIndent) svc = null;
    if ((m = /^service\s+instance\s+(\d+)/i.exec(t))){ svc = {id: m[1], dot1q: null, xc: null, bd: null}; svcIndent = ind; i.svcs.push(svc); continue; }
    if (svc){
      if ((m = /^encapsulation\s+dot1q\s+(\S+)/i.exec(t))) svc.dot1q = m[1];
      else if ((m = /^xconnect\s+(\S+)\s+(\d+)/i.exec(t))){ svc.xc = {peer: m[1], vcid: m[2]}; i.xc.push({peer: m[1], vcid: m[2], svc: svc.id}); }
      else if ((m = /^bridge-domain\s+(\d+)/i.exec(t))) svc.bd = m[1];
      continue;
    }
    if ((m = /^description\s+(.*)$/i.exec(t))) i.desc = m[1].trim();
    else if ((m = /^ip\s+address\s+(\S+)\s+(\S+)(\s+secondary)?/i.exec(t))){ const len = maskLen(m[2]); if (len != null && ip2n(m[1]) != null) i.ips.push({ip: m[1], len, secondary: !!m[3]}); }
    else if ((m = /^ip\s+address\s+(\d+\.\d+\.\d+\.\d+)\/(\d+)/i.exec(t))) i.ips.push({ip:m[1],len:+m[2],secondary:false});
    else if (/^shutdown$/i.test(t)){ i.shut = true; i.shutSpecified = true; }
    else if (/^no\s+shutdown$/i.test(t)){ i.shut = false; i.shutSpecified = true; }
    else if ((m = /^channel-group\s+(\d+)(?:\s+mode\s+(\S+))?/i.exec(t))){ i.chan = 'Po' + m[1]; i.chanMode = m[2] || 'on'; }
    else if ((m = /^switchport\s+mode\s+(\S+)/i.exec(t))){ i.l2 = true; i.mode = m[1].toLowerCase(); i.trunk = i.mode === 'trunk'; }
    else if (/^switchport$/i.test(t)) i.l2 = true;
    else if ((m = /^switchport\s+access\s+vlan\s+(\d+)/i.exec(t))){ i.l2 = true; i.accessVlan = m[1]; }
    else if ((m = /^switchport\s+trunk\s+allowed\s+vlan\s+(.+)/i.exec(t))){ i.l2 = true; i.allowedVlans = m[1]; }
    else if (/^switchport\s+trunk/i.test(t)) i.l2 = true;
    else if ((m = /^(?:(?:ip\s+)?vrf\s+forwarding|vrf\s+member)\s+(\S+)/i.exec(t))) i.vrf = m[1];
    else if ((m = /^ip\s+ospf\s+cost\s+(\d+)/i.exec(t))) i.ospf.cost = +m[1];
    else if (/^ip\s+ospf\s+network\s+point-to-point/i.test(t)) i.ospf.p2p = true;
    else if (/^no\s+ip\s+ospf\s+passive-interface/i.test(t)) i.ospf.passiveIf = 'off';     // NX-OS per-interface passive
    else if (/^ip\s+ospf\s+passive-interface/i.test(t)) i.ospf.passiveIf = 'on';
    else if ((m = /^ip\s+(?:router\s+)?ospf\s+(\S+)\s+area\s+(\S+)/i.exec(t))){ i.ospf.pid = m[1]; i.ospf.area = m[2]; }
    else if ((m = /^xconnect\s+(\S+)\s+(\d+)/i.exec(t))) i.xc.push({peer: m[1], vcid: m[2], svc: null});
    else if (/^mpls\s+ip$/i.test(t)) i.mpls = true;
    else if ((m = /^bandwidth\s+(\d+)/i.exec(t))) i.bw = +m[1];
    else if ((m = /^speed\s+(\S+)/i.exec(t))) i.speed = m[1];
  }
  return finalizeConfig(cfg);
}
function finalizeConfig(cfg){
  // OSPF state per interface; also used after merging separate config sections.
  const areaNorm = a => a == null ? null : (/^\d+$/.test(a) ? n2ip(+a) : a);
  for (const i of cfg.ifs.values()){
    const ip = i.ips.find(x => !x.secondary), key = ifKey(i.name);
    let proc = null, area = i.ospf.area;
    if (area != null) proc = cfg.ospf.find(o => o.pid === i.ospf.pid && normVrf(o.vrf) === normVrf(i.vrf)) || null;
    if (ip && area == null) for (const o of cfg.ospf.filter(o => normVrf(o.vrf) === normVrf(i.vrf))) for (const n of o.networks){
      const w = ip2n(n.wild), base = ip2n(n.ip), me = ip2n(ip.ip);
      if (w == null || base == null || me == null) continue;
      if (((me & ~w) >>> 0) === ((base & ~w) >>> 0)){ proc = o; area = n.area; break; }
    }
    i.ospf.enabled = !!proc || i.ospf.pid != null;
    i.ospf.areaN = areaNorm(area);
    if (proc) i.ospf.passive = proc.passiveDefault ? !proc.nonPassive.has(key) : proc.passive.has(key);
    if (i.ospf.passiveIf) i.ospf.passive = i.ospf.passiveIf === 'on';
    if (/^lo/i.test(i.name)) i.ospf.passive = true;
  }
  return cfg;
}

/* ---------------- show outputs ---------------- */
function parseCdp(text){
  const out = [];
  for (const blk of String(text).split(/^-{8,}\s*$/m)){
    const id = /Device ID:\s*(.+)/i.exec(blk); if (!id) continue;
    const intf = /Interface:\s*([^,\n]+),\s*Port ID \(outgoing port\):\s*(.+)/i.exec(blk);
    const ip = /(?:IP(?:v4)? [Aa]ddress|IPv4 Address):\s*(\d+\.\d+\.\d+\.\d+)/.exec(blk);
    const plat = /Platform:\s*([^,\n]+)/i.exec(blk);
    if (!intf) continue;
    out.push({name: cleanName(id[1]), local: ifShort(intf[1].trim()), remote: ifShort(intf[2].trim()), ip: ip ? ip[1] : null, platform: plat ? plat[1].replace(/^cisco\s+/i, '').trim() : ''});
  }
  return out;
}
function parseLldp(text){
  const out = [];
  // IOS-XE: dashed separators, "Local Intf:". NX-OS: blocks start at "Chassis id:", local port is "Local Port id:".
  const nx = /^\s*Local Port id:/im.test(text) && !/^\s*Local Intf:/im.test(text);
  for (const blk of String(text).split(nx ? /^(?=\s*Chassis id:)/im : /^-{8,}\s*$/m)){
    const local = /Local (?:Intf|Port id):\s*(\S+)/i.exec(blk), port = /^\s*Port id:\s*(.+)/im.exec(blk), sys = /System Name:\s*(.+)/i.exec(blk);
    if (!local || (!sys && !port)) continue;
    const ip = /(?:\bIP|Management Address(?:es)?):\s*(\d+\.\d+\.\d+\.\d+)/.exec(blk), pdesc = /Port Description:\s*(.+)/i.exec(blk);
    let remote = port ? port[1].trim() : '';
    if (!isIfToken(remote) && pdesc && isIfToken(pdesc[1].trim())) remote = pdesc[1].trim();
    out.push({name: sys ? cleanName(sys[1]) : '', local: ifShort(local[1]), remote: isIfToken(remote) ? ifShort(remote) : remote, ip: ip ? ip[1] : null, platform: ''});
  }
  return out;
}
/* "show cdp neighbors": long device IDs wrap onto their own line; ports are written "Gig 0/0/2" */
function parseCdpBrief(text){
  const out = [], lines = String(text).split('\n'); let start = lines.findIndex(l => /Device ID\s+Local Intrfce/.test(l)); if (start < 0) return out;
  const rows = []; let pend = '';
  for (const l of lines.slice(start + 1)){
    if (!l.trim() || /^Total cdp/i.test(l.trim())){ pend = ''; continue; }
    if (/^\S+\s*$/.test(l)){ pend = l.trim(); continue; }             // name alone, details follow on the next line
    rows.push(pend && /^\s/.test(l) ? pend + ' ' + l.trim() : l.trim()); pend = '';
  }
  const PORT = /([A-Za-z][A-Za-z-]*\s?\d+(?:\/\d+)*(?:\.\d+)?)$/;
  for (const r of rows){
    const m = /^(\S+)\s+([A-Za-z][A-Za-z-]*\s?\d+(?:\/\d+)*)\s+(\d+)\s+(.*)$/.exec(r); if (!m) continue;
    let rest = m[4].trim(); const pm = PORT.exec(rest); if (!pm) continue;
    rest = rest.slice(0, pm.index).trim();
    const toks = rest.split(/\s+/), caps = []; while (toks.length && /^[A-Za-z]$/.test(toks[0])) caps.push(toks.shift());
    out.push({name: cleanName(m[1]), local: ifShort(m[2].replace(/\s+/g, '')), remote: ifShort(pm[1].replace(/\s+/g, '')), ip: null, platform: toks.join(' ')});
  }
  return out;
}
/* "show lldp neighbors": the Device ID column is cut to 20 characters and runs straight into the local port */
function parseLldpBrief(text){
  const out = [], lines = String(text).split('\n'), hi = lines.findIndex(l => /Device ID\s+Local Intf\s+Hold-time/i.test(l)); if (hi < 0) return out;
  const col = Math.min(20, lines[hi].indexOf('Local Intf'));
  for (const l of lines.slice(hi + 1)){
    if (!l.trim() || /^Total entries/i.test(l.trim())) continue;
    let name = l.slice(0, col).trim(), rest = l.slice(col);
    let m = /^\s*(\S+)\s+(\d+)\s+(\S+)\s+(.+?)\s*$/.exec(rest);
    if (!m || !/\d/.test(m[1])){                                     // name shorter than the column: split on spaces instead
      const t = /^(\S+)\s+(\S+)\s+(\d+)\s+(\S+)\s+(.+?)\s*$/.exec(l.trim()); if (!t) continue; name = t[1]; m = [null, t[2], t[3], t[4], t[5]];
    }
    out.push({name: cleanName(name), local: ifShort(m[1]), remote: isIfToken(m[4]) ? ifShort(m[4]) : m[4], ip: null, platform: '', truncated: name.length >= col});
  }
  return out;
}
/* "show mpls l2transport vc":  Gi0/0/5   Ethernet:1000   192.0.2.1   1291   UP */
function parseL2vc(text){
  const out = [];
  for (const l of String(text).split('\n')){
    const r = /^(\S+)\s+(\S+?)(?::(\d+))?\s+(\d+\.\d+\.\d+\.\d+)\s+(\d+)\s+(\S+)/.exec(l.trim());
    if (r && !/^Local/i.test(r[1])) out.push({state: r[6].toUpperCase(), ac: ifShort(r[1]), svc: r[3] || null, acState: '', peer: r[4], vcid: r[5], pwState: r[6].toUpperCase()});
  }
  return out;
}
function parseIntDesc(text){
  const m = new Map();
  // NX-OS has no status columns: "Port Type Speed Description" (Ethernet) and "Interface Description" (Po, Lo, Vlan…) sections.
  let mode = 'xe';
  const nxDesc = d => { d = (d || '').trim(); return d === '--' ? '' : d; };
  for (const l of String(text).split('\n')){
    const t = l.trim();
    if (/^Port\s+Type\s+Speed\s+Description/i.test(t)){ mode = 'nx-port'; continue; }
    if (/^Interface\s+Description\s*$/i.test(t)){ mode = 'nx-if'; continue; }
    if (/^Interface\s+Status\s+Protocol\s+Description/i.test(t)){ mode = 'xe'; continue; }
    if (!t || /^-+$/.test(t)) continue;
    if (mode === 'nx-port' || mode === 'nx-if'){
      const r = mode === 'nx-port' ? /^(\S+)\s+(\S+)\s+(\S+)\s*(.*)$/.exec(t) : /^(\S+)\s*(.*)$/.exec(t);
      if (!r || !/\d/.test(r[1]) && !/^mgmt/i.test(r[1])) continue;
      m.set(ifKey(r[1]), {name: ifShort(r[1]), status: '', proto: '', desc: nxDesc(mode === 'nx-port' ? r[4] : r[2])});
      continue;
    }
    const r = /^(\S+)\s+(admin down|up|down|deleted)\s+(up|down|notpresent|dormant|lowerlayerdown)?\s*(.*)$/i.exec(t);
    if (!r || /^interface$/i.test(r[1])) continue;
    m.set(ifKey(r[1]), {name: ifShort(r[1]), status: r[2].toLowerCase(), proto: (r[3] || '').toLowerCase(), desc: (r[4] || '').trim()});
  }
  return m;
}
function parseBrief(text){
  const m = new Map();
  for (const l of String(text).split('\n')){
    const r = /^(\S+)\s+(\S+)\s+(YES|NO)\s+\S+\s+(administratively down|up|down|deleted)\s+(up|down)/i.exec(l.trim());
    // NX-OS: "Eth1/1   198.51.100.1   protocol-up/link-up/admin-up"
    const n = !r && /^(\S+)\s+(\d+\.\d+\.\d+\.\d+)\s+protocol-(up|down)\/link-(up|down)\/admin-(up|down)/i.exec(l.trim());
    if (n){ m.set(ifKey(n[1]), {name: ifShort(n[1]), ip: n[2], status: /down/i.test(n[5]) ? 'admin down' : /down/i.test(n[4]) ? 'down' : 'up', proto: n[3].toLowerCase()}); continue; }
    if (!r) continue;
    m.set(ifKey(r[1]), {name: ifShort(r[1]), ip: ip2n(r[2]) != null ? r[2] : null, status: /admin/i.test(r[4]) ? 'admin down' : r[4].toLowerCase(), proto: r[5].toLowerCase()});
  }
  return m;
}
function parsePo(text){
  const groups = []; let last = null;
  for (const l of String(text).split('\n')){
    let r = /^\s*(\d+)\s+(Po\d+)\((\w+)\)\s+(\S+)\s*(.*)$/i.exec(l);
    if (r){ last = {po: ifShort(r[2]), flags: r[3], proto: r[4], members: []}; groups.push(last); addMembers(r[5]); continue; }
    if (last && /^\s{6,}\S+\(\w+\)/.test(l)) addMembers(l); else if (!l.trim()) last = last;
  }
  function addMembers(s){ let mm; const re = /(\S+?)\((\w+)\)/g; while ((mm = re.exec(s))) last.members.push({name: ifShort(mm[1]), flag: mm[2]}); }
  return groups;
}
function parseOspfNbr(text){
  const out = [];
  for (const l of String(text).split('\n')){
    // "192.0.2.2   0   FULL/  -   00:00:35   192.0.2.3   GigabitEthernet0/0/0" (the state column can contain spaces)
    const t = l.trim().split(/\s+/);
    if (t.length < 5 || ip2n(t[0]) == null || !/^\d+$/.test(t[1])) continue;
    const ips = t.map((x, k) => ip2n(x) != null ? k : -1).filter(k => k > 0), ai = ips[ips.length - 1];
    if (!ai || ai === t.length - 1) continue;
    out.push({rid: t[0], state: t[2].split('/')[0].toUpperCase(), addr: t[ai], intf: ifShort(t[t.length - 1])});
  }
  return out;
}
function parseXc(text){
  const out = [];
  for (const l of String(text).split('\n')){
    const r = /^(\S+)\s+(?:pri|sec)?\s*ac\s+(\S+?)(?::(\d+))?\(.*?\)\s+(\S+)\s+mpls\s+(\d+\.\d+\.\d+\.\d+):(\d+)\s+(\S+)/i.exec(l.trim());
    if (r) out.push({state: r[1].toUpperCase(), ac: ifShort(r[2]), svc: r[3] || null, acState: r[4].toUpperCase(), peer: r[5], vcid: r[6], pwState: r[7].toUpperCase()});
  }
  return out;
}
function parseLdp(text){ const s = new Set(); let m; const re = /Peer LDP Ident:\s*(\d+\.\d+\.\d+\.\d+)/gi; while ((m = re.exec(text))) s.add(m[1]); return s; }
function parseVlan(text){
  const m = new Map();
  for (const l of String(text).split('\n')){ const r = /^(\d{1,4})\s+(\S+)\s+(active|act\/lshut|suspended|act\/unsup)/i.exec(l); if (r) m.set(r[1], r[2]); }
  return m;
}
function parseMac(text){
  const m = new Map();
  for (const l of String(text).split('\n')){
    const r = /^\s*\*?\s*(\d{1,4})\s+([0-9a-f]{4}\.[0-9a-f]{4}\.[0-9a-f]{4})\s+\S+.*?\s(\S+)\s*$/i.exec(l);
    if (!r || /^(CPU|Router|Switch|Drop|sup)/i.test(r[3])) continue;
    const k = ifKey(r[3]), e = m.get(k) || {name: ifShort(r[3]), count: 0, vlans: new Set()}; e.count++; e.vlans.add(r[1]); m.set(k, e);
  }
  return m;
}

/* ---------------- descriptions ---------------- */
const SPEED_RE = /\b(\d+(?:\.\d+)?)\s?(G|Gb|Gbps|M|Mb|Mbps|K|Kb|Kbps)\b/i;
function parseDesc(desc, known){
  const d = String(desc || '').trim(); if (!d) return null;
  const out = {raw: d, kind: 'other', hosts: [], carrier: '', cid: '', speed: ''};
  const hosts = [];
  const toks = d.split(/[\s,;|]+/).filter(Boolean);
  for (let k = 0; k < toks.length; k++){
    const t = toks[k].replace(/[()[\]:]+$/g, '').replace(/^[([]+/, '');
    const up = t.toUpperCase().split('.')[0];
    if (HOST_RE.test(up) || (known && known.has(up))){
      let port = '';
      for (let j = k + 1; j < Math.min(toks.length, k + 3); j++){ const p = toks[j].replace(/[(),:]+$/g, ''); if (isIfToken(p)){ port = ifShort(p); break; } }
      hosts.push({name: up, port, at: k});
    }
  }
  out.hosts = hosts;
  const sp = SPEED_RE.exec(d); if (sp) out.speed = sp[1] + sp[2].charAt(0).toUpperCase();
  let m;
  // "PWIRE:" and "PW:" mean the same thing: a pseudowire attachment port
  if ((m = /^PW(?:IRE)?(?:\s*:|\s|$)\s*(.*)$/i.exec(d))){
    out.kind = 'pwire';
    const r = /(\S+)\s+(\S+)\s+via\s+(\S+)\s+(\S+)\s+to\s+(\S+)\s+(\S+)/i.exec(m[1]);
    if (!m[1].trim()) out.empty = true;
    if (r) out.pw = {a: cleanName(r[1]), ap: ifShort(r[2]), via: cleanName(r[3]), vp: ifShort(r[4]), b: cleanName(r[5]), bp: ifShort(r[6])};
    return out;
  }
  if ((m = /^CIRCUIT(?:\s*:|\s|$)\s*(.*)$/i.exec(d)) && m[1].includes(',') && !/\bCir(cuit)?\s*ID\b/i.test(m[1])){
    // "CIRCUIT: <carrier>, <circuit id / ref>, <phone>, <speed>, [site] <host>, <port> - Email: …" (fields in any order)
    out.kind = 'circuit';
    const f = m[1].split(',').map(x => x.trim()).filter(Boolean);
    out.carrier = f[0] && !HOST_RE.test(f[0].toUpperCase()) && !isIfToken(f[0]) ? f[0] : '';
    for (const x of f.slice(1)){
      if (/^\d+(\.\d+)?\s?(G|Gb|Gbps|M|Mb|Mbps|K|Kb|Kbps)$/i.test(x)){ const sp = SPEED_RE.exec(x); out.speed = sp[1] + sp[2].charAt(0).toUpperCase(); continue; }
      if (/@|^\+?[\d\s().-]{7,}$|^Email/i.test(x) || HOST_SCAN.test(x) || isIfToken(x.split(/\s/)[0])){ HOST_SCAN.lastIndex = 0; continue; }
      HOST_SCAN.lastIndex = 0;
      if (!out.cid && /[\d]/.test(x)) out.cid = x;
    }
    if (!out.speed){ const sp = SPEED_RE.exec(m[1]); if (sp) out.speed = sp[1] + sp[2].charAt(0).toUpperCase(); }
    return out;
  }
  if ((m = /^CIRCUIT(?:\s*:|\s|$)\s*(.*)$/i.exec(d))){
    out.kind = 'circuit';
    const body = m[1], cid = /\bCir(?:cuit)?\s*ID\s*[:#]?\s*(\S+)/i.exec(body);
    out.carrier = body.split(/\bCir(?:cuit)?\s*ID\b|\bto\b|\b\d+(?:\.\d+)?\s?(?:Gbps|Mbps|Kbps|Gb|Mb|Kb|G|M|K)\b/i)[0].replace(/[\s:-]+$/, '').trim();
    if (cid) out.cid = cid[1];
    const to = /\bto\s+(\S+)(?:\s+(\S+))?/i.exec(body);
    if (to && !hosts.length){ const up = cleanName(to[1]); out.hosts.push({name: up, port: to[2] && isIfToken(to[2]) ? ifShort(to[2]) : '', at: 0}); }
    return out;
  }
  if (/^UPLINK(?:\s*:|\s|$)/i.test(d)) out.kind = 'uplink';

  return out;
}

/* ---------------- inventory ---------------- */
function parseInventory(text){
  const map = new Map(); text = String(text || '').replace(/^﻿/, '');
  const lines = text.split(/\r?\n/).filter(l => l.trim());
  // jump-box listing: "1 - HOST (IP)"
  const jump = /^\s*\d+\s*-\s*(\S+)\s*\((\d+\.\d+\.\d+\.\d+)\)/;
  if (lines.some(l => jump.test(l))){
    for (const l of lines){ const m = jump.exec(l); if (m) map.set(m[1].toUpperCase(), {name: m[1].toUpperCase(), ip: m[2], vendor: '', model: ''}); }
    return map;
  }
  const sep = lines[0] && (lines[0].includes('\t') ? '\t' : lines[0].includes(';') && !lines[0].includes(',') ? ';' : ',');
  const split = l => { const out = []; let cur = '', q = false; for (const ch of l){ if (ch === '"') q = !q; else if (ch === sep && !q){ out.push(cur.trim()); cur = ''; } else cur += ch; } out.push(cur.trim()); return out; };
  let head = split(lines[0]).map(h => h.toLowerCase()), start = 1;
  const col = re => head.findIndex(h => re.test(h));
  let ci = {name: col(/host|name|device$/), ip: col(/ip|address/), vendor: col(/vendor|make/), model: col(/model|platform|type/)};
  if (ci.name < 0){ ci = {name: 0, ip: 1, vendor: 2, model: 3}; start = 0; }
  for (const l of lines.slice(start)){
    const c = split(l), n = (c[ci.name] || '').toUpperCase(); if (!n) continue;
    map.set(n, {name: n, ip: ci.ip >= 0 ? c[ci.ip] || '' : '', vendor: ci.vendor >= 0 ? c[ci.vendor] || '' : '', model: ci.model >= 0 ? c[ci.model] || '' : ''});
  }
  return map;
}
const DEFAULT_SITES = '';
function parseSites(text){
  const m = new Map();
  for (const l of String(text || '').split('\n')){ const r = /^\s*([A-Za-z]{3}\d{3})\s*[=:]\s*(.+?)\s*$/.exec(l); if (r) m.set(r[1].toUpperCase(), r[2]); }
  return m;
}

/* ---------------- one device file ---------------- */
function parseDevice(fileName, text){
  const s = scrub(String(text));
  const sess = splitSession(s.text);
  // the file name starts with the hostname; whatever follows (timestamp, extension, anything) is ignored
  const base = String(fileName).replace(/^.*[\\/]/, '').replace(/\.(txt|log|cfg|conf|config|out|text)$/i, '');
  const lead = new RegExp(`^([A-Z][A-Z]{3}\\d{3}${ROLE_RE}\\d{4})`, 'i').exec(base);
  const dev = {file: fileName, fileHost: (lead ? lead[1] : base.split(/[._\s]/)[0] || base).toUpperCase(),
    secretsRemoved: s.removed, prompt: sess.prompt, cmds: new Set(), invalid: sess.invalid, unknownCmds: sess.unknown,
    run: null, cdp: [], lldp: [], desc: new Map(), brief: new Map(), po: [], ospfNbr: [], xc: [], ldp: new Set(), vlans: new Map(), mac: new Map()};
  const runs = sess.blocks.filter(b => b.kind === 'run');
  if (runs.length) dev.run = parseRun(runs.map(b => b.text).join('\n!\n'));
  for (const b of sess.blocks){
    dev.cmds.add(({cdpb: 'cdp', lldpb: 'lldp', l2vc: 'xc'})[b.kind] || b.kind);
    switch (b.kind){
      case 'run': break;
      case 'cdp': dev.cdp.push(...parseCdp(b.text)); break;
      case 'lldp': dev.lldp.push(...parseLldp(b.text)); break;
      case 'desc': for (const [k, v] of parseIntDesc(b.text)) dev.desc.set(k, v); break;
      case 'brief': for (const [k, v] of parseBrief(b.text)) dev.brief.set(k, v); break;
      case 'po': dev.po.push(...parsePo(b.text)); break;
      case 'ospf': dev.ospfNbr.push(...parseOspfNbr(b.text)); break;
      case 'xc': dev.xc.push(...parseXc(b.text)); break;
      case 'ldp': for (const p of parseLdp(b.text)) dev.ldp.add(p); break;
      case 'cdpb': dev.cdp.push(...parseCdpBrief(b.text)); break;
      case 'lldpb': dev.lldp.push(...parseLldpBrief(b.text)); break;
      case 'l2vc': dev.xc.push(...parseL2vc(b.text)); break;
      case 'vlan': for (const [k, v] of parseVlan(b.text)) dev.vlans.set(k, v); break;
      case 'mac': for (const [k, v] of parseMac(b.text)) dev.mac.set(k, v); break;
    }
  }
  const cfgHost = dev.run && dev.run.hostname ? dev.run.hostname.toUpperCase() : null;
  dev.name = parseHost(dev.fileHost) ? dev.fileHost : (sess.prompt && parseHost(sess.prompt) ? sess.prompt.toUpperCase() : cfgHost || (sess.prompt ? sess.prompt.toUpperCase() : dev.fileHost));
  dev.cfgHost = cfgHost;
  return dev;
}

/* ---------------- analysis ---------------- */
const SHOW_SRC = new Set(['cdp', 'lldp', 'ospf', 'xc-up', 'po-up']);
const CFG_SRC = new Set(['subnet', 'desc', 'xconnect', 'pwire']);
// Pick the strongest source first; many weaker observations must not override LLDP.
const WEIGHT = {lldp: 6, cdp: 5, subnet: 4, pwire: 3, desc: 2, ospf: 1};

/* One OSPF link over each pseudowire, taken from the subinterface with the chosen suffix (.5 by default). */
function pwOspfFor(R, suffix){
  suffix = String(suffix || '5').replace(/^\./, '');
  const list = [], problems = [], ipIndex = new Map();
  for (const d of R.devices.values()){ if (d.ip) ipIndex.set(d.ip, d.name); for (const i of d.ifs.values()) for (const a of i.ips) if (!ipIndex.has(a.ip)) ipIndex.set(a.ip, d.name); }
  for (const L of R.phys || []){
    if (!L.pw || !L.pw.core) continue;
    const c = R.devices.get(L.pw.core); if (!c || c.role === 'TL') continue;
    const sub = c.ifs.get(ifKey(L.pw.coreIf + '.' + suffix));
    if (!sub){ if (c.data) problems.push({sev: 'warn', dev: c.name, msg: `${L.pw.coreIf} carries a pseudowire${L.pw.far ? ' to ' + L.pw.far : ''} but has no .${suffix} subinterface — no OSPF link drawn for it on the L3 page.`}); continue; }
    const a = sub.ips.find(x => !x.secondary), nb = (sub.ospfUp || [])[0] || null;
    let far = L.pw.far, farIf = '';
    if (far && L.pw.farIf){ const fd = R.devices.get(far), fs = fd && fd.ifs.get(ifKey(L.pw.farIf.split('.')[0] + '.' + suffix)); if (fs) farIf = fs.name; }
    const byNbr = nb ? ipIndex.get(nb.addr) || ipIndex.get(nb.rid) : null;
    if (byNbr && far && byNbr !== far) problems.push({sev: 'warn', dev: c.name, msg: `${sub.name}: OSPF neighbour ${nb.rid} belongs to ${byNbr}, but the pseudowire leads to ${far}.`});
    if (!far && byNbr) far = byNbr;
    list.push({dev: c.name, if: sub.name, far: far || '', farIf, subnet: a ? n2ip(netOf(a.ip, a.len)) + '/' + a.len : '', ip: a ? a.ip : '', nbr: nb, vrf: sub.vrf || '', tl: L.pw.tl, vcid: L.pw.vcid});
  }
  return {list, problems, suffix};
}

function analyze(parsed, opts = {}){
  const inv = opts.inventory || new Map(), sites = opts.sites || parseSites(DEFAULT_SITES);
  const problems = [], P = (sev, dev, msg) => problems.push({sev, dev: dev || '', msg});
  const devs = new Map();
  const invSites = new Set([...inv.keys()].map(n => (parseHost(n) || {}).site).filter(Boolean));
  const mkDev = (name, extra) => {
    const h = parseHost(name), i = inv.get(name);
    const d = {name, host: h, role: h ? h.role : '', site: h ? h.site : '', floor: h ? h.floor : '', unit: h ? h.unit : '',
      data: null, inv: i || null, ip: i ? i.ip : '', model: i ? i.model : '', vendor: i ? i.vendor : '', external: false, end: h ? END_ROLES.has(h.role) : false, ifs: new Map()};
    Object.assign(d, extra || {}); devs.set(name, d); return d;
  };
  // devices with files
  const seen = new Map();
  for (const p of parsed){
    if (seen.has(p.name)){ P('warn', p.name, `Two files for the same device (${seen.get(p.name)} and ${p.file}) — the second one was used.`); }
    seen.set(p.name, p.file);
    const d = devs.get(p.name) || mkDev(p.name);
    d.data = p;
    if (!d.host) P('warn', p.name, `File "${p.file}": the name does not follow the hostname format, so its site and layer are unknown.`);
    if (p.cfgHost && p.cfgHost !== p.name) P('warn', p.name, `File "${p.file}" contains the config of ${p.cfgHost} (hostname line).`);
    if (p.prompt && p.prompt.toUpperCase() !== p.name && !(p.cfgHost && p.prompt.toUpperCase() === p.cfgHost)) P('warn', p.name, `File "${p.file}": the prompt is ${p.prompt}, not ${p.name}.`);
    if (!p.run) P('warn', p.name, 'No running config found in the file.');
    if (inv.size && !inv.has(p.name)) P('warn', p.name, 'Device file is not in the inventory.');
    for (const c of p.invalid) P('info', p.name, `"${c}" returned an error on this device and was skipped.`);
    if (d.end) P('info', p.name, 'End node (console server / voice gateway): its file was not needed and only its name is used.');
    // interface table: config + show interfaces description + brief
    if (p.run) for (const [k, i] of p.run.ifs) d.ifs.set(k, i);
    for (const [k, v] of p.desc){ let i = d.ifs.get(k); if (!i){ i = newIf(v.name); d.ifs.set(k, i); } if (!i.desc && v.desc) i.desc = v.desc; i.status = v.status; i.proto = v.proto; }
    for (const [k, v] of p.brief){ const i = d.ifs.get(k); if (i){ if (!i.status) i.status = v.status; if (!i.proto) i.proto = v.proto; } }
    for (const i of d.ifs.values()) if (i.status === 'admin down') i.shut = true;
    if (d.model && d.host){
      const M = d.model.toUpperCase(), r = d.role;
      const ok = r === 'TL' ? /ASR|ISR|NCS|C8\d{2}/.test(M) : r === 'CL' || r === 'DL' ? /C9[45]|C68|N[379]K|N9K|NEXUS|C45/.test(M) : r === 'AS' ? /C9[23]|C38|C29|C36|EX\d/.test(M) : r === 'ACS' ? /ACS|AVOCENT|OPENGEAR/.test(M) : true;
      if (!ok) P('info', d.name, `Model ${d.model} is unusual for a ${r} device — check the hostname or the inventory.`);
    }
  }
  // inventory devices without a file
  for (const [n, i] of inv){
    if (devs.has(n)) continue;
    const d = mkDev(n);
    if (!d.end) P('warn', n, 'In the inventory but no file was loaded — drawn greyed.');
  }
  // which devices count as "known"; sites that have at least one file are drawn as local sites
  const known = new Set(devs.keys());
  const loadedSites = new Set([...devs.values()].filter(d => d.data && d.site).map(d => d.site));
  // IP → device index
  const ipIndex = new Map();
  for (const d of devs.values()){
    if (d.ip) ipIndex.set(d.ip, d.name);
    for (const i of d.ifs.values()) for (const a of i.ips) if (!ipIndex.has(a.ip) || /^lo/i.test(i.name)) ipIndex.set(a.ip, d.name);
  }
  const external = (name, why) => {
    if (devs.has(name)) return devs.get(name);
    const h = parseHost(name);
    if (h && inv.size && invSites.has(h.site)){ return null; }       // same site as the inventory but not in it → stale
    const d = mkDev(name, {external: !(h && loadedSites.has(h.site))});
    known.add(name); return d;
  };
  const resolveName = (name, ip) => {
    let n = name ? cleanName(name) : '';
    if (n && devs.has(n)) return n;
    if (ip && ipIndex.has(ip)) return ipIndex.get(ip);
    if (n && parseHost(n)) return n;
    if (n) return n;
    return ip ? 'IP ' + ip : '';
  };

  const portInfo0 = (dev, intf) => { const d = devs.get(dev); return d && intf ? d.ifs.get(ifKey(intf)) || null : null; };
  /* ---- claims: what each port says about its far end ---- */
  const claims = new Map();
  const claim = (dev, intf, peer, peerIf, src, extra) => {
    if (!dev || !intf || !peer || peer === dev) return;
    const k = dev + '|' + ifKey(intf);
    let c = claims.get(k); if (!c){ c = {dev, if: ifShort(intf), list: []}; claims.set(k, c); }
    c.list.push({peer, peerIf: peerIf ? ifShort(peerIf) : '', src, extra: extra || {}});
  };
  const subnets = new Map(), pwLinks = [], logical = [];
  for (const d of devs.values()){
    const p = d.data; if (!p) continue;
    // /31 (and /30) subnets
    for (const i of d.ifs.values()) for (const a of i.ips){
      if (a.secondary || (a.len !== 31 && a.len !== 30) || /^(lo|vl|tu|bdi)/i.test(i.name)) continue;
      const key = (i.vrf || '') + '|' + n2ip(netOf(a.ip, a.len)) + '/' + a.len;
      const list = subnets.get(key) || []; list.push({dev: d.name, i, ip: a.ip, len: a.len}); subnets.set(key, list);
    }
    // descriptions
    for (const i of d.ifs.values()){
      const pd = parseDesc(i.desc, known); i.pdesc = pd; if (!pd) continue;
      if (pd.kind === 'pwire' && pd.empty) continue;
      if (pd.kind === 'pwire' && pd.pw){
        const w = pd.pw;
        // the described port attaches to the local-side device; the far side is reached through the remote TL
        const local = [w.a, w.b].find(x => x !== d.name && (devs.get(x) || {}).site === d.site) || w.a;
        const localPort = local === w.a ? w.ap : w.bp, far = local === w.a ? w.b : w.a, farPort = local === w.a ? w.bp : w.ap;
        claim(d.name, i.name, local, localPort, 'pwire', {pw: w});
        logical.push({kind: 'pwire', from: d.name, fromIf: i.name, via: w.via, viaIf: w.vp, far, farIf: farPort, local, localIf: localPort});
        for (const n of [w.a, w.b, w.via]) if (!devs.has(n)) external(n);
        continue;
      }
      if (!['uplink','circuit'].includes(pd.kind)) continue;
      const tgt = pd.hosts.find(h => h.name !== d.name);
      if (!tgt) continue;
      let peer = devs.get(tgt.name) ? tgt.name : null;
      if (!peer){ const e = external(tgt.name); if (e) peer = e.name; else { P('warn', d.name, `${i.name}: description names ${tgt.name}, which is not in the inventory (old or decommissioned?) — not drawn.`); i.stale = tgt.name; continue; } }
      claim(d.name, i.name, peer, tgt.port, 'desc', {kind: pd.kind, carrier: pd.carrier, cid: pd.cid, speed: pd.speed, desc: pd.raw});
    }
    // CDP / LLDP
    for (const [src, list] of [['cdp', p.cdp], ['lldp', p.lldp]]) for (const n of list){
      let peer = resolveName(n.name, n.ip); if (!peer) continue;
      if (!parseHost(peer) && !devs.has(peer)){
        const i = d.ifs.get(ifKey(n.local)) || (d.ifs.set(ifKey(n.local), newIf(n.local)), d.ifs.get(ifKey(n.local)));
        const pdl = i.pdesc || parseDesc(i.desc, known);
        // carrier CPE (on a CIRCUIT port), phone, AP, MAC-only neighbour: note it on the port, don't draw it.
        // Anything else that answers CDP/LLDP with a name (e.g. a VPN router with a non-standard name) is drawn as an "other" device of this site.
        const junk = /^(SEP|AP|AIR|ATA)[0-9A-F]|^[0-9A-F]{4}\.[0-9A-F]{4}\.[0-9A-F]{4}$|^[0-9A-F]{12}$|^IP /i.test(peer) || /phone|AIR-|\bAP\b|CAP\d/i.test(n.platform || '');
        if ((pdl && pdl.kind === 'circuit') || junk || d.end || !/[A-Z]/.test(peer)){ i.cpe = n.name + (n.remote ? ' ' + n.remote : ''); continue; }
        if (!devs.has(peer)){ mkDev(peer, {site: d.site, other: true, model: n.platform || ''}); known.add(peer); }
      }
      if (!devs.has(peer)){ const e = external(peer); if (!e){ P('warn', d.name, `${n.local}: ${src.toUpperCase()} sees ${peer}, which is not in the inventory.`); continue; } }
      const pd = devs.get(peer); if (pd && n.platform && !pd.model) pd.model = n.platform;
      if (pd && n.ip && !pd.ip) pd.ip = n.ip;
      claim(d.name, n.local, peer, /^[0-9a-f]{4}\.[0-9a-f]{4}\.[0-9a-f]{4}$/i.test(n.remote) ? '' : n.remote, src, {platform: n.platform});
    }
    // OSPF neighbours (show)
    for (const n of p.ospfNbr){
      const peer = ipIndex.get(n.addr) || (ipIndex.get(n.rid) || null);
      const i = d.ifs.get(ifKey(n.intf)); if (i) (i.ospfUp = i.ospfUp || []).push(n);
      if (peer) claim(d.name, n.intf, peer, '', n.state === 'FULL' ? 'ospf' : 'ospf-down', {state: n.state});
    }
  }
  for (const [key, list] of subnets){
    const ds = new Set(list.map(x => x.dev));
    if (list.length === 2 && ds.size === 2){
      const [a, b] = list;
      claim(a.dev, a.i.name, b.dev, b.i.name, 'subnet', {subnet: key.split('|')[1]});
      claim(b.dev, b.i.name, a.dev, a.i.name, 'subnet', {subnet: key.split('|')[1]});
    } else if (list.length > 2) P('warn', list[0].dev, `Subnet ${key.split('|')[1]}${key.split('|')[0] ? ' (VRF ' + key.split('|')[0] + ')' : ''} is configured on ${list.length} interfaces: ${list.map(x => x.dev + ' ' + x.i.name).join(', ')}.`);
    else if (list.length === 1){
      const x = list[0]; x.i.oneSided = key.split('|')[1];
    }
  }
  // xconnect / pseudowires (TL ↔ TL)
  const pwEnds = [];
  for (const d of devs.values()){
    const p = d.data; if (!p || !p.run) continue;
    for (const i of d.ifs.values()) for (const x of i.xc) pwEnds.push({dev: d.name, ac: i.name, svc: x.svc, peer: x.peer, vcid: x.vcid});
    for (const ctxt of p.run.l2vpn){
      const pwm = ctxt.members.find(m => /^pseudowire/i.test(m.name)), ac = ctxt.members.find(m => !/^pseudowire/i.test(m.name));
      const pw = pwm && p.run.pws.get(pwm.name.toLowerCase());
      if (pw && pw.peer) pwEnds.push({dev: d.name, ac: ac ? ifShort(ac.name) : '', svc: ac ? ac.svc : null, peer: pw.peer, vcid: pw.vcid, ctx: ctxt.name});
    }
  }
  const pwDone = new Set();
  for (const e of pwEnds){
    const acIf = devs.get(e.dev).ifs.get(ifKey(e.ac)), pwd = acIf && acIf.pdesc && acIf.pdesc.kind === 'pwire' && acIf.pdesc.pw;
    if (!ipIndex.get(e.peer) && pwd && pwd.via){ external(pwd.via); if (devs.has(pwd.via)){ ipIndex.set(e.peer, pwd.via); if (!devs.get(pwd.via).ip) devs.get(pwd.via).ip = e.peer; } }
    e.farPort = pwd ? pwd.vp : '';
    const peerDev = ipIndex.get(e.peer) || null, k = [e.dev, peerDev || e.peer].sort().join('~') + '#' + e.vcid;
    if (pwDone.has(k)) continue; pwDone.add(k);
    const d = devs.get(e.dev), sh = d.data.xc.find(x => x.vcid === e.vcid && x.peer === e.peer);
    const other = pwEnds.find(o => o !== e && o.vcid === e.vcid && o.dev === peerDev);
    let peer = peerDev;
    if (!peer){ peer = 'PW peer ' + e.peer; if (!devs.has(peer)) mkDev(peer, {external: true, role: 'TL'}); }
    const state = sh ? sh.state : null, ldpOk = d.data.ldp.size ? d.data.ldp.has(e.peer) || [...d.data.ldp].some(x => ipIndex.get(x) === peerDev) : null;
    pwLinks.push({a: e.dev, aIf: e.ac + (e.svc ? '.' + e.svc : ''), b: peer, bIf: other ? other.ac + (other.svc ? '.' + other.svc : '') : e.farPort || '', vcid: e.vcid, state, peerIp: e.peer, ldpOk});
    if (state && state !== 'UP') P('warn', e.dev, `Pseudowire ${e.vcid} to ${peer} is ${state}.`);
    if (ldpOk === false) P('warn', e.dev, `Pseudowire ${e.vcid}: no LDP session to ${e.peer}.`);
    if (!peerDev) P('info', e.dev, `Pseudowire ${e.vcid} goes to ${e.peer}, which does not match any loaded device, inventory IP or PWIRE/PW description.`);
  }

  /* ---- CDP through a pseudowire ----
     An xconnect carries CDP frames end to end, so a core switch's CDP can name the core switch at the other site,
     while LLDP on the same port names the local TL (the real cable). A sighting between two non-TL devices at
     different sites, on a port that is not a CIRCUIT, is therefore the logical neighbour across the pseudowire. */
  const crossCore = (a, b) => { const x = devs.get(a), y = devs.get(b); return x && y && x.site && y.site && x.site !== y.site && x.host && y.host && x.role !== 'TL' && y.role !== 'TL'; };
  const thruPw = [];
  for (const [k, c] of [...claims]){
    if (/\|pw$/.test(k) || !isPhys(c.if)) continue;
    const i = devs.get(c.dev).ifs.get(ifKey(c.if)), isCirc = i && i.pdesc && i.pdesc.kind === 'circuit';
    if (isCirc) continue;
    const moved = c.list.filter(x => x.src === 'cdp' && crossCore(c.dev, x.peer));
    if (!moved.length) continue;
    c.list = c.list.filter(x => !moved.includes(x));
    const pk = k + '|pw'; let pc = claims.get(pk); if (!pc){ pc = {dev: c.dev, if: c.if, list: [], pw: true}; claims.set(pk, pc); }
    pc.list.push(...moved);
    for (const x of moved) thruPw.push({dev: c.dev, if: c.if, peer: x.peer, peerIf: x.peerIf, src: x.src});
    if (!c.list.length) claims.delete(k);
  }
  const thruPwOn = (dev, intf) => thruPw.find(t => t.dev === dev && samePort(t.if, intf));

  /* ---- each port: pick its neighbour ---- */
  const halves = new Map();
  for (const [k, c] of claims){
    const byPeer = new Map();
    for (const x of c.list){ const s = byPeer.get(x.peer) || {peer: x.peer, score: 0, srcs: new Set(), peerIf: '', extras: []}; s.score = Math.max(s.score, WEIGHT[x.src] || 0); s.srcs.add(x.src); s.extras.push(x); byPeer.set(x.peer, s); }
    const ranked = [...byPeer.values()].sort((a, b) => b.score - a.score), best = ranked[0];
    for (const pr of ['lldp', 'cdp', 'subnet', 'desc', 'pwire']){ const x = best.extras.find(e => e.src === pr && e.peerIf); if (x){ best.peerIf = x.peerIf; break; } }
    for (const other of ranked.slice(1)){
      if (other.srcs.has('desc') && [...best.srcs].some(s => SHOW_SRC.has(s) || s === 'subnet'))
        P('warn', c.dev, `${c.if}: description says ${other.peer}, but ${[...best.srcs].filter(s => s !== 'desc').join('/').toUpperCase()} shows ${best.peer} — description looks out of date.`);
      else P('info', c.dev, `${c.if}: more than one neighbour (${ranked.map(r => r.peer).join(', ')}); ${best.peer} was used.`);
    }
    halves.set(k, {dev: c.dev, if: c.if, peer: best.peer, peerIf: best.peerIf, srcs: best.srcs, extras: best.extras, used: false, pw: !!c.pw});
  }
  const links = [];
  const halfOf = (dev, intf) => halves.get(dev + '|' + ifKey(intf));
  for (const h of halves.values()){
    if (h.used) continue; h.used = true;
    const opposite = h.peerIf && !h.pw ? halfOf(h.peer,h.peerIf) : null;
    if (opposite && opposite.peer !== h.dev){
      const strength = s => Math.max(0,...[...s].map(x => WEIGHT[x] || 0));
      if (strength(opposite.srcs) >= strength(h.srcs)) continue;
      opposite.used = true;
    }
    let partner = null;
    if (h.peerIf){ const p = halfOf(h.peer, h.peerIf); if (p && !p.used && p.peer === h.dev && !h.pw === !p.pw) partner = p; }
    if (!partner){
      const cand = [...halves.values()].filter(p => !p.used && p.dev === h.peer && p.peer === h.dev && !h.pw === !p.pw && (!p.peerIf || samePort(p.peerIf, h.if)));
      const exact = cand.filter(p => p.peerIf && samePort(p.peerIf, h.if));
      if (exact.length === 1) partner = exact[0];
      else if (cand.length === 1 && (!h.peerIf || samePort(cand[0].if, h.peerIf))) partner = cand[0];
    }
    const L = {a: {dev: h.dev, if: h.if}, b: {dev: h.peer, if: h.peerIf || ''}, srcs: new Set(h.srcs), extras: [...h.extras]};
    if (partner){
      partner.used = true;
      if (partner.peerIf && !samePort(partner.peerIf, h.if)) P('warn', h.dev, `${h.if} ↔ ${h.peer} ${partner.if}: the two ends disagree about the ports (${partner.dev} says ${partner.peerIf}).`);
      L.b.if = partner.if; for (const s of partner.srcs) L.srcs.add(s); L.extras.push(...partner.extras);
      L.twoSided = true;
    }
    links.push(L);
  }

  /* ---- port-channels: fold member links into one bundle ---- */
  const poOf = (dev, intf) => {
    const d = devs.get(dev); if (!d || !intf) return null;
    if (/^po\d/i.test(intf)) return ifShort(intf);
    const i = d.ifs.get(ifKey(intf)); if (i && i.chan) return i.chan;
    if (d.data) for (const g of d.data.po) if (g.members.some(m => ifKey(m.name) === ifKey(intf))) return g.po;
    return null;
  };
  const bundles = new Map(), plain = [];
  for (const L of links){
    const pa = poOf(L.a.dev, L.a.if), pb = poOf(L.b.dev, L.b.if);
    if (!pa && !pb){ plain.push(L); continue; }
    const ea = {dev: L.a.dev, po: pa, port: L.a.if}, eb = {dev: L.b.dev, po: pb, port: L.b.if};
    const [x, y] = [ea, eb].sort((p, q) => (p.po ? 0 : 1) - (q.po ? 0 : 1) || p.dev.localeCompare(q.dev));
    const k = x.dev + '|' + x.po + '~' + y.dev;
    let B = bundles.get(k); if (!B){ B = {a: {dev: x.dev, if: x.po}, b: {dev: y.dev, if: ''}, srcs: new Set(), extras: [], members: [], bundle: true, twoSided: false}; bundles.set(k, B); }
    if (y.po && !B.b.if) B.b.if = y.po;
    for (const s of L.srcs) B.srcs.add(s); B.extras.push(...L.extras); B.twoSided = B.twoSided || L.twoSided;
    if (!/^po\d/i.test(x.port) || !/^po\d/i.test(y.port)) B.members.push([x.port, y.port]);
  }
  // a Po that is bundled on one device only (other end has the same peer but no Po): keep as bundle on that side
  const parentIf = n => String(n || '').split('.')[0];
  const subGroups = new Map(), flat = [];
  for (const L of plain){
    if (!/\./.test(L.a.if) && !/\./.test(L.b.if)){ flat.push(L); continue; }
    const k = L.a.dev + '|' + ifKey(parentIf(L.a.if)) + '~' + L.b.dev + '|' + ifKey(parentIf(L.b.if));
    let G = subGroups.get(k);
    if (!G){ G = {a: {dev: L.a.dev, if: parentIf(L.a.if)}, b: {dev: L.b.dev, if: parentIf(L.b.if)}, srcs: new Set(), extras: [], subs: [], twoSided: false}; subGroups.set(k, G); }
    for (const s of L.srcs) G.srcs.add(s); G.extras.push(...L.extras); G.twoSided = G.twoSided || L.twoSided;
    G.subs.push(L.a.if.includes('.') ? L.a.if.split('.')[1] : L.b.if.split('.')[1]);
  }
  for (const G of subGroups.values()){ if (G.subs.length === 1){ G.a.if += '.' + G.subs[0]; if (G.b.if && !G.b.if.includes('.')) G.b.if += '.' + G.subs[0]; } flat.push(G); }
  // a CDP/LLDP sighting on the parent port of a subinterface group is the same link: fold it in
  for (const G of subGroups.values()) if (G.subs.length > 1) for (let i = flat.length - 1; i >= 0; i--){
    const L = flat[i]; if (L === G || L.subs) continue;
    const same = (L.a.dev === G.a.dev && ifKey(parentIf(L.a.if)) === ifKey(G.a.if) && L.b.dev === G.b.dev) ? L.b.if
      : (L.b.dev === G.a.dev && ifKey(parentIf(L.b.if)) === ifKey(G.a.if) && L.a.dev === G.b.dev) ? L.a.if : null;
    if (same === null) continue;
    for (const x of L.srcs) G.srcs.add(x); G.extras.push(...L.extras); if (!G.b.if && same) G.b.if = parentIf(same); flat.splice(i, 1);
  }
  const all = [...flat, ...bundles.values()];
  for (const B of bundles.values()){
    if (!B.b.if) B.b.if = B.members.length ? B.members.map(m => m[1]).filter(Boolean).join(', ') : '';
    const cfgCount = (dev, po) => { const d = devs.get(dev); if (!d || !d.data) return null; let n = 0; for (const i of d.ifs.values()) if (i.chan && ifKey(i.chan) === ifKey(po)) n++; if (!n) for (const g of d.data.po) if (ifKey(g.po) === ifKey(po)) n = g.members.length; return n || null; };
    const na = /^po/i.test(B.a.if) ? cfgCount(B.a.dev, B.a.if) : null, nb = /^po/i.test(B.b.if) ? cfgCount(B.b.dev, B.b.if) : null;
    B.memberCount = Math.max(na || 0, nb || 0, B.members.length);
    if (na && nb && na !== nb) P('warn', B.a.dev, `${B.a.if} ↔ ${B.b.dev} ${B.b.if}: ${na} member port${na > 1 ? 's' : ''} on one side, ${nb} on the other.`);
    for (const [dev, po] of [[B.a.dev, B.a.if], [B.b.dev, B.b.if]]){
      const d = devs.get(dev); if (!d || !d.data) continue;
      const g = d.data.po.find(x => ifKey(x.po) === ifKey(po)); if (!g) continue;
      if (g.members.length && g.members.every(m => m.flag === 'P')) B.srcs.add('po-up');
      const bad = g.members.filter(m => m.flag !== 'P'); if (bad.length) P('warn', dev, `${po}: member${bad.length > 1 ? 's' : ''} ${bad.map(m => m.name + '(' + m.flag + ')').join(', ')} not bundled.`);
      if (!/U/.test(g.flags)) P('warn', dev, `${po} is not in use (flags ${g.flags}).`);
    }
  }
  for (const W of pwLinks){
    const L = {a: {dev: W.a, if: W.aIf}, b: {dev: W.b, if: W.bIf}, srcs: new Set(['xconnect']), extras: [], pw: W, twoSided: !!W.bIf};
    if (W.state === 'UP') L.srcs.add('xc-up');
    all.push(L);
  }

  /* ---- physical cables (L1/L2 page) ----
     One entry per cable, on physical ports only (no port-channels, SVIs, subinterfaces, tunnels).
     Evidence: LLDP and CDP (preferred), then /31 on a routed port, then descriptions. When a description
     disagrees with LLDP/CDP about the port, LLDP/CDP win and the description is reported as out of date. */
  const phys = [];
  {
    const PW_ = {lldp: 6, cdp: 5, subnet: 4, desc: 2, pwire: 2};
    const ph = new Map();
    for (const [k, c] of claims){
      if (c.pw || !isPhys(c.if)) continue;
      const list = c.list.filter(x => PW_[x.src] && !(x.src === 'subnet' && thruPwOn(c.dev,c.if)) && !(x.src === 'desc' && x.extra.kind !== 'circuit' && crossCore(c.dev, x.peer)));
      if (!list.length) continue;
      const by = new Map();
      for (const x of list){ const e = by.get(x.peer) || {peer: x.peer, score: 0, srcs: new Set(), extras: []}; e.score = Math.max(e.score, PW_[x.src]); e.srcs.add(x.src); e.extras.push(x); by.set(x.peer, e); }
      const best = [...by.values()].sort((a, b) => b.score - a.score)[0];
      let peerIf = '', portSrc = '';
      for (const pr of ['lldp', 'cdp', 'subnet', 'desc', 'pwire']){ const x = best.extras.find(e => e.src === pr && e.peerIf); if (x){ peerIf = x.peerIf; portSrc = pr; break; } }
      // the description named a different port than LLDP/CDP did
      const dx = best.extras.find(e => (e.src === 'desc' || e.src === 'pwire') && e.peerIf);
      if (dx && (portSrc === 'lldp' || portSrc === 'cdp') && !samePort(dx.peerIf, peerIf))
        P('warn', c.dev, `${c.if}: description says ${best.peer} ${dx.peerIf}, but ${portSrc.toUpperCase()} shows ${best.peer} ${peerIf} — description looks out of date (left over from an old device?).`);
      ph.set(k, {dev: c.dev, if: c.if, peer: best.peer, peerIf, portSrc, srcs: best.srcs, extras: best.extras, used: false});
    }
    const halfP = (dev, intf) => ph.get(dev + '|' + ifKey(intf));
    const seenWarn = new Set();
    for (const h of ph.values()){
      if (h.used) continue; h.used = true;
      const opposite = h.peerIf ? halfP(h.peer,h.peerIf) : null;
      if (opposite && opposite.peer !== h.dev){
        const strength = s => Math.max(0,...[...s].map(x => PW_[x] || 0));
        P('warn',h.dev,`${h.if}: conflicting endpoint evidence on ${h.peer} ${h.peerIf}; the stronger observation is used.`);
        if (strength(opposite.srcs) >= strength(h.srcs)) continue;
        opposite.used = true;
      }
      let partner = null;
      if (h.peerIf){ const q = halfP(h.peer, h.peerIf); if (q && !q.used && q.peer === h.dev) partner = q; }
      if (!partner){
        const pool = [...ph.values()].filter(q => !q.used && q.dev === h.peer && q.peer === h.dev);
        const exact = pool.filter(q => q.peerIf && samePort(q.peerIf, h.if));
        const loose = pool.filter(q => !q.peerIf && (!h.peerIf || samePort(q.if, h.peerIf)));
        partner = exact.length === 1 ? exact[0] : !exact.length && loose.length === 1 ? loose[0] : null;
      }
      const L = {a: {dev: h.dev, if: h.if}, b: {dev: h.peer, if: h.peerIf}, srcs: new Set(h.srcs), extras: [...h.extras], twoSided: false};
      if (partner){
        partner.used = true; L.twoSided = true;
        for (const x of partner.srcs) L.srcs.add(x); L.extras.push(...partner.extras);
        // trust the side whose port name came from LLDP/CDP
        const strong = x => x === 'lldp' || x === 'cdp';
        if (h.peerIf && !samePort(h.peerIf, partner.if)){
          const k = [h.dev, h.if, partner.dev, partner.if].join('|');
          if (strong(h.portSrc) && !strong(partner.portSrc)) L.b.if = h.peerIf;
          else { L.b.if = partner.if; }
          if (!seenWarn.has(k) && !(strong(h.portSrc) && strong(partner.portSrc))){ seenWarn.add(k);
            const [w, r] = strong(h.portSrc) ? [partner, h] : [h, partner];
            P('warn', w.dev, `${w.if}: description says ${w.peer} ${w.peerIf || '?'}, but ${r.portSrc.toUpperCase()} on ${r.dev} shows the cable on ${w.peer} ${strong(h.portSrc) ? h.peerIf : partner.if} — description looks out of date (left over from an old device?).`); }
        } else L.b.if = partner.if;
        if (partner.peerIf && !samePort(partner.peerIf, h.if) && strong(partner.portSrc) && !strong(h.portSrc)) L.a.if = partner.peerIf;
      }
      phys.push(L);
    }
    // CIRCUIT ports with no named far end: draw the circuit to a small greyed box
    for (const d of devs.values()){
      if (!d.data) continue;
      for (const i of d.ifs.values()){
        if (!isPhys(i.name) || !i.pdesc || i.pdesc.kind !== 'circuit') continue;
        if (phys.some(L => (L.a.dev === d.name && samePort(L.a.if, i.name)) || (L.b.dev === d.name && samePort(L.b.if, i.name)))) continue;
        phys.push({a: {dev: d.name, if: i.name}, b: {dev: null, if: '', label: [i.pdesc.carrier || 'Circuit', i.pdesc.cid].filter(Boolean).join('\n')}, srcs: new Set(['desc']), extras: [], twoSided: false});
      }
    }
    // annotate each cable
    const xcPort = (dev, intf) => { const d = devs.get(dev); if (!d || !d.data) return null; const i = d.ifs.get(ifKey(intf)); if (i && i.xc.length) return i.xc[0];
      if (d.data.run) for (const c of d.data.run.l2vpn){ const ac = c.members.find(m => !/^pseudowire/i.test(m.name) && samePort(m.name, intf)); if (ac){ const pwm = c.members.find(m => /^pseudowire/i.test(m.name)), pw = pwm && d.data.run.pws.get(pwm.name.toLowerCase()); if (pw) return pw; } }
      return null; };
    for (const L of phys){
      const ia = portInfo0(L.a.dev, L.a.if), ib = L.b.dev ? portInfo0(L.b.dev, L.b.if) : null;
      const sp = [portSpeed(L.a.if), portSpeed(L.b.if)].filter(Boolean).sort((x, y) => spN(x) - spN(y));
      L.speed = sp[0] || (ia && ia.speed && /^\d+$/.test(ia.speed) ? (+ia.speed >= 1000 ? +ia.speed / 1000 + 'G' : ia.speed + 'M') : '');
      const pd = [ia && ia.pdesc, ib && ib.pdesc].find(x => x && x.kind === 'circuit');
      L.circuit = pd ? {carrier: pd.carrier, cid: pd.cid, speed: pd.speed} : null;
      L.poA = ia && ia.chan || null; L.poB = ib && ib.chan || null;
      for (const [dv, pi, set] of [[L.a.dev, L.a.if, 'poA'], [L.b.dev, L.b.if, 'poB']]){ const d = devs.get(dv); if (!L[set] && d && d.data) for (const g of d.data.po) if (g.members.some(m => samePort(m.name, pi))) L[set] = g.po; }
      const shut = (ia && ia.shut) || (ib && ib.shut);
      const down = !shut && ((ia && (ia.status === 'down' || ia.proto === 'down')) || (ib && (ib.status === 'down' || ib.proto === 'down')));
      L.state = shut ? 'shut' : down ? 'down' : (ia && ia.status === 'up') || (ib && ib.status === 'up') || [...L.srcs].some(x => x === 'cdp' || x === 'lldp') ? 'up' : 'unknown';
      const da = devs.get(L.a.dev), db = L.b.dev ? devs.get(L.b.dev) : null;
      L.endNode = !!((da && da.end) || (db && db.end));
      const hasShow = L.srcs.has('cdp') || L.srcs.has('lldp'), hasCfg = L.srcs.has('desc') || L.srcs.has('pwire') || L.srcs.has('subnet');
      L.confidence = hasShow && hasCfg ? 'confirmed' : hasShow ? (L.endNode || (db && db.other) ? 'confirmed' : 'seen') : 'unverified';
      // a cable from a TL port that carries a pseudowire
      for (const [tl, tp, cr, cp] of [[L.a.dev, L.a.if, L.b.dev, L.b.if], [L.b.dev, L.b.if, L.a.dev, L.a.if]]){
        if (!tl) continue;
        const x = xcPort(tl, tp), ti = portInfo0(tl, tp), pwd = ti && ti.pdesc && ti.pdesc.kind === 'pwire' ? ti.pdesc.pw : null;
        if (!x && !pwd) continue;
        const t = cr ? thruPwOn(cr, cp) : null, w = logical.find(w => w.from === tl && samePort(w.fromIf, tp));
        const pl = pwLinks.find(q => (q.a === tl && samePort(String(q.aIf).split('.')[0], tp)) || (q.b === tl && samePort(String(q.bIf).split('.')[0], tp)));
        L.pw = {tl, tlIf: tp, core: cr, coreIf: cp, vcid: x ? x.vcid : pl ? pl.vcid : '', far: t ? t.peer : w ? w.far : '', farIf: t ? t.peerIf : w ? w.farIf : '', farFrom: t ? t.src : w ? 'desc' : '',
          peerTl: pl ? (pl.a === tl ? pl.b : pl.a) : pwd ? pwd.via : ''};
        if (w && cr && (w.local !== cr || !samePort(w.localIf, cp))){ w.realLocal = cr; w.realLocalIf = cp; }
        if (t && w && w.far !== t.peer) P('warn', tl, `${tp}: PWIRE/PW description says the far end is ${w.far}, but CDP on ${cr} ${cp} sees ${t.peer} through the pseudowire.`);
        break;
      }
    }
    // the description of the PW attachment port may name an old local port: correct it from the cable
    for (const w of logical) if (w.realLocal){ w.local = w.realLocal; w.localIf = w.realLocalIf; }
  }

  /* ---- L3: one OSPF link over each pseudowire, on the baseline subinterface (.5 by default) ---- */
  for (const L of phys) if (L.pw && L.pw.far && !devs.has(L.pw.far)) external(L.pw.far);
  const pwo = pwOspfFor({devices: devs, phys}, opts.baseline || '5');
  const pwOspf = pwo.list; for (const p of pwo.problems) P(p.sev, p.dev, p.msg);

  /* ---- per-link state, kind, checks ---- */
  const pwPorts = new Set();
  for (const w of logical) for (const [dv, pi] of [[w.local, w.localIf], [w.far, w.farIf]]) if (dv && pi) pwPorts.add(dv + '|' + ifKey(parentIf(pi)));
  const onPw = (dv, pi) => pwPorts.has(dv + '|' + ifKey(parentIf(pi)));
  const portInfo = (dev, intf) => { const d = devs.get(dev); return d && intf ? d.ifs.get(ifKey(intf)) || null : null; };
  const out = [], seenOnly = new Map();
  for (const L of all){
    const ia = portInfo(L.a.dev, L.a.if), ib = portInfo(L.b.dev, L.b.if), da = devs.get(L.a.dev), db = devs.get(L.b.dev);
    const shut = (ia && ia.shut) || (ib && ib.shut);
    const down = !shut && ((ia && (ia.status === 'down' || ia.proto === 'down')) || (ib && (ib.status === 'down' || ib.proto === 'down')));
    L.state = shut ? 'shut' : down ? 'down' : (ia && ia.status === 'up') || (ib && ib.status === 'up') ? 'up' : 'unknown';
    if (L.pw) L.state = L.pw.state === 'UP' ? 'up' : L.pw.state ? 'down' : 'unknown';
    const desc = [ia && ia.pdesc, ib && ib.pdesc].filter(Boolean);
    const circuit = desc.find(x => x.kind === 'circuit') || L.extras.map(e => e.extra).find(e => e.kind === 'circuit');
    L.circuit = circuit ? {carrier: circuit.carrier, cid: circuit.cid, speed: circuit.speed} : null;
    const sub = L.extras.find(e => e.src === 'subnet');
    L.subnet = sub ? sub.extra.subnet : (ia && ia.oneSided) || (ib && ib.oneSided) || '';
    L.trunk = !!((ia && ia.trunk) || (ib && ib.trunk));
    L.cpe = (ia && ia.cpe) || (ib && ib.cpe) || '';
    L.endNode = !!((da && da.end) || (db && db.end));
    const interSite = da && db && da.site && db.site && da.site !== db.site;
    const crossCore = da && db && da.site !== db.site && da.role !== 'TL' && db.role !== 'TL';
    const viaPw = !L.pw && !L.srcs.has('pwire') && (onPw(L.a.dev, L.a.if) || onPw(L.b.dev, L.b.if) || (L.subs && L.subs.length > 1 && crossCore));
    const ospfOnly = [...L.srcs].every(x => x === 'ospf' || x === 'ospf-down');
    L.kind = ospfOnly ? 'ospf-adj' : L.pw ? 'pw' : L.srcs.has('pwire') ? 'pw-attach' : viaPw ? 'over-pw' : L.circuit ? 'circuit' : L.bundle ? 'bundle' : L.endNode ? 'endnode'
      : interSite && da.role !== 'TL' && db.role !== 'TL' && !L.circuit ? 'over-pw' : L.subnet ? 'routed' : L.trunk ? 'trunk' : 'link';
    const showData = [da, db].some(d => d && d.data && ['cdp', 'lldp', 'ospf', 'xc', 'po'].some(c => d.data.cmds.has(c)));
    const hasCfg = [...L.srcs].some(s => CFG_SRC.has(s)), hasShow = [...L.srcs].some(s => SHOW_SRC.has(s));
    L.confidence = L.endNode ? (hasShow ? 'confirmed' : 'unverified') : hasCfg && hasShow ? 'confirmed' : hasCfg ? (showData && !L.endNode && L.kind !== 'pw-attach' && db && !db.external ? 'config-only' : 'unverified') : 'seen';
    if (L.confidence === 'seen' && !L.endNode && L.state !== 'shut' && !['ospf-adj', 'over-pw'].includes(L.kind) && !(db && db.other)) (seenOnly.get(L.a.dev) || seenOnly.set(L.a.dev, []).get(L.a.dev)).push(L.a.if);
    if (L.confidence === 'config-only' && L.state !== 'shut' && L.kind !== 'over-pw') P('info', L.a.dev, `${L.a.if} ↔ ${L.b.dev} ${L.b.if || ''}: in the config but not seen by CDP/LLDP/OSPF.`);
    // one-way description
    if (L.srcs.has('desc') && !L.endNode && db && db.data && ib && !(ib.pdesc && ib.pdesc.hosts.some(h => h.name === L.a.dev)) && L.kind !== 'pw-attach')
      P('info', L.b.dev, `${L.b.if}: no description back to ${L.a.dev} (${L.a.if} describes this link).`);
    if (!L.twoSided && !L.endNode && db && db.data && !L.b.if && L.kind !== 'pw' && L.kind !== 'ospf-adj') P('info', L.a.dev, `${L.a.if} → ${L.b.dev}: far-end port not found.`);
    // OSPF both ends
    if (L.subnet && ia && ib && ia.ospf.enabled && ib.ospf.enabled){
      if ((ia.ospf.cost || null) !== (ib.ospf.cost || null)) P('warn', L.a.dev, `${L.a.if} ↔ ${L.b.dev} ${L.b.if}: OSPF cost ${ia.ospf.cost ?? 'auto'} vs ${ib.ospf.cost ?? 'auto'}.`);
      if (ia.ospf.areaN !== ib.ospf.areaN) P('warn', L.a.dev, `${L.a.if} ↔ ${L.b.dev} ${L.b.if}: OSPF area ${ia.ospf.areaN} vs ${ib.ospf.areaN}.`);
      if (ia.ospf.p2p !== ib.ospf.p2p) P('warn', L.a.dev, `${L.a.if} ↔ ${L.b.dev} ${L.b.if}: OSPF point-to-point set on one side only.`);
      if (!!ia.ospf.passive !== !!ib.ospf.passive) P('warn', L.a.dev, `${L.a.if} ↔ ${L.b.dev} ${L.b.if}: OSPF passive on one side only.`);
      L.cost = ia.ospf.cost || ib.ospf.cost || null; L.area = ia.ospf.areaN;
    }
    if (L.subnet && !L.twoSided && L.srcs.has('desc') && db && db.data) P('warn', L.a.dev, `${L.a.if}: /${L.subnet.split('/')[1]} ${L.subnet} found on this side only (${L.b.dev} has no matching address).`);
    out.push(L);
  }
  for (const [dv, ports] of seenOnly) P('info', dv, `${ports.length} link${ports.length > 1 ? 's were' : ' was'} found by CDP/LLDP only — no description on ${ports.join(', ')}.`);
  // OSPF configured but not up (needs show ip ospf neighbor)
  for (const d of devs.values()){
    if (!d.data || !d.data.cmds.has('ospf')) continue;
    for (const i of d.ifs.values()) if (i.ospf && i.ospf.enabled && !i.ospf.passive && !i.shut && i.status !== 'down' && !(i.vrf && !i.ospf.pid) && !/^lo/i.test(i.name) && i.ips.length && !(i.ospfUp || []).some(n => n.state === 'FULL'))
      P('warn', d.name, `${i.name}: OSPF is configured (not passive) but no FULL neighbour is shown.`);
  }
  // MAC hints for end nodes
  for (const L of out) if (L.endNode){
    const sw = devs.get(L.a.dev).end ? L.b : L.a, d = devs.get(sw.dev), m = d && d.data && d.data.mac.get(ifKey(sw.if));
    if (m && m.count <= 2) L.srcs.add('mac');
  }
  const order = {error: 0, warn: 1, info: 2};
  { const seenP = new Set(); for (let k = problems.length - 1; k >= 0; k--){ const key = problems[k].dev + '|' + problems[k].msg; if (seenP.has(key)) problems.splice(k, 1); else seenP.add(key); } }
  problems.sort((a, b) => order[a.sev] - order[b.sev] || a.dev.localeCompare(b.dev));
  return {devices: devs, links: out, phys, pwOspf, problems, sites, logical, inventory: inv};
}

/* ---------------- board builder ----------------
   Page layout rule (every page): top = data centres and remote (other-country) sites,
   upper = transport (TL), middle = core / distribution (CL, DL, AG, ML), bottom = access / server farm (AS, SF)
   and end nodes. Other sites in the same country sit on the left and right sides. */
const KIND = {TL: ['router', 'blue'], CL: ['l3switch', 'red'], DL: ['l3switch', 'orange'], AG: ['l3switch', 'yellow'], ML: ['l3switch', 'violet'],
  AS: ['switch', 'green'], ACS: ['console', 'grey'], VG: ['vgw', 'violet'], SF: ['switch', 'teal'], MX: ['switch', 'pink']};
const ROLE_NAME = {TL: 'Transport (TL)', CL: 'Core (CL)', DL: 'Distribution (DL)', AG: 'Aggregation (AG)', ML: 'MAN (ML)'};
const ROLE_ROW = {TL: 0, CL: 1, DL: 1, AG: 2, ML: 2, AS: 3, SF: 3, MX: 3, VG: 3, ACS: 3};

function mergeDevices(old, next){
  if (!old) return next;
  if (old.name !== next.name) throw Error('Only files for the same device can be merged.');
  const unique = list => [...new Map(list.map(x => [JSON.stringify(x),x])).values()];
  for (const key of ['desc','brief','status','interfaceDetails','vlans','mac']){old[key] ||= new Map();for (const [k,v] of next[key] || []) old[key].set(k,v);}
  for (const key of ['cdp','lldp','po','ospfNbr','xc','ospfProcesses','ospfInterfaces','portKinds']) old[key] = unique([...(old[key] || []),...(next[key] || [])]);
  if (next.run){
    if (!old.run) old.run = next.run;
    else {
      for (const [k,b] of next.run.ifs){
        const a = old.run.ifs.get(k);
        if (!a){old.run.ifs.set(k,b);continue;}
        for (const [field,v] of Object.entries(b)){
          if (field === 'ospf') Object.assign(a.ospf,Object.fromEntries(Object.entries(v).filter(([key,val]) => !['enabled','areaN','passive'].includes(key) && val != null && val !== false)));
          else if (Array.isArray(v)) a[field] = unique([...(a[field] || []),...v]);
          else if (field === 'shut'){if (b.shutSpecified) a.shut = v;}
          else if (typeof v === 'boolean'){if (v) a[field] = v;}
          else if (v != null && v !== '') a[field] = v;
        }
        if (b.mode){a.mode=b.mode;a.trunk=b.trunk;}
      }
      for (const p of next.run.ospf){
        const prior = old.run.ospf.find(x => x.pid === p.pid && normVrf(x.vrf) === normVrf(p.vrf));
        if (!prior) old.run.ospf.push(p);
        else {prior.networks=unique([...prior.networks,...p.networks]);prior.rid=p.rid || prior.rid;
          for (const key of ['passive','nonPassive']) for (const v of p[key]) prior[key].add(v);
          prior.passiveDefault ||= p.passiveDefault;}
      }
      for (const [k,v] of next.run.pws) old.run.pws.set(k,v);
      old.run.l2vpn = unique([...old.run.l2vpn,...next.run.l2vpn]);
      for (const v of next.run.vrfs) old.run.vrfs.add(v);
      old.run.hostname = next.run.hostname || old.run.hostname;
      old.run.lines += next.run.lines;
      finalizeConfig(old.run);
    }
  }
  for (const cmd of next.cmds) old.cmds.add(cmd);
  for (const v of next.ldp) old.ldp.add(v);
  old.invalid=unique([...old.invalid,...next.invalid]);old.unknownCmds=unique([...old.unknownCmds,...next.unknownCmds]);
  old.secretsRemoved += next.secretsRemoved;
  old.file=[...new Set(old.file.split(' + ').concat(next.file))].join(' + ');
  old.prompt ||= next.prompt;old.cfgHost ||= next.cfgHost;
  return old;
}

function parseRouterMap(text){
  const out = new Map();
  String(text || '').split(/\r?\n/).forEach((line, i) => {
    if (!line.trim() || /^\s*#/.test(line)) return;
    const m = /^\s*(\d+(?:\.\d+){3})\s*=\s*([A-Za-z0-9][A-Za-z0-9_-]{0,62})\s*$/.exec(line);
    if (!m || ip2n(m[1]) == null) throw Error('Peer mapping line ' + (i + 1) + ': use IP = HOSTNAME.');
    const host = m[2].toUpperCase();
    if (out.has(m[1]) && out.get(m[1]) !== host) throw Error('Conflicting peer mapping for ' + m[1]);
    out.set(m[1], host);
  });
  return out;
}
const normVrf = v => !v || /^(?:default|global)$/i.test(v) ? 'default' : v;
const normArea = a => a == null ? null : /^\d+$/.test(a) ? n2ip(+a) : String(a);
function ospfMetrics(R, dev, intf){
  const d = R.devices.get(dev), p = d?.ifs.get(ifKey(intf || ''));
  const shown = d?.data?.ospfInterfaces?.find(i => ifKey(i.name) === ifKey(intf || ''));
  return {cost: shown?.cost ?? p?.ospf?.cost ?? null, area: normArea(shown?.area ?? p?.ospf?.areaN ?? p?.ospf?.area),
    port: ifShort(intf || ''), vrf: normVrf(p?.vrf || shown?.vrf)};
}
function costLabel(a, b){
  if (a.cost != null && b.cost != null) return 'cost ' + (a.cost === b.cost ? a.cost : a.cost + ' / ' + b.cost);
  const one = a.cost != null ? a : b.cost != null ? b : null;
  return one ? 'cost ' + one.cost + ' (' + one.port + ')' : '';
}

/* Router identities are resolved conservatively: conflicting owners stay unresolved. */
function ospfRecords(R, opts = {}){
  const devices = [...R.devices.values()], identities = new Map(), inventory = new Map(), management = new Map(), addresses = new Map();
  const put = (map, key, host) => { if (key) (map.get(key) || map.set(key, new Set()).get(key)).add(host); };
  const manual = opts.routerMap instanceof Map ? opts.routerMap : new Map(Object.entries(opts.routerMap || {}));
  const scoped = (vrf, ip) => normVrf(vrf) + '|' + ip;
  for (const d of devices){
    if (d.inv?.ip) put(inventory, d.inv.ip, d.name);
    if (d.ip) put(management, d.ip, d.name);
    for (const p of [...(d.data?.ospfProcesses || []), ...(d.data?.run?.ospf || [])]) if (p.rid) put(identities, scoped(p.vrf, p.rid), d.name);
    for (const p of d.data?.ospfInterfaces || []) if (p.rid) put(identities, scoped(p.vrf, p.rid), d.name);
    for (const i of d.ifs.values()) for (const a of i.ips || []){
      put(addresses, scoped(i.vrf, a.ip), d.name);
      if (/^lo/i.test(i.name)) put(identities, scoped(i.vrf, a.ip), d.name);
    }
    for (const n of [...(d.data?.cdp || []), ...(d.data?.lldp || [])]){
      const peer = cleanName(n.name);
      if (n.ip && R.devices.has(peer)) put(management, n.ip, peer);
    }
  }
  const owner = (entries, me) => entries?.size === 1 && !entries.has(me) ? [...entries][0] : null;
  const out = [], problems = [], seen = new Set(), vrfFilter = opts.vrf ?? 'default';
  const suffix = String(opts.baseline || '5').replace(/^\./, ''), excluded = new Set(opts.excluded || []);
  for (const d of devices){
    // neighbours left out by the import filters, reported so a "missing" adjacency is explained
    const hidden = {vrf: new Map(), svi: [], sub: []};
    const note = () => {
      const list = (a, n = 4) => a.slice(0, n).join(', ') + (a.length > n ? ' …' : '');
      if (hidden.vrf.size) problems.push({sev: 'info', dev: d.name, msg: `${[...hidden.vrf.values()].reduce((a, b) => a + b, 0)} OSPF neighbour(s) in VRF ${[...hidden.vrf.keys()].join(', ')} not shown — the OSPF VRF filter is "${vrfFilter}". Choose that VRF or All VRFs to include them.`});
      if (hidden.svi.length) problems.push({sev: 'info', dev: d.name, msg: `${hidden.svi.length} OSPF neighbour(s) on SVI/BDI not shown (${list(hidden.svi)}). Turn on SVI/BDI neighbours to include them.`});
      if (hidden.sub.length) problems.push({sev: 'info', dev: d.name, msg: `${hidden.sub.length} OSPF neighbour(s) on subinterfaces other than .${suffix} not shown (${list(hidden.sub)}). Change the subinterface suffix to include them.`});
    };
    for (const nb of d.data?.ospfNbr || []){
      const local = d.ifs.get(ifKey(nb.intf)), m = ospfMetrics(R, d.name, nb.intf);
      const vrf = normVrf(nb.vrf || local?.vrf || m.vrf);
      if (vrfFilter && vrf !== vrfFilter){ hidden.vrf.set(vrf, (hidden.vrf.get(vrf) || 0) + 1); continue; }
      if (!opts.includeSvis && /^(?:Vl|BDI)\d/i.test(nb.intf)){ hidden.svi.push(nb.intf); continue; }
      const sub = /\.(\d+)$/.exec(nb.intf); if (sub && sub[1] !== suffix){ hidden.sub.push(nb.intf); continue; }
      const peer = manual.get(nb.rid) || owner(identities.get(scoped(vrf, nb.rid)), d.name)
        || owner(inventory.get(nb.rid), d.name) || owner(management.get(nb.rid), d.name)
        || owner(addresses.get(scoped(vrf, nb.addr)), d.name);
      if (peer === d.name) continue;
      const remote = peer && R.devices.get(peer), localIPs = new Set((local?.ips || []).map(a => a.ip));
      const myIDs = new Set([nb.localRid, ...(d.data?.ospfProcesses || []).filter(p => normVrf(p.vrf) === vrf).map(p => p.rid),
        ...(d.data?.run?.ospf || []).filter(p => normVrf(p.vrf) === vrf).map(p => p.rid)].filter(Boolean));
      const back = (remote?.data?.ospfNbr || []).filter(x => normVrf(x.vrf || remote.ifs.get(ifKey(x.intf))?.vrf) === vrf
        && (localIPs.has(x.addr) || (myIDs.has(x.rid) && (remote.ifs.get(ifKey(x.intf))?.ips || []).some(a => a.ip === nb.addr))));
      const reverse = back.length === 1 ? back[0] : null;
      const farPorts = remote ? [...remote.ifs.values()].filter(i => normVrf(i.vrf) === vrf && i.ips.some(a => a.ip === nb.addr)) : [];
      const farIf = reverse?.intf || (farPorts.length === 1 ? farPorts[0].name : '');
      const bDev = peer || 'unresolved:' + (d.site || d.name);
      const a = {dev: d.name, if: nb.intf}, b = {dev: bDev, if: farIf};
      const endpointKey = [a.dev + '|' + ifKey(a.if), b.dev + '|' + ifKey(b.if)].sort().join('~');
      if (excluded.has(endpointKey)) continue;
      const key = vrf + '|' + endpointKey + (farIf ? '' : '|' + nb.rid + '|' + nb.addr);
      if (excluded.has('ospf:' + key)) continue;
      if (seen.has(key)) continue; seen.add(key);
      const far = ospfMetrics(R, peer, farIf), cost = costLabel(m, far);
      const state = nb.state === 'FULL' && (!reverse || reverse.state === 'FULL') ? 'FULL' : nb.state !== 'FULL' ? nb.state : reverse.state;
      const record = {key, a, b, peer: peer || null, site: d.site, peerSite: remote?.site || parseHost(peer)?.site || '',
        rid: nb.rid, address: nb.addr, vrf, pid: nb.pid || local?.ospf?.pid || '', state, area: m.area, cost, localCost: m.cost, remoteCost: far.cost};
      out.push(record);
      if (!peer) problems.push({sev:'warn',dev:d.name,msg:'Unknown peer ' + nb.rid + ' on ' + nb.intf + ' (VRF ' + vrf + '). Add it to the inventory or peer mappings.'});
      if (m.cost != null && far.cost != null && m.cost !== far.cost)
        problems.push({sev:'warn',dev:d.name,msg:nb.intf + ' ↔ ' + peer + ' ' + farIf + ': OSPF cost ' + m.cost + ' / ' + far.cost + '.'});
      if (m.area != null && far.area != null && m.area !== far.area)
        problems.push({sev:'warn',dev:d.name,msg:nb.intf + ' ↔ ' + peer + ': OSPF area ' + m.area + ' / ' + far.area + '.'});
    }
    note();
  }
  return {records:out, problems};
}
function ospfEvidence(records){
  return records.map((r, i) => `${i + 1}. ${r.a.dev} ${r.a.if} ↔ ${r.peer || 'Unknown peer ' + r.rid} ${r.b.if}\nRouter ID: ${r.rid}; neighbour address: ${r.address}; VRF: ${r.vrf}; process: ${r.pid || 'unknown'}; area: ${r.area ?? 'unknown'}; ${r.cost || 'cost unknown'}; state: ${r.state}`).join('\n\n');
}
function ospfLabel(records, showCosts = true){
  const vrfs = [...new Set(records.map(r => r.vrf))].sort(), areas = [...new Set(records.map(r => r.area).filter(a => a != null))];
  const costs = [...new Set(records.map(r => r.cost).filter(Boolean))];
  return ['OSPF' + (records.length > 1 ? ' ×' + records.length : ''), vrfs.some(v => v !== 'default') ? 'VRFs ' + vrfs.join('/') : '',
    areas.length ? 'area ' + areas.join('/') : '', showCosts ? costs.join('; ') : ''].filter(Boolean).join(' · ');
}
/* Operating speeds come only from command observations, never media type or BW. */
function speedMbps(raw){
  const value = String(raw ?? '').trim().replace(/^(?:a-|auto-)/i, '').replace(/\s+/g, '').replace(/,/g, '');
  const m = /^(\d+(?:\.\d+)?)([kmgt])?(?:b(?:it)?(?:\/s|\/sec|ps)?)?$/i.exec(value);
  if (!m) return null;
  const mbps = Number(m[1]) * ({k:.001,m:1,g:1000,t:1000000}[(m[2] || 'm').toLowerCase()]);
  return Number.isFinite(mbps) && mbps > 0 ? mbps : null;
}
function speedLabel(mbps){
  if (!Number.isFinite(mbps) || mbps <= 0) return 'Speed unknown';
  const [n, unit] = mbps >= 1e6 ? [mbps/1e6,'Tb/s'] : mbps >= 1000 ? [mbps/1000,'Gb/s'] : mbps < 1 ? [mbps*1000,'Kb/s'] : [mbps,'Mb/s'];
  return Number(n.toPrecision(8)) + ' ' + unit;
}
function portOperatingSpeed(R, endpoint){
  const d = R.devices.get(endpoint.dev), key = ifKey(endpoint.if || '');
  const status = d?.data?.status?.get(key), detail = d?.data?.interfaceDetails?.get(key);
  const observations = [];
  for (const [data,source] of [[status,'show interfaces status'],[detail,'show interfaces']]) if (data)
    observations.push({source, raw:data.speed || '', mbps:speedMbps(data.speed), state:data.status || 'unknown'});
  const states = new Set(observations.map(o => o.state).filter(s => s !== 'unknown'));
  const stateConflict = states.has('up') && (states.has('down') || states.has('admin down'));
  const down = !stateConflict && (states.has('down') || states.has('admin down'));
  const active = observations.filter(o => o.state === 'up' && o.mbps != null);
  const rates = [...new Set(active.map(o => o.mbps))];
  return {dev:endpoint.dev, port:endpoint.if || '', file:d?.data?.file || '', observations, down, stateConflict,
    speedConflict:rates.length > 1, mbps:!down && !stateConflict && rates.length === 1 ? rates[0] : null,
    hasData:observations.length > 0};
}
function physicalLinkSpeed(R, link){
  const a = portOperatingSpeed(R,link.a), b = portOperatingSpeed(R,link.b);
  let status = 'unknown', mbps = null, text = 'Speed unknown';
  if (a.stateConflict || b.stateConflict){status='state-conflict';text='State conflict';}
  else if (a.down || b.down || link.state === 'shut' || (link.state === 'down' && ![...a.observations,...b.observations].some(o => o.state === 'up'))){status='down';text=link.state === 'shut'?'Admin down':'Down';}
  else if (a.speedConflict || b.speedConflict){status='mismatch';text='Speed conflict';}
  else if (a.mbps != null && b.mbps != null){
    if (a.mbps === b.mbps){status='agreed';mbps=a.mbps;text=speedLabel(mbps);}
    else {status='mismatch';text='Rates differ · A '+speedLabel(a.mbps)+' / B '+speedLabel(b.mbps);}
  } else if (a.mbps != null || b.mbps != null){status='one-sided';mbps=a.mbps ?? b.mbps;text=speedLabel(mbps)+' (one end)';}
  const evidence = endpoint => `${endpoint.dev} ${endpoint.port}\nSource file: ${endpoint.file || 'unavailable'}\n` + (endpoint.observations.length
    ? endpoint.observations.map(o => `${o.source}: ${o.state}; speed ${o.raw || 'unknown'}${o.mbps != null ? ' ('+speedLabel(o.mbps)+')' : ''}`).join('\n')
    : 'No operating speed observation in the uploaded file.');
  return {status,mbps,text,a,b,evidence:'Operating speed from uploaded snapshot\n'+evidence(a)+'\n\n'+evidence(b)};
}
function buildBoard(R, opts = {}){
  let n = 0; const id = () => 'i' + (++n).toString(36) + Math.random().toString(36).slice(2, 6);
  const siteName = code => R.sites.get(code) || code || 'Other';
  const showShut = !!opts.showShut, suffix = String(opts.baseline || '5').replace(/^\./, '');
  const selSite = opts.site || '', vrfSel = opts.vrf ?? 'default', includeSvis = !!opts.includeSvis, excluded = new Set(opts.excluded || []);
  const epK = e => e.dev + '|' + ifKey(e.if || '');   // same key as IdeaImport.linkKey (review tick boxes)
  const linkKey = L => [epK(L.a), epK(L.b)].sort().join('~');
  const keepL = L => !excluded.has(linkKey(L)) && (showShut || L.state !== 'shut');
  const country = d => d ? (opts.siteCountries?.[d.site] || d.host?.letter || '') : '';
  const isDC = site => (opts.dataCenterSites||[]).includes(site) || /DC|data\s*cent/i.test(R.sites.get(site) || '');
  const base = {fill: 'solid', dash: 'solid', size: 'm', fontSize: 'm', font: opts.appearance==='sketch'?'draw':'sans'};
  const portOf = (dev, intf) => { const d = R.devices.get(dev); return d && intf ? d.ifs.get(ifKey(intf)) || null : null; };
  const costText = (a, b) => opts.showCosts === false ? '' : costLabel(ospfMetrics(R, a.dev, a.if), ospfMetrics(R, b.dev, b.if));
  const vrfOf = (dev, intf) => { const i = portOf(dev, intf); return i && i.vrf || 'default'; };
  const deviceShape = (d, x, y, view) => {
    const [kind, color] = KIND[d.role] || ['switch', 'grey'];
    const rack = view !== 'icon', info = [];
    if (d.host) info.push(`${siteName(d.site)} · floor ${d.floor} · unit ${d.unit}`);
    const extra = [d.model, d.ip].filter(Boolean).join(' · '); if (extra) info.push(extra);
    if (!d.data && !d.end) info.push(d.external ? 'not in this import' : 'no data file');
    return {...base, id: id(), type: 'device', x, y, w: rack ? 290 : 64, h: rack ? 64 : 64, kind, color: d.data || d.end ? color : 'grey', fill: d.data || d.end ? 'solid' : 'semi',
      text: d.label || d.name, info: d.info || info.join('\n'), role: d.role || '', view: rack ? 'rack' : 'icon', nameInside: rack,
      mgmtIP: d.ip || '', model: d.model || '', vendor: d.vendor || '', networkKey: 'device:' + d.name};
  };
  const labelShape = (key, text, info) => ({...base, id: id(), type: 'device', x: 0, y: 0, w: 64, h: 64, kind: 'router', color: 'grey', fill: 'semi', text, info: info || '', role: '', view: 'icon', nameInside: false, networkKey: 'device:' + key});
  const zone = (text, x, y, w, h, color) => ({...base, fill: 'semi', dash: 'dashed', size: 's', id: id(), type: 'zone', x, y, w, h, color, text});
  const title = (text, x, y) => ({...base, fill: 'none', fontSize: 'xl', id: id(), type: 'text', x, y, w: Math.max(200, String(text).length * 19 + 40), h: 44, color: 'black', text});
  const note = (text, x, y, w, h, color = 'yellow') => ({...base, fontSize: 's', id: id(), type: 'note', x, y, w, h, color, text});
  const foundBy = L => 'Found by: ' + [...(L.srcs || [])].join(', ') + (L.confidence ? ' · ' + L.confidence : '') + (L.cpe ? ' · carrier CPE seen: ' + L.cpe : '') + (L.circuit && L.circuit.cid ? ' · circuit ' + L.circuit.cid : '')
    + '\n' + [L.a.dev + ' ' + (L.a.if || ''), (L.b.dev || L.b.label || '?') + ' ' + (L.b.if || '')].join(' ↔ ');
  const linkStyle = L => {
    let color = 'black', dash = 'solid', size = 'm';
    switch (L.kind){
      case 'circuit': color = 'yellow'; size = 'l'; break;
      case 'pw': color = 'teal'; dash = 'dotted'; size = 'l'; break;
      case 'pw-attach': color = 'teal'; size = 'l'; break;
      case 'bundle': color = 'blue'; size = 'xl'; break;
      case 'trunk': color = 'blue'; size = 'l'; break;
      case 'endnode': color = 'grey'; size = 's'; break;
      case 'over-pw': color = 'grey'; dash = 'dashed'; size = 's'; break;
    }
    if (L.confidence === 'config-only' && dash === 'solid') dash = 'dashed';
    if (L.state === 'down'){ color = 'grey'; if (dash === 'solid') dash = 'dashed'; }
    if (L.state === 'shut'){ color = 'grey'; dash = 'dotted'; size = 's'; }
    if (L.kind === 'circuit' && dash === 'dashed' && L.state !== 'down') dash = 'solid';      // circuits stay solid even when only described
    if(L.kind==='circuit' && !['down','shut'].includes(L.state)){color='yellow';dash='solid';size='l';}
    return {color, dash, size, pipe: L.kind === 'pw'};
  };
  const linkText = L => {
    const parts = [];
    if (L.kind === 'pw') parts.push(`PW ${L.pw.vcid}` + (L.pw.state && L.pw.state !== 'UP' ? ' · ' + L.pw.state : ''));
    else if (L.circuit) parts.push([L.circuit.carrier, L.circuit.cid, L.circuit.speed].filter(Boolean).join(' · '));
    else if (L.bundle) parts.push(`${L.a.if}${L.memberCount ? ' · ' + L.memberCount + ' link' + (L.memberCount > 1 ? 's' : '') : ''}`);
    else if (L.kind === 'over-pw') parts.push('over pseudowire' + (L.subs && L.subs.length > 1 ? '' : L.subnet ? ' · ' + L.subnet : ''));
    if (L.subs && L.subs.length > 1){ const v = L.subs.map(Number).filter(n => !isNaN(n)).sort((a, b) => a - b); parts.push(`${L.subs.length} subinterfaces` + (v.length ? ` (.${v[0]}–.${v[v.length - 1]})` : '')); }
    else if (L.subnet) parts.push(L.subnet);
    if (L.state === 'down') parts.push('DOWN'); else if (L.state === 'shut') parts.push('shut');
    else if (L.confidence === 'config-only') parts.push('not seen');
    return parts.filter(Boolean).join(' · ');
  };
  const rawConn = (aId, bId, aLabel, bLabel, bend, st, text, fb, key) => ({...base, fill: 'none', id: id(), type: 'connector', x: 0, y: 0, w: 0, h: 0, start: {id: aId}, end: {id: bId}, arrows: 'none', route: 'straight', bend: bend || 0,
    text: text || '', startLabel: aLabel || '', endLabel: bLabel || '', color: st.color, dash: st.dash, size: st.size, foundBy: fb || '', networkKey: key || '',
    ...(st.pipe && opts.pipes !== false ? {pipe: 'on', pipeColor: st.pipeColor || 'teal', pipeSize: 'm'} : {})});
  const connector = (L, aId, bId, aLabel, bLabel, bend, override) => {
    const st = {...linkStyle(L), ...(override || {})};
    return rawConn(aId, bId, aLabel, bLabel, bend, st, override && override.text != null ? override.text : linkText(L), foundBy(L), linkKey(L));
  };
  const multiBend = () => { const seen = new Map(); return (a, b) => { const k = [a, b].sort().join('~'), c = seen.get(k) || 0; seen.set(k, c + 1); return c === 0 ? 0 : (c % 2 ? 1 : -1) * Math.ceil(c / 2) * 60; }; };
  // a link between two devices on the same row would run through the devices in between: arc it
  const arc = (shapes, aId, bId, bd) => {
    const sa = shapes.find(x => x.id === aId), sb = shapes.find(x => x.id === bId); if (!sa || !sb) return bd;
    if (Math.abs(sa.y - sb.y) < 10 && Math.abs(sa.x - sb.x) > 450) return (bd || 0) - (60 + Math.abs(sa.x - sb.x) * .1);
    return bd;
  };

  const links = R.links.filter(keepL), physLinks = (R.phys || []).filter(keepL);
  const devs = [...R.devices.values()];
  const bySite = new Map();
  for (const d of devs){ const k = d.external ? '~ext' : d.site || '~other'; (bySite.get(k) || bySite.set(k, []).get(k)).push(d); }
  const localSites = [...bySite.keys()].filter(k => !k.startsWith('~')).sort();
  const pageSites = selSite ? localSites.filter(s => s === selSite) : localSites;
  const inScope = L => !selSite || [L.a.dev, L.b.dev].some(x => { const d = R.devices.get(x); return d && d.site === selSite; });
  const homeCountry = (() => { const c = new Map(); for (const d of devs) if (d.data && d.host && (!selSite || d.site === selSite)) c.set(country(d), (c.get(country(d)) || 0) + 1); return [...c].sort((a, b) => b[1] - a[1])[0]?.[0] || ''; })();
  const sortDev = (a, b) => a.name.localeCompare(b.name);
  const byRole = (a, b) => (ROLE_ROW[a.role] ?? 5) - (ROLE_ROW[b.role] ?? 5) || sortDev(a, b);
  const pages = [];
  // OSPF over pseudowires with the chosen suffix; review notes follow the suffix too
  const pwo = pwOspfFor(R, suffix);
  const problems = R.problems.filter(p => !/carries a pseudowire.* but has no \.\d+ subinterface/.test(p.msg));
  for (const p of pwo.problems) if (!problems.some(q => q.dev === p.dev && q.msg === p.msg)) problems.push(p);

  /* ---- far ends: top band (data centres, other countries, circuits) or left/right (same country) ---- */
  const farPlacer = (shapes, place, localSite, cty, rack, topOnly = false) => {
    const top = [], sides = new Map();
    const add = (key, make, d) => {
      if (place.has(key)) return place.get(key);
      const s = make(); if (!(d && d.data)){ s.color = 'grey'; s.fill = 'semi'; } shapes.push(s); place.set(key, s.id);
      if (!topOnly && d && d.site && d.site !== localSite && !isDC(d.site) && cty && country(d) === cty){ (sides.get(d.site) || sides.set(d.site, []).get(d.site)).push(s); }
      else top.push(s);
      return s.id;
    };
    // returns the right-hand edge used
    const layout = (left, right, topY) => {
      let rightEdge = right;
      if (top.length){
        const gap = rack ? 330 : 230, need = top.reduce((a, s) => a + s.w, 0) + (top.length - 1) * (gap - (rack ? 270 : 64)) + 80;
        const w = Math.max(right - left + 40, need);
        const usedRows = [...new Set(top.map(s => ROLE_ROW[s.role] ?? 3))].sort((a,b) => a-b);
        const firstY = rack ? topY-(usedRows.length-1)*170 : topY-10;
        shapes.unshift(zone('Data centres · remote sites · circuits', left - 20, firstY-60, w, rack ? (usedRows.length-1)*170+200 : 170, 'blue'));
        const total = top.reduce((a, s) => a + s.w, 0), space = top.length > 1 ? (w - 80 - total) / (top.length - 1) : 0;
        let x = top.length > 1 ? left + 20 : left - 20 + w / 2 - top[0].w / 2;
        for (const s of top){ s.x = x; s.y = rack ? firstY + usedRows.indexOf(ROLE_ROW[s.role] ?? 3)*170 : firstY; x += s.w + space; }
        rightEdge = Math.max(rightEdge, left - 20 + w);
      }
      const order = [...sides.keys()].sort(); let ly = -70, ry = -70;
      const zw = rack ? 330 : 300, step = rack ? 110 : 120;
      order.forEach((site, k) => {
        const items = sides.get(site).sort((a,b) => (ROLE_ROW[a.role] ?? 3)-(ROLE_ROW[b.role] ?? 3)), onLeft = k % 2 === 0, h = 80 + items.length * step, x0 = onLeft ? left - zw - 120 : right + 100;
        const y0 = onLeft ? ly : ry;
        shapes.unshift(zone(siteName(site) + ' (same country)', x0, y0, zw, h, 'grey'));
        items.forEach((s, i) => { s.x = x0 + (zw - s.w) / 2; s.y = y0 + 45 + i * step; });
        if (onLeft) ly += h + 40; else { ry += h + 40; rightEdge = Math.max(rightEdge, x0 + zw); }
      });
      return rightEdge;
    };
    return {layout, dev: d => add(d.name, () => { const s = deviceShape(d, 0, 0, rack ? 'rack' : 'icon'); if (!rack) s.info = (d.site ? siteName(d.site) : '') + (d.model ? '\n' + d.model : ''); return s; }, d),
      label: (key, text, info) => add(key, () => labelShape(key, text, info || 'far end'), null)};
  };

  /* ---- network layout (every page): sites side by side; rows TL (top) · CL / DL · AG / ML · AS / SF / VG / ACS / other (bottom) ---- */
  const rowOf = d => ROLE_ROW[d.layoutRole || d.role] ?? 3;
  const placeNetwork = (list, shapes, place, cols) => {
    const inCol=list.filter(d=>d&&!d.pseudo&&cols.includes(d.site));
    const grids=cols.map(site=>[0,1,2,3].map(r=>inCol.filter(d=>d.site===site&&rowOf(d)===r).sort((a,b)=>r===3?(({AS:0,SF:1,VG:2,ACS:3}[a.role]??4)-({AS:0,SF:1,VG:2,ACS:3}[b.role]??4)||sortDev(a,b)):sortDev(a,b))));
    const degree=d=>physLinks.filter(L=>L.a.dev===d.name||L.b.dev===d.name).length;
    const maxDegree=Math.max(1,...inCol.map(degree)),rowY=[];let y=0,last=-1;
    for(let r=0;r<4;r++){
      const count=Math.max(0,...grids.map(g=>g[r].length));if(!count){rowY[r]=y;continue;}
      if(last>=0)y+=Math.max(310,190+maxDegree*26);
      rowY[r]=y;y+=(r===3?count-1:Math.ceil(count/2)-1)*160+64;last=r;
    }
    let x=0;
    cols.forEach((site,ci)=>{
      const g=grids[ci],localDegree=Math.max(1,...g.flat().map(degree));
      const rail=100+localDegree*26,gap=420,w=580+gap+2*rail;
      g.forEach((row,r)=>row.forEach((d,i)=>{
        const n=Math.min(2,row.length-Math.floor(i/2)*2);
        const dx=r===3||n===1?(w-290)/2:rail+(i%2)*(290+gap);
        const dy=rowY[r]+(r===3?i:Math.floor(i/2))*160;
        const sh=deviceShape(d,x+dx,dy,'rack');sh.layoutSite=site;sh.layoutRow=r;shapes.push(sh);place.set(d.name,sh.id);
      }));
      shapes.unshift(zone(siteName(site),x-40,-80,w+80,y+190,'grey'));x+=w+300;
    });
    return {maxX:Math.max(660,x-300),bottom:y+110};
  };
  // Generate movable, anchored lanes. Geometry is recomputed by the drawing engine when devices move.
  const routeNetwork = shapes => {
    const boxes=new Map(shapes.filter(s=>s.type==='device').map(s=>[s.id,s]));
    const lines=shapes.filter(s=>s.type==='connector'&&boxes.has(s.start?.id)&&boxes.has(s.end?.id));
    const groups=new Map(),requests=new Map(),lanes=new Map();
    const request=(c,key,side,other)=>{const shape=boxes.get(c[key].id),k=shape.id+':'+side;
      const row={c,key,side,other};if(!requests.has(k))requests.set(k,[]);requests.get(k).push(row);};
    for(const c of lines){
      const A=boxes.get(c.start.id),B=boxes.get(c.end.id),same=A.layoutSite&&A.layoutSite===B.layoutSite;
      const a={x:A.x+A.w/2,y:A.y+A.h/2},b={x:B.x+B.w/2,y:B.y+B.h/2};
      const pair=[A.id,B.id].sort().join('~'),pairCount=groups.get(pair)||0;groups.set(pair,pairCount+1);
      let sa,sb;c.bend=0;
      if(same&&A.layoutRow!==B.layoutRow&&(A.layoutRow===3||B.layoutRow===3)){
        const U=a.y<b.y?A:B,L=U===A?B:A,side=U.x+U.w/2<L.x+L.w/2?'left':'right';
        const k=U.id+':'+side,lane=lanes.get(k)||0;lanes.set(k,lane+1);
        c.routing={kind:'access',side,offset:50+lane*26,drop:100+lane*26};
        sa=U===A?'bottom':side;sb=U===B?'bottom':side;c.route='elbow';
      }else if(same&&Math.abs(a.y-b.y)>80){
        sa=a.y<b.y?'bottom':'top';sb=a.y<b.y?'top':'bottom';
        const k=A.layoutSite+':'+Math.min(A.layoutRow,B.layoutRow),lane=lanes.get(k)||0;lanes.set(k,lane+1);
        c.routing={kind:'between',offset:(lane%7-3)*22};c.route='elbow';
      }else if(same&&Math.abs(a.y-b.y)<80&&pairCount===0){
        sa=a.x<b.x?'right':'left';sb=a.x<b.x?'left':'right';c.route='straight';delete c.routing;
      }else{
        const lane=lanes.get('top')||0;lanes.set('top',lane+1);sa=sb='top';c.route='elbow';c.routing={kind:'top',offset:90+lane*30};
      }
      request(c,'start',sa,b);request(c,'end',sb,a);
      c.layoutGenerated=true;
    }
    for(const rows of requests.values()){
      rows.sort((a,b)=>a.other.x-b.other.x||a.other.y-b.other.y||a.c.networkKey.localeCompare(b.c.networkKey));
      rows.forEach((r,i)=>{const t=(i+1)/(rows.length+1),q=r.side==='top'?{x:t,y:0}:r.side==='bottom'?{x:t,y:1}:r.side==='left'?{x:0,y:t}:{x:1,y:t};r.c[r.key].anchor=q;});
    }
    // Fall back to obstacle-aware routing only where a planned lane meets a device body.
    const position=e=>{const s=boxes.get(e.id);return {x:s.x+e.anchor.x*s.w,y:s.y+e.anchor.y*s.h};};
    const crosses=(a,b,r)=>{
      let lo=0,hi=1;for(const [v,d,min,max] of [[a.x,b.x-a.x,r.x+1,r.x+r.w-1],[a.y,b.y-a.y,r.y+1,r.y+r.h-1]]){
        if(Math.abs(d)<1e-9){if(v<=min||v>=max)return false;}
        else {let t=(min-v)/d,u=(max-v)/d;if(t>u)[t,u]=[u,t];lo=Math.max(lo,t);hi=Math.min(hi,u);if(lo>=hi)return false;}
      }return hi>0&&lo<1;
    };
    for(const c of lines){
      const A=boxes.get(c.start.id),B=boxes.get(c.end.id),a=position(c.start),b=position(c.end),q=c.routing;let pts=[a,b];
      if(q?.kind==='top'){const y=Math.min(A.y,B.y)-q.offset;pts=[a,{x:a.x,y},{x:b.x,y},b];}
      else if(q?.kind==='between'){const y=(a.y+b.y)/2+q.offset;pts=[a,{x:a.x,y},{x:b.x,y},b];}
      else if(q?.kind==='access'){
        const upper=A.y<B.y?A:B,lower=upper===A?B:A,u=upper===A?a:b,l=upper===A?b:a;
        const x=q.side==='left'?Math.min(A.x,B.x)-q.offset:Math.max(A.x+A.w,B.x+B.w)+q.offset,y=Math.min(upper.y+upper.h+q.drop,lower.y-24);
        pts=[u,{x:u.x,y},{x,y},{x,y:l.y},l];if(upper!==A)pts.reverse();
      }
      if([...boxes.values()].some(s=>s.id!==A.id&&s.id!==B.id&&pts.slice(1).some((b,i)=>crosses(pts[i],b,s))))c.route='smart';
    }
  };
  const finishPage = (name, shapes) => {
    const heading = shapes.find(s => s.type === 'text' && s.fontSize === 'xl');
    if (heading && shapes.length > 1) heading.y = Math.min(...shapes.filter(s => s !== heading).map(s => s.y))-120;
    // keep device positions from the same page of the current board
    const old = (opts.previousPages || []).find(p => p.name === name);
    if (old){ const pos = new Map(old.shapes.filter(s => s.type === 'device').map(s => [s.networkKey || 'device:' + s.text, s]));
      for (const s of shapes) if (s.type === 'device'){ const p = pos.get(s.networkKey); if (p) Object.assign(s, {x: p.x, y: p.y, w: p.w, h: p.h}); } }
    routeNetwork(shapes);
    if(heading){const nodes=new Map(shapes.map(s=>[s.id,s]));const topLanes=shapes.filter(s=>s.routing?.kind==='top').map(c=>Math.min(nodes.get(c.start.id).y,nodes.get(c.end.id).y)-c.routing.offset);heading.y=Math.min(heading.y,...topLanes.map(y=>y-110));}
    pages.push({id: id(), name, cam: null, shapes});
  };

  /* ---- network-wide page helper: local sites as columns, far ends on top / sides ---- */
  const displayNodes = new Map(R.devices);
  const networkPage = (name, heading, edges, legend, extra = [], view = {}) => {
    const shapes = [], place = new Map(), bend = multiBend(), managementLanes = new Map();
    shapes.push(title(`${opts.title || 'Network'} · ${heading}`, 0, -1060));
    const nodes = new Map();
    for (const e of edges) for (const end of [e.a, e.b]) if (end.dev && !nodes.has(end.dev))
      nodes.set(end.dev, displayNodes.get(end.dev) || {name: end.dev, pseudo: true, label: end.label || end.dev, info: end.info});
    for (const d of view.include || []) nodes.set(d.name, d);
    const focus = view.site || selSite;
    const dataSites = new Set(devs.filter(d => d.data).map(d => d.site));
    const primary = [...nodes.values()].filter(d => !d.pseudo && d.site && (dataSites.has(d.site) || d.other || d.summary)
      && (focus ? d.site === focus : !isDC(d.site) && (!homeCountry || country(d) === homeCountry)));
    const cols = [...new Set(primary.map(d => d.site))].sort();
    const {maxX, bottom} = placeNetwork(primary, shapes, place, cols);
    const far = farPlacer(shapes, place, focus || (cols.length === 1 ? cols[0] : ''), homeCountry, !view.peersOnTop, !!view.peersOnTop);
    for (const d of nodes.values()) if (!place.has(d.name)) d.pseudo ? far.label(d.name, d.label, d.info || 'logical endpoint') : far.dev(d);
    const right = far.layout(0, maxX, -330);
    for (const e of edges){
      const aId = place.get(e.a.dev), bId = place.get(e.b.dev); if (!aId || !bId) continue;
      const c = e.L ? connector(e.L, aId, bId, e.a.if, e.b.if, arc(shapes, aId, bId, bend(e.a.dev, e.b.dev)), e.override)
        : rawConn(aId, bId, e.a.if, e.b.if, arc(shapes, aId, bId, bend(e.a.dev, e.b.dev)), e.style, e.text, e.evidence, e.key);
      if (e.adjacencies) c.adjacencies = e.adjacencies;
      if (e.operatingSpeed){
        c.operatingSpeed = e.operatingSpeed;
        // Keep this presentation view focused on rates; ports stay in selection evidence.
        c.startLabel = ''; c.endLabel = '';
        const a = shapes.find(s => s.id === aId), b = shapes.find(s => s.id === bId);
        if (a && b && Math.abs(a.y-b.y) < 10){
          const key=[aId,bId].sort().join('~'), lane=managementLanes.get(key)||0;managementLanes.set(key,lane+1);
          c.bend=(a.x < b.x ? -1 : 1)*(160+lane*80);
        }
      }
      shapes.push(c);
    }
    shapes.push(note(legend, right + 60, -330, 400, 260));
    extra.forEach((t, i) => shapes.push(note(t, 0, bottom + 60 + i * 170, 750, 150, 'orange')));
    if (!edges.length) shapes.push(note('No matching connections in the loaded data.', 0, -190, 500, 100));
    finishPage(name, shapes);
  };

  /* Management page: physical endpoints in uploaded files, actual observed rates. */
  {
    const uploaded = devs.filter(d => d.data && (!selSite || d.site === selSite));
    const edges = physLinks.filter(L => inScope(L) && R.devices.get(L.a.dev)?.data && R.devices.get(L.b.dev)?.data
      && isPhys(L.a.if) && (!L.b.if || isPhys(L.b.if))).map(L => {
        const operating = physicalLinkSpeed(R,L), inferred = ![...L.srcs].some(s => s === 'lldp' || s === 'cdp');
        if (['mismatch','state-conflict'].includes(operating.status)) problems.push({sev:L.circuit?'info':'warn',dev:L.a.dev,
          msg:`${L.a.if} ↔ ${L.b.dev} ${L.b.if || '?'}: ${operating.text}. Check the endpoint observations and collection times.`});
        const color = operating.status === 'agreed' ? 'green' : operating.status === 'one-sided' ? 'blue'
          : ['mismatch','state-conflict'].includes(operating.status) ? 'orange' : 'grey';
        if(operating.status==='unknown'){
          for(const endpoint of [operating.a,operating.b]){
            const key=endpoint.dev+' '+endpoint.port;
            if(!problems.some(p=>p.speedCollection===key))problems.push({sev:'info',dev:endpoint.dev,speedCollection:key,
              msg:`${endpoint.port}: no usable operating speed. Collect show interface status (Nexus/Catalyst) or show interfaces ${endpoint.port} (ASR 920/detail fallback), including command headings. Interface names, media types and configured BW are not measured speeds.`});
          }
        }
        const evidence = operating.evidence+'\n\n'+foundBy(L)
          +(L.circuit ? '\nProvider handoff port rates; service bandwidth is separate'+(L.circuit.speed?': '+L.circuit.speed+' in description':'')+'.' : '')
          +(L.poA || L.poB ? '\nPort-channel membership: '+[L.poA,L.poB].filter(Boolean).join(' / ')+'. Each member is drawn separately.' : '')
          +(inferred ? '\nConnection is inferred from configuration/descriptions, not confirmed by CDP/LLDP.' : '');
        return {a:L.a,b:L.b,key:'physical-speed:'+linkKey(L),text:operating.text+(L.circuit?' · port rate':''),evidence,
          operatingSpeed:operating,style:{color,dash:operating.status==='down'?'dotted':inferred?'dashed':'solid',size:'l'}};
      });
    const count = status => edges.filter(e => e.operatingSpeed.status === status).length;
    networkPage('Physical link speeds','Physical link speeds · uploaded snapshot',edges,
      `${edges.length} physical connection(s) between uploaded devices.\n${count('agreed')} speeds match both ends · ${count('one-sided')} from one end\n${count('unknown')} unknown · ${count('down')} down · ${count('mismatch')+count('state-conflict')} conflicting\n\nGreen: both ends agree; blue: one end reports a rate; orange: conflicting observations; grey: unknown/down.\nDashed: inferred connection. Port-channel members remain separate.`,
      ['Rates are operating port speeds at collection time. Use show interfaces status or show interfaces; add CDP/LLDP neighbors or interface descriptions to identify connections. Upload fresh outputs to refresh.\nCarrier service capacity and traffic utilization are separate metrics. Missing operating rates stay unknown; interface types, configured speed and BW are not used as measured speed.'],
      {include:uploaded});
  }

  /* WAN uses the same role rows and country/site placement as the other pages. */
  {
    const edges = links.filter(L => inScope(L) && !['over-pw', 'pw-attach', 'ospf-adj'].includes(L.kind)
      && (R.devices.get(L.a.dev)?.site !== R.devices.get(L.b.dev)?.site
        || [L.a.dev, L.b.dev].every(n => R.devices.get(n)?.role === 'TL')))
      .map(L => ({a:L.a,b:L.b,L}));
    networkPage('WAN', 'WAN / TL environment', edges,
      'Yellow: carrier circuit. Teal pipes: pseudowire. Blue: bundles.\nTL, core, aggregation, access rows; sites side by side.\nData centers and other countries above; same-country sites without files on the sides.', [],
      {include:devs.filter(d => d.role === 'TL' && d.data && (!selSite || d.site === selSite))});
  }

  /* ---- pseudowire page ---- */
  {
    const edges = [];
    for (const L of links) if (['pw', 'pw-attach', 'over-pw'].includes(L.kind) && inScope(L))
      edges.push({a: L.a, b: L.b, L, override: L.kind === 'pw' || L.kind === 'pw-attach' ? null : {text: linkText(L)}});
    for (const w of R.logical) if (w.via && w.far && !edges.some(e => [e.a.dev, e.b.dev].sort().join() === [w.via, w.far].sort().join()) && (!selSite || [w.from, w.local].some(x => (R.devices.get(x) || {}).site === selSite)))
      edges.push({a: {dev: w.via, if: w.viaIf}, b: {dev: w.far, if: w.farIf}, style: {color: 'teal', dash: 'dashed', size: 'm'}, text: 'via ' + w.via, evidence: 'From the PWIRE/PW description on ' + w.from + ' ' + w.fromIf});
    networkPage('Pseudowires', 'pseudowires through the TL environment', edges,
      'Legend (pseudowires)\n— teal dotted: pseudowire between TLs (xconnect, VC ID)\n— teal solid: attachment cable, core ↔ TL\n— grey dashed: core-to-core over the pseudowire\nA pseudowire line is a service, not a direct cable.');
  }

  /* OSPF: aggregate selected adjacencies, retain each record in selection evidence. */
  {
    const ospf = ospfRecords(R, opts), all = ospf.records;
    for (const p of ospf.problems) if (!problems.some(q => q.dev === p.dev && q.msg === p.msg)) problems.push(p);
    const unresolved = new Map();
    for (const r of all) if (!r.peer){
      const ids = unresolved.get(r.b.dev) || new Set(); ids.add(r.rid); unresolved.set(r.b.dev, ids);
    }
    const decorate = e => {
      const unknown = unresolved.get(e.dev);
      return unknown ? {...e, label:'Unresolved peers · ' + e.dev.replace('unresolved:', ''),
        info:[...unknown].sort().map(ip => 'Unknown peer ' + ip).join('\n')} : e;
    };
    const group = (records, endpoints = r => [r.a, r.b]) => {
      const groups = new Map();
      for (const r of records){
        const [a,b] = endpoints(r), k = [a.dev, b.dev].sort().join('~');
        if (a.dev === b.dev) continue;
        const g = groups.get(k) || {a,b,records:[]}; g.records.push(r); groups.set(k,g);
      }
      return [...groups.entries()].map(([key,g]) => ({key:'ospf-group:' + key, a:decorate({...g.a,if:''}), b:decorate({...g.b,if:''}),
        text:ospfLabel(g.records, opts.showCosts !== false), evidence:ospfEvidence(g.records), adjacencies:g.records,
        style:{color:g.records.every(r => r.state === 'FULL') ? 'teal' : 'grey',dash:'dashed',size:'m'}}));
    };
    const siteAnchors = new Map();
    const anchor = (site, fallback) => {
      if (!site) return fallback;
      if (siteAnchors.has(site)) return siteAnchors.get(site);
      const tl = devs.filter(d => d.site === site && d.role === 'TL').sort((a,b) => Number(!!b.data)-Number(!!a.data) || sortDev(a,b))[0];
      if (tl){siteAnchors.set(site,tl.name);return tl.name;}
      const ref = devs.find(d => d.site === site), name = 'site:' + site;
      displayNodes.set(name,{...ref,name,label:siteName(site),layoutRole:'TL',role:'',summary:true,
        info:'Site overview anchor (no TL in the input); select a line for actual router endpoints.'});
      siteAnchors.set(site,name);return name;
    };
    const selected = all.filter(r => !selSite || r.site === selSite || r.peerSite === selSite);
    const overview = group(selected,r => r.site && r.peerSite && r.site === r.peerSite ? [r.a,r.b]
      : [{dev:anchor(r.site,r.a.dev)},r.peer ? {dev:anchor(r.peerSite,r.b.dev)} : r.b]);
    const legend = `OSPF logical topology; these lines are not cables.\nOne line per site pair; same-site device pairs remain distinct.\nSite connections anchor at the TL row. Select a line for every actual adjacency.\nVRF: ${vrfSel || 'all'}; only .${suffix} subinterfaces; ${includeSvis ? 'SVIs included' : 'SVIs hidden'}.\nCounts include only sessions selected by these filters.`;
    networkPage('OSPF overview','OSPF overview',overview,legend);
    const sites = [...new Set(devs.filter(d => d.data && (!selSite || d.site === selSite)).map(d => d.site).filter(Boolean))].sort();
    for (const site of sites){
      const records = all.filter(r => r.site === site || r.peerSite === site);
      networkPage('OSPF · ' + site, 'OSPF · ' + siteName(site), group(records),
        `One line per device pair. Select a line for all included adjacencies.\nVRF: ${vrfSel || 'all'}; .${suffix} subinterfaces; ${includeSvis ? 'SVIs included' : 'SVIs hidden'}.\nRemote peers appear as small boxes above the site.\nArea and cost labels can be reduced using import options.`, [],
        {site,peersOnTop:true,include:devs.filter(d => d.site === site && d.data && (d.data.cmds.has('ospf') || ['TL','CL','DL'].includes(d.role)))});
    }
  }

  /* ---- per site: L1 (cables), L2 (bundles collapsed), L3 (routed) ---- */
  const physStyle = L => {
    let color = 'black', dash = 'solid', size = 'm';
    if (L.circuit){ color = 'yellow'; size = 'l'; }
    else if (L.pw){ color = 'teal'; dash = 'dotted'; }
    else if (L.poA || L.poB){ color = 'blue'; size = 'l'; }
    else if (L.endNode){ color = 'grey'; size = 's'; }
    if (L.confidence === 'unverified' && dash === 'solid' && !L.circuit) dash = 'dashed';
    if (L.state === 'down'){ color = 'grey'; if (dash === 'solid') dash = 'dashed'; }
    if (L.state === 'shut'){ color = 'grey'; dash = 'dotted'; size = 's'; }
    if(L.circuit && !['down','shut'].includes(L.state)){color='yellow';dash='solid';size='l';}
    return {color, dash, size, pipe: !!L.pw && !L.circuit};
  };
  const tail = L => L.state === 'down' ? 'DOWN' : L.state === 'shut' ? 'shut' : L.confidence === 'unverified' && !L.circuit ? 'not seen by CDP/LLDP' : '';
  const pwText = L => L.pw ? 'PW' + (L.pw.vcid ? ' ' + L.pw.vcid : '') + (L.pw.far ? ' → ' + L.pw.far : L.pw.peerTl ? ' → ' + L.pw.peerTl : '') : '';
  const physText = L => [L.circuit ? [L.circuit.carrier || 'Circuit', L.circuit.speed || L.speed].filter(Boolean).join(' · ') : L.speed,
    [...new Set([L.poA, L.poB].filter(Boolean))].join('/'), pwText(L), tail(L)].filter(Boolean).join(' · ');
  const shortVlans = v => !v ? '' : v.length > 28 ? v.slice(0, 26).replace(/,[^,]*$/, '') + ',…' : v;
  // Layer 2: port-channel members collapsed into one bundle; other cables keep their L2 role
  const l2Links = (() => {
    const out = [], bundles = new Map();
    for (const L of physLinks){
      if (L.poA || L.poB){
        const a = {dev: L.a.dev, if: L.poA || L.a.if}, b = {dev: L.b.dev, if: L.poB || L.b.if}, k = [epK(a), epK(b)].sort().join('~');
        let B = bundles.get(k); if (!B){ B = {...L, a, b, bundle: true, members: [], srcs: new Set()}; bundles.set(k, B); out.push(B); }
        B.members.push(L); for (const s of L.srcs) B.srcs.add(s);
        if (L.state === 'up') B.state = 'up';
      } else out.push(L);
    }
    for (const L of links) if (L.bundle && !out.some(x => x.bundle && [x.a.dev, x.b.dev].sort().join() === [L.a.dev, L.b.dev].sort().join())) out.push({...L, members: [], fromLinks: true});
    return out;
  })();
  const l2Text = L => {
    if (L.bundle){ const n = L.members.length || L.memberCount || 0, sp = L.members[0] && L.members[0].speed;
      const ia = portOf(L.a.dev, L.a.if), ib = portOf(L.b.dev, L.b.if), tr = (ia && ia.trunk) || (ib && ib.trunk), v = (ia && ia.allowedVlans) || (ib && ib.allowedVlans);
      return [L.a.if, n ? n + ' × ' + (sp || 'link') : '', tr ? 'trunk' + (v ? ' · VLANs ' + shortVlans(v) : '') : '', tail(L)].filter(Boolean).join(' · '); }
    if (L.circuit || L.pw) return physText(L);
    const ia = portOf(L.a.dev, L.a.if), ib = L.b.dev ? portOf(L.b.dev, L.b.if) : null, p = [ia, ib].filter(Boolean);
    const tr = p.find(i => i.trunk), acc = p.find(i => i.accessVlan), routed = p.find(i => i.ips && i.ips.length);
    const role = tr ? 'trunk' + (tr.allowedVlans ? ' · VLANs ' + shortVlans(tr.allowedVlans) : '') : acc ? 'access VLAN ' + acc.accessVlan : routed ? 'routed' : '';
    return [L.speed, role, tail(L)].filter(Boolean).join(' · ');
  };
  const l2Style = L => {
    if (L.bundle){ const st = {color: 'blue', dash: 'solid', size: 'xl'}; if (L.state === 'down') st.color = 'grey'; if (L.state === 'shut'){ st.color = 'grey'; st.dash = 'dotted'; } return st; }
    const st = physStyle(L), ia = portOf(L.a.dev, L.a.if), ib = L.b.dev ? portOf(L.b.dev, L.b.if) : null;
    if (st.color === 'black' && ((ia && ia.trunk) || (ib && ib.trunk))){ st.color = 'blue'; st.size = 'l'; }
    return st;
  };
  // OSPF over SVIs: named on the link between the same two devices on L3
  const svi = new Map();
  for (const L of R.links) if (L.kind === 'ospf-adj'){
    const v = [L.a.if, L.b.if].find(x => /^vl/i.test(x || '')); if (!v) continue;
    const k = [L.a.dev, L.b.dev].sort().join('~'), nv = +v.replace(/\D/g, ''), cur = svi.get(k);
    if (!cur || nv < cur.n) svi.set(k, {n: nv, name: 'Vlan' + nv});
  }
  // the L1/L2 view: every cable (port-channel members one by one, labelled with their Po) plus bundles seen without members
  const l1l2Links = [...physLinks, ...l2Links.filter(L => L.fromLinks)];
  const l1l2Text = L => {
    if (L.circuit) return [[L.circuit.carrier || 'Circuit', L.circuit.cid, L.circuit.speed || L.speed].filter(Boolean).join(' · '), tail(L)].filter(Boolean).join(' · ');
    if (L.pw) return physText(L);
    if (L.fromLinks) return l2Text(L);
    const ia = portOf(L.a.dev, L.a.if), ib = L.b.dev ? portOf(L.b.dev, L.b.if) : null, p = [ia, ib].filter(Boolean);
    const tr = p.find(i => i.trunk), acc = p.find(i => i.accessVlan), routed = p.find(i => i.ips && i.ips.length);
    const po = [...new Set([L.poA, L.poB].filter(Boolean))].join('/');
    const role = tr ? 'trunk' + (tr.allowedVlans && !po ? ' · VLANs ' + shortVlans(tr.allowedVlans) : '') : acc ? 'access VLAN ' + acc.accessVlan : routed ? 'routed' : '';
    return [po, L.speed, role, tail(L)].filter(Boolean).join(' · ');
  };
  const loadedSites = new Set(devs.filter(d => d.data).map(d => d.site));
  const netList = devs.filter(d => !d.external && d.site && loadedSites.has(d.site)
    && (selSite ? d.site === selSite : !isDC(d.site) && (!homeCountry || country(d)===homeCountry)));
  const netCols = localSites.filter(st => netList.some(d => d.site === st));
  const netSet = new Set(netList.map(d => d.name)), local = nm => netSet.has(nm);
  const netPage = (name, heading, draw, legend, withNote) => {
    const shapes = [], place = new Map(), bend = multiBend();
    shapes.push(title(`${opts.title || 'Network'} · ${heading}`, 0, -1060));
    const {maxX, bottom} = placeNetwork(netList, shapes, place, netCols);
    const far = farPlacer(shapes, place, netCols.length === 1 ? netCols[0] : '', homeCountry, true);
    const end = (e, labelKey, labelText) => e.dev ? (local(e.dev) ? place.get(e.dev) : far.dev(R.devices.get(e.dev) || {name: e.dev})) : far.label(labelKey, labelText || 'Circuit', 'circuit far end');
    if (!selSite) for (const d of devs.filter(d => d.data && !local(d.name))) far.dev(d);
    draw({shapes, place, bend, far, end});
    const right = far.layout(0, maxX, -330);
    shapes.push(note(legend, right + 60, -330, 380, 250));
    if (withNote){ const probs = problems.filter(p => netSet.has(p.dev) && p.sev !== 'info');
      if (probs.length) shapes.push(note(`${probs.length} thing${probs.length > 1 ? 's' : ''} to check — see the Problems page.\n` + probs.slice(0, 6).map(p => '• ' + p.dev + ': ' + p.msg).join('\n') + (probs.length > 6 ? '\n…' : ''), right + 60, -40, 420, 110 + Math.min(6, probs.length) * 40, 'orange')); }
    finishPage(name, shapes);
  };
  const each = (arr, fn) => { for (const L of arr){ if (!inScope(L)) continue; const [x,y] = L.a.dev ? [L.a,L.b] : [L.b,L.a]; fn(L,x,y); } };
  netPage('L1/L2', 'L1/L2 physical links (all devices)', ({shapes, place, bend, end}) => each(l1l2Links, (L, x, y) => {
    end(x);
    const yId = end(y, 'circ:' + x.dev + x.if, y.label);
    const st = L.fromLinks ? l2Style(L) : physStyle(L);
    shapes.push(rawConn(place.get(x.dev), yId, x.if, y.if, arc(shapes, place.get(x.dev), yId, bend(x.dev, y.dev || x.if)), st, l1l2Text(L),
      L.bundle && L.members && L.members.length ? 'Members:\n' + L.members.map(m => m.a.dev + ' ' + m.a.if + ' ↔ ' + (m.b.dev || '?') + ' ' + (m.b.if || '')).join('\n') + '\n' + foundBy(L) : foundBy(L), linkKey(L)));
  }), 'Legend (L1/L2)\nOne line per cable; port-channel members are drawn one by one and labelled with their Po.\n— bright yellow: circuit (carrier, circuit ID and bandwidth from the CIRCUIT description)\n— blue: port-channel member · black: cable (trunk / access / routed in the label)\n— pipe with teal dots: cable carrying a pseudowire\n— dashed: from descriptions only (not seen by CDP/LLDP)\n— grey: down / shut\nTop: data centres and remote sites.', true);
  netPage('L3', 'L3 routed view (all devices)', ({shapes, place, bend, end}) => {
    const subOf = (dev, intf) => intf ? portOf(dev, String(intf).split('.')[0] + '.' + suffix) : null;
    for (const L of links){
      // a group of subinterfaces (over a pseudowire or a circuit) is drawn once, from its .N subinterface
      if (L.subs && (L.subs.length > 1 || L.kind === 'over-pw')){
        const al = local(L.a.dev); if (!inScope(L)) continue;
        const [x, y] = al ? [L.a, L.b] : [L.b, L.a], sx = subOf(x.dev, x.if); if (!sx) continue;
        if (pwo.list.some(o => (o.dev === x.dev && samePort(o.if, sx.name)) || (o.dev === y.dev && o.far === x.dev))) continue;
        if (vrfSel && (sx.vrf || 'default') !== vrfSel) continue;
        const sy = subOf(y.dev, y.if), a = sx.ips.find(q => !q.secondary), nb = (sx.ospfUp || [])[0];
        end(x); const yId = end(y);
        shapes.push(rawConn(place.get(x.dev), yId, sx.name, sy ? sy.name : '', arc(shapes, place.get(x.dev), yId, bend(x.dev, y.dev)),
          {color: L.circuit ? 'yellow' : 'teal', dash: L.circuit ? 'solid' : 'dashed', size: 'm'},
          [L.circuit ? [L.circuit.carrier, L.circuit.speed].filter(Boolean).join(' · ') : L.kind === 'over-pw' ? 'over PW' : '', a ? n2ip(netOf(a.ip, a.len)) + '/' + a.len : '', nb ? 'OSPF ' + nb.state : '', costText({dev:x.dev,if:sx.name},{dev:y.dev,if:sy?.name})].filter(Boolean).join(' · '),
          `.${suffix} subinterface of ${L.subs ? L.subs.length + ' subinterfaces' : 'the link'}\n` + foundBy(L), linkKey(L)));
        continue;
      }
      if (['ospf-adj', 'pw', 'pw-attach'].includes(L.kind)) continue;
      if (vrfSel && (vrfOf(L.a.dev, L.a.if) !== vrfSel || vrfOf(L.b.dev, L.b.if) !== vrfSel) && !L.bundle) continue;
      const al = local(L.a.dev); if (!inScope(L)) continue;
      if (!L.subnet && ![L.a,L.b].some(e => portOf(e.dev,e.if)?.ips.length) && !svi.has([L.a.dev,L.b.dev].sort().join('~'))) continue;
      const [x, y] = al ? [L.a, L.b] : [L.b, L.a]; end(x); const yId = end(y);
      const c = connector(L, place.get(x.dev), yId, x.if, y.if, arc(shapes, place.get(x.dev), yId, bend(x.dev, y.dev)));
      c.text = [c.text, costText(x,y)].filter(Boolean).join(' · ');
      const sv = svi.get([L.a.dev, L.b.dev].sort().join('~')); if (sv && !c.text.includes('OSPF')) c.text = [c.text, 'OSPF over ' + sv.name].filter(Boolean).join(' · ');
      shapes.push(c);
    }
    for (const [k, sv] of svi){ const [p, q] = k.split('~'); if (selSite && ![p,q].some(n => R.devices.get(n)?.site===selSite)) continue;
      if (links.some(L => L.kind !== 'ospf-adj' && [L.a.dev, L.b.dev].sort().join('~') === k)) continue;
      shapes.push(rawConn(end({dev:p}), end({dev:q}), '', '', bend(p, q), {color: 'black', dash: 'dashed', size: 'm'}, ['OSPF over ' + sv.name,costText({dev:p,if:sv.name},{dev:q,if:sv.name})].filter(Boolean).join(' · '))); }
    const drawn = new Set();
    for (const o of pwo.list){
      if ((selSite && ![o.dev,o.far].some(n => R.devices.get(n)?.site===selSite)) || (vrfSel && (o.vrf || 'default') !== vrfSel)) continue;
      const pk = [o.dev, o.far].sort().join('~') + '|' + o.subnet; if (o.far && drawn.has(pk)) continue; drawn.add(pk);
      end({dev:o.dev});
      const yId = o.far ? end({dev: o.far}) : end({}, 'pw:' + o.dev + o.if, 'PW far end');
      const st = o.nbr && o.nbr.state === 'FULL' ? {color: 'teal', dash: 'dashed', size: 'm'} : {color: 'grey', dash: 'dashed', size: 'm'};
      shapes.push(rawConn(place.get(o.dev), yId, o.if, o.farIf, arc(shapes, place.get(o.dev), yId, bend(o.dev, o.far || o.if)), st, ['over PW' + (o.vcid ? ' ' + o.vcid : ''), o.subnet, o.nbr ? 'OSPF ' + o.nbr.state : 'no OSPF neighbour shown', o.vrf ? 'VRF ' + o.vrf : '',costText({dev:o.dev,if:o.if},{dev:o.far,if:o.farIf})].filter(Boolean).join(' · '),
        `OSPF on the .${suffix} subinterface over the pseudowire via ${o.tl || '?'}` + (o.nbr ? `\nNeighbour ${o.nbr.rid} at ${o.nbr.addr}` : '')));
    }
  }, `Legend (L3)\n— routed links with their /31\n— teal dashed: OSPF on the .${suffix} subinterface over a pseudowire\n— VLANs and the other subinterfaces are left out; OSPF over an SVI is named on the link${vrfSel ? '\nVRF shown: ' + vrfSel : ''}\nTop: data centres and remote sites.`, false);

  /* ---- problems page ---- */
  {
    const by = s => problems.filter(p => p.sev === s);
    const fmt = list => list.map(p => `• ${p.dev ? p.dev + ': ' : ''}${p.msg}`).join('\n');
    const shapes = [title(`${opts.title || 'Network'} · import report`, 0, -120)];
    const nDev = devs.filter(d => d.data).length;
    shapes.push(note(`Import summary\n${nDev} device file${nDev === 1 ? '' : 's'} read · ${devs.filter(d => !d.data && !d.external && !d.end).length} inventory device(s) without a file · ${devs.filter(d => d.external).length} device(s) outside this import\n${physLinks.length} cable(s) · ${links.length} logical link(s): ${links.filter(l => l.confidence === 'confirmed').length} confirmed, ${links.filter(l => l.confidence === 'config-only').length} config only, ${links.filter(l => l.confidence === 'seen').length} seen by CDP/LLDP only` + (excluded.size ? `\n${excluded.size} link(s) left out by you in the review` : '') + (showShut ? '' : `\nShut links hidden`) + `\nOSPF baseline subinterface: .${suffix}`, 0, -40, 900, 140, 'blue'));
    const w = by('warn'), i = by('info');
    if (w.length) shapes.push(note(`Check these (${w.length})\n` + fmt(w), 0, 140, 900, 60 + w.length * 22, 'orange'));
    if (i.length) shapes.push(note(`For information (${i.length})\n` + fmt(i), 960, 140, 900, 60 + i.length * 22, 'grey'));
    if (!w.length && !i.length) shapes.push(note('No problems found.', 0, 140, 400, 80, 'green'));
    finishPage('Problems', shapes);
  }
  const ORDER = ['WAN', 'L1/L2', 'Physical link speeds', 'L3', 'Pseudowires', 'OSPF overview', ...pages.filter(p => p.name.startsWith('OSPF · ')).map(p => p.name), 'Problems'];
  pages.sort((a, b) => (ORDER.indexOf(a.name) + 1 || 99) - (ORDER.indexOf(b.name) + 1 || 99));
  return {app: 'idea-board', version: 2, name: opts.title || 'Imported network', savedAt: new Date().toISOString(), current: 0, pages, assets: {}};
}



/* ---------------- debug summary (no hostnames, IPs or secrets) ---------------- */
function debugSummary(R){
  const tok = new Map(); let t = 0;
  const T = n => { if (!n) return ''; if (!tok.has(n)){ const h = parseHost(n); tok.set(n, (h ? h.role : 'X') + '-' + String(++t).padStart(2, '0')); } return tok.get(n); };
  const ipMask = s => String(s).replace(/\b(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\b/g, '10.x.x.$4');
  const nameMask = s => String(s).replace(HOST_SCAN, m => T(m.toUpperCase()));
  const clean = s => ipMask(nameMask(s));
  const out = ['IdeaBoard config import — debug summary (hostnames and IPs replaced)', 'engine ' + VERSION, ''];
  for (const d of [...R.devices.values()].sort((a, b) => a.name.localeCompare(b.name))){
    const p = d.data;
    let line = `${T(d.name)} role=${d.role || '?'} site=${d.site ? 'S' + [...new Set([...R.devices.values()].map(x => x.site))].indexOf(d.site) : '?'} model=${(d.model || '').replace(/[^\w-]/g, '') || '?'}`;
    if (!p) line += d.external ? ' [outside import]' : ' [no file]';
    else {
      const ifs = [...d.ifs.values()];
      line += ` cmds=${[...p.cmds].join(',')}${p.invalid.length ? ' invalid=' + p.invalid.length : ''} cfgLines=${p.run ? p.run.lines : 0} ifs=${ifs.length} withIP=${ifs.filter(i => i.ips.length).length} desc=${ifs.filter(i => i.desc).length} shut=${ifs.filter(i => i.shut).length} po=${new Set(ifs.map(i => i.chan).filter(Boolean)).size} ospfIf=${ifs.filter(i => i.ospf && i.ospf.enabled && !i.ospf.passive).length} xc=${ifs.reduce((a, i) => a + i.xc.length, 0) + (p.run ? p.run.l2vpn.length : 0)} cdp=${p.cdp.length} lldp=${p.lldp.length} ospfNbr=${p.ospfNbr.length} xcShow=${p.xc.length} ldp=${p.ldp.size} mac=${p.mac.size} secretsMasked=${p.secretsRemoved}`;
      if (p.unknownCmds.length) line += ` otherCmds=${p.unknownCmds.length}`;
      const kinds = {}; for (const i of ifs) if (i.pdesc) kinds[i.pdesc.kind] = (kinds[i.pdesc.kind] || 0) + 1;
      line += ' descKinds=' + JSON.stringify(kinds);
    }
    out.push(line);
  }
  out.push('', 'Links:');
  for (const L of R.links) out.push(`${T(L.a.dev)} ${L.a.if} <-> ${T(L.b.dev)} ${L.b.if || '?'} kind=${L.kind} conf=${L.confidence} state=${L.state} src=${[...L.srcs].join(',')}${L.memberCount ? ' members=' + L.memberCount : ''}`);
  out.push('', 'Cables (L1/L2):');
  for (const L of R.phys || []) out.push(`${T(L.a.dev)} ${L.a.if} <-> ${L.b.dev ? T(L.b.dev) : 'circuit-end'} ${L.b.if || '?'} speed=${L.speed || '?'}${L.poA || L.poB ? ' po=' + (L.poA || L.poB) : ''}${L.pw ? ' pw=' + (L.pw.far ? T(L.pw.far) : '?') : ''}${L.circuit ? ' circuit' : ''} conf=${L.confidence} state=${L.state} src=${[...L.srcs].join(',')}`);
  out.push('', 'OSPF over pseudowires (.5):');
  for (const o of R.pwOspf || []) out.push(`${T(o.dev)} ${o.if} -> ${o.far ? T(o.far) : '?'} nbr=${o.nbr ? o.nbr.state : 'none'}`);
  out.push('', 'Problems:');
  for (const p of R.problems) out.push(`[${p.sev}] ${T(p.dev)}: ${clean(p.msg)}`);
  return clean(out.join('\n'));
}

const api = {VERSION, parseHost, ifShort, ifKey, scrub, splitSession, parseRun, parseCdp, parseLldp, parseIntDesc, parseBrief, parsePo, parseOspfNbr, parseXc, parseLdp, parseVlan, parseMac,
  parseDesc, parseInventory, parseSites, DEFAULT_SITES, CMD_NAMES, parseDevice, analyze, buildBoard, debugSummary, pwOspfFor, samePort, mergeDevices, parseRouterMap, ospfRecords, ospfMetrics, costLabel,
  speedMbps, speedLabel, portOperatingSpeed, physicalLinkSpeed};
if (typeof module === 'object' && module.exports) module.exports = api; else root.IdeaImport = api;
})(typeof window !== 'undefined' ? window : globalThis);


/* Extra parsers (interface status, OSPF process / interface, VC detail, NX-OS forms) and import helpers. */
(function(root){
'use strict';
const I=typeof module==='object'&&module.exports?module.exports:root.IdeaImport;
const originalParse=I.parseDevice, originalAnalyze=I.analyze;
const key=I.ifKey, short=I.ifShort;
const ipv4=/^\d{1,3}(?:\.\d{1,3}){3}$/;
const iface=n=>/^(?:[A-Za-z-]+\d[\w/.:-]*|(?:ge|xe|et)-\d[\w/.-]*)$/.test(n||'');
const parent=n=>String(n||'').replace(/\.\d+$/,'');
const clean=n=>String(n||'').toUpperCase().split('.')[0];
const clone=x=>typeof structuredClone==='function'?structuredClone(x):x;
function commandContext(cmd){
 const v=/\bvrf\s+(\S+)/i.exec(cmd||''), p=/\bospf\s+((?!neighbors?\b|interface\b|vrf\b)\S+)/i.exec(cmd||'');
 return {vrf:v&&v[1]!=='all'?v[1]:'',pid:p?p[1]:''};
}
function parseOspfProcesses(text,cmd){
 const out=[];let ctx=commandContext(cmd);
 for(const line of text.split('\n')){
  const m=/Routing Process\s+["']?ospf\s+(\S+?)["']?\s+with ID\s+(\d+(?:\.\d+){3})/i.exec(line)||/OSPF Router with ID\s*\(([^)]+)\)\s*\(Process(?: ID)?\s+(\S+)/i.exec(line)||/Routing Process\s+(\S+)\s+with ID\s+(\d+(?:\.\d+){3})/i.exec(line);
  if(m){const nx=/OSPF Router/i.test(line);ctx={...ctx,pid:(nx?m[2]:m[1]).replace(/["')]/g,''),rid:nx?m[1]:m[2]};const v=/\bVRF\s+([^\s,)]+)/i.exec(line);if(v)ctx.vrf=v[1];out.push({...ctx});}
 }
 return out;
}
function parseOspfInterfaces(text,cmd){
 const out=[];let ctx=commandContext(cmd),current=null;
 for(const line of text.split('\n')){
  const head=/OSPF.*?ID\s*\(([^)]+)\).*?Process(?: ID)?\s+(\S+)(?:\s+VRF\s+(\S+))?/i.exec(line);
  if(head)ctx={...ctx,rid:head[1],pid:head[2],vrf:(head[3]||ctx.vrf||'').replace(/\)$/,'')};
  const hv=/\bVRF\s+([^\s,)]+)/i.exec(line);if(hv)ctx.vrf=hv[1];
  let m=/^\s*(\S+)\s+(\S+)\s+(\S+)\s+(\d+(?:\.\d+){3})\/(\d+)\s+(\d+)\s+(\S+)/.exec(line);
  if(m&&iface(m[1])){out.push({...ctx,name:short(m[1]),pid:m[2],area:m[3],ip:m[4],len:+m[5],cost:+m[6],state:m[7]});continue;}
  m=/^\s*(\S+)\s+(\d+)\s+(\S+)\s+(\d+)\s+(\S+)\s+(\d+)\s+(\S+)/.exec(line);
  if(m&&iface(m[1])){out.push({...ctx,name:short(m[1]),interfaceId:m[2],area:m[3],cost:+m[4],state:m[5]});continue;}
  m=/^\s*(\S+) is (?:up|down|administratively down), line protocol/i.exec(line);
  if(m){current={...ctx,name:short(m[1])};out.push(current);continue;}
  if(!current)continue;
  m=/Internet Address\s+(\d+(?:\.\d+){3})\/(\d+),\s*Area\s+(\S+)/i.exec(line);
  if(m)Object.assign(current,{ip:m[1],len:+m[2],area:m[3].replace(/,$/,'')});
  m=/Process ID\s+(\S+), Router ID\s+(\S+), Network Type\s+(\S+), Cost:\s*(\d+)/i.exec(line);
  if(m)Object.assign(current,{pid:m[1],rid:m[2],networkType:m[3],cost:+m[4]});
  m=/State\s+(DR|BDR|DROTHER|POINT_TO_POINT|P2P|DOWN|LOOPBACK)/i.exec(line);if(m)current.state=m[1];
 }
 return out;
}
function parseStatus(text){
 const out=new Map(),lines=text.split('\n'),header=lines.findIndex(x=>/^Port\s+(?:(?:Name|Description)\s+)?Status\s+Vlan\s+Duplex\s+Speed/i.test(x.trim()));
 if(header<0)return out;
 for(const line of lines.slice(header+1)){
  const tokens=line.trim().split(/\s+/),name=tokens[0];if(!iface(name))continue;
  // Names may contain spaces and columns vary across Cisco platforms; NX-OS cuts states to 9 characters ("notconnec", "xcvrAbsen").
  const cols=i=>/^(?:a-)?(?:full|half|auto|--)$/i.test(tokens[i+2]||'')&&(I.speedMbps(tokens[i+3])!=null||/^(?:a-)?(auto|--|unknown)$/i.test(tokens[i+3]||''));
  let index=tokens.findIndex((t,i)=>i>0&&/^(connected|notconnec\w*|disabled|err-?disabled|errDisabl\w*|inactive|suspend\w*|monitor\w*|sfpAbsent|sfpInval\w*|xcvrAbsen\w*|xcvrInval\w*|noOperMem\w*|channelDo\w*|linkFlapE\w*|down|up|faulty)$/i.test(t)&&cols(i));
  if(index<0)index=tokens.findIndex((t,i)=>i>0&&/^[A-Za-z][\w-]*$/.test(t)&&cols(i));
  if(index<0)continue;
  const tail=tokens.slice(index),st=tail[0];
  out.set(key(name),{name:short(name),status:/^(connected|up)$/i.test(st)?'up':/^disabled$/i.test(st)?'admin down':'down',switchStatus:st,vlan:tail[1],duplex:tail[2],speed:tail[3]});
 }
 return out;
}
/* NX-OS "show interface brief": Ethernet and Port-channel sections (Type "eth"); speed like "10G(D)". */
function parseNxBrief(text){
 const out=new Map();
 for(const line of text.split('\n')){
  const t=line.trim().split(/\s+/);
  if(t.length<7||!iface(t[0])||!/^eth$/i.test(t[2]))continue;
  const st=t[4],speed=t[t.length-2].replace(/\(D\)$/i,''),reason=t.slice(5,-2).join(' ');
  const status=/^up$/i.test(st)?'up':/administratively down/i.test(reason)||/^disabled$/i.test(st)?'admin down':'down';
  out.set(key(t[0]),{name:short(t[0]),status,switchStatus:st,vlan:t[1],duplex:'',speed,reason});
 }
 return out;
}
/* "show ip ospf neighbor detail" (IOS-XE) and "show ip ospf neighbors detail" (NX-OS) */
function parseOspfNbrDetail(text,cmd){
 const out=[];let ctx=commandContext(cmd),cur=null;
 for(const line of text.split('\n')){
  let m=/Neighbor\s+(\d+(?:\.\d+){3}),\s*interface address\s+(\d+(?:\.\d+){3})/i.exec(line);
  if(m){cur={...ctx,rid:m[1],addr:m[2],state:'',intf:''};out.push(cur);continue;}
  if(!cur)continue;
  m=/via interface\s+([^\s,]+)/i.exec(line);if(m)cur.intf=short(m[1]);
  m=/State is\s+(\w+)/i.exec(line);if(m)cur.state=m[1].split('/')[0].toUpperCase();
  m=/Process ID\s+(\S+?),?\s+VRF\s+([^\s,]+)/i.exec(line);if(m){cur.pid=m[1];cur.vrf=m[2];}
 }
 return out.filter(n=>n.intf&&n.state);
}
// which output kinds a parser reads its rows into (used to report commands that were found but gave no rows)
const ROWS={cdp:p=>p.cdp.length,cdpb:p=>p.cdp.length,lldp:p=>p.lldp.length,lldpb:p=>p.lldp.length,desc:p=>p.desc.size,brief:p=>p.brief.size,
 po:p=>p.po.length,ospf:p=>p.ospfNbr.length,xc:p=>p.xc.length,l2vc:p=>p.xc.length,status:p=>p.status.size,nxbrief:p=>p.status.size,
 interfaces:p=>p.interfaceDetails.size,ospfi:p=>(p.ospfInterfaces||[]).length,ospfp:p=>(p.ospfProcesses||[]).length};
const HAS_PORT=/\b(?:Gi|Te|Twe|Tw|Hu|Fo|Fa|Eth|Ethernet|GigabitEthernet|TenGigabitEthernet|TwentyFiveGigE|HundredGigE|Po|Port-channel|Vlan|Vl|BDI)\s?\d+(?:\/\d+)*/i;
function parseInterfaceDetails(text){
 const out=new Map();let current=null;
 for(const line of text.split('\n')){
  const header=/^\s*(\S+) is (administratively down|up|down)(?:, line protocol is (up|down))?/i.exec(line);
  if(header&&iface(header[1])){
   const state=/administratively down/i.test(header[2])?'admin down':header[2].toLowerCase()==='up'&&header[3]?.toLowerCase()!=='down'?'up':'down';
   current={name:short(header[1]),status:state,speed:''};out.set(key(current.name),current);continue;
  }
  if(!current)continue;
  const operating=/\b(?:full|half|auto)[ -]duplex\s*[,;]\s*([^,;\n]+)/i.exec(line);
  if(operating&&I.speedMbps(operating[1])!=null)current.speed=operating[1].trim();
 }
 return out;
}
function parseVcDetail(text){
 const out=[];let local=null;
 for(const line of text.split('\n')){
  let m=/Local interface:\s*(\S+)\s+(up|down|administratively down)/i.exec(line);
  if(m){local={ac:short(m[1].replace(/,$/,'')),acState:m[2].toUpperCase(),svc:null};continue;}
  m=/Destination address:\s*(\d+(?:\.\d+){3}),\s*VC ID:\s*(\d+),\s*VC status:\s*(\S+)/i.exec(line);
  if(m&&local)out.push({...local,peer:m[1],vcid:m[2],state:m[3].toUpperCase(),pwState:m[3].toUpperCase()});
 }
 return out;
}
I.parseDevice=function(name,text){
 const p=originalParse(name,text),sess=I.splitSession(I.scrub(String(text)).text);
 p.status=new Map();p.interfaceDetails=new Map();p.ospfProcesses=[];p.ospfInterfaces=[];p.platform='unknown';
 for(const b of sess.blocks){
  if(b.kind==='status'){p.cmds.add('status');for(const [k,v]of parseStatus(b.text))p.status.set(k,v);}
  if(b.kind==='nxbrief'){p.cmds.add('nxbrief');for(const [k,v]of parseNxBrief(b.text))if(!p.status.has(k))p.status.set(k,v);}
  if(b.kind==='interfaces'){p.cmds.add('interfaces');for(const [k,v]of parseInterfaceDetails(b.text))p.interfaceDetails.set(k,v);}
  if(b.kind==='ospfp'){p.cmds.add('ospfp');p.ospfProcesses.push(...parseOspfProcesses(b.text,b.cmd));}
  if(b.kind==='ospfi'){p.cmds.add('ospfi');p.ospfInterfaces.push(...parseOspfInterfaces(b.text,b.cmd));}
  if(b.kind==='l2vc')p.xc.push(...parseVcDetail(b.text));
 }
 // Re-read neighbors with context intact; summary parsers otherwise discard NX-OS headings.
 p.ospfNbr=[];
 for(const b of sess.blocks.filter(b=>b.kind==='ospf')){
  if(/interface address/i.test(b.text)&&!/Neighbor ID\s+Pri\s+State/i.test(b.text)){p.ospfNbr.push(...parseOspfNbrDetail(b.text,b.cmd));continue;}
  let ctx=commandContext(b.cmd);
  for(const line of b.text.split('\n')){
   const proc=/OSPF.*?ID\s*\(([^)]+)\).*?Process(?: ID)?\s+(\S+)/i.exec(line),vrf=/\bVRF\s+([^\s,)]+)/i.exec(line);
   if(proc)ctx={...ctx,localRid:proc[1],pid:proc[2].replace(/\)$/,'')};if(vrf)ctx.vrf=vrf[1];
   const n=I.parseOspfNbr(line)[0];if(n){p.ospfNbr.push({...n,...ctx});continue;}
   const t=line.trim().split(/\s+/);
   if(ipv4.test(t[0])&&t.length>=5&&iface(t.at(-1))){
    const ai=t.findIndex((x,i)=>i>0&&ipv4.test(x));
    if(ai>0)p.ospfNbr.push({...ctx,rid:t[0],addr:t[ai],state:t[1].split('/')[0].toUpperCase(),intf:short(t.at(-1))});
   }
  }
 }
 if(/NX-OS|Nexus/i.test(text))p.platform='NX-OS';else if(/IOS XE|ASR.?920|C9[35]00/i.test(text))p.platform='IOS XE';
 // outputs that name ports, so they should have produced rows (an empty neighbour table names none)
 p.portKinds=[];
 for(const b of sess.blocks)if(ROWS[b.kind]&&HAS_PORT.test(b.text.replace(/^.*(?:Local Intrfce|Local Intf|Local Port id|Interface)\s*$/gim,''))&&!p.portKinds.some(x=>x.kind===b.kind))p.portKinds.push({kind:b.kind,cmd:b.cmd});
 return p;
};
I.analyze=function(parsed,opts={}){
 // Existing analysis annotates config objects. Re-analysis must start from fresh data.
 const inputs=[];
 for (const p of clone(parsed)){const old=inputs.find(x=>x.name===p.name);if(old)I.mergeDevices(old,p);else inputs.push(p);}
 const canonical=(p,n)=>{
  const exact=p?.run?.ifs.get(key(n));if(exact)return exact.name;
  const matches=[...(p?.run?.ifs.values()||[])].filter(i=>I.samePort(i.name,n));
  return matches.length===1?matches[0].name:n;
 };
 for(const p of inputs){
  for(const field of ['desc','brief','status','interfaceDetails'])p[field]=new Map([...(p[field]||[])].map(([k,v])=>{const name=canonical(p,v.name);return [key(name),{...v,name}];}));
  for(const n of [...p.cdp,...p.lldp]){n.local=canonical(p,n.local);const remote=inputs.find(q=>q.name===String(n.name).toUpperCase().split('.')[0]);n.remote=canonical(remote,n.remote);}
  for(const n of p.ospfNbr)n.intf=canonical(p,n.intf);
  for(const n of p.ospfInterfaces||[])n.name=canonical(p,n.name);
  // Port state: show interfaces description first, then show interfaces status, then show interfaces (NX-OS descriptions carry no state).
  for(const src of [p.status,p.interfaceDetails])for(const [k,v]of src||[]){const e=p.desc.get(k);if(!e)p.desc.set(k,{name:v.name,desc:'',status:v.status,proto:''});else if(!e.status)e.status=v.status;}
  for(const n of [...p.cdp,...p.lldp])if(!p.desc.has(key(n.local)))p.desc.set(key(n.local),{name:n.local,desc:'',status:'',proto:''});
  for(const [k,v]of p.brief)if(!p.desc.has(k))p.desc.set(k,{name:v.name,desc:'',status:v.status,proto:v.proto});
  // Show-only pseudowire data still establishes transport service endpoints.
  if(!p.run&&p.xc.length)p.run=I.parseRun('');
  if(p.run)for(const x of p.xc){const k=key(x.ac);let i=p.run.ifs.get(k);if(!i){i=I.parseRun('interface '+x.ac).ifs.get(k);p.run.ifs.set(k,i);}if(!i.xc.some(q=>q.peer===x.peer&&q.vcid===x.vcid))i.xc.push({peer:x.peer,vcid:x.vcid,svc:x.svc});}
  // Apply observed OSPF metrics before comparing the two ends of routed links.
  if(p.ospfInterfaces?.length&&!p.run)p.run=I.parseRun('');
  for(const shown of p.ospfInterfaces||[]){
   let i=p.run.ifs.get(key(shown.name));
   if(!i){i=I.parseRun('interface '+shown.name).ifs.get(key(shown.name));p.run.ifs.set(key(shown.name),i);}
   Object.assign(i.ospf,{cost:shown.cost??i.ospf.cost,area:shown.area??i.ospf.area,areaN:shown.area??i.ospf.areaN,pid:shown.pid||i.ospf.pid,enabled:true});
   if(shown.vrf)i.vrf=shown.vrf;
   if(shown.ip&&!i.ips.some(a=>a.ip===shown.ip))i.ips.push({ip:shown.ip,len:shown.len,secondary:false});
  }
 }
 const inventory=new Map(opts.inventory||[]);
 const routerMap=opts.routerMap instanceof Map?opts.routerMap:new Map(Object.entries(opts.routerMap||{}));
 for(const [ip,name]of routerMap)if(!inventory.has(name))inventory.set(name,{name,ip,vendor:'',model:''});
 const R=originalAnalyze(inputs,{...opts,inventory});
 for(const d of R.devices.values())if(d.data){
  for(const cmd of d.data.unknownCmds||[])R.problems.push({sev:'info',dev:d.name,msg:'Unrecognized output was not used: '+cmd});
  for(const {kind,cmd}of d.data.portKinds||[])if(!ROWS[kind](d.data))R.problems.push({sev:'warn',dev:d.name,msg:'"'+cmd+'" ('+(I.CMD_NAMES[kind]||kind)+') was found and names ports, but no rows could be read from it — its data is missing from the diagrams. Check this platform output.'});
  for(const [k,v]of d.data.status||[]){const i=d.ifs.get(k);if(i)Object.assign(i,{switchStatus:v.switchStatus,observedSpeed:v.speed});}
  for(const v of d.data.ospfInterfaces||[]){const i=d.ifs.get(key(v.name));if(i)Object.assign(i.ospf,{area:v.area??i.ospf.area,cost:v.cost??i.ospf.cost,pid:v.pid||i.ospf.pid,networkType:v.networkType||''});}
 }
 const checkedRates=new Set();
 for(const link of R.phys||[])for(const end of [link.a,link.b]){
  if(!R.devices.get(end.dev)?.data||!end.if||!/^(?:Gi|Te|Twe|Fo|Hu|Fa|Eth)\d/i.test(short(end.if)))continue;
  const k=end.dev+' '+end.if;if(checkedRates.has(k))continue;checkedRates.add(k);
  const rate=I.portOperatingSpeed(R,end);if(rate.mbps==null&&!rate.down&&!rate.stateConflict&&!rate.speedConflict)
   R.problems.push({sev:'info',dev:end.dev,speedCollection:k,msg:end.if+': operating speed unavailable. Include show interface status (Nexus/Catalyst) or show interfaces '+end.if+' (ASR 920/detail fallback). Keep command headings; interface type and configured BW do not establish an operating rate.'});
 }
 R.ospfReview=I.ospfRecords(R,{...opts,excluded:[]});
 for(const problem of R.ospfReview.problems)if(!R.problems.some(p=>p.dev===problem.dev&&p.msg===problem.msg))R.problems.push(problem);
 return R;
};
const endpoint=e=>e.dev+'|'+key(e.if||'');
const linkKey=L=>[endpoint(L.a),endpoint(L.b)].sort().join('~');
I.linkKey=linkKey;

I.parseStatus=parseStatus;I.parseVcDetail=parseVcDetail;I.parseInterfaceDetails=parseInterfaceDetails;
})(typeof window!=='undefined'?window:globalThis);

