// Interface history: state timeline + every message for the port.
import { esc, icon, api, qs, n, fmtTs, shortIf, loading, dur } from '../util.js';
import { state, go } from '../state.js';
import { eventTable, bindEventTable, RANGES } from '../components.js';
import { stateBar } from '../charts.js';

export async function render(main, { params }) {
  const interp = state.lastSearch;
  state.lastSearch = null;
  let range = params.range || (['3d', '7d'].includes(state.range) ? state.range : '7d');
  main.innerHTML = `<div class="page">${loading()}</div>`;

  async function load() {
    const d = await api('/api/interface?' + qs({ host: params.host, iface: params.iface, range }));
    const now = state.now();
    const segs = d.segments;
    const downTime = segs.filter(s => s.state === 'down').reduce((a, s) => a + (s.t1 - s.t0), 0);
    const last = [...d.events].reverse().find(e => ['link_state', 'errdisable'].includes(e.kind) && e.state);
    main.innerHTML = `<div class="page">
      <div class="crumb"><a href="#/device/${esc(d.host)}">${esc(d.host)}</a> / interface</div>
      <div class="ph"><div><h1>${esc(d.host)} · ${esc(d.interface)}</h1>
        <div class="sub">${esc(d.class ? `Port class: ${d.class}` : '')}${last ? ` · last logged state <b>${esc(last.state)}</b> at ${esc(fmtTs(last.ts))}` : ' · no state messages in range'}</div></div>
        <div class="grow"></div><div class="seg" id="rng">${RANGES.filter(r => r[0] !== 'today').map(([v, l]) => `<button data-v="${v}" class="${v === range ? 'on' : ''}">${l}</button>`).join('')}</div></div>
      ${interp ? `<div class="interp">${icon('search', 'sm')} Interpreted <b>“${esc(interp.query)}”</b> as: ${esc(interp.explain.join(' · '))}</div>` : ''}
      <div class="grid">
        <div class="card c12"><div class="hd"><h3>Link state over time</h3><span class="grow"></span>
          <span class="legend"><span><i style="background:color-mix(in srgb, var(--s-good) 70%, transparent)"></i>up</span><span><i style="background:var(--s-critical)"></i>down</span><span><i style="background:var(--surface-3)"></i>unknown (no message yet)</span></span></div>
          <div class="bd"><div id="sb"></div>
          <div class="statgrid" style="margin-top:12px">
            <div class="stat"><div class="l">Link-down events</div><div class="v num">${n(d.downs)}</div></div>
            <div class="stat"><div class="l">Time down (from logs)</div><div class="v">${dur(downTime)}</div></div>
            <div class="stat"><div class="l">Messages</div><div class="v num">${n(d.events.length)}</div></div>
            <div class="stat"><div class="l">Error counters</div><div class="v" style="font-size:13px;font-weight:500">Not in syslog - run <span class="mono">show interface ${esc(shortIf(d.interface))} counters errors</span></div></div>
          </div></div></div>
        <div class="card c12"><div class="hd"><h3>All messages for this interface</h3><span class="grow"></span>
          <a class="btn sm" href="#/investigate?${qs({ host: d.host, iface: d.interface, range })}">Open in Investigate</a></div>
          <div class="bd" style="padding:0" id="evt">${eventTable([...d.events].reverse(), { now, showHost: false, maxh: 600 })}</div></div>
      </div></div>`;
    stateBar(main.querySelector('#sb'), segs, d.window.t0, d.window.t1);
    bindEventTable(main.querySelector('#evt'));
    main.querySelectorAll('#rng button').forEach(b => b.onclick = () => { range = b.dataset.v; load(); });
  }
  await load();
}
