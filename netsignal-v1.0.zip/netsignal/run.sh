#!/usr/bin/env bash
# NetSignal launcher (Linux / macOS)
cd "$(dirname "$0")"
if [ ! -d .venv ]; then
  python3 -m venv .venv && .venv/bin/pip install -q -r requirements.txt
fi
exec .venv/bin/python -m netsignal "$@"
