"""Functional browser checks. Requires Python Playwright and Chromium for testing only."""
import io
import json
import os
import pathlib
import shutil
import tempfile
import zipfile
import xml.etree.ElementTree as ET

from playwright.sync_api import sync_playwright, expect

ROOT = pathlib.Path(__file__).resolve().parents[1]
URL = os.environ.get('IDEABOARD_URL', 'http://127.0.0.1:8000/')
ARTIFACTS = pathlib.Path(os.environ.get('IDEABOARD_TEST_OUTPUT', tempfile.gettempdir() + '/ideaboard-3.6-tests'))
HOSTS = ['EDEM001CL0101', 'EDEM001CL0102']


def collector(host, peer):
    return f'''Running command show running-config | section interface on the {host}
interface GigabitEthernet1/0/1
 description UPLINK: {peer} Gi1/0/1
 switchport mode trunk
 channel-group 10 mode active
 no shutdown
!
Running command show interfaces description on the {host}
Interface                      Status         Protocol Description
Gi1/0/1                        up             up       UPLINK: {peer} Gi1/0/1
Running command sho interface status on the {host}
Port      Name                  Status       Vlan       Duplex  Speed Type
Gi1/0/1   To the other core     connected    trunk      a-full  a-1000 10GBase-SR
Running command show cdp neighbors detail on the {host}
Device ID: {peer}
Platform: cisco C9500, Capabilities: Switch
Interface: GigabitEthernet1/0/1, Port ID (outgoing port): GigabitEthernet1/0/1
Holdtime : 150 sec
'''


def ospf_session(host, side):
    peer=2-side
    config=''
    observations=''
    for i, vrf in enumerate(['default','BLUE']):
        port=f'Gi1/0/{i+1}.5'
        config+=f'interface {port}\n'
        if vrf!='default': config+=f' vrf forwarding {vrf}\n'
        config+=f' ip address 192.0.2.{2*i+side} 255.255.255.254\n ip ospf {i+1} area 0\n ip ospf cost {10+10*side}\n!\nrouter ospf {i+1}'
        if vrf!='default':config+=f' vrf {vrf}'
        config+=f'\n router-id 198.51.100.{side+1}\n!\n'
        observations+=f'{host}#show ip ospf {i+1} neighbor'+('' if vrf=='default' else f' vrf {vrf}')+f'\n198.51.100.{peer} 1 FULL/DR 00:00:30 192.0.2.{2*i+1-side} {port}\n'
    return f'{host}#show running-config\n{config}{observations}'


def select_page(page, name):
    if not page.locator('#pagesPanel').evaluate("el=>el.classList.contains('open')"):
        page.locator('#pageBtn').click()
    page.locator('#pagesPanel .pp-name').filter(has_text=name).first.click()
    page.wait_for_function('(name)=>ideaBoard.pages[ideaBoard.curPage].name===name', arg=name)


def board_data(page):
    return page.evaluate('()=>({name:document.querySelector("#boardName").value,pages:ideaBoard.pages})')


def open_import(page, files):
    page.locator('#menuBtn').click()
    page.locator('[data-menu="cfgimport"]').click()
    assert page.locator('#niVrf').input_value()=='default'
    with page.expect_file_chooser() as chosen:
        page.locator('[data-act="files"]').click()
    assert not chosen.value.element.get_attribute('accept')
    chosen.value.set_files(files)
    page.wait_for_function("document.querySelectorAll('#cfgImport .ni-name').length===2")
    assert not page.locator('#cfgImport .ni-error').count()


def run():
    ARTIFACTS.mkdir(parents=True,exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='ideaboard-browser-') as temp, sync_playwright() as pw:
        executable=os.environ.get('CHROMIUM_PATH') or shutil.which('chromium') or shutil.which('google-chrome')
        browser=pw.chromium.launch(executable_path=executable,headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
        context=browser.new_context(accept_downloads=True,viewport={'width':1440,'height':1000})
        page=context.new_page()
        errors=[]
        page.on('pageerror',lambda error: errors.append(str(error)))
        page.goto(URL)
        page.wait_for_function('window.IdeaImport && window.IdeaImportUI && window.ideaBoard && window.IdeaVisio')
        assert page.locator('#appVersion').inner_text()=='v3.8.0'

        files=[]
        for host,peer in [HOSTS,HOSTS[::-1]]:
            path=pathlib.Path(temp)/(host+'.20261015.120000')
            path.write_text(collector(host,peer));files.append(path)
        open_import(page,files)
        assert page.locator('.ni-stat').nth(1).inner_text().startswith('1\n')
        page.locator('[data-act="draw"]').click()
        select_page(page,'L1/L2')
        current=board_data(page)
        physical=next(p for p in current['pages'] if p['name']=='L1/L2')
        links=[s for s in physical['shapes'] if s['type']=='connector']
        assert len(links)==1 and 'Po10' in links[0]['text']
        print('PASS: timestamp files through file picker; individual Po member and valid generated pages',flush=True)

        select_page(page,'Physical link speeds')
        management=next(p for p in board_data(page)['pages'] if p['name']=='Physical link speeds')
        rate=next(s for s in management['shapes'] if s['type']=='connector')
        assert rate['text']=='1 Gb/s' and rate['operatingSpeed']['status']=='agreed'
        assert 'pipe' not in rate
        page.locator('#canvas').focus();page.keyboard.press('v')
        page.locator('#world [data-id="'+rate['id']+'"] text').filter(has_text=rate['text']).click()
        expect(page.locator('#stylePanel')).to_contain_text('speed a-1000 (1 Gb/s)')
        page.locator('#menuBtn').click()
        with page.expect_download() as svg:
            page.locator('[data-menu="svg"]').click()
        assert '1 Gb/s' in pathlib.Path(svg.value.path()).read_text()
        page.locator('#menuBtn').click();page.locator('[data-menu="visio"]').click()
        page.locator('#visioScope').select_option('current')
        with page.expect_download() as speed_vsdx:page.locator('#visioDownload').click()
        speed_payload=pathlib.Path(speed_vsdx.value.path()).read_bytes()
        speed_roundtrip=page.evaluate('async payload=>await IdeaVisio.parse(new Uint8Array(payload))',list(speed_payload))
        restored=next(s for s in speed_roundtrip['pages'][0]['shapes'] if s['type']=='connector')
        assert restored['text']=='1 Gb/s' and restored['operatingSpeed']['mbps']==1000
        page.locator('#visioClose').click()
        print('PASS: management speed page, source inspection, SVG and Visio speed/evidence round trips',flush=True)
        page.locator('#menuBtn').click()
        with page.expect_download() as saved:
            page.locator('[data-menu="save"]').click()
        saved_board=json.loads(pathlib.Path(saved.value.path()).read_text())
        assert saved_board['app']=='idea-board'
        assert any(s.get('operatingSpeed',{}).get('mbps')==1000 for p in saved_board['pages'] for s in p['shapes'])
        page.reload()
        page.wait_for_function("document.querySelector('#world').textContent.includes('EDEM001CL0101')")
        page.locator('#canvas').focus()
        page.keyboard.press('Shift+F')
        page.wait_for_function("document.body.classList.contains('clean')")
        page.wait_for_function('document.fullscreenElement!==null')
        page.keyboard.press('Escape')
        page.wait_for_function("!document.body.classList.contains('clean')")
        print('PASS: board download and reload; Shift+F fullscreen and Escape',flush=True)

        page.locator('#menuBtn').click();page.locator('[data-menu="cfgimport"]').click()
        with page.expect_file_chooser() as folder:page.locator('[data-act="folder"]').click()
        assert folder.value.element.get_attribute('webkitdirectory') is not None
        folder.value.set_files(temp)
        page.wait_for_function("document.querySelectorAll('#cfgImport .ni-name').length===2")
        page.get_by_role('button',name='Close import',exact=True).click()
        page.locator('#menuBtn').click();page.locator('[data-menu="cfgimport"]').click()
        page.locator('#niPaste').fill(collector(*HOSTS))
        page.locator('[data-act="paste"]').click()
        page.wait_for_function("document.querySelectorAll('#cfgImport .ni-name').length===1")
        page.get_by_role('button',name='Close import',exact=True).click()
        print('PASS: folder upload and pasted collector session',flush=True)

        # OSPF options and remembered mappings through their real UI.
        ospf_files=[]
        for side,host in enumerate(['EDEM001CL0101','EDEM002DL0101']):
            path=pathlib.Path(temp)/(host+'.csv')
            path.write_text(ospf_session(host,side));ospf_files.append(path)
        archive=pathlib.Path(temp)/'get-out.zip'
        with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
            for path in ospf_files:z.write(path,'outputs/'+path.name)
        open_import(page,[archive])
        assert page.locator('#niVrf option[value="BLUE"]').count()==1
        page.locator('#niVrf').select_option('')
        page.locator('#niCosts').uncheck()
        page.locator('[data-tab="links"]').click()
        assert page.locator('input[data-link^="ospf:"]').count()==2
        page.locator('input[data-link^="ospf:"]').first.uncheck()
        assert not page.locator('input[data-link^="ospf:"]').first.is_checked()
        page.locator('input[data-link^="ospf:"]').first.check()
        page.get_by_text('OSPF peer mappings (remembered in this browser)',exact=True).click()
        page.locator('#niPeers').fill('198.51.100.50 = EDEM050TL0101')
        page.locator('#niPeers').press('Tab')
        page.locator('[data-act="draw"]').click()
        select_page(page,'OSPF · DEM001')
        data=board_data(page)
        p=next(p for p in data['pages'] if p['name']=='OSPF · DEM001')
        c=next(s for s in p['shapes'] if s['type']=='connector')
        assert len(c['adjacencies'])==2 and 'OSPF ×2' in c['text']
        assert 'cost ' not in c['text'] and 'cost 10 / 20' in c['foundBy']
        page.locator('#canvas').focus()
        page.keyboard.press('v')
        page.locator('#world [data-id="'+c['id']+'"] text').filter(has_text=c['text']).first.click()
        page.screenshot(path=str(ARTIFACTS/'ospf-site.png'))
        expect(page.locator('#stylePanel')).to_contain_text('VRF: BLUE')
        page.screenshot(path=str(ARTIFACTS/'ospf-site.png'))
        print('PASS: ZIP inputs with arbitrary extensions; VRF grouping, cost toggle and selection evidence',flush=True)

        page.locator('#menuBtn').click()
        page.locator('[data-menu="cfgimport"]').click()
        assert page.locator('#niPeers').input_value()=='198.51.100.50 = EDEM050TL0101'
        page.get_by_text('OSPF peer mappings (remembered in this browser)',exact=True).click()
        page.locator('#niPeers').fill('not a mapping')
        page.locator('#niPeers').press('Tab')
        assert 'Peer mapping line 1' in page.locator('.ni-error').inner_text()
        assert page.locator('[data-act="draw"]').is_disabled()
        page.get_by_role('button',name='Close import',exact=True).click()
        print('PASS: peer mapping persistence and validation',flush=True)

        # Native document structure and browser round trips, not desktop Visio rendering.
        for theme in ['light','black','none']:
            page.locator('#menuBtn').click();page.locator('[data-menu="visio"]').click()
            page.locator('#visioBg').select_option(theme)
            page.locator('#visioScope').select_option('all')
            with page.expect_download() as downloaded:page.locator('#visioDownload').click()
            payload=pathlib.Path(downloaded.value.path()).read_bytes()
            with zipfile.ZipFile(io.BytesIO(payload)) as z:
                assert z.testzip() is None
                pages_xml=ET.fromstring(z.read('visio/pages/pages.xml'))
                bg=[n for n in pages_xml if n.attrib.get('Background')=='1']
                assert len(bg)==(0 if theme=='none' else 1)
                for name in z.namelist():
                    if name.endswith(('.xml','.rels')):ET.fromstring(z.read(name))
            path=ARTIFACTS/f'Example-{theme}.vsdx';path.write_bytes(payload)
            parsed=page.evaluate('async payload=>{const r=await IdeaVisio.parse(new Uint8Array(payload));return {pages:r.pages,warnings:r.warnings};}',list(payload))
            assert len(parsed['pages'])==len(data['pages'])
            parsed_links=[s for p in parsed['pages'] for s in p['shapes'] if s['type']=='connector']
            assert any(len(s.get('adjacencies',[]))==2 for s in parsed_links)
            page.locator('#visioClose').click()
        print('PASS: Light/Black/None Visio ZIP/XML, background pages, adjacency metadata round trips',flush=True)

        # Simulate supported native Visio edits without claiming desktop Visio execution.
        target_index=next(i for i,p in enumerate(data['pages']) if p['name']=='OSPF · DEM001')
        part=f'visio/pages/page{target_index+1}.xml'
        ns={'v':'http://schemas.microsoft.com/office/visio/2012/main'}
        before=next(s for s in parsed['pages'][target_index]['shapes'] if s['type']=='device' and s['text']=='EDEM001CL0101')
        buffer=io.BytesIO()
        with zipfile.ZipFile(io.BytesIO(payload)) as original,zipfile.ZipFile(buffer,'w',zipfile.ZIP_DEFLATED) as modified:
            for name in original.namelist():
                content=original.read(name)
                if name==part:
                    doc=ET.fromstring(content)
                    group=next(g for g in doc.findall('./v:Shapes/v:Shape',ns) if g.attrib.get('Type')=='Group'
                               and any(t.text=='EDEM001CL0101' for t in g.findall('.//v:Text',ns)))
                    pin=next(c for c in group.findall('v:Cell',ns) if c.attrib.get('N')=='PinX')
                    pin.attrib['V']=str(float(pin.attrib['V'])+1)
                    text=next(t for t in group.findall('.//v:Text',ns) if t.text=='EDEM001CL0101')
                    text.text='EDITED-CORE'
                    content=ET.tostring(doc,encoding='utf-8',xml_declaration=True)
                modified.writestr(name,content)
        edited=page.evaluate('async payload=>await IdeaVisio.parse(new Uint8Array(payload))',list(buffer.getvalue()))
        moved=next(s for s in edited['pages'][target_index]['shapes'] if s['type']=='device' and s['text']=='EDITED-CORE')
        assert abs(moved['x']-before['x']-96)<0.1
        edited_path=ARTIFACTS/'Simulated-Visio-edit.vsdx';edited_path.write_bytes(buffer.getvalue())
        page.locator('#visioInput').set_input_files(edited_path)
        page.wait_for_function("document.querySelector('#boardName').value.startsWith('Simulated-Visio-edit')")
        for p in board_data(page)['pages']:
            ids={s['id'] for s in p['shapes']}
            for c in [s for s in p['shapes'] if s['type']=='connector']:
                assert c['start'].get('id') in ids and c['end'].get('id') in ids
        print('PASS: simulated native device move/rename and glued connector reimport',flush=True)

        # A port name typed into its tag in Visio comes back as the link's port label; tags are tied to their link.
        tag_edit=page.evaluate("""async()=>{
          const icon='M11 19h24';
          const shapes=[{id:'a',type:'device',x:0,y:0,w:64,h:64,color:'#2b8a3e',hostname:'EDEM001AS0101',icon,fillMode:'solid',ib:JSON.stringify({type:'device',kind:'switch',text:'EDEM001AS0101',x:0,y:0,w:64,h:64})},
            {id:'b',type:'device',x:300,y:0,w:64,h:64,color:'#2b8a3e',hostname:'EDEM001AS0102',icon,fillMode:'solid',ib:JSON.stringify({type:'device',kind:'switch',text:'EDEM001AS0102',x:300,y:0,w:64,h:64})},
            {id:'c',type:'connector',points:[{x:64,y:32},{x:300,y:32}],start:{id:'a',anchor:{x:1,y:.5}},end:{id:'b',anchor:{x:0,y:.5}},route:'straight',color:'#1d1d1d',lineWidth:2.5,startLabel:'Gi1/0/1',endLabel:'Gi1/0/2',ib:JSON.stringify({type:'connector',route:'straight',startLabel:'Gi1/0/1',endLabel:'Gi1/0/2'})},
            {id:'t',type:'rect',role:'portTag',bind:{conn:'c',end:'start'},x:80,y:22,w:50,h:20,text:'Gi1/0/1',color:'#1d1d1d',fontSize:12,vname:'Port label',ib:'{"type":"portLabel"}'}];
          const out=IdeaVisio.build({name:'t',pages:[{name:'P',shapes}],style:'visio',bg:'none',grid:'none'});
          const files=out.files.map(([n,c])=>[n,n==='visio/pages/page1.xml'?c.replace('<Text>Gi1/0/1</Text>','<Text>Gi1/0/9</Text>'):c]);
          const parsed=await IdeaVisio.parse(IdeaVisio.zip(files));
          const link=parsed.pages[0].shapes.find(s=>s.type==='connector');
          return {start:link.startLabel,end:link.endLabel,formula:/PNTX\\(LOCTOPAR\\(POINTALONGPATH\\(Sheet\\.3!Geometry1\\.Path/.test(out.files.find(f=>f[0]==='visio/pages/page1.xml')[1])};
        }""")
        assert tag_edit=={'start':'Gi1/0/9','end':'Gi1/0/2','formula':True},tag_edit
        print('PASS: port tags follow their link in Visio; a tag edited in Visio is read back as the port label',flush=True)

        assert not errors,errors
        print('PASS: no browser JavaScript errors',flush=True)
        browser.close()


if __name__=='__main__':run()
