"""NetSignal command line.

  python -m netsignal                     run the dashboard (mode from config.yaml; demo by default)
  python -m netsignal --demo              force demo mode with SIMULATED data
  python -m netsignal test-connection     verify read-only SSH/SFTP access to the syslog server
  python -m netsignal analyze FILE [...]  offline parser coverage report for real log files (.gz ok)
  python -m netsignal generate-sample     (re)create the simulated CISCO directory
"""
from __future__ import annotations

import argparse
import gzip
import os
import sys
import threading
import time
import webbrowser
from collections import Counter
from pathlib import Path


def _setup(cfg_path, demo):
    from .config import load_config
    from .timeutil import set_timezone
    cfg = load_config(cfg_path)
    if demo:
        cfg["source"]["mode"] = "demo"
    set_timezone(cfg.get("log_timezone"))
    return cfg


def cmd_run(args):
    import uvicorn
    from .api import App, build
    from .classifier import Classifier
    from .ingest.manager import IngestManager, Pipeline
    from .store import Store

    cfg = _setup(args.config, args.demo)
    simulated = cfg["source"]["mode"] == "demo"
    db_path = cfg["database"]["path"]
    if simulated:
        from .simulate import generate, LiveWriter
        d = cfg["source"]["demo"]
        db_path = str(Path(db_path).with_name("netsignal-demo.db"))
        for suffix in ("", "-wal", "-shm"):
            try:
                os.remove(db_path + suffix)
            except FileNotFoundError:
                pass
        print("[demo] generating SIMULATED Cisco syslog data ...", flush=True)
        counts = generate(d["directory"], int(d["history_days"]), int(d["lines_per_day"]))
        print(f"[demo] {counts}", flush=True)
        LiveWriter(d["directory"], float(d["live_rate"])).start()

    store = Store(db_path)
    cls = Classifier(cfg)
    pipe = Pipeline(store, cls)
    ing = IngestManager(cfg, store, pipe)
    ing.start()
    app = build(App(cfg, store, cls, pipe, ing, simulated))
    host = args.host or cfg["server"]["host"]
    port = int(args.port or cfg["server"]["port"])
    url = f"http://{'127.0.0.1' if host in ('0.0.0.0', '::') else host}:{port}/"
    print(f"\n  NetSignal running at {url}  (source: {cfg['source']['mode']}{' - SIMULATED DATA' if simulated else ''})\n",
          flush=True)
    if not args.no_browser:
        threading.Timer(1.5, lambda: webbrowser.open(url)).start()
    uvicorn.run(app, host=host, port=port, log_level="warning")


def cmd_test(args):
    from .ingest.access import make_access
    cfg = _setup(args.config, False)
    if cfg["source"]["mode"] != "ssh":
        print(f"source.mode is '{cfg['source']['mode']}' - testing that backend")
    acc = make_access(cfg)
    print(f"connecting to {acc.describe()} ...")
    t = time.time()
    acc.connect()
    print(f"  connected in {time.time() - t:.1f}s")
    files = sorted(acc.listdir(), key=lambda f: f[0])
    print(f"  {len(files)} files in directory; archives/live:")
    for name, size, mtime in files[-10:]:
        print(f"    {name:24} {size / 1e6:10.1f} MB  {time.strftime('%Y-%m-%d %H:%M', time.localtime(mtime))}")
    live = acc.join(cfg["source"]["live_file"])
    size, _ = acc.stat(live)
    tail = acc.read_range(live, max(0, size - 2000), 2000).decode("utf-8", "replace").splitlines()[-3:]
    print("  last lines of live file:")
    for ln in tail:
        print("    " + ln[:160])
    acc.close()
    print("OK - read-only access works.")


def cmd_analyze(args):
    from .classifier import Classifier
    from .parsers import cisco
    from .timeutil import now_dt
    cfg = _setup(args.config, False)
    cls = Classifier(cfg)
    total = unparsed = 0
    cats, rules, unk, sig, plat = Counter(), Counter(), Counter(), Counter(), Counter()
    for fn in args.files:
        op = gzip.open if fn.endswith(".gz") else open
        with op(fn, "rt", encoding="utf-8", errors="replace") as f:
            for line in f:
                ev = cisco.parse_line(line, now_dt())
                if not ev:
                    continue
                total += 1
                if ev.get("unparsed"):
                    unparsed += 1
                    continue
                ev = cls.classify(ev)
                cats[ev["category"]] += 1
                rules[ev["rule"]] += 1
                sig[ev["signal"]] += 1
                plat[ev.get("platform")] += 1
                if ev["rule"] is None and ev.get("code"):
                    unk[ev["code"]] += 1
    print(f"lines: {total:,}   unparsed: {unparsed:,}   classified: {total - unparsed - sum(unk.values()):,}")
    print("signal:", dict(sig))
    print("platform:", dict(plat))
    print("categories:", dict(cats.most_common()))
    print("\nTop unclassified codes (add rules for these):")
    for c, n in unk.most_common(30):
        print(f"  {n:8,}  {c}")


def cmd_generate(args):
    from .simulate import generate
    cfg = _setup(args.config, True)
    d = cfg["source"]["demo"]
    print(generate(d["directory"], int(d["history_days"]), int(d["lines_per_day"])))


def main(argv=None):
    p = argparse.ArgumentParser(prog="netsignal", description="Network Syslog Intelligence Dashboard")
    p.add_argument("--config", help="path to config.yaml")
    sub = p.add_subparsers(dest="cmd")
    r = sub.add_parser("run", help="run the dashboard (default)")
    for sp in (p, r):
        sp.add_argument("--demo", action="store_true", help="use SIMULATED data")
        sp.add_argument("--host")
        sp.add_argument("--port")
        sp.add_argument("--no-browser", action="store_true")
    sub.add_parser("test-connection", help="test read-only SSH/SFTP access")
    a = sub.add_parser("analyze", help="parser coverage report for log files")
    a.add_argument("files", nargs="+")
    sub.add_parser("generate-sample", help="create simulated data")
    args = p.parse_args(argv)
    {"test-connection": cmd_test, "analyze": cmd_analyze, "generate-sample": cmd_generate}.get(args.cmd, cmd_run)(args)


if __name__ == "__main__":
    main()
