// Command Center: situation brief, alert panels, findings, timeline, heatmap.
import { esc, icon, api, n, compact, sevBadge, fmtShort, ago, healthColor, emptyState, loading } from '../util.js';
import { state, go } from '../state.js';
import { rangeSeg, bindRange, findingList, bindFindings, openEvent } from '../components.js';
import { sparkline, timeline, heatmap, legend } from '../charts.js';

const SEV_COLOR = { critical: 'var(--s-critical)', major: 'var(--s-major)', warning: 'var(--s-warning)', low: 'var(--s-low)', info: 'var(--s-low)' };

export async function render(main) {
  let data = null, showRoutine = false;
  main.innerHTML = `<div class="page">${loading('Analysing syslog')}</div>`;

  async function load() {
    data = await api(`/api/overview?range=${state.range}`);
    draw();
  }

  function draw() {
    const d = data, now = state.now(), k = d.kpis;
    const sev = k.by_severity || {};
    const worst = sev.critical ? 'critical' : sev.major ? 'major' : sev.warning ? 'warning' : null;
    const other = d.cards.find(c => c.id === 'other');
    const briefC = worst ? SEV_COLOR[worst] : 'var(--s-good)';
    const sim = state.meta?.simulated ? `<div class="banner-sim">${icon('info', 'sm')}<span><b>Demo mode:</b> all data on this dashboard is <b>simulated</b> Cisco syslog modelled on your server's format. Configure <span class="mono">source.mode: ssh</span> in config.yaml to connect to the live syslog server.</span></div>` : '';
    main.innerHTML = `<div class="page">
      ${sim}
      <div class="ph"><div><h1>Command Center</h1><div class="sub">What happened, which devices are affected, and what to look at next.</div></div>
        <div class="grow"></div><span class="muted" id="updated">updated ${esc(fmtShort(now, now))}</span>${rangeSeg()}</div>

      <div class="grid">
        <div class="card brief c7" style="--brief-c:${briefC}">
          <h2>${worst ? icon('alert') : icon('check')} Situation brief</h2>
          <ul>${d.summary.map((s, i) => `<li class="${i === 0 ? 'top' : ''}">${linkify(s, d.findings)}</li>`).join('')}</ul>
        </div>
        <div class="c5"><div class="kpis">
          <div class="card kpi"><div class="l">Messages analysed</div><div class="v num">${compact(k.messages)}</div>
            <div class="s">${n(k.devices)} devices reporting</div></div>
          <div class="card kpi"><div class="l">Routine noise filtered</div><div class="v num">${k.noise_pct}%</div>
            <div class="s">${compact(k.routine)} routine · ${compact(k.significant)} warning+</div></div>
          <div class="card kpi"><div class="l">Findings</div><div class="v num">${n(k.findings)}</div>
            <div class="sevbar">${['critical', 'major', 'warning', 'low', 'info'].map(s => sev[s] ? `<span title="${sev[s]} ${s}" style="flex:${sev[s]};background:${SEV_COLOR[s]}"></span>` : '').join('')}</div>
            <div class="s">${['critical', 'major', 'warning'].map(s => `${sev[s] || 0} ${s}`).join(' · ')}</div></div>
          <div class="card kpi"><div class="l">Devices with findings</div><div class="v num">${n(k.devices_with_findings)}</div>
            <div class="s">of ${n(k.devices)} reporting</div></div>
        </div></div>
      </div>

      <div class="section-title">Troubleshooting panels <span class="line"></span><span style="text-transform:none;letter-spacing:0;font-weight:400">big number = warning-or-higher messages · click a panel to investigate${other && other.total ? ` · <a href="#/category/other">${n(other.total)} unclassified message(s)</a>` : ''}</span></div>
      <div class="cats" id="cats">${d.cards.filter(c => c.id !== 'other').map(c => card(c, now)).join('')}</div>

      <div class="grid" style="margin-top:16px">
        <div class="card c7"><div class="hd"><h3>Needs attention</h3><span class="grow"></span><a class="btn sm" href="#/findings">All ${n(k.findings)} findings ${icon('arrow', 'sm')}</a></div>
          <div class="bd" style="padding:6px 0 4px" id="flist">${findingList(d.findings.filter(f => ['critical', 'major', 'warning'].includes(f.severity)).slice(0, 7), now)}</div></div>
        <div class="c5" style="display:flex;flex-direction:column;gap:16px">
          <div class="card"><div class="hd"><h3>${icon('git', 'sm')} What changed</h3><span class="grow"></span><a class="btn sm" href="#/investigate?kind=config_change">All changes</a></div>
            <div class="bd">${changes(d.changes, now)}</div></div>
          <div class="card"><div class="hd"><h3>Lowest device health</h3><span class="grow"></span><a class="btn sm" href="#/devices">Devices</a></div>
            <div class="bd">${healthList(d.health)}</div></div>
        </div>
      </div>

      <div class="card" style="margin-top:16px"><div class="hd"><h3>Activity timeline</h3><span class="grow"></span>${legend(showRoutine ? ['critical', 'major', 'warning', 'info', 'routine'] : ['critical', 'major', 'warning', 'info'])}
        <label class="toggle ${showRoutine ? 'on' : ''}" id="tgRoutine"><span class="sw"></span>Include routine</label></div>
        <div class="bd"><div class="chart" id="tl"></div><div class="note">Drag across the chart to investigate a time slice.</div></div></div>

      <div class="card" style="margin-top:16px"><div class="hd"><h3>Device hotspots</h3><span class="muted" style="font-size:12px">warning+ messages per device over time · darker = more · badge = health score</span></div>
        <div class="bd" id="hm">${d.heatmap.hosts.length ? '' : emptyState('No warning-level activity in this window')}</div></div>
    </div>`;

    bindRange(main, () => load());
    bindFindings(main.querySelector('#flist'));
    main.querySelectorAll('[data-cat]').forEach(el => el.addEventListener('click', () => go(`#/category/${el.dataset.cat}`)));
    main.querySelectorAll('[data-latest]').forEach(el => el.addEventListener('click', ev => { ev.stopPropagation(); openEvent(+el.dataset.latest); }));
    main.querySelectorAll('[data-chg]').forEach(el => el.addEventListener('click', () => openEvent(+el.dataset.chg)));
    main.querySelector('#tgRoutine').addEventListener('click', () => { showRoutine = !showRoutine; draw(); });
    drawCharts();
  }

  function drawCharts() {
    const d = data, now = state.now();
    const sig = showRoutine ? ['critical', 'major', 'warning', 'info', 'routine'] : ['critical', 'major', 'warning', 'info'];
    const tl = main.querySelector('#tl');
    if (tl) timeline(tl, d.timeline, {
      signals: sig, height: 180, now,
      onSelect: (a, b) => go(`#/investigate?t0=${Math.floor(a)}&t1=${Math.ceil(b)}&signal_min=${showRoutine ? '' : 'info'}`),
    });
    const hm = main.querySelector('#hm');
    if (hm && d.heatmap.hosts.length) heatmap(hm, d.heatmap, {
      now, healthColor,
      onCell: (h, a, b) => go(`#/investigate?host=${h}&t0=${Math.floor(a)}&t1=${Math.ceil(b)}&signal_min=warning`),
      onHost: h => go(`#/device/${h}`),
    });
  }

  await load();
  const timer = setInterval(() => { if (!document.hidden) load().catch(() => {}); }, 20000);
  const onResize = () => data && drawCharts();
  window.addEventListener('resize', onResize);
  window.addEventListener('themechange', onResize);
  return () => { clearInterval(timer); window.removeEventListener('resize', onResize); window.removeEventListener('themechange', onResize); };
}

function card(c, now) {
  const fsev = ['critical', 'major', 'warning', 'low', 'info'];
  const chips = fsev.filter(s => c.findings[s]).map(s => sevBadge(s, `${c.findings[s]} ${s}`)).join('');
  const delta = c.significant - c.prev_significant;
  const pct = c.prev_significant ? Math.round(delta / c.prev_significant * 100) : null;
  const dl = c.prev_significant || c.significant ? `<span class="delta ${delta > 0 ? 'up' : delta < 0 ? 'down' : ''}" title="vs previous period (${c.prev_significant})">${delta > 0 ? '▲' : delta < 0 ? '▼' : '■'} ${pct === null ? 'new' : Math.abs(pct) + '%'}</span>` : '';
  const color = c.worst ? SEV_COLOR[c.worst] : 'transparent';
  const sparkColor = c.worst ? SEV_COLOR[c.worst] : 'var(--s-info)';
  const latest = c.latest ? `<div class="latest" data-latest="${c.latest.id}" title="${esc(c.latest.message)}"><b>${esc(fmtShort(c.latest.ts, now))}</b> ${esc(c.latest.host)} · ${esc(c.latest.message)}</div>`
    : `<div class="latest">${c.total ? `${n(c.total)} routine/info messages only` : 'No messages in this window'}</div>`;
  return `<div class="card cat ${c.findings_total ? '' : 'clear'}" style="--cat-c:${color}" data-cat="${esc(c.id)}" title="${esc(c.description)}">
    <div class="top"><div class="ic">${icon(c.icon)}</div><div class="nm">${esc(c.name)}</div></div>
    <div class="big"><span class="v num">${compact(c.significant)}</span>${dl}<span class="l">${c.devices ? `${c.devices} device${c.devices > 1 ? 's' : ''}` : ''}</span></div>
    ${sparkline(c.spark, { color: sparkColor, h: 30 })}
    <div class="fchips">${chips}</div>
    <div class="meta">${c.top_devices.slice(0, 2).map(t => `<span>${esc(t.host)} <b class="num">${t.n}</b></span>`).join('')}${c.routine ? `<span class="muted">${compact(c.routine)} routine hidden</span>` : ''}</div>
    ${latest}</div>`;
}

function changes(rows, now) {
  if (!rows.length) return '<div class="muted">No configuration changes logged in this window.</div>';
  return `<div class="mini">${rows.slice(0, 6).map(r => `<div class="row" data-chg="${r.id}" style="grid-template-columns:70px 130px 1fr">
    <span class="mono muted">${esc(fmtShort(r.ts, now))}</span><span>${esc(r.host)}</span>
    <span class="m">${esc(r.user ? r.user + ' · ' : '')}${esc(r.message)}</span></div>`).join('')}</div>`;
}

function healthList(rows) {
  if (!rows.length) return '<div class="muted">All devices healthy.</div>';
  return `<div style="display:flex;flex-direction:column;gap:6px">${rows.slice(0, 6).map(r => `
    <a href="#/device/${esc(r.host)}" style="display:grid;grid-template-columns:150px 1fr 34px;gap:10px;align-items:center;color:inherit;text-decoration:none">
      <span style="font-size:12.5px">${esc(r.host)}</span>
      <span style="height:6px;border-radius:3px;background:var(--surface-2)"><span style="display:block;height:100%;width:${r.score}%;background:${healthColor(r.score)};border-radius:3px"></span></span>
      <b class="num" style="font-size:12.5px;text-align:right">${r.score}</b></a>`).join('')}</div>`;
}

function linkify(text, findings) {
  let html = esc(text);
  for (const f of findings) {
    const t = esc(f.title);
    if (html.includes(t)) html = html.replace(t, `<a href="#/finding/${esc(f.id)}">${t}</a>`);
  }
  return html;
}
